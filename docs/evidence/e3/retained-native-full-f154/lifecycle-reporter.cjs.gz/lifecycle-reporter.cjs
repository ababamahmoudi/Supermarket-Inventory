const fs = require('node:fs');
const path = require('node:path');
function append(data) { fs.appendFileSync(process.env.NATIVE_LIFECYCLE_PATH, JSON.stringify({ utc: new Date().toISOString(), ...data }) + '\n'); }
function identity(test) { return { id: test.id, project: test.parent.project().name, file: path.relative(process.cwd(), test.location.file), titlePath: test.titlePath(), location: test.location }; }
class LifecycleReporter {
  onBegin(config, suite) { append({ type: 'begin', workers: config.workers, tests: suite.allTests().map(identity) }); }
  onTestBegin(test, result) { append({ type: 'test-begin', ...identity(test), workerIndex: result.workerIndex, retry: result.retry }); }
  onTestEnd(test, result) { append({ type: 'test-end', ...identity(test), expectedStatus: test.expectedStatus, status: result.status, retry: result.retry, duration: result.duration, annotations: test.annotations, errors: result.errors }); }
  onError(error) { append({ type: 'global-error', error }); }
  onEnd(result) { append({ type: 'end', result }); }
}
module.exports = LifecycleReporter;
