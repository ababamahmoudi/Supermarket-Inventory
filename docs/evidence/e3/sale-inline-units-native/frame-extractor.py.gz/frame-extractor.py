#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,zipfile,collections
proof=Path('/tmp/e3-sale-inline-units-original-files');out=proof/'release-frame-evidence';out.mkdir(exist_ok=True)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def decode(value):
 if not isinstance(value,dict):return value
 if 'o'in value:return{item['k']:decode(item['v'])for item in value['o']}
 if 'a'in value:return[decode(x)for x in value['a']]
 for key in ['s','n','b']:
  if key in value:return value[key]
 if value.get('v')=='null':return None
 raise ValueError(value)
life=[json.loads(x)for x in(proof/'phone-run-001/lifecycle.ndjson').read_text().splitlines()]
results=[]
for language in ['en','fa']:
 matches=[x for x in life if x['type']=='test-end'and x['titlePath'][-1]=='C8 actual cost-up posting, Keep with delivery hold, and End preserve invoice money and source ('+language+')']
 if not matches:continue
 assert len(matches)==1 and matches[0]['status']=='passed'
 folders=list((proof/'phone-run-001/native-output').glob('c8-sales-C8-actual-cost-up-*-nvoice-money-and-source-'+language+'--phone'));assert len(folders)==1
 trace=folders[0]/'trace.zip';trace_raw=trace.read_bytes();geometry_rows=[]
 with zipfile.ZipFile(trace)as z:
  for name in z.namelist():
   if not name.endswith('.trace'):continue
   rows=[json.loads(x)for x in z.read(name).decode().splitlines()];before={r['callId']:r for r in rows if r.get('type')=='before'}
   for row in rows:
    if row.get('type')=='after'and 'sale-delivery-release'in json.dumps(row.get('result',{})):
     geometry=decode(row['result']['value']);assert geometry['scene']=='sale-delivery-release'and geometry['language']==language and geometry['width']==geometry['actualWidth']==390 and geometry['failures']==[]
     assert all(x['lines']==1 for x in geometry['unitFragments']);start=before[row['callId']];page_ids={n.split('/')[1].rsplit('-',1)[0]for n in z.namelist()if n.startswith('screencast/')and n.endswith('.jpeg')};assert len(page_ids)==1;page_id=next(iter(page_ids))
     frames=sorted(n for n in z.namelist()if n.startswith('screencast/'+page_id+'-')and n.endswith('.jpeg'));assert frames
     frame_name=frames[-1];frame=z.read(frame_name)
     dest=out/('phone-'+language+'-release.jpeg')
     if dest.exists():assert dest.read_bytes()==frame
     else:dest.write_bytes(frame)
     rawrow=(json.dumps(row,ensure_ascii=False,separators=(',',':'))+'\n').encode();(out/('derived-original-'+language+'-geometry-trace-record.json')).write_bytes(rawrow)
     (out/('derived-'+language+'-geometry.json')).write_text(json.dumps(geometry,indent=2,ensure_ascii=False)+'\n')
     geometry_rows.append({'geometry':geometry,'page_id':page_id,'trace_event_file':name,'trace_event_call_id':row['callId'],'frame':str(dest),'frame_original_zip_path':frame_name,'frame_original_sha256':sha(frame),'frame_original_bytes':len(frame)})
  assert len(geometry_rows)==1
 results.append({'language':language,'source_commit':'431bdba29e25a3b53e3acc5d7ef8ad186150ab2b','native_test_title':matches[0]['titlePath'],'actual_status':'passed','retry':matches[0]['retry'],'trace':str(trace),'trace_sha256':sha(trace_raw),'trace_bytes':len(trace_raw),'frame_and_geometry':geometry_rows[0],'presentation':'Untouched JPEG screencast frame extracted from actual passing original phone trace, no crops, edits or synthesized content. It is the last captured frame for the page that produced actual release geometry.'})
p=out/'frame-provenance.json';p.write_text(json.dumps(results,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'languages':[x['language']for x in results],'provenance':str(p),'frames':[{k:x['frame_and_geometry'][k]for k in ['frame','frame_original_sha256','frame_original_zip_path']}for x in results]},ensure_ascii=False))
