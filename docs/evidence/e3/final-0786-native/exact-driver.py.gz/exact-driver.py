#!/usr/bin/env python3
"""Exact Git source → normal build → owned preview → original native/capture runs.

Preparation is read-only against the real repository. Only /tmp proof files are
written. Resume always uses the captured full SHA, even if Root advances E2/E3.
No source, test timeout, assertion, retry, authentication, storage or SDK override.
"""
from pathlib import Path, PurePosixPath
import argparse, collections, hashlib, json, os, re, shutil, signal, socket
import subprocess, sys, tarfile, time, urllib.parse, urllib.request

ALLOWED = ('prototype/', 'docs/', 'seed/', 'assets/')
FOLLOWUP_FILES = ['tests/c8-sales.spec.ts', 'tests/layout-proof-c6.spec.ts', 'tests/product-unit-order-c6.spec.ts', 'tests/c8-layout-proof.spec.ts']
FOLLOWUP_BASENAMES = {Path(name).name for name in FOLLOWUP_FILES}
NODE_DIR = '/workspace/scratch/node-install/node-v22.23.3-linux-x64/bin'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)

def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args])

def tracked(repo, commit):
    rows = []
    for entry in git(repo, 'ls-tree', '-rz', '--format=%(objectmode)%x09%(objecttype)%x09%(objectname)%x09%(path)', commit).split(b'\0'):
        if not entry:
            continue
        mode, kind, blob, raw = entry.decode().split('\t', 3)
        if raw == 'AGENTS.md' or raw.startswith(ALLOWED):
            if kind != 'blob' or mode not in ('100644', '100755'):
                raise RuntimeError('Unsupported tracked source entry: ' + raw)
            rows.append({'path': raw, 'mode': mode, 'blob': blob})
    if not rows or not any(x['path'] == 'prototype/scripts/capture-e1.mjs' for x in rows):
        raise RuntimeError('Expected committed E1 application and capture script')
    return rows

def source_pins(tree, rows):
    result = {}
    for row in rows:
        path = tree / row['path']
        if path.is_symlink() or not path.is_file():
            raise RuntimeError('Source missing or linked: ' + row['path'])
        data = path.read_bytes()
        actual = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        if actual != row['blob']:
            raise RuntimeError('Source differs from captured Git blob: ' + row['path'])
        result[row['path']] = {'sha256': sha(data), 'git_blob': actual, 'bytes': len(data)}
    return result

def dist_pins(path):
    if not (path / 'index.html').is_file():
        raise RuntimeError('Missing actual built index.html')
    result = {}
    for file in sorted(path.rglob('*')):
        if file.is_symlink():
            raise RuntimeError('Unexpected dist symlink')
        if file.is_file():
            result[str(file.relative_to(path))] = sha(file.read_bytes())
    return result

def freeze(args):
    proof, repo = args.proof_dir, args.repo
    if proof.exists():
        raise RuntimeError('Choose a new proof directory; immutable records are never overwritten')
    if not re.fullmatch('[a-f0-9]{40}', args.commit or ''):
        raise RuntimeError('Pass the exact full 40-character committed SHA')
    actual = git(repo, 'rev-parse', args.commit + '^{commit}').decode().strip()
    if actual != args.commit:
        raise RuntimeError('Commit resolution differs')
    rows = tracked(repo, actual)
    # Freeze only after Root commits the intended E1 implementation and helpers.
    if git(repo, 'rev-parse', 'HEAD').decode().strip() != actual:
        raise RuntimeError('Freeze must start at the explicitly approved current HEAD; resume may run after it advances')
    source_pins(repo, rows)
    proof.mkdir(parents=True)
    tree = proof / 'source'
    tree.mkdir()
    archive = proof / 'exact-source.tar'
    with archive.open('wb') as output:
        subprocess.run(['git', '-C', str(repo), 'archive', '--format=tar', actual, 'AGENTS.md', 'prototype', 'docs', 'seed', 'assets'], stdout=output, check=True)
    with tarfile.open(archive) as tar:
        for member in tar:
            name = PurePosixPath(member.name)
            if name.is_absolute() or '..' in name.parts:
                raise RuntimeError('Unsafe Git archive path')
            target = tree.joinpath(*name.parts)
            if member.isdir():
                target.mkdir(parents=True, exist_ok=True)
            elif member.isfile():
                target.parent.mkdir(parents=True, exist_ok=True)
                with tar.extractfile(member) as source, target.open('wb') as destination:
                    shutil.copyfileobj(source, destination)
                target.chmod(member.mode & 0o777)
            else:
                raise RuntimeError('Unexpected archive entry type: ' + member.name)
    pins = source_pins(tree, rows)
    dependencies = repo / 'prototype/node_modules'
    if not dependencies.is_dir():
        raise RuntimeError('Root stable dependencies must already be installed')
    (tree / 'prototype/node_modules').symlink_to(dependencies, target_is_directory=True)
    save(proof / 'source-pins.json', pins)
    data = {'commit': actual, 'git_repository': str(repo), 'source_root': str(tree), 'tracked_files': rows,
            'source_file_count': len(pins), 'source_fingerprint': sha(json.dumps(pins, sort_keys=True).encode()),
            'root_head_at_freeze': actual, 'node_dir': str(args.node_dir), 'dependencies': str(dependencies),
            'archive_sha256': sha(archive.read_bytes()), 'expected_native_tests': args.expected_tests,
            'source_scope': 'Exact committed prototype/docs/seed/assets/AGENTS.md; runtime outputs and the explicitly recorded private Playwright adapter are outside tracked Git source.'}
    save(proof / 'freeze.json', data)
    print(json.dumps({'frozen': actual, 'files': len(pins), 'proof': str(proof)}), flush=True)
    return data

def run(command, cwd, env, folder, label):
    folder.mkdir(parents=True, exist_ok=True)
    start = time.time()
    with (folder / (label + '.log')).open('w') as log:
        process = subprocess.Popen(command, cwd=cwd, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        save(folder / (label + '-running.json'), {'pid': process.pid, 'command': command, 'started_utc_epoch': start})
        interrupted = False
        try:
            code = process.wait()
        except BaseException:
            interrupted = True
            os.killpg(process.pid, signal.SIGINT)
            try:
                code = process.wait(timeout=20)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGTERM)
                code = process.wait(timeout=10)
            save(folder / (label + '-interrupted.json'), {'actual_exit_code': code, 'interrupted': True})
            raise
    result = {'command': command, 'actual_exit_code': code, 'seconds': time.time() - start, 'interrupted': interrupted}
    save(folder / (label + '-execution.json'), result)
    print(json.dumps({label: result}), flush=True)
    return result

def unique_run(proof, job):
    for index in range(1, 1000):
        path = proof / f'{job}-run-{index:03d}'
        try:
            path.mkdir()
            return path
        except FileExistsError:
            continue
    raise RuntimeError('Too many existing attempts')

def wait_preview(base, process):
    deadline = time.monotonic() + 30
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise RuntimeError('Owned preview exited before readiness')
        try:
            with urllib.request.urlopen(base, timeout=1) as response:
                if response.status == 200:
                    return
        except Exception:
            pass
        time.sleep(0.1)
    raise RuntimeError('Owned preview did not become ready within original 30-second webServer budget')

def http_pins(base, dist):
    actual = {}
    for name, expected in dist.items():
        with urllib.request.urlopen(base + '/' + urllib.parse.quote(name), timeout=10) as response:
            data = response.read()
            if response.status != 200 or sha(data) != expected:
                raise RuntimeError('Served production bytes differ: ' + name)
            actual[name] = {'sha256': sha(data), 'status': response.status}
    return actual

def native_outcomes(report):
    cases = []
    def walk(suites):
        for suite in suites:
            for spec in suite.get('specs', []):
                for test in spec.get('tests', []):
                    results = test.get('results', [])
                    last = results[-1] if results else None
                    status = last.get('status') if last else None
                    annotations = test.get('annotations', [])
                    explicit_skip = test.get('expectedStatus') == 'skipped' or any(x.get('type') in ('skip', 'fixme') for x in annotations)
                    if status == 'passed':
                        outcome = 'PASS'
                    elif status == 'skipped':
                        outcome = 'INTENTIONAL_SKIP' if explicit_skip else 'NOT_RUN'
                    elif status == 'interrupted':
                        outcome = 'INTERRUPTED'
                    elif status in ('failed', 'timedOut'):
                        outcome = 'FAIL'
                    else:
                        outcome = 'NOT_RUN'
                    cases.append({'id': spec.get('id'), 'title': spec['title'], 'file': spec.get('file'), 'project': test.get('projectName'),
                                  'outcome': outcome, 'actual_status': status, 'expected_status': test.get('expectedStatus'),
                                  'attempts': len(results), 'retry_numbers': [x.get('retry') for x in results], 'annotations': annotations})
            walk(suite.get('suites', []))
    walk(report.get('suites', []))
    return {'counts': dict(collections.Counter(case['outcome'] for case in cases)), 'total_discovered': len(cases), 'cases': cases,
            'original_stats': report.get('stats'), 'global_errors': report.get('errors', []),
            'configured_workers': report.get('config', {}).get('workers'),
            'configured_projects': [{key: p.get(key) for key in ['name', 'retries', 'timeout']} for p in report.get('config', {}).get('projects', [])]}


parser = argparse.ArgumentParser(description="One fresh exact Git source/build; FOUR ENTIRE original sales, layout oracle, unit-order and all-page C8 geometry files; original Desktop/Phone projects, two workers each. Bounded72-case proof, NOT full812.")
parser.add_argument('--proof-dir',type=Path,required=True)
parser.add_argument('--repo',type=Path,default=Path('/workspace/Supermarket-Inventory'))
parser.add_argument('--commit')
parser.add_argument('--freeze-only',action='store_true')
parser.add_argument('--build',action='store_true')
parser.add_argument('--project',choices=['desktop','phone'])
parser.add_argument('--port',type=int)
parser.add_argument('--node-dir',type=Path,default=Path(NODE_DIR))
parser.add_argument('--chromium',default='/usr/bin/chromium')
parser.add_argument('--expected-tests',type=int,default=72)
parser.add_argument('--nonsecure-origin',default='http://supermarket-lan-proof.invalid')
args=parser.parse_args();args.proof_dir=args.proof_dir.resolve();args.repo=args.repo.resolve()
if not str(args.proof_dir).startswith('/tmp/'):raise RuntimeError('Proof output must stay under /tmp')
if args.freeze_only:
    freeze(args)
    shutil.copy2('/tmp/e3-phone-project-e47/lifecycle-reporter.cjs',args.proof_dir/'lifecycle-reporter.cjs')
    save(args.proof_dir/'private-harness.json',{'runner_sha256':sha(Path(__file__).read_bytes()),'lifecycle_reporter_sha256':sha((args.proof_dir/'lifecycle-reporter.cjs').read_bytes()),'purpose':'Read-only lifecycle records in addition to unchanged native line+JSON reporters; no test mutation or budget change'})
    raise SystemExit(0)
save(args.proof_dir/('runtime-harness-'+('build' if args.build else (args.project or 'unspecified'))+'.json'), {'runner_path': str(Path(__file__)), 'runner_sha256':sha(Path(__file__).read_bytes()), 'frozen_original_harness': json.loads((args.proof_dir/'private-harness.json').read_text()), 'evidence_only_cli_override':'--trace=on; complete passing trace/frame evidence only, original assertions/budgets/retries/skips unchanged'})
frozen=json.loads((args.proof_dir/'freeze.json').read_text());tree=Path(frozen['source_root']);original=json.loads((args.proof_dir/'source-pins.json').read_text())
assert source_pins(tree,frozen['tracked_files'])==original
env=dict(os.environ);env['PATH']=frozen['node_dir']+':'+env['PATH'];env['PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH']=args.chromium
if env.get('CI'):raise RuntimeError('Original configured local retries=0 required')
if env.get('C6_NONSECURE_TEST_ORIGIN') or env.get('C6_LAN_BASE_URL'):raise RuntimeError('No inherited transport overrides')
if args.build:
    if (args.proof_dir/'build').exists():raise RuntimeError('Fresh build record exists; do not overwrite')
    result=run(['npm','run','build'],tree/'prototype',env,args.proof_dir/'build','normal-build')
    save(args.proof_dir/'build/source-guard.json',{'before':True,'after':source_pins(tree,frozen['tracked_files'])==original,'commit':frozen['commit'],'old_build_reused':False})
    if result['actual_exit_code']!=0:raise SystemExit(1)
    save(args.proof_dir/'dist-pins.json',dist_pins(tree/'prototype/dist'))
    print(json.dumps({'fresh_normal_build':frozen['commit'],'actual_exit_code':0,'dist_files':len(dist_pins(tree/'prototype/dist')),'old_build_reused':False}),flush=True)
    raise SystemExit(0)
if not args.project:parser.error('Choose freeze-only, build, or project')
project=args.project;expected_project=36;expected_skips=0
build_result=json.loads((args.proof_dir/'build/normal-build-execution.json').read_text());assert build_result['actual_exit_code']==0
dist=json.loads((args.proof_dir/'dist-pins.json').read_text());assert dist_pins(tree/'prototype/dist')==dist
port=args.port or (5195 if project=='desktop' else 5196)
with socket.socket()as s:s.bind(('127.0.0.1',port))
base=f'http://127.0.0.1:{port}';folder=unique_run(args.proof_dir,project)
adapter=tree/f'prototype/playwright.final-{project}-proof.config.ts';adapter.write_text('import base from "./playwright.config";\nexport default { ...base, use: { ...base.use, baseURL: '+json.dumps(base)+' }, webServer: undefined };\n')
save(folder/'runner-adapter.json',{'path':str(adapter),'sha256':sha(adapter.read_bytes()),'config_changes':['owned preview baseURL','webServerundefined; original normal Vite preview owned by runner'],'cli_project_filter':project,'budgets_assertions_retries_skips_unchanged':True,'evidence_only_cli_overrides':['--trace=on'],'runtime_runner_sha256':sha(Path(__file__).read_bytes()),'source_commit':frozen['commit'],'fresh_normal_build':True,'old_build_reused':False})
preview_log=(folder/'preview.log').open('w');preview=subprocess.Popen(['node','node_modules/vite/bin/vite.js','preview','--host','0.0.0.0','--port',str(port),'--strictPort'],cwd=tree/'prototype',env=env,stdout=preview_log,stderr=subprocess.STDOUT,start_new_session=True);save(folder/'owned-preview.json',{'pid':preview.pid,'base_url':base})
checks={};executions=[]
try:
    wait_preview(base,preview);checks['source_before']=source_pins(tree,frozen['tracked_files'])==original;checks['http_before']=http_pins(base,dist);save(folder/'guards-before.json',checks)
    discovery_env=dict(env);discovery_env['PLAYWRIGHT_JSON_OUTPUT_NAME']=str(folder/'discovery.json')
    discovery=run(['node','node_modules/@playwright/test/cli.js','test','--config',str(adapter),'--project='+project,*FOLLOWUP_FILES,'--list','--reporter=json'],tree/'prototype',discovery_env,folder,'discovery')
    assert discovery['actual_exit_code']==0
    def canonical(raw):
        cases=[]
        def walk(suites,titles):
            for suite in suites:
                chain=titles+[suite['title']]
                for spec in suite.get('specs',[]):
                    for test in spec.get('tests',[]):
                        key=[test['projectName'],spec['file'],chain+[spec['title']]]
                        cases.append({'key':json.dumps(key,ensure_ascii=False,separators=(',',':')),'project':test['projectName'],'file':spec['file'],'titles':chain+[spec['title']]})
                walk(suite.get('suites',[]),chain)
        walk(raw.get('suites',[]),[]);return cases
    discovered=canonical(json.loads((folder/'discovery.json').read_text()));original_expected=json.loads(Path('/tmp/e3-phone-project-e47/all-expected-cases.json').read_text())['cases'];original_keys={x['key']for x in original_expected if x['project']==project and x['file'] in FOLLOWUP_BASENAMES}
    assert len(discovered)==expected_project and {x['key']for x in discovered}==original_keys
    save(folder/'expected-cases.json',{'total':len(discovered),'cases':discovered,'exact_original_project_keys':True})
    native_env=dict(env);native_env['PLAYWRIGHT_JSON_OUTPUT_NAME']=str(folder/'playwright.json');native_env['C6_NONSECURE_TEST_ORIGIN']=args.nonsecure_origin
    origin=urllib.parse.urlparse(args.nonsecure_origin);assert origin.scheme=='http'and(origin.hostname or'').endswith('.invalid')
    reporter=args.proof_dir/'lifecycle-reporter.cjs';native_env['NATIVE_LIFECYCLE_PATH']=str(folder/'lifecycle.ndjson')
    save(folder/'private-reporter.json',{'path':str(reporter),'sha256':sha(reporter.read_bytes()),'purpose':'read-only lifecycle events only; no test mutation'})
    result=run(['node','node_modules/@playwright/test/cli.js','test','--config',str(adapter),'--project='+project,*FOLLOWUP_FILES,'--workers=2','--trace=on','--reporter=line,json,'+str(reporter),'--output',str(folder/'native-output')],tree/'prototype',native_env,folder,'native');executions.append(result)
    raw=json.loads((folder/'playwright.json').read_text());outcomes=native_outcomes(raw);actualkeys=canonical(raw);checks['case_keys_exact']=len(actualkeys)==expected_project and{x['key']for x in actualkeys}==original_keys
    skips=json.loads(Path('/tmp/e3-exact-project-combiner/expected-original-phone-skips.json').read_text())['cases'];expected_skip={(x['file'],x['titles'][-1]):x['annotations']for x in skips if x['project']==project and x['file'] in FOLLOWUP_BASENAMES};actual_skip={(x['file'],x['title']):[a for a in x['annotations']if a.get('type')in('skip','fixme')]for x in outcomes['cases']if x['outcome']=='INTENTIONAL_SKIP'};checks['skip_keys_reasons_exact']=actual_skip==expected_skip
    counts=outcomes['counts'];wanted={'PASS':expected_project-expected_skips}
    if expected_skips:wanted['INTENTIONAL_SKIP']=expected_skips
    checks['native_success']=result['actual_exit_code']==0 and outcomes['total_discovered']==expected_project and counts==wanted and not outcomes['global_errors']and outcomes['configured_workers']==2 and all(x['retries']==0 for x in outcomes['configured_projects'])and all(x['attempts']<=1 for x in outcomes['cases'])and checks['case_keys_exact']and checks['skip_keys_reasons_exact']
    save(folder/'native-outcomes.json',outcomes);save(folder/'canonical-case-keys.json',actualkeys)
finally:
    try:
        checks['source_after']=source_pins(tree,frozen['tracked_files'])==original;checks['dist_after']=dist_pins(tree/'prototype/dist')==dist;checks['http_after']=http_pins(base,dist)if preview.poll()is None else None;checks['http_unchanged']=checks.get('http_before')==checks.get('http_after')and checks.get('http_after')is not None
    except Exception as error:checks['guard_error']=repr(error)
    if preview.poll()is None:
        os.killpg(preview.pid,signal.SIGTERM)
        try:preview.wait(timeout=5)
        except subprocess.TimeoutExpired:os.killpg(preview.pid,signal.SIGKILL);preview.wait(timeout=5)
    preview_log.close();save(folder/'execution-result.json',{'commit':frozen['commit'],'project':project,'fresh_normal_build':True,'old_build_reused':False,'executions':executions,'checks':checks,'scope':'FOUR ENTIRE original files c8-sales.spec.ts, layout-proof-c6.spec.ts, product-unit-order-c6.spec.ts and c8-layout-proof.spec.ts;36 original case keys per project with stronger Persian compound assertions in existing cases, both projects72. Bounded committed-source shared formatter followup only, NEVER a new-source whole812 claim.'})
raise SystemExit(0 if all(checks.get(k)is True for k in('native_success','source_before','source_after','dist_after','http_unchanged'))else 1)
