from pathlib import Path
import json,subprocess,hashlib,os,time
r=Path('/workspace/Supermarket-Inventory');p=Path('/tmp/e3-postprint-diagnostic');env=os.environ.copy();env['PATH']='/workspace/scratch/node-install/node-v22.23.3-linux-x64/bin:'+env['PATH']
files=[x for x in subprocess.check_output(['git','ls-files'],cwd=r,text=True).splitlines() if x.startswith(('prototype/','seed/','assets/')) or x in ['AGENTS.md','docs/return-policy.md']]
pins=lambda:{x:hashlib.sha256((r/x).read_bytes()).hexdigest() for x in files}
before=pins();commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();cmd=['node','node_modules/vitest/vitest.mjs','run','--maxWorkers=2','--reporter=default','--reporter=json','--reporter=/tmp/e3-postprint-diagnostic/observer.mjs','--outputFile=/tmp/e3-postprint-diagnostic/app.json']
(p/'start.json').write_text(json.dumps({'commit':commit,'source':before,'command':cmd},indent=2)+'\n');start=time.time()
with (p/'app.log').open('w') as log:done=subprocess.run(cmd,cwd=r/'prototype',env=env,stdout=log,stderr=subprocess.STDOUT)
result={'commit':commit,'command':cmd,'exit_code':done.returncode,'seconds':time.time()-start,'source_unchanged':pins()==before};(p/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
