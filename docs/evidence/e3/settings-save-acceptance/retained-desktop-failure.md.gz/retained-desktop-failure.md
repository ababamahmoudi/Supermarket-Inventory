# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: settings.spec.ts >> divisors update live, survive refresh, and invalid money preserves valid rules
- Location: tests/settings.spec.ts:25:1

# Error details

```
Error: expect(locator).toHaveValue(expected) failed

Locator:  getByLabel('Cost divisor for Grocery', { exact: true })
Expected: "0.50"
Received: "0.65"
Timeout:  5000ms

Call log:
  - Expect "toHaveValue" getByLabel('Cost divisor for Grocery', { exact: true }) with timeout 5000ms
  - waiting for getByLabel('Cost divisor for Grocery', { exact: true })
    11 × locator resolved to <input dir="ltr" type="text" value="0.65" inputmode="decimal" id="divisor-grocery" aria-invalid="false" class="ui-input ui-number numeric control-narrow"/>
       - unexpected value "0.65"

```

```yaml
- textbox "Cost divisor for Grocery": "0.65"
```

# Test source

```ts
  1   | import { expect, test, type Page } from "@playwright/test";
  2   | import {
  3   |   chooseOption,
  4   |   signIn,
  5   |   visitPage,
  6   |   resetDemo,
  7   |   setLanguage,
  8   | } from "./helpers";
  9   | 
  10  | async function openSettings(page: Page) {
  11  |   await signIn(page, "Supervisor");
  12  |   await visitPage(page, "Settings");
  13  |   await page
  14  |     .getByRole("navigation", { name: "Settings groups" })
  15  |     .getByRole("button", { name: "Catalog", exact: true })
  16  |     .click();
  17  |   await expect(
  18  |     page.getByRole("heading", { name: "Pricing categories", exact: true }),
  19  |   ).toBeVisible();
  20  |   return page.locator(".card").filter({
  21  |     has: page.getByRole("heading", { name: "Price tester", exact: true }),
  22  |   });
  23  | }
  24  | 
  25  | test("divisors update live, survive refresh, and invalid money preserves valid rules", async ({
  26  |   page,
  27  | }) => {
  28  |   let sandbox = await openSettings(page);
  29  |   await expect(sandbox.getByText("$1.49", { exact: true })).toBeVisible();
  30  |   const divisor = page.getByLabel("Cost divisor for Grocery", { exact: true });
  31  |   await divisor.fill("0.50");
  32  |   await expect(sandbox.getByText("$1.99", { exact: true })).toBeVisible();
  33  |   await page.getByRole("button", { name: "Save changes", exact: true }).click();
  34  | 
  35  |   await page.reload();
  36  |   sandbox = page.locator(".card").filter({
  37  |     has: page.getByRole("heading", { name: "Price tester", exact: true }),
  38  |   });
  39  |   await expect(
  40  |     page.getByLabel("Cost divisor for Grocery", { exact: true }),
> 41  |   ).toHaveValue("0.50");
      |     ^ Error: expect(locator).toHaveValue(expected) failed
  42  |   await expect(sandbox.getByText("$1.99", { exact: true })).toBeVisible();
  43  |   await page.getByLabel("Cost divisor for Grocery", { exact: true }).fill("0");
  44  |   await expect(page.getByRole("alert")).toContainText(
  45  |     "Enter a divisor greater than zero.",
  46  |   );
  47  |   await expect(sandbox.getByText("$1.99", { exact: true })).toBeVisible();
  48  | 
  49  |   await page
  50  |     .getByLabel("Cost divisor for Grocery", { exact: true })
  51  |     .fill("0.65");
  52  |   const cost = page.getByLabel("Unit cost before tax", { exact: true });
  53  |   await cost.fill("-1");
  54  |   await expect(
  55  |     sandbox.getByText(
  56  |       "Enter a cost of zero or more, with no more than four decimal places.",
  57  |     ),
  58  |   ).toBeVisible();
  59  |   await expect(sandbox.locator(".price-display")).toHaveCount(0);
  60  |   await cost.fill("1.12345");
  61  |   await expect(sandbox.locator(".price-display")).toHaveCount(0);
  62  |   await cost.fill("1.12");
  63  |   await expect(sandbox.getByText("$1.49", { exact: true })).toBeVisible();
  64  |   await expect(sandbox.getByText("24.83%", { exact: true })).toBeVisible();
  65  |   await expect(
  66  |     sandbox.getByText("Below minimum margin", { exact: true }),
  67  |   ).toBeVisible();
  68  | });
  69  | 
  70  | test("Rice uses unrounded raw and the same result renders in Persian RTL", async ({
  71  |   page,
  72  | }) => {
  73  |   const sandbox = await openSettings(page);
  74  |   await chooseOption(
  75  |     page,
  76  |     page.getByLabel("Pricing category", { exact: true }),
  77  |     "rice",
  78  |     "Rice",
  79  |   );
  80  |   const cost = page.getByLabel("Unit cost before tax", { exact: true });
  81  |   await cost.fill("3.1920");
  82  |   await expect(sandbox.getByText("$3.99", { exact: true })).toBeVisible();
  83  |   await cost.fill("3.1921");
  84  |   await expect(sandbox.getByText("3.99", { exact: true })).toBeVisible();
  85  |   await expect(sandbox.getByText("$4.99", { exact: true })).toBeVisible();
  86  |   await setLanguage(page, "fa");
  87  |   await expect(page.locator("html")).toHaveAttribute("dir", "rtl");
  88  |   await expect(
  89  |     page.getByRole("heading", { name: "آزمایش قیمت", exact: true }),
  90  |   ).toBeVisible();
  91  |   await expect(page.getByText("$4.99", { exact: true })).toBeVisible();
  92  |   await expect(
  93  |     page.getByLabel("هزینه هر واحد پیش از مالیات", { exact: true }),
  94  |   ).toHaveAttribute("dir", "ltr");
  95  | });
  96  | 
  97  | test("Reset demo restores pricing rules, including an invalid field draft", async ({
  98  |   page,
  99  | }) => {
  100 |   await openSettings(page);
  101 |   await page
  102 |     .getByLabel("Cost divisor for Grocery", { exact: true })
  103 |     .fill("0.50");
  104 |   await page.getByLabel("Cost divisor for Grocery", { exact: true }).fill("-1");
  105 |   await resetDemo(page);
  106 |   await expect(
  107 |     page.getByLabel("Cost divisor for Grocery", { exact: true }),
  108 |   ).toHaveValue("0.65");
  109 |   await expect(page.getByText("$1.49", { exact: true })).toBeVisible();
  110 | });
  111 | 
```