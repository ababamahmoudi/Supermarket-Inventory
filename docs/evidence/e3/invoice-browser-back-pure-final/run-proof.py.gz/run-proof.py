from pathlib import Path
import argparse, gzip, hashlib, json, os, subprocess, tarfile, time

ROOT = Path('/workspace/Supermarket-Inventory')
BASE = Path('/tmp/final-pure-invoice-navigation')
COMMIT = 'f1545dfb4da4e0ea1a4059dcdd3aa1d59e231f76'
OLD = '8db82a74c9720b04c2e942f6bf0d7e4cd614c36a'
PRODUCTION = 'prototype/src/screens/Invoices.tsx'
FIXTURE = 'prototype/src/screens/Invoices.navigation.e1.test.tsx'

def sha(data): return hashlib.sha256(data).hexdigest()
def dump(path, value): path.write_text(json.dumps(value, indent=2) + '\n')
def git(*args): return subprocess.check_output(['git', '-C', str(ROOT), *args])

def prepare():
    BASE.mkdir(exist_ok=False)
    archive = BASE / 'exact-f154-source.tar'
    with archive.open('wb') as out:
        subprocess.run(['git', '-C', str(ROOT), 'archive', COMMIT], stdout=out, check=True)
    candidate = BASE / 'candidate'
    candidate.mkdir()
    with tarfile.open(archive) as tf: tf.extractall(candidate, filter='data')
    (candidate / 'prototype/node_modules').symlink_to(ROOT / 'prototype/node_modules', target_is_directory=True)
    final = git('show', f'{COMMIT}:{PRODUCTION}')
    old = git('show', f'{OLD}:{PRODUCTION}')
    assert (candidate / PRODUCTION).read_bytes() == final
    assert b'void resume(item);' in old
    assert final == old.replace(
        b'                            void resume(item);',
        b'                            // The route effect selects the protected workspace.\n'
        b'                            // Starting resume() here also navigated after its\n'
        b'                            // async command, which could undo browser Back.', 1)
    (BASE / 'old-production.tsx').write_bytes(old)
    (BASE / 'fixed-production.tsx').write_bytes(final)
    config = candidate / 'prototype/vitest-final-navigation-proof.config.ts'
    config.write_text('''import config from "./vite.config.ts";
export default {
  ...config,
  server: {
    ...config.server,
    fs: {
      ...config.server?.fs,
      allow: [
        ...(config.server?.fs?.allow ?? []),
        "/workspace/Supermarket-Inventory/prototype/node_modules",
      ],
    },
  },
};
''')
    tracked = git('ls-tree', '-rz', '--name-only', COMMIT).decode().split('\0')
    names = [name for name in tracked if name and (name.startswith(('prototype/', 'seed/', 'assets/')) or name.endswith('AGENTS.md') or name == 'docs/return-policy.md')]
    pins = {name: sha((candidate / name).read_bytes()) for name in names if (candidate / name).is_file()}
    dump(BASE / 'start.json', {
        'commit': COMMIT,
        'old_production_from': OLD,
        'archive_sha256': sha(archive.read_bytes()),
        'production_final_sha256': sha(final),
        'production_old_sha256': sha(old),
        'identical_final_fixture_sha256': sha((candidate / FIXTURE).read_bytes()),
        'runner_adapter': str(config.relative_to(candidate)),
        'runner_adapter_only_change': 'Append actual shared node_modules directory to Vite server.fs.allow; do not replace any production import, context, actor, permission, repository, command or transaction.',
        'pinned_inputs': pins,
    })
    print(json.dumps({'prepared': str(BASE), 'fixture_sha256': sha((candidate / FIXTURE).read_bytes()), 'pinned_inputs': len(pins)}), flush=True)

def run():
    candidate = BASE / 'candidate'
    start = json.loads((BASE / 'start.json').read_text())
    initial = start['pinned_inputs']
    env = dict(os.environ)
    env['PATH'] = '/workspace/scratch/node-install/node-v22.23.3-linux-x64/bin:' + env['PATH']
    rows = []
    for phase in ('old', 'fixed'):
        production = (BASE / f'{phase}-production.tsx').read_bytes()
        (candidate / PRODUCTION).write_bytes(production)
        expected = dict(initial, **{PRODUCTION: sha(production)})
        assert all(sha((candidate / name).read_bytes()) == digest for name, digest in expected.items())
        observer = BASE / f'{phase}-observer.mjs'
        observer.write_text('''import { writeFileSync } from 'node:fs';
const output = ''' + json.dumps(str(BASE / f'{phase}-global-errors.json')) + ''';
const save = value => writeFileSync(output, JSON.stringify(value, null, 2) + '\\n');
export default class ErrorObserver {
  onInit(ctx) {
    this.ctx = ctx;
    process.once('exit', code => save({phase:'process-exit',code,errors:this.ctx.state.getUnhandledErrors?.() ?? [],atRunEnd:this.result}));
  }
  onTestRunEnd(modules, errors, reason) {
    this.result={phase:'onTestRunEnd',reason,errors,moduleCount:modules.length};
    save(this.result);
  }
}
''')
        command = ['node', 'node_modules/vitest/vitest.mjs', 'run', '--config', 'vitest-final-navigation-proof.config.ts',
                   'src/screens/Invoices.navigation.e1.test.tsx', '--maxWorkers=1', '--reporter=default', '--reporter=json',
                   f'--reporter={observer}', f'--outputFile={BASE / (phase + ".json")}']
        when = time.time()
        with (BASE / f'{phase}.log').open('w') as out:
            result = subprocess.run(command, cwd=candidate / 'prototype', env=env, stdout=out, stderr=subprocess.STDOUT)
        unchanged = all(sha((candidate / name).read_bytes()) == digest for name, digest in expected.items())
        report = json.loads((BASE / f'{phase}.json').read_text())
        errors = json.loads((BASE / f'{phase}-global-errors.json').read_text())
        row = {'phase': phase, 'command': command, 'actual_exit_code': result.returncode, 'seconds': time.time() - when,
               'source_unchanged_during_phase': unchanged,
               'identical_final_fixture_sha256': sha((candidate / FIXTURE).read_bytes()),
               'production_sha256': sha((candidate / PRODUCTION).read_bytes()),
               'passed': report['numPassedTests'], 'failed': report['numFailedTests'], 'pending': report['numPendingTests'],
               'global_errors': errors['errors']}
        dump(BASE / f'{phase}-result.json', row)
        rows.append(row)
        print(json.dumps(row), flush=True)
    summary = {'final_code_commit': COMMIT, 'results': rows, 'root_unchanged': (ROOT / PRODUCTION).read_bytes() == (BASE / 'fixed-production.tsx').read_bytes() and (ROOT / FIXTURE).read_bytes() == (candidate / FIXTURE).read_bytes(),
               'claim': 'Identical final useLayoutEffect observer fixture with genuine protected Provider/IDB/command and actual history.back: old duplicate resume production fails; patched production passes. Bounded regression evidence, not final browser or full application result.'}
    dump(BASE / 'summary.json', summary)
    assert rows[0]['actual_exit_code'] == 1 and rows[0]['failed'] == 1 and rows[0]['passed'] == 0
    assert rows[1]['actual_exit_code'] == 0 and rows[1]['failed'] == 0 and rows[1]['passed'] == 1
    assert all(r['source_unchanged_during_phase'] and r['identical_final_fixture_sha256'] == start['identical_final_fixture_sha256'] and not r['global_errors'] for r in rows)
    assert summary['root_unchanged']

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--prepare', action='store_true')
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    if args.prepare: prepare()
    if args.run: run()
