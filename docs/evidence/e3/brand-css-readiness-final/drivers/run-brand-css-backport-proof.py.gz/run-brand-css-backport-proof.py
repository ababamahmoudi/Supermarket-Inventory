from pathlib import Path
import hashlib,json,os,subprocess,tarfile,time
ROOT=Path('/workspace/Supermarket-Inventory');BASE=Path('/tmp/brand-css-readiness-backports');BASE.mkdir(exist_ok=False);FILE='prototype/src/store.test.tsx';EXPECTED='acbb2ff78e964d5842a86da1fdcd4e7866d3a401decda5b100e2be4de2665dba';BRANCHES={'e1':'feat/prototype-e1-location-roles','e2':'feat/prototype-e2-price-updates'}
sha=lambda b:hashlib.sha256(b).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git','-C',str(ROOT),*args])
env=dict(os.environ);env['PATH']='/workspace/scratch/node-install/node-v22.23.3-linux-x64/bin:'+env['PATH'];all_results=[]
for stage,branch in BRANCHES.items():
 commit=git('rev-parse',branch).decode().strip();folder=BASE/stage;folder.mkdir();candidate=folder/'candidate';candidate.mkdir();archive=folder/'exact-branch-source.tar'
 with archive.open('wb') as out:subprocess.run(['git','-C',str(ROOT),'archive',commit],stdout=out,check=True)
 with tarfile.open(archive) as tf:tf.extractall(candidate,filter='data')
 (candidate/'prototype/node_modules').symlink_to(ROOT/'prototype/node_modules',target_is_directory=True)
 assert sha((candidate/FILE).read_bytes())==EXPECTED
 paths=[p for p in git('ls-tree','-rz','--name-only',commit).decode().split('\0') if p and (p.startswith(('prototype/','seed/','assets/')) or p.endswith('AGENTS.md') or p=='docs/return-policy.md')]
 def pins():return {p:sha((candidate/p).read_bytes()) for p in paths if (candidate/p).is_file()}
 before=pins();config=candidate/'prototype/vitest-brand-backport-proof.config.ts';config.write_text('''import config from "./vite.config.ts";
export default {
 ...config,
 server: {
  ...config.server,
  fs: {
   ...config.server?.fs,
   allow: [...(config.server?.fs?.allow ?? []), "/workspace/Supermarket-Inventory/prototype/node_modules"],
  },
 },
};
''')
 observer=folder/'observer.mjs';observer.write_text('''import {writeFileSync} from 'node:fs';
const output='''+json.dumps(str(folder/'global-errors.json'))+''';
const save=v=>writeFileSync(output,JSON.stringify(v,null,2)+'\\n');
export default class ErrorObserver {
 onInit(ctx){this.ctx=ctx;process.once('exit',code=>save({phase:'process-exit',code,errors:this.ctx.state.getUnhandledErrors?.()??[],atRunEnd:this.result}));}
 onTestRunEnd(modules,errors,reason){this.result={phase:'onTestRunEnd',reason,errors,moduleCount:modules.length};save(this.result);}
}
''')
 dump(folder/'start.json',{'stage':stage,'branch':branch,'commit':commit,'archive_sha256':sha(archive.read_bytes()),'source_pin_count':len(before),'source_pins':before,'source_overlay':[],'fixture_sha256':EXPECTED,'runner_adapter':'Append only actual shared dependency directory to Vite fs.allow for genuine PDF worker import; no source mock/replacement.','max_workers':1,'entire_test_file':FILE})
 commands=[('unit',['node','node_modules/vitest/vitest.mjs','run','--config','vitest-brand-backport-proof.config.ts','src/store.test.tsx','--maxWorkers=1','--reporter=default','--reporter=json','--reporter='+str(observer),'--outputFile='+str(folder/'unit.json')]),('eslint',['node','node_modules/eslint/bin/eslint.js','src/store.test.tsx','--max-warnings','0']),('prettier',['node','node_modules/prettier/bin/prettier.cjs','--check','src/store.test.tsx'])];checks=[]
 for name,command in commands:
  began=time.time()
  with (folder/f'{name}.log').open('w') as out:res=subprocess.run(command,cwd=candidate/'prototype',env=env,stdout=out,stderr=subprocess.STDOUT)
  row={'name':name,'command':command,'actual_exit_code':res.returncode,'seconds':time.time()-began,'source_unchanged':pins()==before};checks.append(row);print(json.dumps({'stage':stage,**row}),flush=True)
 report=json.loads((folder/'unit.json').read_text());errors=json.loads((folder/'global-errors.json').read_text());result={'stage':stage,'branch':branch,'commit':commit,'checks':checks,'source_pin_count':len(before),'unit_counts':{k:report[k] for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','success']},'global_errors':errors['errors'],'fixture_sha256':sha((candidate/FILE).read_bytes()),'no_source_overlay':True,'all_exact_color_assertions_unchanged':True,'default_waitFor_timeout_1000_unchanged':True,'show_helper_timeout_10000_unchanged':True,'vitest_case_timeout_30000_unchanged':True};dump(folder/'result.json',result);all_results.append(result)
 assert all(c['actual_exit_code']==0 and c['source_unchanged'] for c in checks)
 assert report['numPassedTests']==report['numTotalTests'] and report['numTotalTests']>0 and report['numFailedTests']==0 and report['numPendingTests']==0 and not errors['errors']
dump(BASE/'summary.json',{'scope':'Sequential E1 then E2 entire store.test.tsx on exact committed branch archives;1 total worker; no source overlay, branch switch or tracked edit','results':all_results});print(json.dumps({'complete':True,'results':[{'stage':r['stage'],'passed':r['unit_counts']['numPassedTests'],'global_errors':r['global_errors']} for r in all_results]}),flush=True)
