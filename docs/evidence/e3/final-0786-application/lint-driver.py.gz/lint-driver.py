from pathlib import Path
import subprocess,json,os,time,hashlib,sys
r=Path('/workspace/Supermarket-Inventory');p=Path('/tmp/e3-persian-final-'+sys.argv[1]);p.mkdir(exist_ok=False)
env=dict(os.environ);env['PATH']='/workspace/scratch/node-install/node-v22.23.3-linux-x64/bin:'+env['PATH']
old=json.loads(Path('/tmp/e3-final-full-application-v2/start.json').read_text()); names=list(old['source']); old['commit']='0786ea262b6ebdf573cd02f2b56479952633ee21'; old['source']={n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in names}
pins=lambda:{n:hashlib.sha256((r/n).read_bytes()).hexdigest()for n in names}
assert pins()==old['source']; assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==old['commit']
cmd= {'sdk':['npm','run','test:sdk','--','--maxWorkers=2','--reporter=default','--reporter=json','--outputFile='+str(p/'sdk.json')],'lint':['npm','run','lint']}[sys.argv[1]]
(p/'start.json').write_text(json.dumps({'commit':old['commit'],'command':cmd,'source':old['source']},indent=2)+'\n')
t=time.time()
with (p/'raw.log').open('w') as log:
 done=subprocess.run(cmd,cwd=r/'prototype',env=env,stdout=log,stderr=subprocess.STDOUT)
result={'commit':old['commit'],'command':cmd,'actual_exit_code':done.returncode,'seconds':time.time()-t,'source_unchanged':pins()==old['source']}
(p/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
raise SystemExit(0 if result['actual_exit_code']==0 and result['source_unchanged'] else 1)
