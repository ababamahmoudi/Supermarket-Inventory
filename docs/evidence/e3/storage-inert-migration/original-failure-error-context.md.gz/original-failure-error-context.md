# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: storage-c6.spec.ts >> C6 migrates a near-full 5MiB legacy text store with verified raw backups and no lost source bytes
- Location: tests/storage-c6.spec.ts:860:1

# Error details

```
TypeError: Cannot read properties of undefined (reading 'file_data')
```

# Page snapshot

```yaml
- generic [ref=f2e3]:
  - link "Skip to content" [ref=f2e4] [cursor=pointer]:
    - /url: "#main-content"
  - complementary "Main menu" [ref=f2e5]:
    - generic [ref=f2e6]:
      - img "Super Arzon" [ref=f2e9]
      - generic [ref=f2e10]: Super Arzon
    - navigation "Pages" [ref=f2e11]:
      - button "Daily" [ref=f2e13] [cursor=pointer]
      - button "Catalog" [ref=f2e18] [cursor=pointer]
      - generic [ref=f2e22]:
        - button "Manager" [expanded] [ref=f2e23] [cursor=pointer]
        - generic [ref=f2e27]:
          - link "Dashboard" [ref=f2e28] [cursor=pointer]:
            - /url: "#dashboard"
          - link "Approvals" [ref=f2e35] [cursor=pointer]:
            - /url: "#approvals"
            - generic [ref=f2e40]: "3"
          - link "Alerts" [ref=f2e41] [cursor=pointer]:
            - /url: "#alerts"
            - generic [ref=f2e46]: "3"
          - link "Payables" [ref=f2e47] [cursor=pointer]:
            - /url: "#payables"
          - link "Orders" [ref=f2e51] [cursor=pointer]:
            - /url: "#orders"
      - button "Admin" [ref=f2e59] [cursor=pointer]
    - button "User menu" [ref=f2e64] [cursor=pointer]:
      - generic [ref=f2e65]:
        - generic [aria-hidden] [ref=f2e66]: DM
        - generic [ref=f2e67]:
          - strong [ref=f2e68]: Demo Manager
          - generic [ref=f2e69]: Manager
  - generic [ref=f2e70]:
    - banner [ref=f2e71]:
      - button "Collapse sidebar" [expanded] [ref=f2e72] [cursor=pointer]
      - navigation "Breadcrumbs" [ref=f2e76]:
        - link "North York" [ref=f2e77] [cursor=pointer]:
          - /url: "#dashboard"
        - link "Dashboard" [ref=f2e80] [cursor=pointer]:
          - /url: "#dashboard"
      - search [ref=f2e81]:
        - textbox "Search all products" [ref=f2e85]:
          - /placeholder: Search products
        - generic [aria-hidden] [ref=f2e86]: /
      - combobox "Location" [ref=f2e87] [cursor=pointer]:
        - generic [ref=f2e92]: North York
      - button "Switch to Persian" [ref=f2e95] [cursor=pointer]: فا
      - button "Switch to dark theme" [ref=f2e96] [cursor=pointer]
      - button "Comfortable text size" [ref=f2e99] [cursor=pointer]:
        - generic [aria-hidden] [ref=f2e100]: Aa
      - button "Notifications, 5 unread" [ref=f2e101] [cursor=pointer]:
        - generic [ref=f2e102]: "5"
      - button "Demo" [ref=f2e107] [cursor=pointer]
    - main [ref=f2e110]:
      - generic [ref=f2e111]:
        - generic [ref=f2e112]:
          - heading "Manager dashboard" [level=1] [ref=f2e113]
          - paragraph [ref=f2e114]: Your branch priorities, approvals, and recent activity.
        - button "Review approvals" [ref=f2e116] [cursor=pointer]
      - generic [ref=f2e117]:
        - generic [ref=f2e118]:
          - generic [ref=f2e119]:
            - 'button "Approvals waiting: 3" [ref=f2e120] [cursor=pointer]':
              - generic [ref=f2e121]: Approvals waiting
              - strong [ref=f2e127]: "3"
              - generic "1 price change · 1 new product" [ref=f2e128]
            - 'button "Open alerts: 3" [ref=f2e131] [cursor=pointer]':
              - generic [ref=f2e132]: Open alerts
              - strong [ref=f2e137]: "3"
              - generic "0 lower prices · 1 conflict" [ref=f2e138]
            - 'button "Open shorts: 0" [ref=f2e141] [cursor=pointer]':
              - generic [ref=f2e142]: Open shorts
              - strong [ref=f2e148]: "0"
              - generic "Items waiting for delivery" [ref=f2e149]
            - 'button "Expiring soon: 2" [ref=f2e152] [cursor=pointer]':
              - generic [ref=f2e153]: Expiring soon
              - strong [ref=f2e159]: "2"
              - generic "Within each product's reminder window" [ref=f2e160]
          - generic [ref=f2e163]:
            - generic [ref=f2e164]:
              - heading "Approvals queue" [level=2] [ref=f2e165]
              - generic [ref=f2e166]:
                - generic [ref=f2e167]:
                  - generic [ref=f2e168]:
                    - heading "Sunflower Oil 1.8 L روغن آفتابگردان ۱٫۸ لیتری" [level=3] [ref=f2e169]:
                      - generic [ref=f2e170]:
                        - strong [ref=f2e171]:
                          - generic [ref=f2e172]:
                            - text: Sunflower Oil
                            - generic [ref=f2e173]: 1.8 L
                        - generic [ref=f2e175]:
                          - text: روغن آفتابگردان
                          - generic [ref=f2e176]: ۱٫۸ لیتری
                    - generic [ref=f2e177]: Sale request
                  - generic [ref=f2e178]:
                    - strong [ref=f2e179]: $7.99
                    - generic [ref=f2e180]: North York
                    - generic [ref=f2e181]: 2026-10-15 – 2026-10-28
                  - paragraph [ref=f2e182]: "Requested by: Demo North York Floor Worker · Why? slow seller"
                  - paragraph [ref=f2e183]:
                    - text: Margin at this price
                    - generic [ref=f2e184]: 24%
                  - generic [ref=f2e185]:
                    - paragraph [ref=f2e186]: This price is below the minimum margin.
                    - checkbox "Use this price anyway" [ref=f2e187] [cursor=pointer]
                  - generic [ref=f2e190]:
                    - button "Approve" [ref=f2e191] [cursor=pointer]
                    - button "Change and approve" [ref=f2e192] [cursor=pointer]
                    - button "Reject" [ref=f2e193] [cursor=pointer]
                - generic [ref=f2e194]:
                  - generic [ref=f2e195]:
                    - generic [ref=f2e196]:
                      - strong [ref=f2e197]:
                        - generic [ref=f2e198]:
                          - text: Lavash Bread
                          - generic [ref=f2e199]: 500 g
                      - generic [ref=f2e201]:
                        - text: نان لواش
                        - generic [ref=f2e202]: ۵۰۰ گرمی
                    - generic [ref=f2e203]: "0006"
                  - generic [ref=f2e204]: Price change
                  - generic [ref=f2e205]:
                    - generic [ref=f2e206]:
                      - text: Old
                      - generic [ref=f2e207]: $1.99
                    - generic [ref=f2e208]:
                      - text: New
                      - generic [ref=f2e209]: $2.99
                  - generic [ref=f2e210]: North York
                  - generic [ref=f2e211]:
                    - button "Approve" [ref=f2e212] [cursor=pointer]
                    - button "More" [ref=f2e213] [cursor=pointer]
                - generic [ref=f2e219]:
                  - generic [ref=f2e220]:
                    - generic [ref=f2e221]:
                      - strong [ref=f2e222]:
                        - generic [ref=f2e223]:
                          - text: Dried Barberries
                          - generic [ref=f2e224]: 100 g
                      - generic [ref=f2e226]:
                        - text: زرشک خشک
                        - generic [ref=f2e227]: ۱۰۰ گرمی
                    - generic [ref=f2e228]: "0015"
                  - generic [ref=f2e229]: New product
                  - generic [ref=f2e230]:
                    - generic [ref=f2e231]:
                      - text: Old
                      - generic [ref=f2e232]: —
                    - generic [ref=f2e233]:
                      - text: New
                      - generic [ref=f2e234]: $5.49
                  - generic [ref=f2e235]: North York
                  - generic [ref=f2e236]:
                    - button "Approve" [ref=f2e237] [cursor=pointer]
                    - button "More" [ref=f2e238] [cursor=pointer]
            - generic [ref=f2e244]:
              - heading "Alerts" [level=2] [ref=f2e245]
              - generic [ref=f2e246]:
                - generic [ref=f2e247]:
                  - generic [ref=f2e248]:
                    - strong [ref=f2e249]:
                      - generic [ref=f2e251]:
                        - text: Black Tea
                        - generic [ref=f2e252]: 450 g
                    - generic [ref=f2e253]: All branches
                  - generic [ref=f2e254]: Conflict
                  - button "Review" [ref=f2e257] [cursor=pointer]
                - generic [ref=f2e260]:
                  - generic [ref=f2e261]:
                    - strong [ref=f2e262]:
                      - generic [ref=f2e264]:
                        - text: Lavash Bread
                        - generic [ref=f2e265]: 500 g
                    - generic [ref=f2e266]: North York
                  - generic [ref=f2e267]: Date tracking
                  - button "Review" [ref=f2e270] [cursor=pointer]
                - generic [ref=f2e273]:
                  - generic [ref=f2e274]:
                    - strong [ref=f2e275]:
                      - generic [ref=f2e277]:
                        - text: Sour Cherry Juice
                        - generic [ref=f2e278]: 1 L
                    - generic [ref=f2e279]: North York
                  - generic [ref=f2e280]: Date tracking
                  - button "Review" [ref=f2e283] [cursor=pointer]
          - generic [ref=f2e286]:
            - generic [ref=f2e287]:
              - heading "Recent invoices" [level=2] [ref=f2e288]
              - table [ref=f2e290]:
                - rowgroup [ref=f2e295]:
                  - row [ref=f2e296]:
                    - columnheader "Invoice" [ref=f2e297]
                    - columnheader "Status" [ref=f2e298]
                    - columnheader "Action" [ref=f2e299]
                - rowgroup [ref=f2e300]:
                  - row [ref=f2e301] [cursor=pointer]:
                    - cell "FV-20390" [ref=f2e302]
                    - cell "Posted" [ref=f2e304]
                    - cell [ref=f2e307]:
                      - generic [ref=f2e308]:
                        - link "View" [ref=f2e309]:
                          - /url: "#invoices?id=a2-fixture%3AFV-20390"
                        - button "Show details" [ref=f2e312]
                  - row [ref=f2e315] [cursor=pointer]:
                    - cell "GG-11879" [ref=f2e316]
                    - cell "Posted" [ref=f2e318]
                    - cell [ref=f2e321]:
                      - generic [ref=f2e322]:
                        - link "View" [ref=f2e323]:
                          - /url: "#invoices?id=a2-fixture%3AGG-11879"
                        - button "Show details" [ref=f2e326]
                  - row [ref=f2e329] [cursor=pointer]:
                    - cell "SB-7862" [ref=f2e330]
                    - cell "Posted" [ref=f2e332]
                    - cell [ref=f2e335]:
                      - generic [ref=f2e336]:
                        - link "View" [ref=f2e337]:
                          - /url: "#invoices?id=a2-fixture%3ASB-7862"
                        - button "Show details" [ref=f2e340]
                  - row [ref=f2e343] [cursor=pointer]:
                    - cell "SB-7848" [ref=f2e344]
                    - cell "Posted" [ref=f2e346]
                    - cell [ref=f2e349]:
                      - generic [ref=f2e350]:
                        - link "View" [ref=f2e351]:
                          - /url: "#invoices?id=a2-fixture%3ASB-7848"
                        - button "Show details" [ref=f2e354]
                  - row [ref=f2e357] [cursor=pointer]:
                    - cell "HW-4910" [ref=f2e358]
                    - cell "Posted" [ref=f2e360]
                    - cell [ref=f2e363]:
                      - generic [ref=f2e364]:
                        - link "View" [ref=f2e365]:
                          - /url: "#invoices?id=a2-fixture%3AHW-4910"
                        - button "Show details" [ref=f2e368]
            - generic [ref=f2e371]:
              - generic [ref=f2e372]:
                - heading "Returns" [level=2] [ref=f2e373]
                - button "View all returns" [ref=f2e374] [cursor=pointer]
              - generic [ref=f2e377]:
                - generic [ref=f2e378] [cursor=pointer]:
                  - generic [ref=f2e379]:
                    - strong [ref=f2e380]: Fresh Valley Foods
                    - generic [ref=f2e381]:
                      - text: North York ·
                      - generic [ref=f2e384]:
                        - text: Sour Cherry Juice
                        - generic [ref=f2e385]: 1 L
                  - generic [ref=f2e386]: Open
                  - link "View" [ref=f2e389]:
                    - /url: "#return?id=demo-return-1"
                - generic [ref=f2e392] [cursor=pointer]:
                  - generic [ref=f2e393]:
                    - strong [ref=f2e394]: Golden Grain Distributors
                    - generic [ref=f2e395]:
                      - text: North York ·
                      - generic [ref=f2e398]:
                        - text: Basmati Rice
                        - generic [ref=f2e399]: 4.5 kg
                  - generic [ref=f2e400]: Partially resolved
                  - link "View" [ref=f2e403]:
                    - /url: "#return?id=demo-return-2"
          - generic [ref=f2e406]:
            - heading "Supplier balances" [level=2] [ref=f2e407]
            - table [ref=f2e409]:
              - rowgroup [ref=f2e416]:
                - row [ref=f2e417]:
                  - columnheader "Supplier" [ref=f2e418]
                  - columnheader "Balance" [ref=f2e419]
                  - columnheader "Open invoices" [ref=f2e420]
                  - columnheader "Overdue" [ref=f2e421]
                  - columnheader "Action" [ref=f2e422]
              - rowgroup [ref=f2e423]:
                - row [ref=f2e424] [cursor=pointer]:
                  - cell "HomeWare Imports" [ref=f2e425]
                  - cell "$1,260.00" [ref=f2e426]
                  - cell "1" [ref=f2e427]
                  - cell "$0.00" [ref=f2e428]
                  - cell [ref=f2e429]:
                    - link "View" [ref=f2e430]:
                      - /url: "#payables"
                - row [ref=f2e433] [cursor=pointer]:
                  - cell "Golden Grain Distributors" [ref=f2e434]
                  - cell "$842.10" [ref=f2e435]
                  - cell "2" [ref=f2e436]
                  - cell "$210.00" [ref=f2e437]
                  - cell [ref=f2e438]:
                    - link "View" [ref=f2e439]:
                      - /url: "#payables"
                - row [ref=f2e442] [cursor=pointer]:
                  - cell "Fresh Valley Foods" [ref=f2e443]
                  - cell "$169.79" [ref=f2e444]
                  - cell "1" [ref=f2e445]
                  - cell "$0.00" [ref=f2e446]
                  - cell [ref=f2e447]:
                    - link "View" [ref=f2e448]:
                      - /url: "#payables"
                - row [ref=f2e451] [cursor=pointer]:
                  - cell "Sunrise Beverages" [ref=f2e452]
                  - cell "$96.40" [ref=f2e453]
                  - cell "1" [ref=f2e454]
                  - cell "$96.40" [ref=f2e455]
                  - cell [ref=f2e456]:
                    - link "View" [ref=f2e457]:
                      - /url: "#payables"
                - row [ref=f2e460] [cursor=pointer]:
                  - cell "Corner Spice Co." [ref=f2e461]
                  - cell "$0.00" [ref=f2e462]
                  - cell "0" [ref=f2e463]
                  - cell "$0.00" [ref=f2e464]
                  - cell [ref=f2e465]:
                    - link "View" [ref=f2e466]:
                      - /url: "#payables"
          - generic [ref=f2e469]:
            - generic [ref=f2e470]:
              - heading "Purchases by supplier, this month" [level=2] [ref=f2e471]
              - list [ref=f2e472]:
                - listitem [ref=f2e473]:
                  - generic [ref=f2e474]:
                    - generic [ref=f2e475]: Golden Grain Distributors
                    - generic [ref=f2e476]: $636.00
                - listitem [ref=f2e479]:
                  - generic [ref=f2e480]:
                    - generic [ref=f2e481]: Fresh Valley Foods
                    - generic [ref=f2e482]: $181.22
                - listitem [ref=f2e485]:
                  - generic [ref=f2e486]:
                    - generic [ref=f2e487]: Sunrise Beverages
                    - generic [ref=f2e488]: $133.59
              - paragraph [ref=f2e491]: Net purchases · CAD
            - generic [ref=f2e492]:
              - heading "Purchases, last 8 weeks" [level=2] [ref=f2e493]
              - img "Net purchases by week" [ref=f2e495]:
                - 'generic "2026-08-21 – 2026-08-27: $25.20" [ref=f2e498]'
                - 'generic "2026-08-28 – 2026-09-03: $0.00" [ref=f2e499]'
                - 'generic "2026-09-04 – 2026-09-10: $368.00" [ref=f2e500]'
                - 'generic "2026-09-11 – 2026-09-17: $0.00" [ref=f2e501]'
                - 'generic "2026-09-18 – 2026-09-24: $1,332.78" [ref=f2e502]'
                - 'generic "2026-09-25 – 2026-10-01: $0.00" [ref=f2e503]'
                - 'generic "2026-10-02 – 2026-10-08: $133.59" [ref=f2e504]'
                - 'generic "2026-10-09 – 2026-10-15: $817.22" [ref=f2e505]'
              - generic [ref=f2e506]:
                - generic [ref=f2e507]: 2026-08-21
                - generic [ref=f2e508]: 2026-09-04
                - generic [ref=f2e509]: 2026-09-18
                - generic [ref=f2e510]: 2026-10-09
              - paragraph [ref=f2e511]: Net purchases · CAD
          - generic [ref=f2e512]:
            - generic [ref=f2e513]:
              - heading "Arrived this week" [level=2] [ref=f2e514]
              - generic [ref=f2e515] [cursor=pointer]:
                - generic [ref=f2e516]:
                  - strong [ref=f2e517]:
                    - generic [ref=f2e518]:
                      - strong [ref=f2e519]:
                        - generic [ref=f2e520]:
                          - text: Canned Fava Beans
                          - generic [ref=f2e521]: 400 g
                      - generic [ref=f2e523]:
                        - text: باقالا کنسرو شده
                        - generic [ref=f2e524]: ۴۰۰ گرمی
                  - generic [ref=f2e525]:
                    - text: North York · 2026-10-14 ·
                    - generic [ref=f2e526]: FV-20390
                - generic [ref=f2e527]: 24 units
                - link "View" [ref=f2e530]:
                  - /url: "#received?product=0002"
              - generic [ref=f2e533] [cursor=pointer]:
                - generic [ref=f2e534]:
                  - strong [ref=f2e535]:
                    - generic [ref=f2e536]:
                      - strong [ref=f2e537]:
                        - generic [ref=f2e538]:
                          - text: Ground Sumac
                          - generic [ref=f2e539]: 100 g
                      - generic [ref=f2e541]:
                        - text: سماق
                        - generic [ref=f2e542]: ۱۰۰ گرمی
                  - generic [ref=f2e543]:
                    - text: North York · 2026-10-14 ·
                    - generic [ref=f2e544]: FV-20390
                - generic [ref=f2e545]: 12 units
                - link "View" [ref=f2e548]:
                  - /url: "#received?product=0005"
              - generic [ref=f2e551] [cursor=pointer]:
                - generic [ref=f2e552]:
                  - strong [ref=f2e553]:
                    - generic [ref=f2e554]:
                      - strong [ref=f2e555]:
                        - generic [ref=f2e556]:
                          - text: Lavash Bread
                          - generic [ref=f2e557]: 500 g
                      - generic [ref=f2e559]:
                        - text: نان لواش
                        - generic [ref=f2e560]: ۵۰۰ گرمی
                  - generic [ref=f2e561]:
                    - text: North York · 2026-10-14 ·
                    - generic [ref=f2e562]: FV-20390
                - generic [ref=f2e563]: 20 units
                - link "View" [ref=f2e566]:
                  - /url: "#received?product=0006"
              - generic [ref=f2e569] [cursor=pointer]:
                - generic [ref=f2e570]:
                  - strong [ref=f2e571]:
                    - generic [ref=f2e572]:
                      - strong [ref=f2e573]:
                        - generic [ref=f2e574]:
                          - text: Sour Cherry Juice
                          - generic [ref=f2e575]: 1 L
                      - generic [ref=f2e577]:
                        - text: آب آلبالو
                        - generic [ref=f2e578]: ۱ لیتری
                  - generic [ref=f2e579]:
                    - text: North York · 2026-10-14 ·
                    - generic [ref=f2e580]: FV-20390
                - generic [ref=f2e581]: 36 units
                - link "View" [ref=f2e584]:
                  - /url: "#received?product=0003"
              - generic [ref=f2e587] [cursor=pointer]:
                - generic [ref=f2e588]:
                  - strong [ref=f2e589]:
                    - generic [ref=f2e590]:
                      - strong [ref=f2e591]:
                        - generic [ref=f2e592]:
                          - text: Dried Barberries
                          - generic [ref=f2e593]: 100 g
                      - generic [ref=f2e595]:
                        - text: زرشک خشک
                        - generic [ref=f2e596]: ۱۰۰ گرمی
                  - generic [ref=f2e597]:
                    - text: North York · 2026-10-14 ·
                    - generic [ref=f2e598]: FV-20390
                - generic [ref=f2e599]: 6 units
                - link "View" [ref=f2e602]:
                  - /url: "#received?product=0015"
              - generic [ref=f2e605] [cursor=pointer]:
                - generic [ref=f2e606]:
                  - strong [ref=f2e607]:
                    - generic [ref=f2e608]:
                      - strong [ref=f2e609]:
                        - generic [ref=f2e610]:
                          - text: Potato Chips
                          - generic [ref=f2e611]: 150 g
                      - generic [ref=f2e613]:
                        - text: چیپس سیب‌زمینی
                        - generic [ref=f2e614]: ۱۵۰ گرمی
                  - generic [ref=f2e615]:
                    - text: North York · 2026-10-14 ·
                    - generic [ref=f2e616]: FV-20390
                - generic [ref=f2e617]: 12 units
                - link "View" [ref=f2e620]:
                  - /url: "#received?product=0009"
            - generic [ref=f2e623]:
              - heading "Price changes this week" [level=2] [ref=f2e624]
              - generic [ref=f2e625] [cursor=pointer]:
                - generic [ref=f2e626]:
                  - strong [ref=f2e627]:
                    - generic [ref=f2e629]:
                      - text: Black Tea
                      - generic [ref=f2e630]: 450 g
                  - generic [ref=f2e631]: Demo Supervisor · North York · 2026-10-14 · $6.49
                - generic [ref=f2e632]: Approved
                - link "View" [ref=f2e635]:
                  - /url: "#product?code=0004"
              - generic [ref=f2e638] [cursor=pointer]:
                - generic [ref=f2e639]:
                  - strong [ref=f2e640]:
                    - generic [ref=f2e642]:
                      - text: Dried Red Kidney Beans
                      - generic [ref=f2e643]: 900 g
                  - generic [ref=f2e644]: Demo Supervisor · North York · 2026-10-13 · $3.99
                - generic [ref=f2e645]: Approved
                - link "View" [ref=f2e648]:
                  - /url: "#product?code=0007"
        - complementary "Notes and activity" [ref=f2e651]:
          - generic [ref=f2e652]:
            - generic [ref=f2e653]:
              - heading "Price updates to apply" [level=2] [ref=f2e654]
              - button "View all 0" [ref=f2e655] [cursor=pointer]:
                - text: View all
                - generic [ref=f2e656]: "0"
            - paragraph [ref=f2e662]: No pending price updates.
          - generic [ref=f2e663]:
            - heading "Notes for Manager" [level=2] [ref=f2e664]
            - generic [ref=f2e666] [cursor=pointer]:
              - generic [ref=f2e667]:
                - strong [ref=f2e668]: Customer asked about the tea glass set price; please confirm.
                - generic [ref=f2e669]:
                  - text: Demo Floor Worker · North York ·
                  - time [ref=f2e670]: Just now
              - generic [ref=f2e671]: Open
              - link "View" [ref=f2e674]:
                - /url: "#notes"
          - generic [ref=f2e677]:
            - heading "Activity" [level=2] [ref=f2e678]
            - list [ref=f2e679]:
              - listitem [ref=f2e680]:
                - generic [aria-hidden] [ref=f2e681]: S
                - generic [ref=f2e682]:
                  - strong [ref=f2e683]: Start sale
                  - generic [ref=f2e686]:
                    - text: Stainless Steel Pot
                    - generic [ref=f2e687]: 24 cm
                  - generic [ref=f2e688]: System · North York
                  - time [ref=f2e689]: Just now
              - listitem [ref=f2e690]:
                - generic [aria-hidden] [ref=f2e691]: DS
                - generic [ref=f2e692]:
                  - strong [ref=f2e693]: Approve price
                  - generic [ref=f2e696]:
                    - text: Black Tea
                    - generic [ref=f2e697]: 450 g
                  - generic [ref=f2e698]: Demo Supervisor · North York
                  - time [ref=f2e699]: 1 d ago
              - listitem [ref=f2e700]:
                - generic [aria-hidden] [ref=f2e701]: DS
                - generic [ref=f2e702]:
                  - strong [ref=f2e703]: Approve price
                  - generic [ref=f2e706]:
                    - text: Dried Red Kidney Beans
                    - generic [ref=f2e707]: 900 g
                  - generic [ref=f2e708]: Demo Supervisor · North York
                  - time [ref=f2e709]: 2 d ago
```

# Test source

```ts
  834  |     backups.some(
  835  |       (backup) =>
  836  |         backup.raw === malformed && backup.sha256 === digest(malformed),
  837  |     ),
  838  |   ).toBe(true);
  839  |   await page.reload();
  840  |   await expect(page.getByText(/Saved history could not be read/)).toHaveCount(
  841  |     0,
  842  |   );
  843  |   await testInfo.attach(
  844  |     "Unreadable History retained and exactly archived before Reset",
  845  |     {
  846  |       body: JSON.stringify(
  847  |         {
  848  |           original_sha256: digest(malformed),
  849  |           backup_verified: true,
  850  |           reset_reloaded: true,
  851  |         },
  852  |         null,
  853  |         2,
  854  |       ),
  855  |       contentType: "application/json",
  856  |     },
  857  |   );
  858  | });
  859  | 
  860  | test("C6 migrates a near-full 5MiB legacy text store with verified raw backups and no lost source bytes", async ({
  861  |   page,
  862  | }, testInfo) => {
  863  |   test.setTimeout(120_000);
  864  |   await signIn(page, "Supervisor");
  865  |   await waitForSavedFiles(page);
  866  |   const photo = await makePhoto(page, 77, 400_000);
  867  |   const inline = `data:image/jpeg;base64,${photo.base64}`;
  868  |   const legacyState = await saved(page);
  869  |   legacyState.invoice.file_data = inline;
  870  |   legacyState.invoice.file_name = "legacy-immutable-original.jpg";
  871  |   legacyState.invoice.file_type = "image/jpeg";
  872  |   legacyState.invoice.legacy_demo_original = {
  873  |     file_name: "legacy-preserved.jpg",
  874  |     file_type: "image/jpeg",
  875  |     file_data: inline,
  876  |   };
  877  |   legacyState.config.company.logo_data = inline;
  878  |   const raw = JSON.stringify(encodeHistoryStorage(legacyState));
  879  |   const legacyBackup = structuredClone(legacyState);
  880  |   delete legacyBackup.invoice.legacy_demo_original;
  881  |   delete legacyBackup.config.company.logo_data;
  882  |   const backupRaw = JSON.stringify(encodeHistoryStorage(legacyBackup));
  883  |   await freshMigrationSurface(page);
  884  |   const prepared = await page.evaluate(
  885  |     ({ raw, backupRaw, mainKey }) => {
  886  |       localStorage.setItem(mainKey, raw);
  887  |       localStorage.setItem("supermarket-prototype-before-c4", backupRaw);
  888  |       const used = Array.from({ length: localStorage.length }, (_, index) =>
  889  |         localStorage.key(index)!,
  890  |       ).reduce(
  891  |         (sum, key) =>
  892  |           sum + (key.length + localStorage.getItem(key)!.length) * 2,
  893  |         0,
  894  |       );
  895  |       const fillerKey = "c6-storage-proof-padding";
  896  |       const padding = Math.floor(
  897  |         (5 * 1024 * 1024 - 4096 - used - fillerKey.length * 2) / 2,
  898  |       );
  899  |       if (padding < 0)
  900  |         throw new Error(
  901  |           "Legacy fixture exceeded the 5MiB limit before migration.",
  902  |         );
  903  |       localStorage.setItem(fillerKey, "x".repeat(padding));
  904  |       return { raw, backupRaw, usedBefore: 5 * 1024 * 1024 - 4096 };
  905  |     },
  906  |     { raw, backupRaw, mainKey },
  907  |   );
  908  |   // Safari's relevant text quota is stricter than Chromium's. Enforce 5MiB on
  909  |   // actual Storage writes while using the browser's real IndexedDB/Blobs.
  910  |   await page.addInitScript(() => {
  911  |     const original = Storage.prototype.setItem;
  912  |     Storage.prototype.setItem = function (key: string, value: string) {
  913  |       if (this === localStorage) {
  914  |         let bytes = (key.length + String(value).length) * 2;
  915  |         for (let index = 0; index < this.length; index++) {
  916  |           const existingKey = this.key(index)!;
  917  |           if (existingKey !== key)
  918  |             bytes +=
  919  |               (existingKey.length + this.getItem(existingKey)!.length) * 2;
  920  |         }
  921  |         if (bytes > 5 * 1024 * 1024)
  922  |           throw new DOMException("5MiB text quota", "QuotaExceededError");
  923  |       }
  924  |       return original.call(this, key, value);
  925  |     };
  926  |   });
  927  |   await signIn(page, "Manager");
  928  |   await waitForSavedFiles(page);
  929  |   const state = await saved(page);
  930  |   expect(await page.evaluate((key) => localStorage.getItem(key), mainKey)).toBe(
  931  |     prepared.raw,
  932  |   );
  933  |   expect(state.invoice.file_data).toMatch(/^idb-file:v1:/);
> 934  |   expect(state.invoice.legacy_demo_original!.file_data).toBe(
       |                                              ^ TypeError: Cannot read properties of undefined (reading 'file_data')
  935  |     state.invoice.file_data,
  936  |   );
  937  |   expect(state.config.company.logo_data).toBe(state.invoice.file_data);
  938  |   const files = await retainedFiles(page, [state.invoice.file_data!]);
  939  |   expect(files[0].hash).toBe(photo.sha256);
  940  |   expect(files[0].size).toBe(photo.size);
  941  |   const backups = await page.evaluate(async (databaseName) => {
  942  |     const database = await new Promise<IDBDatabase>((resolve, reject) => {
  943  |       const request = indexedDB.open(databaseName, 1);
  944  |       request.onsuccess = () => resolve(request.result);
  945  |       request.onerror = () => reject(request.error);
  946  |     });
  947  |     try {
  948  |       const records = await new Promise<
  949  |         { storage_key: string; raw: Blob; sha256: string }[]
  950  |       >((resolve, reject) => {
  951  |         const request = database
  952  |           .transaction("backups", "readonly")
  953  |           .objectStore("backups")
  954  |           .getAll();
  955  |         request.onsuccess = () => resolve(request.result);
  956  |         request.onerror = () => reject(request.error);
  957  |       });
  958  |       return Promise.all(
  959  |         records.map(async (record) => ({
  960  |           key: record.storage_key,
  961  |           raw: await record.raw.text(),
  962  |           digest: record.sha256,
  963  |         })),
  964  |       );
  965  |     } finally {
  966  |       database.close();
  967  |     }
  968  |   }, databaseName);
  969  |   expect(
  970  |     backups.some(
  971  |       (backup) => backup.key === mainKey && backup.raw === prepared.raw,
  972  |     ),
  973  |   ).toBe(true);
  974  |   expect(
  975  |     backups.some(
  976  |       (backup) =>
  977  |         backup.key === "supermarket-prototype-before-c4" &&
  978  |         backup.raw === prepared.backupRaw,
  979  |     ),
  980  |   ).toBe(true);
  981  |   for (const backup of backups) expect(digest(backup.raw)).toBe(backup.digest);
  982  |   const text = await textBytes(page);
  983  |   expect(text).toBeLessThan(5 * 1024 * 1024);
  984  |   await expect(page.getByText(storageFailure)).toHaveCount(0);
  985  |   await page.reload();
  986  |   await waitForSavedFiles(page);
  987  |   expect((await saved(page)).invoice.file_data).toBe(state.invoice.file_data);
  988  |   expect((await retainedFiles(page, [state.invoice.file_data!]))[0].hash).toBe(
  989  |     photo.sha256,
  990  |   );
  991  |   await testInfo.attach("Strict 5MiB migration and verified restore evidence", {
  992  |     body: JSON.stringify(
  993  |       {
  994  |         source_hash: photo.sha256,
  995  |         source_size: photo.size,
  996  |         migrated_reference: state.invoice.file_data,
  997  |         text_bytes_after: text,
  998  |         exact_main_backup_sha256: digest(prepared.raw),
  999  |         exact_legacy_backup_sha256: digest(prepared.backupRaw),
  1000 |         verified_backup_count: backups.length,
  1001 |         reload_preserved: true,
  1002 |       },
  1003 |       null,
  1004 |       2,
  1005 |     ),
  1006 |     contentType: "application/json",
  1007 |   });
  1008 | });
  1009 | 
  1010 | test("C6 keeps legacy inline evidence intact when the file database is disabled", async ({
  1011 |   page,
  1012 | }) => {
  1013 |   await signIn(page, "Supervisor");
  1014 |   await waitForSavedFiles(page);
  1015 |   const legacyState = await saved(page);
  1016 |   legacyState.invoice.file_data =
  1017 |     "data:application/pdf;base64,JVBERi0xLjcKJUZpY3Rpb25hbCBkZW1v";
  1018 |   legacyState.invoice.file_name = "retained-on-failure.pdf";
  1019 |   legacyState.invoice.file_type = "application/pdf";
  1020 |   const before = JSON.stringify(encodeHistoryStorage(legacyState));
  1021 |   await freshMigrationSurface(page);
  1022 |   await page.evaluate(
  1023 |     ({ mainKey, raw }) => localStorage.setItem(mainKey, raw),
  1024 |     { mainKey, raw: before },
  1025 |   );
  1026 |   await page.addInitScript((fileDatabaseName) => {
  1027 |     const originalOpen = indexedDB.open.bind(indexedDB);
  1028 |     indexedDB.open = (name, version) => {
  1029 |       if (name === fileDatabaseName)
  1030 |         throw new DOMException("File database disabled", "SecurityError");
  1031 |       return version === undefined
  1032 |         ? originalOpen(name)
  1033 |         : originalOpen(name, version);
  1034 |     };
```