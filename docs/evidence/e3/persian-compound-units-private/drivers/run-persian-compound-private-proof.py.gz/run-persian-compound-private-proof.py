from pathlib import Path
import collections,concurrent.futures,difflib,hashlib,json,os,shutil,signal,subprocess,time,urllib.request,urllib.parse
repo=Path('/workspace/Supermarket-Inventory');candidate=Path('/tmp/e3-persian-compound-units-candidate');manifest=json.loads((candidate/'manifest.json').read_text());root=Path('/tmp/e3-persian-compound-private-proof');root.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(path,data):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(data,indent=2)+'\n')
for f in manifest['files']:f['sha256']=sha(Path(f['source']).read_bytes());assert sha((repo/f['path']).read_bytes())==f['baseline_sha256']
save(candidate/'manifest.json',manifest)
(candidate/'candidate.diff').write_text(''.join(''.join(difflib.unified_diff((repo/f['path']).read_text().splitlines(keepends=True),Path(f['source']).read_text().splitlines(keepends=True),fromfile='a/'+f['path'],tofile='b/'+f['path']))for f in manifest['files']))
source=Path('/tmp/e3-sale-inline-units-original-files/source');allpins=json.loads(Path('/tmp/e3-sale-inline-units-original-files/source-pins.json').read_text());pins={n:p for n,p in allpins.items()if n.startswith(('prototype/','seed/','assets/'))or n in ['AGENTS.md','docs/return-policy.md']};assert len(pins)==595
for variant in ['old-unit','patched','old-oracle']:
 tree=root/variant/'source'
 for name,pin in pins.items():
  raw=(source/name).read_bytes();assert sha(raw)==pin['sha256'];p=tree/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
 overlays=[]
 for f in manifest['files']:
  if variant=='old-unit'and f['path']!='prototype/src/presentation.units.test.tsx':continue
  if variant=='old-oracle'and f['path']=='prototype/scripts/c6-layout-proof.mjs':continue
  raw=Path(f['source']).read_bytes();assert sha(raw)==f['sha256'];(tree/f['path']).write_bytes(raw);overlays.append(f['path'])
 (tree/'prototype/node_modules').symlink_to(repo/'prototype/node_modules',target_is_directory=True)
 config='import base from "./vite.config";\nexport default { ...base, server: { ...base.server, fs: { allow: ['+json.dumps(str(tree))+','+json.dumps(str(repo/'prototype/node_modules'))+'] } } };\n';(tree/'prototype/vite.private-proof.config.ts').write_text(config)
 frozen={n:sha((tree/n).read_bytes())for n in pins};save(root/variant/'source-pins-before.json',frozen);save(root/variant/'freeze.json',{'baseline_commit':'431bdba29e25a3b53e3acc5d7ef8ad186150ab2b','application_input_files':len(pins),'overlay_paths':overlays,'overlay_manifest_sha256':sha((candidate/'manifest.json').read_bytes()),'private_vitest_adapter_sha256':sha(config.encode()),'private_vitest_adapter_reason':'Permit real shared dependency files for actual pdfjs worker import; no source/mock/permission override. Identical adapter structure for old/new.'})
env=dict(os.environ);env['PATH']='/workspace/scratch/node-install/node-v22.23.3-linux-x64/bin:'+env['PATH'];env['PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH']='/usr/bin/chromium';assert not env.get('CI')
def run(variant,command,label,extra=None):
 folder=root/variant;tree=folder/'source';started=time.time();used=dict(env);used.update(extra or{})
 with(folder/(label+'.log')).open('w')as log:
  p=subprocess.Popen(command,cwd=tree/'prototype',env=used,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);save(folder/(label+'-running.json'),{'pid':p.pid,'command':command});code=p.wait()
 result={'command':command,'actual_exit_code':code,'seconds':time.time()-started};save(folder/(label+'-execution.json'),result);print(json.dumps({'variant':variant,'label':label,**result}),flush=True);return result
baseunit=['node','node_modules/vitest/vitest.mjs','run','src/presentation.units.test.tsx','--config','vite.private-proof.config.ts','--maxWorkers=1','--reporter=default','--reporter=json']
def units():
 for variant in ['old-unit','patched']:
  run(variant,baseunit+['--outputFile='+str(root/variant/'vitest.json')],'unit')
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:
 a=pool.submit(units);b=pool.submit(run,'patched',['npm','run','build'],'normal-build');a.result();build=b.result()
assert build['actual_exit_code']==0,'Actual normal build failed; preserve raw log'
changed=[f['path'].removeprefix('prototype/')for f in manifest['files']]
run('patched',['node','node_modules/eslint/bin/eslint.js',*changed,'--max-warnings=0'],'changed-eslint')
run('patched',['node','node_modules/prettier/bin/prettier.cjs','--check',*changed],'changed-prettier')
distroot=root/'patched/source/prototype/dist';dist={str(p.relative_to(distroot)):sha(p.read_bytes())for p in distroot.rglob('*')if p.is_file()};save(root/'dist-pins.json',dist);shutil.copytree(distroot,root/'old-oracle/source/prototype/dist')
for variant in ['old-oracle','patched']:
 folder=root/variant;tree=folder/'source';port=5198;base=f'http://127.0.0.1:{port}';cfg='import base from "./playwright.config";\nexport default { ...base, use: { ...base.use, baseURL: '+json.dumps(base)+' }, webServer: undefined };\n';(tree/'prototype/playwright.private-proof.config.ts').write_text(cfg)
 with(folder/'preview.log').open('w')as log:
  preview=subprocess.Popen(['node','node_modules/vite/bin/vite.js','preview','--host','127.0.0.1','--port',str(port),'--strictPort'],cwd=tree/'prototype',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);save(folder/'owned-preview.json',{'pid':preview.pid,'baseURL':base})
  try:
   deadline=time.monotonic()+30
   while True:
    if preview.poll()is not None:raise RuntimeError('Owned preview exited')
    try:
     with urllib.request.urlopen(base,timeout=1)as r:
      if r.status==200:break
    except Exception:pass
    if time.monotonic()>deadline:raise RuntimeError('Original30second preview budget exceeded')
    time.sleep(.1)
   def http():return{n:sha(urllib.request.urlopen(base+'/'+urllib.parse.quote(n),timeout=10).read())for n in dist}
   before=http();assert before==dist
   command=['node','node_modules/@playwright/test/cli.js','test','--config','playwright.private-proof.config.ts','tests/layout-proof-c6.spec.ts','--project=phone','--grep','^ordinary en Activity sizes stay together and an unmarked split is detected$','--workers=1','--trace=on','--reporter=line,json','--output',str(folder/'native-output')]
   result=run(variant,command,'native',{'PLAYWRIGHT_JSON_OUTPUT_NAME':str(folder/'playwright.json')});after=http();save(folder/'native-guards.json',{'http_before_matches_fresh_dist':before==dist,'all_served_http_unchanged':before==after,'dist_files':len(dist),'fresh_candidate_build':True,'old_oracle_reuses_identical_new_production_dist':variant=='old-oracle','production_source_is_identical_between_oracle_variants':True,'evidence_only_trace_override':'--trace=on','original_test_budget_retries_skips_unchanged':True})
  finally:
   if preview.poll()is None:os.killpg(preview.pid,signal.SIGTERM);preview.wait(timeout=10)
for variant in ['old-unit','patched','old-oracle']:
 tree=root/variant/'source';before=json.loads((root/variant/'source-pins-before.json').read_text());after={n:sha((tree/n).read_bytes())for n in pins};save(root/variant/'source-guard.json',{'before_sha256':sha(json.dumps(before,sort_keys=True).encode()),'after_sha256':sha(json.dumps(after,sort_keys=True).encode()),'source_unchanged':before==after,'application_input_files':len(pins)});assert before==after
print(json.dumps({'proof_dir':str(root),'complete':True}),flush=True)
