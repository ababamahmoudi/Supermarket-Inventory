from pathlib import Path
import hashlib,json,os,signal,subprocess,time,urllib.request,urllib.parse
root=Path('/tmp/e3-persian-compound-private-proof');sha=lambda b:hashlib.sha256(b).hexdigest();env=dict(os.environ);env['PATH']='/workspace/scratch/node-install/node-v22.23.3-linux-x64/bin:'+env['PATH'];env['PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH']='/usr/bin/chromium';assert not env.get('CI');dist=json.loads((root/'dist-pins.json').read_text())
def save(path,data):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(data,indent=2)+'\n')
for variant in ['old-oracle','patched']:
 tree=root/variant/'source';folder=root/variant/'native-run-002';folder.mkdir();pins=json.loads((root/variant/'source-pins-before.json').read_text());assert all(sha((tree/n).read_bytes())==p for n,p in pins.items());base='http://127.0.0.1:5198'
 def run(command,label,extra):
  used=dict(env);used.update(extra);start=time.time()
  with(folder/(label+'.log')).open('w')as log:
   process=subprocess.Popen(command,cwd=tree/'prototype',env=used,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);save(folder/(label+'-running.json'),{'pid':process.pid,'command':command});code=process.wait()
  result={'command':command,'actual_exit_code':code,'seconds':time.time()-start};save(folder/(label+'-execution.json'),result);print(json.dumps({'variant':variant,'label':label,**result}),flush=True);return result
 with(folder/'preview.log').open('w')as log:
  preview=subprocess.Popen(['node','node_modules/vite/bin/vite.js','preview','--host','127.0.0.1','--port','5198','--strictPort'],cwd=tree/'prototype',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);save(folder/'owned-preview.json',{'pid':preview.pid,'base_url':base})
  try:
   end=time.monotonic()+30
   while True:
    if preview.poll()is not None:raise RuntimeError('Owned preview exited')
    try:
     with urllib.request.urlopen(base,timeout=1)as response:
      if response.status==200:break
    except Exception:pass
    if time.monotonic()>end:raise RuntimeError('Original30second preview budget exceeded')
    time.sleep(.1)
   def http():return{n:sha(urllib.request.urlopen(base+'/'+urllib.parse.quote(n),timeout=10).read())for n in dist}
   before=http();assert before==dist
   command=['node','node_modules/@playwright/test/cli.js','test','--config','playwright.private-proof.config.ts','tests/layout-proof-c6.spec.ts','--project=phone','--grep','ordinary en Activity sizes stay together']
   result=run(command+['--list','--reporter=json'],'discovery',{'PLAYWRIGHT_JSON_OUTPUT_NAME':str(folder/'discovery.json')});assert result['actual_exit_code']==0
   raw=json.loads((folder/'discovery.json').read_text());specs=[]
   def walk(suites):
    for suite in suites:
     specs.extend(suite.get('specs',[]));walk(suite.get('suites',[]))
   walk(raw['suites']);assert len(specs)==1 and specs[0]['title']=='ordinary en Activity sizes stay together and an unmarked split is detected';save(folder/'expected-case.json',{'original_case':specs[0]['title'],'count':1,'entire_expanded_control_case':True})
   result=run(command+['--workers=1','--trace=on','--reporter=line,json','--output',str(folder/'native-output')],'native',{'PLAYWRIGHT_JSON_OUTPUT_NAME':str(folder/'playwright.json')});after=http();guard={'all595_source_inputs_unchanged':all(sha((tree/n).read_bytes())==p for n,p in pins.items()),'http_before_matches_actual_fresh_candidate_dist':before==dist,'http_after_identical':before==after,'http_asset_count':len(dist),'fresh_candidate_production_build':True,'same_production_source_and_dist_for_both_oracle_variants':True,'oracle_only_difference':True,'original_budgets_retries_assertions_retained':True,'evidence_only_override':'--trace=on'};save(folder/'guards.json',guard);assert all(guard[k]for k in ['all595_source_inputs_unchanged','http_before_matches_actual_fresh_candidate_dist','http_after_identical'])
  finally:
   if preview.poll()is None:os.killpg(preview.pid,signal.SIGTERM);preview.wait(timeout=10)
print(json.dumps({'proof_dir':str(root),'followup_complete':True}),flush=True)
