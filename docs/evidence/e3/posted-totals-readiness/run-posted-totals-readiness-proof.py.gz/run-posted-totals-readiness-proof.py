from pathlib import Path
import gzip,hashlib,json,os,subprocess,tarfile,time
ROOT=Path('/workspace/Supermarket-Inventory');BASE=Path('/tmp/posted-totals-causal-readiness');COMMIT='431bdba29e25a3b53e3acc5d7ef8ad186150ab2b';PATH='prototype/src/screens/DocumentsReturns.c5.test.tsx'
sha=lambda b:hashlib.sha256(b).hexdigest()
def dump(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git','-C',str(ROOT),*args])
BASE.mkdir(exist_ok=False); candidate=BASE/'candidate';candidate.mkdir()
archive=BASE/'exact-431-source.tar'
with archive.open('wb') as out:subprocess.run(['git','-C',str(ROOT),'archive',COMMIT],stdout=out,check=True)
with tarfile.open(archive) as tf:tf.extractall(candidate,filter='data')
(candidate/'prototype/node_modules').symlink_to(ROOT/'prototype/node_modules',target_is_directory=True)
baseline=(candidate/PATH).read_bytes();text=baseline.decode()
text=text.replace('import i18n from "../i18n";','''import i18n from "../i18n";
import {
  renderedUiReady,
  clearRenderedUiReadiness,
} from "../test/rendered-ui-readiness";''',1)
old='''function ProtectedPostedSample() {
  const { state } = useDemo();
  const workspace = state.invoice_workspace;
  return workspace ? (
    <PostedInvoice
      original={workspace.invoice}
      invoice={workspace.invoice}
      versionId="original"
    />
  ) : null;
}'''
new='''function ProtectedPostedSample() {
  const { state, authStage } = useDemo();
  const workspace = state.invoice_workspace;
  return (
    <>
      <output data-testid="posted-auth-stage">{authStage}</output>
      {workspace ? (
        <PostedInvoice
          original={workspace.invoice}
          invoice={workspace.invoice}
          versionId="original"
        />
      ) : null}
    </>
  );
}'''
assert old in text;text=text.replace(old,new,1)
text=text.replace('afterEach(() => {\n  for (const fixture of fixtures.splice(0))','afterEach(() => {\n  clearRenderedUiReadiness();\n  for (const fixture of fixtures.splice(0))',1)
marker='''  try {
    await screen.findByRole("heading", {
      name: original.supplier_invoice_number,
    });'''
replacement='''  try {
    // Fixture preparation commits storage; Provider startup still resumes the
    // real session and publishes its protected projection asynchronously.
    await renderedUiReady(
      () => screen.queryByTestId("posted-auth-stage")?.textContent === "complete",
    );
    await screen.findByRole("heading", {
      name: original.supplier_invoice_number,
    });'''
assert marker in text;text=text.replace(marker,replacement,1)
# No original assertion, callback, amount, canonical check or timeout changes.
old_assertions=baseline.decode()[baseline.decode().index('    await screen.findByRole("heading", {\n      name: original.supplier_invoice_number,'):]
assert text.endswith(old_assertions)
(candidate/PATH).write_text(text)
config=candidate/'prototype/vitest-readiness-proof.config.ts';config.write_text('''import config from "./vite.config.ts";
export default {
  ...config,
  server: {
    ...config.server,
    fs: {
      ...config.server?.fs,
      allow: [
        ...(config.server?.fs?.allow ?? []),
        "/workspace/Supermarket-Inventory/prototype/node_modules",
      ],
    },
  },
};
''')
files=[p for p in git('ls-tree','-rz','--name-only',COMMIT).decode().split('\0') if p and (p.startswith(('prototype/','seed/','assets/')) or p.endswith('AGENTS.md') or p=='docs/return-policy.md')]
def pins():return {p:sha((candidate/p).read_bytes()) for p in files if (candidate/p).is_file()}
before=pins();dump(BASE/'start.json',{'commit':COMMIT,'archive_sha256':sha(archive.read_bytes()),'only_source_delta':PATH,'baseline_sha256':sha(baseline),'candidate_sha256':sha((candidate/PATH).read_bytes()),'pinned_source_count':len(before),'source_pins':before,'original_financial_canonical_assertion_tail_unchanged':True,'timeouts_changed':False,'new_authority_or_permission_mocks':False,'runner_adapter':'Append only actual shared node_modules directory to Vite fs.allow for genuine PDF worker URL.'})
env=dict(os.environ);env['PATH']='/workspace/scratch/node-install/node-v22.23.3-linux-x64/bin:'+env['PATH']
observer=BASE/'observer.mjs';observer.write_text('''import {writeFileSync} from 'node:fs';
const output='''+json.dumps(str(BASE/'global-errors.json'))+''';
const save=v=>writeFileSync(output,JSON.stringify(v,null,2)+'\\n');
export default class ErrorObserver {
 onInit(ctx){this.ctx=ctx;process.once('exit',code=>save({phase:'process-exit',code,errors:this.ctx.state.getUnhandledErrors?.()??[],atRunEnd:this.result}));}
 onTestRunEnd(modules,errors,reason){this.result={phase:'onTestRunEnd',reason,errors,moduleCount:modules.length};save(this.result);}
}
''')
commands=[('unit',['node','node_modules/vitest/vitest.mjs','run','--config','vitest-readiness-proof.config.ts','src/screens/DocumentsReturns.c5.test.tsx','--maxWorkers=1','--reporter=default','--reporter=json','--reporter='+str(observer),'--outputFile='+str(BASE/'unit.json')]),('eslint',['node','node_modules/eslint/bin/eslint.js','src/screens/DocumentsReturns.c5.test.tsx','--max-warnings','0']),('prettier',['node','node_modules/prettier/bin/prettier.cjs','--check','src/screens/DocumentsReturns.c5.test.tsx'])]
results=[]
for name,cmd in commands:
 began=time.time()
 with (BASE/f'{name}.log').open('w') as out:result=subprocess.run(cmd,cwd=candidate/'prototype',env=env,stdout=out,stderr=subprocess.STDOUT)
 row={'name':name,'command':cmd,'actual_exit_code':result.returncode,'seconds':time.time()-began,'source_unchanged':pins()==before};results.append(row);print(json.dumps(row),flush=True)
report=json.loads((BASE/'unit.json').read_text());errors=json.loads((BASE/'global-errors.json').read_text());summary={'commit':COMMIT,'results':results,'unit_counts':{k:report[k] for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','success']},'global_errors':errors['errors'],'all_final_heading_financial_canonical_assertions_unchanged':text.endswith(old_assertions),'test_budget_30000_unchanged':True,'default_heading_budget_1000_unchanged':True,'root_file_unchanged':(ROOT/PATH).read_bytes()==baseline,'cause_limit':'The first full run timed out before Provider published a workspace; raw failure did not expose its exact startup phase, and no CPU cause is claimed.'};dump(BASE/'summary.json',summary)
assert all(x['actual_exit_code']==0 and x['source_unchanged'] for x in results)
assert report['numPassedTests']==7 and report['numFailedTests']==0 and report['numPendingTests']==0
assert not errors['errors'] and summary['root_file_unchanged']
