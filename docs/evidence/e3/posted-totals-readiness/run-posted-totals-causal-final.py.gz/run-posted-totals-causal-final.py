from pathlib import Path
import hashlib,json,os,subprocess,time
ROOT=Path('/workspace/Supermarket-Inventory');BASE=Path('/tmp/posted-totals-causal-readiness');candidate=BASE/'candidate';PATH='prototype/src/screens/DocumentsReturns.c5.test.tsx'
sha=lambda b:hashlib.sha256(b).hexdigest()
def dump(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
oldstart=json.loads((BASE/'start.json').read_text());initial=BASE/'initial-unformatted';initial.mkdir(exist_ok=False)
for name in ['start.json','observer.mjs','unit.json','unit.log','eslint.log','prettier.log','summary.json','global-errors.json']:(BASE/name).rename(initial/name)
(initial/'unformatted-fixture.tsx').write_bytes((candidate/PATH).read_bytes())
env=dict(os.environ);env['PATH']='/workspace/scratch/node-install/node-v22.23.3-linux-x64/bin:'+env['PATH']
cmd=['node','node_modules/prettier/bin/prettier.cjs','--write','src/screens/DocumentsReturns.c5.test.tsx'];began=time.time()
with (BASE/'format.log').open('w') as out:res=subprocess.run(cmd,cwd=candidate/'prototype',env=env,stdout=out,stderr=subprocess.STDOUT)
dump(BASE/'format-result.json',{'command':cmd,'actual_exit_code':res.returncode,'seconds':time.time()-began,'scope':'Only private candidate fixture formatted; initial7-pass/Prettier-failed attempt retained separately.'});assert res.returncode==0
files=list(oldstart['source_pins'])
def pins():return {p:sha((candidate/p).read_bytes()) for p in files}
before=pins();start=dict(oldstart);start.update({'candidate_sha256':sha((candidate/PATH).read_bytes()),'source_pins':before,'initial_unformatted_attempt':'initial-unformatted/summary.json; unit7passCLI0/eslint0/Prettier1, preserved'});dump(BASE/'start.json',start)
observer=BASE/'observer.mjs';observer.write_bytes((initial/'observer.mjs').read_bytes())
commands=[('unit',['node','node_modules/vitest/vitest.mjs','run','--config','vitest-readiness-proof.config.ts','src/screens/DocumentsReturns.c5.test.tsx','--maxWorkers=1','--reporter=default','--reporter=json','--reporter='+str(observer),'--outputFile='+str(BASE/'unit.json')]),('eslint',['node','node_modules/eslint/bin/eslint.js','src/screens/DocumentsReturns.c5.test.tsx','--max-warnings','0']),('prettier',['node','node_modules/prettier/bin/prettier.cjs','--check','src/screens/DocumentsReturns.c5.test.tsx'])];results=[]
for name,cmd in commands:
 began=time.time()
 with (BASE/f'{name}.log').open('w') as out:res=subprocess.run(cmd,cwd=candidate/'prototype',env=env,stdout=out,stderr=subprocess.STDOUT)
 row={'name':name,'command':cmd,'actual_exit_code':res.returncode,'seconds':time.time()-began,'source_unchanged':pins()==before};results.append(row);print(json.dumps(row),flush=True)
report=json.loads((BASE/'unit.json').read_text());errors=json.loads((BASE/'global-errors.json').read_text());baseline=subprocess.check_output(['git','-C',str(ROOT),'show','431bdba29e25a3b53e3acc5d7ef8ad186150ab2b:'+PATH]);tail=baseline.decode()[baseline.decode().index('    await screen.findByRole("heading", {\n      name: original.supplier_invoice_number,'):]
summary={'commit':start['commit'],'results':results,'unit_counts':{k:report[k] for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','success']},'global_errors':errors['errors'],'source_pin_count':len(before),'all_final_heading_financial_canonical_assertions_unchanged':(candidate/PATH).read_text().endswith(tail),'test_budget_30000_unchanged':True,'default_heading_budget_1000_unchanged':True,'root_file_unchanged':(ROOT/PATH).read_bytes()==baseline,'cause_limit':'First full431 run1429pass/1fail timed out before Provider published a workspace; raw failure does not identify exact startup phase and CPU cause is not claimed. Unchanged-source431 full diagnostic later genuinely passed1430/1430 with SDK75, no global errors and CLI0.','initial_unformatted_attempt_retained':'initial-unformatted/'};dump(BASE/'summary.json',summary)
assert all(r['actual_exit_code']==0 and r['source_unchanged'] for r in results)
assert report['numPassedTests']==7 and report['numFailedTests']==0 and report['numPendingTests']==0 and not errors['errors']
assert summary['all_final_heading_financial_canonical_assertions_unchanged'] and summary['root_file_unchanged']
