# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: invoices.spec.ts >> simulated upload, review, lower-price answer and two partial chip deliveries conserve stock and cents
- Location: tests/invoices.spec.ts:64:1

# Error details

```
Error: locator.check: Clicking the checkbox did not change its state
Call log:
  - waiting for locator('.invoice-line').nth(5).getByRole('checkbox', { name: 'Mark as short', exact: true })
    - locator resolved to <button type="button" role="checkbox" aria-checked="false" class="ui-checked-control">…</button>
  - attempting click action
    - waiting for element to be visible, enabled and stable
    - element is visible, enabled and stable
    - scrolling into view if needed
    - done scrolling
    - performing click action
    - click action done
    - waiting for scheduled navigations to finish
    - navigations have finished

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - complementary "Main menu" [ref=e5]:
    - generic [ref=e6]:
      - img "Super Arzon" [ref=e9]
      - generic [ref=e10]: Super Arzon
    - navigation "Pages" [ref=e11]:
      - generic [ref=e12]:
        - button "Daily" [expanded] [ref=e13] [cursor=pointer]
        - generic [ref=e17]:
          - link "Lookup" [ref=e18] [cursor=pointer]:
            - /url: "#lookup"
          - link "Invoices" [ref=e23] [cursor=pointer]:
            - /url: "#invoices"
          - link "Received" [ref=e28] [cursor=pointer]:
            - /url: "#received"
          - link "Returns" [ref=e35] [cursor=pointer]:
            - /url: "#returns"
          - link "Price updates" [ref=e40] [cursor=pointer]:
            - /url: "#price-updates"
          - link "Labels" [ref=e46] [cursor=pointer]:
            - /url: "#labels"
          - link "Date tracking" [ref=e51] [cursor=pointer]:
            - /url: "#expiry"
          - link "Notes" [ref=e56] [cursor=pointer]:
            - /url: "#notes"
          - link "Branch requests" [ref=e60] [cursor=pointer]:
            - /url: "#requests"
      - button "Catalog" [ref=e66] [cursor=pointer]
      - button "Manager" [ref=e71] [cursor=pointer]
      - button "Admin" [ref=e76] [cursor=pointer]
    - button "User menu" [ref=e81] [cursor=pointer]:
      - generic [ref=e82]:
        - generic [aria-hidden] [ref=e83]: DN
        - generic [ref=e84]:
          - strong [ref=e85]: Demo North York Floor Worker
          - generic [ref=e86]: Floor Worker
  - generic [ref=e87]:
    - banner [ref=e88]:
      - button "Collapse sidebar" [expanded] [ref=e89] [cursor=pointer]
      - navigation "Breadcrumbs" [ref=e93]:
        - link "North York" [ref=e94] [cursor=pointer]:
          - /url: "#invoices"
        - link "Invoices" [ref=e97] [cursor=pointer]:
          - /url: "#invoices"
        - link "FV-20417" [ref=e100] [cursor=pointer]:
          - /url: "#invoices?id=invoice-26ec3f53ea96cffa8e7b9c4ccac5f5e8"
      - search [ref=e101]:
        - textbox "Search all products" [ref=e105]:
          - /placeholder: Search products
        - generic [aria-hidden] [ref=e106]: /
      - combobox "Location" [ref=e107] [cursor=pointer]:
        - generic [ref=e112]: North York
      - button "Switch to Persian" [ref=e115] [cursor=pointer]: فا
      - button "Switch to dark theme" [ref=e116] [cursor=pointer]
      - button "Comfortable text size" [ref=e119] [cursor=pointer]:
        - generic [aria-hidden] [ref=e120]: Aa
      - button "Notifications, 0 unread" [ref=e121] [cursor=pointer]
      - button "Demo" [ref=e126] [cursor=pointer]
    - main [ref=e129]:
      - generic [ref=e130]:
        - link "Back to Invoices" [ref=e131] [cursor=pointer]:
          - /url: "#invoices"
        - generic [ref=e134]:
          - generic [ref=e135]:
            - heading "Invoices" [level=1] [ref=e136]
            - paragraph [ref=e137]: Deliveries and supplier invoices
          - button "New invoice" [ref=e139] [cursor=pointer]
        - tablist "Invoice views" [ref=e140]:
          - tab "Drafts" [ref=e141] [cursor=pointer]
          - tab "Processing" [ref=e143] [cursor=pointer]
          - tab "Needs review" [selected] [ref=e145] [cursor=pointer]
          - tab "Ready to post" [ref=e147] [cursor=pointer]
          - tab "Posted" [ref=e149] [cursor=pointer]
          - tab "Cancelled" [ref=e151] [cursor=pointer]
        - generic [ref=e153]:
          - complementary "Original invoice" [ref=e154]:
            - generic [ref=e155]:
              - heading "Original invoice" [level=2] [ref=e156]
              - paragraph [ref=e157]: AI invoice reading is simulated
              - generic [ref=e159]:
                - generic [ref=e160]: Upload a PDF or photo
                - generic [ref=e161]:
                  - button "Upload a PDF or photo" [ref=e162]
                  - button "Take photo" [ref=e163]
                  - generic [ref=e164]:
                    - generic [ref=e168]:
                      - strong [ref=e169]: fictional-supplier-invoice.png
                      - generic [ref=e170]: 1 KB
                    - button "Remove file" [ref=e171] [cursor=pointer]
                  - button "Browse" [ref=e176] [cursor=pointer]
              - group "Original invoice" [ref=e177]:
                - generic [ref=e178]:
                  - button "Zoom out" [ref=e179] [cursor=pointer]
                  - generic [ref=e181]: 100%
                  - button "Zoom in" [ref=e182] [cursor=pointer]
                - button "Fit width" [ref=e184] [cursor=pointer]
                - button "Fit page" [ref=e185] [cursor=pointer]
                - button "Download" [disabled] [ref=e186]
              - status [ref=e190]: Loading original invoice…
              - img "Original invoice image" [ref=e192]
          - generic [ref=e193]:
            - generic [ref=e194]:
              - generic "Delivery summary" [ref=e195]:
                - generic [ref=e196]:
                  - generic [ref=e197]: Subtotal
                  - strong [ref=e198]: $174.52
                - generic [ref=e199]:
                  - generic [ref=e200]: Tax
                  - strong [ref=e201]: $2.50
                - generic [ref=e202]:
                  - generic [ref=e203]: Shorts and refused deduction
                  - strong [ref=e204]: "-$7.23"
                - generic [ref=e205]:
                  - generic [ref=e206]: Payable
                  - strong [ref=e207]: $169.79
              - paragraph [ref=e208]: This is the amount of this invoice, not a supplier balance. Received records only physically delivered units.
            - generic [ref=e209]:
              - heading [level=2] [ref=e210]:
                - button "Invoice details" [ref=e211] [cursor=pointer]
              - paragraph [ref=e214]:
                - generic [ref=e215]: Fresh Valley Foods
                - text: ·
                - generic [ref=e216]: FV-20417
                - text: · North York ·
                - generic [ref=e217]: 2026-10-15
              - paragraph [ref=e218]:
                - generic [ref=e219]: Needs review
                - text: Changes save automatically in this browser.
            - generic [ref=e220]:
              - heading "Review invoice lines" [level=2] [ref=e221]
              - paragraph [ref=e222]: Choose Cases or Units and confirm the product, pack, quantities, cost, and date decision on each line.
              - table [ref=e224]:
                - 'rowgroup "Line 1: Canned Fava Beans 400 g" [ref=e225]':
                  - row [ref=e226] [cursor=pointer]:
                    - cell "1. Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی 0002 · 400 g Matched" [ref=e227]:
                      - generic [ref=e228]:
                        - heading [level=3] [ref=e229]:
                          - button "1. Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی" [expanded] [ref=e230]:
                            - generic [ref=e231]: "1."
                            - generic [ref=e232]:
                              - strong [ref=e233]:
                                - generic [ref=e234]:
                                  - text: Canned Fava Beans
                                  - generic [ref=e235]: 400 g
                              - generic [ref=e237]:
                                - text: باقالا کنسرو شده
                                - generic [ref=e238]: ۴۰۰ گرمی
                        - paragraph [ref=e241]:
                          - text: 0002 ·
                          - generic [ref=e242]: 400 g
                        - generic [ref=e245]: Matched
                    - cell [ref=e248]:
                      - generic [ref=e249]:
                        - generic [ref=e250]: Invoiced
                        - textbox "Invoiced" [ref=e251]: "2"
                      - generic [ref=e252]:
                        - generic [ref=e253]: Delivered
                        - textbox "Delivered" [ref=e254]: "24"
                    - cell [ref=e255]:
                      - generic [ref=e256]:
                        - generic [ref=e257]: Unit cost before tax
                        - textbox "Unit cost before tax" [ref=e258]: "0.98"
                    - cell "Line total $23.52" [ref=e259]:
                      - generic [ref=e260]: Line total
                      - text: $23.52
                    - 'cell "Selling price $1.49 Approved: $1.49" [ref=e261]':
                      - generic [ref=e262]:
                        - generic [ref=e263]: Selling price
                        - strong [ref=e264]: $1.49
                        - paragraph [ref=e265]: "Approved: $1.49"
                  - row [ref=e266]:
                    - cell [ref=e267]:
                      - generic [ref=e268]:
                        - group [ref=e269]:
                          - generic [ref=e270]:
                            - generic [ref=e271]: Quantity unit
                            - combobox "Quantity unit" [ref=e272] [cursor=pointer]:
                              - generic [ref=e273]: Cases
                          - generic [ref=e276]:
                            - generic [ref=e277]: Units per case
                            - textbox "Units per case" [ref=e278]: "12"
                          - generic [ref=e279]:
                            - generic [ref=e280]: Supplier item code (optional)
                            - textbox "Supplier item code (optional)" [ref=e281]
                          - generic [ref=e282]:
                            - generic [ref=e283]: Case cost before tax
                            - textbox "Case cost before tax" [ref=e284]: "11.7600"
                          - paragraph [ref=e285]: 2 × 12 = 24 units
                          - generic [ref=e286]:
                            - generic [ref=e287]: Matched product
                            - combobox "Matched product" [ref=e288] [cursor=pointer]:
                              - generic [ref=e290]:
                                - text: ⁦0002⁩ · ⁦
                                - generic [ref=e291]:
                                  - text: Canned Fava Beans
                                  - generic [ref=e292]: 400 g
                                - text: ⁩
                          - generic [ref=e295]:
                            - generic [ref=e296]: Pricing category
                            - combobox "Pricing category" [ref=e297] [cursor=pointer]:
                              - generic [ref=e298]: Grocery
                        - button "Remove line" [ref=e301] [cursor=pointer]
                        - checkbox "Mark as short" [ref=e302] [cursor=pointer]
                        - group [ref=e305]:
                          - generic [ref=e306]:
                            - generic [ref=e307]: Track date
                            - group "Track date" [ref=e308]:
                              - button "Yes" [pressed] [ref=e309] [cursor=pointer]
                              - button "No" [ref=e311] [cursor=pointer]
                          - generic [ref=e313]:
                            - generic [ref=e314]:
                              - generic [ref=e315]: Date tracking
                              - combobox "Date tracking" [ref=e316] [cursor=pointer]:
                                - generic [ref=e317]: Expiry
                            - generic [ref=e320]:
                              - generic [ref=e321]: Date
                              - button "Date" [ref=e322] [cursor=pointer]:
                                - generic [ref=e323]: Choose date
                            - generic [ref=e326]:
                              - generic [ref=e327]: Lot number (optional)
                              - textbox "Lot number (optional)" [ref=e328]
                        - checkbox "Confirm this invoice line" [ref=e329] [cursor=pointer]
                - 'rowgroup "Line 2: Ground Sumac 100 g" [ref=e332]':
                  - row [ref=e333] [cursor=pointer]:
                    - cell "2. Ground Sumac 100 g سماق ۱۰۰ گرمی 0005 · 100 g Matched" [ref=e334]:
                      - generic [ref=e335]:
                        - heading [level=3] [ref=e336]:
                          - button "2. Ground Sumac 100 g سماق ۱۰۰ گرمی" [expanded] [ref=e337]:
                            - generic [ref=e338]: "2."
                            - generic [ref=e339]:
                              - strong [ref=e340]:
                                - generic [ref=e341]:
                                  - text: Ground Sumac
                                  - generic [ref=e342]: 100 g
                              - generic [ref=e344]:
                                - text: سماق
                                - generic [ref=e345]: ۱۰۰ گرمی
                        - paragraph [ref=e348]:
                          - text: 0005 ·
                          - generic [ref=e349]: 100 g
                        - generic [ref=e352]: Matched
                    - cell [ref=e355]:
                      - generic [ref=e356]:
                        - generic [ref=e357]: Invoiced
                        - textbox "Invoiced" [ref=e358]: "1"
                      - generic [ref=e359]:
                        - generic [ref=e360]: Delivered
                        - textbox "Delivered" [ref=e361]: "12"
                    - cell [ref=e362]:
                      - generic [ref=e363]:
                        - generic [ref=e364]: Unit cost before tax
                        - textbox "Unit cost before tax" [ref=e365]: "1.30"
                    - cell "Line total $15.60" [ref=e366]:
                      - generic [ref=e367]: Line total
                      - text: $15.60
                    - 'cell "Selling price $1.99 Approved: $1.99" [ref=e368]':
                      - generic [ref=e369]:
                        - generic [ref=e370]: Selling price
                        - strong [ref=e371]: $1.99
                        - paragraph [ref=e372]: "Approved: $1.99"
                  - row [ref=e373]:
                    - cell [ref=e374]:
                      - generic [ref=e375]:
                        - group [ref=e376]:
                          - generic [ref=e377]:
                            - generic [ref=e378]: Quantity unit
                            - combobox "Quantity unit" [ref=e379] [cursor=pointer]:
                              - generic [ref=e380]: Cases
                          - generic [ref=e383]:
                            - generic [ref=e384]: Units per case
                            - textbox "Units per case" [ref=e385]: "12"
                          - generic [ref=e386]:
                            - generic [ref=e387]: Supplier item code (optional)
                            - textbox "Supplier item code (optional)" [ref=e388]
                          - generic [ref=e389]:
                            - generic [ref=e390]: Case cost before tax
                            - textbox "Case cost before tax" [ref=e391]: "15.6000"
                          - paragraph [ref=e392]: 1 × 12 = 12 units
                          - generic [ref=e393]:
                            - generic [ref=e394]: Matched product
                            - combobox "Matched product" [ref=e395] [cursor=pointer]:
                              - generic [ref=e397]:
                                - text: ⁦0005⁩ · ⁦
                                - generic [ref=e398]:
                                  - text: Ground Sumac
                                  - generic [ref=e399]: 100 g
                                - text: ⁩
                          - generic [ref=e402]:
                            - generic [ref=e403]: Pricing category
                            - combobox "Pricing category" [ref=e404] [cursor=pointer]:
                              - generic [ref=e405]: Grocery
                        - button "Remove line" [ref=e408] [cursor=pointer]
                        - checkbox "Mark as short" [ref=e409] [cursor=pointer]
                        - group [ref=e412]:
                          - generic [ref=e413]:
                            - generic [ref=e414]: Track date
                            - group "Track date" [ref=e415]:
                              - button "Yes" [pressed] [ref=e416] [cursor=pointer]
                              - button "No" [ref=e418] [cursor=pointer]
                          - generic [ref=e420]:
                            - generic [ref=e421]:
                              - generic [ref=e422]: Date tracking
                              - combobox "Date tracking" [ref=e423] [cursor=pointer]:
                                - generic [ref=e424]: Expiry
                            - generic [ref=e427]:
                              - generic [ref=e428]: Date
                              - button "Date" [ref=e429] [cursor=pointer]:
                                - generic [ref=e430]: Choose date
                            - generic [ref=e433]:
                              - generic [ref=e434]: Lot number (optional)
                              - textbox "Lot number (optional)" [ref=e435]
                        - checkbox "Confirm this invoice line" [ref=e436] [cursor=pointer]
                - 'rowgroup "Line 3: Lavash Bread 500 g" [ref=e439]':
                  - row [ref=e440] [cursor=pointer]:
                    - cell "3. Lavash Bread 500 g نان لواش ۵۰۰ گرمی 0006 · 500 g Matched" [ref=e441]:
                      - generic [ref=e442]:
                        - heading [level=3] [ref=e443]:
                          - button "3. Lavash Bread 500 g نان لواش ۵۰۰ گرمی" [expanded] [ref=e444]:
                            - generic [ref=e445]: "3."
                            - generic [ref=e446]:
                              - strong [ref=e447]:
                                - generic [ref=e448]:
                                  - text: Lavash Bread
                                  - generic [ref=e449]: 500 g
                              - generic [ref=e451]:
                                - text: نان لواش
                                - generic [ref=e452]: ۵۰۰ گرمی
                        - paragraph [ref=e455]:
                          - text: 0006 ·
                          - generic [ref=e456]: 500 g
                        - generic [ref=e459]: Matched
                    - cell [ref=e462]:
                      - generic [ref=e463]:
                        - generic [ref=e464]: Invoiced
                        - textbox "Invoiced" [ref=e465]: "2"
                      - generic [ref=e466]:
                        - generic [ref=e467]: Delivered
                        - textbox "Delivered" [ref=e468]: "20"
                    - cell [ref=e469]:
                      - generic [ref=e470]:
                        - generic [ref=e471]: Unit cost before tax
                        - textbox "Unit cost before tax" [ref=e472]: "1.55"
                    - cell "Line total $31.00" [ref=e473]:
                      - generic [ref=e474]: Line total
                      - text: $31.00
                    - 'cell "Selling price $2.99 Pending Goes to approval when posted Approved: $1.99" [ref=e475]':
                      - generic [ref=e476]:
                        - generic [ref=e477]: Selling price
                        - strong [ref=e478]: $2.99
                        - generic [ref=e479]: Pending
                        - generic [ref=e481]: Goes to approval when posted
                        - paragraph [ref=e482]: "Approved: $1.99"
                  - row [ref=e483]:
                    - cell [ref=e484]:
                      - generic [ref=e485]:
                        - group [ref=e486]:
                          - generic [ref=e487]:
                            - generic [ref=e488]: Quantity unit
                            - combobox "Quantity unit" [ref=e489] [cursor=pointer]:
                              - generic [ref=e490]: Cases
                          - generic [ref=e493]:
                            - generic [ref=e494]: Units per case
                            - textbox "Units per case" [ref=e495]: "10"
                          - generic [ref=e496]:
                            - generic [ref=e497]: Supplier item code (optional)
                            - textbox "Supplier item code (optional)" [ref=e498]
                          - generic [ref=e499]:
                            - generic [ref=e500]: Case cost before tax
                            - textbox "Case cost before tax" [ref=e501]: "15.5000"
                          - paragraph [ref=e502]: 2 × 10 = 20 units
                          - generic [ref=e503]:
                            - generic [ref=e504]: Matched product
                            - combobox "Matched product" [ref=e505] [cursor=pointer]:
                              - generic [ref=e507]:
                                - text: ⁦0006⁩ · ⁦
                                - generic [ref=e508]:
                                  - text: Lavash Bread
                                  - generic [ref=e509]: 500 g
                                - text: ⁩
                          - generic [ref=e512]:
                            - generic [ref=e513]: Pricing category
                            - combobox "Pricing category" [ref=e514] [cursor=pointer]:
                              - generic [ref=e515]: Grocery
                        - button "Remove line" [ref=e518] [cursor=pointer]
                        - checkbox "Mark as short" [ref=e519] [cursor=pointer]
                        - group [ref=e522]:
                          - generic [ref=e523]:
                            - generic [ref=e524]: Track date
                            - group "Track date" [ref=e525]:
                              - button "Yes" [pressed] [ref=e526] [cursor=pointer]
                              - button "No" [ref=e528] [cursor=pointer]
                          - generic [ref=e530]:
                            - generic [ref=e531]:
                              - generic [ref=e532]: Date tracking
                              - combobox "Date tracking" [ref=e533] [cursor=pointer]:
                                - generic [ref=e534]: Expiry
                            - generic [ref=e537]:
                              - generic [ref=e538]: Date
                              - button "Date" [ref=e539] [cursor=pointer]:
                                - generic [ref=e540]: Choose date
                            - generic [ref=e543]:
                              - generic [ref=e544]: Lot number (optional)
                              - textbox "Lot number (optional)" [ref=e545]
                        - checkbox "Confirm this invoice line" [ref=e546] [cursor=pointer]
                - 'rowgroup "Line 4: Sour Cherry Juice 1 L" [ref=e549]':
                  - row [ref=e550] [cursor=pointer]:
                    - cell "4. Sour Cherry Juice 1 L آب آلبالو ۱ لیتری 0003 · 1 L Matched" [ref=e551]:
                      - generic [ref=e552]:
                        - heading [level=3] [ref=e553]:
                          - button "4. Sour Cherry Juice 1 L آب آلبالو ۱ لیتری" [expanded] [ref=e554]:
                            - generic [ref=e555]: "4."
                            - generic [ref=e556]:
                              - strong [ref=e557]:
                                - generic [ref=e558]:
                                  - text: Sour Cherry Juice
                                  - generic [ref=e559]: 1 L
                              - generic [ref=e561]:
                                - text: آب آلبالو
                                - generic [ref=e562]: ۱ لیتری
                        - paragraph [ref=e565]:
                          - text: 0003 ·
                          - generic [ref=e566]: 1 L
                        - generic [ref=e569]: Matched
                    - cell [ref=e572]:
                      - generic [ref=e573]:
                        - generic [ref=e574]: Invoiced
                        - textbox "Invoiced" [ref=e575]: "3"
                      - generic [ref=e576]:
                        - generic [ref=e577]: Delivered
                        - textbox "Delivered" [ref=e578]: "36"
                    - cell [ref=e579]:
                      - generic [ref=e580]:
                        - generic [ref=e581]: Unit cost before tax
                        - textbox "Unit cost before tax" [ref=e582]: "1.80"
                    - cell "Line total $64.80" [ref=e583]:
                      - generic [ref=e584]: Line total
                      - text: $64.80
                    - 'cell "Selling price $2.99 Approved: $2.99" [ref=e585]':
                      - generic [ref=e586]:
                        - generic [ref=e587]: Selling price
                        - strong [ref=e588]: $2.99
                        - paragraph [ref=e589]: "Approved: $2.99"
                  - row [ref=e590]:
                    - cell "Remove line Mark as short Lower-cost receipt Lower-cost receipt Confirm this invoice line" [ref=e591]:
                      - generic [ref=e592]:
                        - group [ref=e593]:
                          - generic [ref=e594]:
                            - generic [ref=e595]: Quantity unit
                            - combobox "Quantity unit" [ref=e596] [cursor=pointer]:
                              - generic [ref=e597]: Cases
                          - generic [ref=e600]:
                            - generic [ref=e601]: Units per case
                            - textbox "Units per case" [ref=e602]: "12"
                          - generic [ref=e603]:
                            - generic [ref=e604]: Supplier item code (optional)
                            - textbox "Supplier item code (optional)" [ref=e605]
                          - generic [ref=e606]:
                            - generic [ref=e607]: Case cost before tax
                            - textbox "Case cost before tax" [ref=e608]: "21.6000"
                          - paragraph [ref=e609]: 3 × 12 = 36 units
                          - generic [ref=e610]:
                            - generic [ref=e611]: Matched product
                            - combobox "Matched product" [ref=e612] [cursor=pointer]:
                              - generic [ref=e614]:
                                - text: ⁦0003⁩ · ⁦
                                - generic [ref=e615]:
                                  - text: Sour Cherry Juice
                                  - generic [ref=e616]: 1 L
                                - text: ⁩
                          - generic [ref=e619]:
                            - generic [ref=e620]: Pricing category
                            - combobox "Pricing category" [ref=e621] [cursor=pointer]:
                              - generic [ref=e622]: Grocery
                        - button "Remove line" [ref=e625] [cursor=pointer]
                        - checkbox "Mark as short" [ref=e626] [cursor=pointer]
                        - generic [ref=e629]:
                          - generic [ref=e630]: Lower-cost receipt
                          - group "Lower-cost receipt" [ref=e631]:
                            - button "Regular receipt" [pressed] [ref=e632] [cursor=pointer]
                            - button "Short-dated (expiry discount)" [ref=e634] [cursor=pointer]
                        - group [ref=e636]:
                          - generic [ref=e637]:
                            - generic [ref=e638]: Track date
                            - group "Track date" [ref=e639]:
                              - button "Yes" [pressed] [ref=e640] [cursor=pointer]
                              - button "No" [ref=e642] [cursor=pointer]
                          - generic [ref=e644]:
                            - generic [ref=e645]:
                              - generic [ref=e646]: Date tracking
                              - combobox "Date tracking" [ref=e647] [cursor=pointer]:
                                - generic [ref=e648]: Expiry
                            - generic [ref=e651]:
                              - generic [ref=e652]: Date
                              - button "Date" [ref=e653] [cursor=pointer]:
                                - generic [ref=e654]: Choose date
                            - generic [ref=e657]:
                              - generic [ref=e658]: Lot number (optional)
                              - textbox "Lot number (optional)" [ref=e659]
                        - checkbox "Confirm this invoice line" [ref=e660] [cursor=pointer]
                - 'rowgroup "Line 5: Dried Barberries 100 g" [ref=e663]':
                  - row [ref=e664] [cursor=pointer]:
                    - cell [ref=e665]:
                      - generic [ref=e666]:
                        - heading [level=3] [ref=e667]:
                          - button "5. Dried Barberries 100 g زرشک خشک ۱۰۰ گرمی" [expanded] [ref=e668]:
                            - generic [ref=e669]: "5."
                            - generic [ref=e670]:
                              - strong [ref=e671]:
                                - generic [ref=e672]:
                                  - text: Dried Barberries
                                  - generic [ref=e673]: 100 g
                              - generic [ref=e675]:
                                - text: زرشک خشک
                                - generic [ref=e676]: ۱۰۰ گرمی
                        - paragraph [ref=e679]: No Product Code yet
                        - generic [ref=e680]: Pending new product
                    - cell [ref=e683]:
                      - generic [ref=e684]:
                        - generic [ref=e685]: Invoiced
                        - textbox "Invoiced" [ref=e686]: "1"
                      - generic [ref=e687]:
                        - generic [ref=e688]: Delivered
                        - textbox "Delivered" [ref=e689]: "6"
                    - cell [ref=e690]:
                      - generic [ref=e691]:
                        - generic [ref=e692]: Unit cost before tax
                        - textbox "Unit cost before tax" [ref=e693]: "3.40"
                    - cell "Line total $20.40" [ref=e694]:
                      - generic [ref=e695]: Line total
                      - text: $20.40
                    - cell "Selling price $5.49 Pending Goes to approval when posted No approved price yet" [ref=e696]:
                      - generic [ref=e697]:
                        - generic [ref=e698]: Selling price
                        - strong [ref=e699]: $5.49
                        - generic [ref=e700]: Pending
                        - generic [ref=e702]: Goes to approval when posted
                        - paragraph [ref=e703]: No approved price yet
                  - row [ref=e704]:
                    - cell [ref=e705]:
                      - generic [ref=e706]:
                        - group [ref=e707]:
                          - generic [ref=e708]:
                            - generic [ref=e709]: Quantity unit
                            - combobox "Quantity unit" [ref=e710] [cursor=pointer]:
                              - generic [ref=e711]: Cases
                          - generic [ref=e714]:
                            - generic [ref=e715]: Units per case
                            - textbox "Units per case" [ref=e716]: "6"
                          - generic [ref=e717]:
                            - generic [ref=e718]: Supplier item code (optional)
                            - textbox "Supplier item code (optional)" [ref=e719]
                          - generic [ref=e720]:
                            - generic [ref=e721]: Case cost before tax
                            - textbox "Case cost before tax" [ref=e722]: "20.4000"
                          - paragraph [ref=e723]: 1 × 6 = 6 units
                          - generic [ref=e724]:
                            - generic [ref=e725]: Matched product
                            - combobox "Matched product" [ref=e726] [cursor=pointer]:
                              - generic [ref=e727]: Create pending new product
                          - generic [ref=e730]:
                            - generic [ref=e731]: Pricing category
                            - combobox "Pricing category" [ref=e732] [cursor=pointer]:
                              - generic [ref=e733]: Grocery
                          - generic [ref=e736]:
                            - generic [ref=e737]: New product name (English)
                            - textbox "New product name (English)" [ref=e738]: Dried Barberries 100 g
                          - generic [ref=e739]:
                            - generic [ref=e740]: New product name (Persian) (optional)
                            - textbox "New product name (Persian) (optional)" [ref=e741]: زرشک خشک ۱۰۰ گرمی
                        - button "Remove line" [ref=e742] [cursor=pointer]
                        - checkbox "Mark as short" [ref=e743] [cursor=pointer]
                        - group [ref=e746]:
                          - generic [ref=e747]:
                            - generic [ref=e748]: Track date
                            - group "Track date" [ref=e749]:
                              - button "Yes" [ref=e750] [cursor=pointer]
                              - button "No" [ref=e752] [cursor=pointer]
                        - checkbox "Confirm this invoice line" [ref=e754] [cursor=pointer]
                - 'rowgroup "Line 6: Potato Chips 150 g" [ref=e757]':
                  - row [ref=e758] [cursor=pointer]:
                    - 'cell "6. Potato Chips 150 g چیپس سیب‌زمینی ۱۵۰ گرمی 0009 · 150 g Matched Short: 4 Taxable" [ref=e759]':
                      - generic [ref=e760]:
                        - heading [level=3] [ref=e761]:
                          - button "6. Potato Chips 150 g چیپس سیب‌زمینی ۱۵۰ گرمی" [expanded] [ref=e762]:
                            - generic [ref=e763]: "6."
                            - generic [ref=e764]:
                              - strong [ref=e765]:
                                - generic [ref=e766]:
                                  - text: Potato Chips
                                  - generic [ref=e767]: 150 g
                              - generic [ref=e769]:
                                - text: چیپس سیب‌زمینی
                                - generic [ref=e770]: ۱۵۰ گرمی
                        - paragraph [ref=e773]:
                          - text: 0009 ·
                          - generic [ref=e774]: 150 g
                        - generic [ref=e777]:
                          - generic [ref=e778]: Matched
                          - generic [ref=e780]: "Short: 4"
                          - generic [ref=e782]: Taxable
                    - cell [ref=e784]:
                      - generic [ref=e785]:
                        - generic [ref=e786]: Invoiced
                        - textbox "Invoiced" [ref=e787]: "1"
                      - generic [ref=e788]:
                        - generic [ref=e789]: Delivered
                        - textbox "Delivered" [ref=e790]: "8"
                    - cell [ref=e791]:
                      - generic [ref=e792]:
                        - generic [ref=e793]: Unit cost before tax
                        - textbox "Unit cost before tax" [ref=e794]: "1.60"
                    - cell "Line total $19.20" [ref=e795]:
                      - generic [ref=e796]: Line total
                      - text: $19.20
                    - 'cell "Selling price $2.99 Approved: $2.99" [ref=e797]':
                      - generic [ref=e798]:
                        - generic [ref=e799]: Selling price
                        - strong [ref=e800]: $2.99
                        - paragraph [ref=e801]: "Approved: $2.99"
                  - row [ref=e802]:
                    - 'cell "Remove line Mark as short Missing units: 4 · Deduction: $7.23 ($6.40 + $0.83 ) tax Confirm this invoice line" [ref=e803]':
                      - generic [ref=e804]:
                        - group [ref=e805]:
                          - generic [ref=e806]:
                            - generic [ref=e807]: Quantity unit
                            - combobox "Quantity unit" [ref=e808] [cursor=pointer]:
                              - generic [ref=e809]: Cases
                          - generic [ref=e812]:
                            - generic [ref=e813]: Units per case
                            - textbox "Units per case" [ref=e814]: "12"
                          - generic [ref=e815]:
                            - generic [ref=e816]: Supplier item code (optional)
                            - textbox "Supplier item code (optional)" [ref=e817]
                          - generic [ref=e818]:
                            - generic [ref=e819]: Case cost before tax
                            - textbox "Case cost before tax" [ref=e820]: "19.2000"
                          - paragraph [ref=e821]: 1 × 12 = 12 units
                          - generic [ref=e822]:
                            - generic [ref=e823]: Matched product
                            - combobox "Matched product" [ref=e824] [cursor=pointer]:
                              - generic [ref=e826]:
                                - text: ⁦0009⁩ · ⁦
                                - generic [ref=e827]:
                                  - text: Potato Chips
                                  - generic [ref=e828]: 150 g
                                - text: ⁩
                          - generic [ref=e831]:
                            - generic [ref=e832]: Pricing category
                            - combobox "Pricing category" [ref=e833] [cursor=pointer]:
                              - generic [ref=e834]: Grocery (Taxable)
                        - button "Remove line" [ref=e837] [cursor=pointer]
                        - checkbox "Mark as short" [checked] [active] [ref=e838] [cursor=pointer]
                        - paragraph [ref=e843]:
                          - text: "Missing units: 4 · Deduction:"
                          - generic [ref=e844]: $7.23
                          - generic [ref=e845]: ($6.40 + $0.83 )
                          - text: tax
                        - group [ref=e846]:
                          - generic [ref=e847]:
                            - generic [ref=e848]: Track date
                            - group "Track date" [ref=e849]:
                              - button "Yes" [pressed] [ref=e850] [cursor=pointer]
                              - button "No" [ref=e852] [cursor=pointer]
                          - generic [ref=e854]:
                            - generic [ref=e855]:
                              - generic [ref=e856]: Date tracking
                              - combobox "Date tracking" [ref=e857] [cursor=pointer]:
                                - generic [ref=e858]: Expiry
                            - generic [ref=e861]:
                              - generic [ref=e862]: Date
                              - button "Date" [ref=e863] [cursor=pointer]:
                                - generic [ref=e864]: Choose date
                            - generic [ref=e867]:
                              - generic [ref=e868]: Lot number (optional)
                              - textbox "Lot number (optional)" [ref=e869]
                        - checkbox "Confirm this invoice line" [ref=e870] [cursor=pointer]
              - generic [ref=e873]:
                - generic [ref=e874]:
                  - generic [ref=e875]: Add a product to the invoice
                  - combobox "Add a product to the invoice" [ref=e876] [cursor=pointer]:
                    - generic [ref=e878]:
                      - text: ⁦0002⁩ · ⁦
                      - generic [ref=e879]:
                        - text: Canned Fava Beans
                        - generic [ref=e880]: 400 g
                      - text: ⁩
                - button "Add line" [ref=e883] [cursor=pointer]
                - button "+ Add new product" [ref=e884] [cursor=pointer]
            - generic [ref=e885]:
              - heading "Same-supplier lower price" [level=2] [ref=e886]
              - paragraph [ref=e887]: Sour Cherry Juice 1 L · Fresh Valley Foods · Old $1.95 · New $1.80
              - paragraph [ref=e888]: Your answers create a Supervisor alert when you post. Unknown information is allowed with a note.
              - group [ref=e889]:
                - generic [ref=e890]:
                  - generic [ref=e891]: Is the expiry date the same as the goods already in the store?
                  - combobox "Is the expiry date the same as the goods already in the store?" [ref=e892] [cursor=pointer]:
                    - generic [ref=e893]: Choose an answer
          - generic [ref=e897]:
            - button "Save as draft" [ref=e898] [cursor=pointer]
            - button "Post invoice" [ref=e899] [cursor=pointer]
```

# Test source

```ts
  1   | import { readCanonicalBusinessEvidence } from "./business-evidence";
  2   | import { expect, test, type Page } from "@playwright/test";
  3   | import { createHash } from "node:crypto";
  4   | import {
  5   |   signIn,
  6   |   chooseOption,
  7   |   setLanguage,
  8   |   openInvoiceUpload,
  9   | } from "./helpers";
  10  | 
  11  | test.setTimeout(60000);
  12  | 
  13  | const pixel = Buffer.from(
  14  |   "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jUjYAAAAASUVORK5CYII=",
  15  |   "base64",
  16  | );
  17  | async function signInWorker(page: Page) {
  18  |   await signIn(page, "Floor Worker");
  19  |   await page.goto("/#invoices");
  20  |   await expect(
  21  |     page.getByRole("heading", { name: "Invoices", exact: true }),
  22  |   ).toBeVisible();
  23  | }
  24  | async function upload(page: Page) {
  25  |   await (
  26  |     await openInvoiceUpload(page)
  27  |   ).setInputFiles({
  28  |     name: "fictional-supplier-invoice.png",
  29  |     mimeType: "image/png",
  30  |     buffer: pixel,
  31  |   });
  32  |   await expect(
  33  |     page.getByRole("status").filter({ hasText: "Reading invoice…" }),
  34  |   ).toBeVisible();
  35  |   await expect(
  36  |     page.getByRole("heading", { name: "Review invoice lines" }),
  37  |   ).toBeVisible({ timeout: 8000 });
  38  |   await expect(page.locator(".invoice-line")).toHaveCount(6, {
  39  |     timeout: 10000,
  40  |   });
  41  |   await expect
  42  |     .poll(() =>
  43  |       readCanonicalBusinessEvidence(page).then((canonicalState) => {
  44  |         const invoice = JSON.parse(JSON.stringify(canonicalState)!).invoice;
  45  |         return {
  46  |           fileName: invoice.file_name,
  47  |           originalHash: invoice.file_data?.split(":").at(-1),
  48  |           status: invoice.status,
  49  |         };
  50  |       }),
  51  |     )
  52  |     .toEqual({
  53  |       fileName: "fictional-supplier-invoice.png",
  54  |       originalHash: createHash("sha256").update(pixel).digest("hex"),
  55  |       status: "review",
  56  |     });
  57  | }
  58  | async function stored(page: Page) {
  59  |   return readCanonicalBusinessEvidence(page).then((canonicalState) =>
  60  |     JSON.parse(JSON.stringify(canonicalState)!),
  61  |   );
  62  | }
  63  | 
  64  | test("simulated upload, review, lower-price answer and two partial chip deliveries conserve stock and cents", async ({
  65  |   page,
  66  | }) => {
  67  |   await page.addInitScript(() => {
  68  |     Object.defineProperty(globalThis.crypto, "randomUUID", {
  69  |       value: undefined,
  70  |       configurable: true,
  71  |     });
  72  |   });
  73  |   const browserErrors: string[] = [];
  74  |   page.on("pageerror", (error) => browserErrors.push(error.message));
  75  |   await signInWorker(page);
  76  |   // The unread retained original now opens from its real Drafts row.
  77  |   await page.getByRole("button", { name: "Continue", exact: true }).click();
  78  |   await expect(
  79  |     page
  80  |       .getByRole("complementary", { name: "Original invoice", exact: true })
  81  |       .getByText("AI invoice reading is simulated", { exact: true }),
  82  |   ).toBeVisible();
  83  |   // This workflow tests a new uploaded invoice, separately from the retained
  84  |   // original whose Continue action was checked above.
  85  |   await page.getByRole("button", { name: "New invoice", exact: true }).click();
  86  |   const before = await stored(page);
  87  |   const beforeStock = before.stock["Branch 1:0009"];
  88  |   await upload(page);
  89  |   expect(await page.evaluate(() => typeof globalThis.crypto.randomUUID)).toBe(
  90  |     "undefined",
  91  |   );
  92  |   const sumac = page.locator(".invoice-line").nth(1);
  93  |   await sumac.getByLabel("Unit cost before tax", { exact: true }).fill("1.60");
  94  |   await expect(sumac.locator(".price-display")).toHaveText("$2.99");
  95  |   await sumac.getByLabel("Unit cost before tax", { exact: true }).fill("1.30");
  96  |   await expect(sumac.locator(".price-display")).toHaveText("$1.99");
  97  |   const chips = page.locator(".invoice-line").nth(5);
  98  |   await chips
  99  |     .getByRole("checkbox", { name: "Mark as short", exact: true })
> 100 |     .check();
      |      ^ Error: locator.check: Clicking the checkbox did not change its state
  101 |   await expect(chips.getByText(/Deduction:/)).toContainText("$7.23");
  102 |   await expect(
  103 |     page.getByRole("button", { name: "Post invoice", exact: true }),
  104 |   ).toBeEnabled();
  105 |   await page.getByRole("button", { name: "Post invoice", exact: true }).click();
  106 |   await expect(
  107 |     page.getByRole("alert", { name: "What's missing", exact: true }),
  108 |   ).toBeVisible();
  109 |   await chooseOption(
  110 |     page,
  111 |     page.getByLabel(
  112 |       "Is the expiry date the same as the goods already in the store?",
  113 |       {
  114 |         exact: true,
  115 |       },
  116 |     ),
  117 |     "unknown",
  118 |     "Unknown — add a note",
  119 |   );
  120 |   await page
  121 |     .getByLabel("What information is unknown? (required)", { exact: true })
  122 |     .fill("Demo only: old stock label cannot be read.");
  123 |   for (const line of await page.locator(".invoice-line").all()) {
  124 |     await line.getByRole("button", { name: "No", exact: true }).click();
  125 |     await line
  126 |       .getByRole("checkbox", { name: "Confirm this invoice line", exact: true })
  127 |       .click();
  128 |   }
  129 |   await page
  130 |     .getByRole("button", { name: "Save as draft", exact: true })
  131 |     .click();
  132 |   await page.reload();
  133 |   await expect(
  134 |     page.getByLabel("What information is unknown? (required)", { exact: true }),
  135 |   ).toHaveValue("Demo only: old stock label cannot be read.");
  136 |   await expect(
  137 |     page.getByRole("button", { name: "Post invoice", exact: true }),
  138 |   ).toBeEnabled();
  139 |   const beforePost = await stored(page);
  140 |   await page.getByRole("button", { name: "Post invoice", exact: true }).click();
  141 |   const confirmation = page.getByRole("dialog", {
  142 |     name: "Post invoice",
  143 |     exact: true,
  144 |   });
  145 |   await expect(confirmation).toBeVisible();
  146 |   expect((await stored(page)).invoice).toEqual(beforePost.invoice);
  147 |   expect((await stored(page)).ledger).toEqual(beforePost.ledger);
  148 |   await confirmation
  149 |     .getByRole("button", { name: "Cancel", exact: true })
  150 |     .click();
  151 |   expect((await stored(page)).invoice).toEqual(beforePost.invoice);
  152 |   await page.getByRole("button", { name: "Post invoice", exact: true }).click();
  153 |   await page
  154 |     .getByRole("dialog", { name: "Post invoice", exact: true })
  155 |     .getByRole("button", { name: "Post invoice", exact: true })
  156 |     .click();
  157 |   await expect(page.getByRole("status")).toContainText("Posted.");
  158 |   await expect(
  159 |     page.getByRole("button", { name: "Post invoice", exact: true }),
  160 |   ).toHaveCount(0);
  161 |   let state = await stored(page);
  162 |   expect(state.stock["Branch 1:0009"]).toBe(beforeStock + 8);
  163 |   expect(state.invoice.payable_after_open_shorts).toBe("169.79");
  164 |   expect(
  165 |     state.alerts.filter(
  166 |       (alert: { type: string }) => alert.type === "lower_price",
  167 |     ),
  168 |   ).toHaveLength(1);
  169 |   const deliveryReference = page.getByLabel("Delivery document reference", {
  170 |     exact: true,
  171 |   });
  172 |   const deliveryQuantity = page.getByLabel("Actual units received now", {
  173 |     exact: true,
  174 |   });
  175 |   await deliveryReference.fill("");
  176 |   await deliveryQuantity.fill("0");
  177 |   await page
  178 |     .getByRole("button", { name: "Receive short delivery", exact: true })
  179 |     .click();
  180 |   await expect(deliveryReference).toHaveAttribute("aria-invalid", "true");
  181 |   await expect(deliveryQuantity).toHaveAttribute("aria-invalid", "true");
  182 |   await deliveryReference.fill("FICTITIOUS-CHIPS-1");
  183 |   await expect(deliveryReference).toHaveAttribute("aria-invalid", "false");
  184 |   await expect(deliveryQuantity).toHaveAttribute("aria-invalid", "true");
  185 |   await deliveryQuantity.fill("2");
  186 |   await expect(deliveryQuantity).toHaveAttribute("aria-invalid", "false");
  187 |   await page
  188 |     .getByLabel("Delivery document reference", { exact: true })
  189 |     .fill("FICTITIOUS-CHIPS-1");
  190 |   await page
  191 |     .getByRole("button", { name: "Receive short delivery", exact: true })
  192 |     .click();
  193 |   await expect(page.getByRole("status")).toContainText("$3.62");
  194 |   state = await stored(page);
  195 |   expect(state.stock["Branch 1:0009"]).toBe(beforeStock + 10);
  196 |   await page
  197 |     .getByLabel("Delivery document reference", { exact: true })
  198 |     .fill("FICTITIOUS-CHIPS-2");
  199 |   await page
  200 |     .getByRole("button", { name: "Receive short delivery", exact: true })
```