# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: c5-button-audit.spec.ts >> C5 button contract covers Labels, Notes, History, Received and ledger forms
- Location: tests/c5-button-audit.spec.ts:199:1

# Error details

```
Error: Labels Products: en-light

expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 18

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

```
Error: Labels Products: en-dark

expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 18

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

```
Error: Labels Products: fa-light

expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 18

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

```
Error: Received: en-light

expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 22

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

```
Error: Received: en-dark

expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 22

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

```
Error: Received: fa-light

expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 22

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

```
Error: Payables overview: en-light

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 7

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

```
Error: Payables overview: en-dark

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 7

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

```
Error: Payables overview: fa-light

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 7

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

```
Error: Supplier ledger: en-light

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 7

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

```
Error: Supplier ledger: en-dark

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 7

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

```
Error: Supplier ledger: fa-light

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 7

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

```
Error: Record external payment form: en-light

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 7

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

```
Error: Record external payment form: en-dark

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 7

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

```
Error: Record external payment form: fa-light

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 7

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

```
Error: Record ledger entry form: en-light

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 7

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

```
Error: Record ledger entry form: en-dark

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 7

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

```
Error: Record ledger entry form: fa-light

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 7

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

```
Error: Record supplier dispute form: en-light

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 7

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

```
Error: Record supplier dispute form: en-dark

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 7

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

```
Error: Record supplier dispute form: fa-light

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 7

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=e5]:
    - banner [ref=e6]:
      - button "Open menu" [ref=e7] [cursor=pointer]
      - combobox "Location" [ref=e11] [cursor=pointer]:
        - generic [ref=e16]: North York
      - button "Notifications, 5 unread" [ref=e19] [cursor=pointer]:
        - generic [ref=e20]: "5"
      - button "User menu" [ref=e25] [cursor=pointer]:
        - generic [aria-hidden] [ref=e27]: DM
      - button "More" [active] [ref=e28] [cursor=pointer]
    - main [ref=e34]:
      - generic [ref=e35]:
        - generic [ref=e36]:
          - heading "Payables" [level=1] [ref=e37]
          - paragraph [ref=e38]: Supplier balances and payment records by branch.
        - button "Record external payment" [ref=e40] [cursor=pointer]
      - generic [ref=e41]:
        - heading "Suppliers" [level=2] [ref=e42]
        - generic "Payables filters" [ref=e43]:
          - textbox "Search suppliers" [ref=e48]
          - combobox "Payables branch" [ref=e49] [cursor=pointer]:
            - generic [ref=e50]: North York
          - checkbox "Overdue only" [ref=e53] [cursor=pointer]
          - checkbox "With balance" [ref=e56] [cursor=pointer]
          - button "Clear filters" [ref=e59] [cursor=pointer]
          - generic [ref=e61]:
            - generic [ref=e62]: 5 suppliers
            - button "Columns" [ref=e63] [cursor=pointer]
        - table [ref=e67]:
          - rowgroup [ref=e68]:
            - row "Fresh Valley Foods" [ref=e69]:
              - cell [ref=e70]:
                - link "Fresh Valley Foods" [ref=e72] [cursor=pointer]:
                  - /url: "#payables"
              - cell "$169.79" [ref=e73]
              - cell [ref=e74]:
                - link "View Fresh Valley Foods" [ref=e75] [cursor=pointer]:
                  - /url: "#payables"
              - cell "North York 2026-10-28" [ref=e78]:
                - generic [ref=e79]: North York
                - generic [ref=e80]: 2026-10-28
            - row "Golden Grain Distributors" [ref=e82]:
              - cell [ref=e83]:
                - link "Golden Grain Distributors" [ref=e85] [cursor=pointer]:
                  - /url: "#payables"
              - cell "$842.10" [ref=e86]
              - cell [ref=e87]:
                - link "View Golden Grain Distributors" [ref=e88] [cursor=pointer]:
                  - /url: "#payables"
              - cell "North York 2026-10-18" [ref=e91]:
                - generic [ref=e92]: North York
                - generic [ref=e93]: 2026-10-18
            - row "HomeWare Imports" [ref=e95]:
              - cell [ref=e96]:
                - link "HomeWare Imports" [ref=e98] [cursor=pointer]:
                  - /url: "#payables"
              - cell "$1,260.00" [ref=e99]
              - cell [ref=e100]:
                - link "View HomeWare Imports" [ref=e101] [cursor=pointer]:
                  - /url: "#payables"
              - cell "North York 2026-10-24" [ref=e104]:
                - generic [ref=e105]: North York
                - generic [ref=e106]: 2026-10-24
            - row "Sunrise Beverages" [ref=e108]:
              - cell [ref=e109]:
                - link "Sunrise Beverages" [ref=e111] [cursor=pointer]:
                  - /url: "#payables"
              - cell "$96.40" [ref=e112]
              - cell [ref=e113]:
                - link "View Sunrise Beverages" [ref=e114] [cursor=pointer]:
                  - /url: "#payables"
              - cell "North York 2026-10-13" [ref=e117]:
                - generic [ref=e118]: North York
                - generic [ref=e119]: 2026-10-13
            - row "Corner Spice Co." [ref=e121]:
              - cell [ref=e122]:
                - link "Corner Spice Co." [ref=e124] [cursor=pointer]:
                  - /url: "#payables"
              - cell "$0.00" [ref=e125]
              - cell [ref=e126]:
                - link "View Corner Spice Co." [ref=e127] [cursor=pointer]:
                  - /url: "#payables"
              - cell "North York —" [ref=e130]:
                - generic [ref=e131]: North York
                - generic [ref=e132]: —
      - generic [ref=e134]:
        - generic [ref=e136]:
          - generic [ref=e137]: Supplier
          - combobox "Supplier" [ref=e138] [cursor=pointer]:
            - generic [ref=e139]: Fresh Valley Foods
        - tablist "View" [ref=e142]:
          - tab "Current ledger" [selected] [ref=e143] [cursor=pointer]
          - tab "Month-end summary" [ref=e145] [cursor=pointer]
        - generic [ref=e147]:
          - button "Print summary" [ref=e148] [cursor=pointer]
          - button "Export CSV" [ref=e149] [cursor=pointer]
          - button "Record opening balance, credit, or adjustment" [ref=e150] [cursor=pointer]
          - button "View all suppliers" [ref=e151] [cursor=pointer]
      - generic [ref=e152]:
        - heading "Record supplier dispute" [level=2] [ref=e153]
        - generic [ref=e154]:
          - generic [ref=e155]: Dispute note (required)
          - textbox "Dispute note (required)" [ref=e156]
        - generic [ref=e157]:
          - button "Close" [ref=e158] [cursor=pointer]
          - button "Record dispute" [ref=e159] [cursor=pointer]
      - region "Supplier financial report" [ref=e160]:
        - generic [ref=e161]:
          - heading "Fresh Valley Foods" [level=2] [ref=e162]
          - paragraph [ref=e163]: North York · CAD · As of 2026-10-15
        - generic [ref=e164]:
          - generic [ref=e165]:
            - generic [ref=e166]: Supplier balance
            - strong [ref=e167]: $169.79
          - generic [ref=e168]:
            - generic [ref=e169]: Open invoice
            - strong [ref=e170]: "1"
          - generic [ref=e171]:
            - generic [ref=e172]: Overdue
            - strong [ref=e173]: $0.00
          - generic [ref=e174]:
            - generic [ref=e175]: Unapplied supplier credit
            - strong [ref=e176]: $0.00
        - generic [ref=e177]:
          - generic [ref=e178]:
            - heading "Supplier ledger" [level=2] [ref=e179]
            - button "Columns" [ref=e180] [cursor=pointer]
          - table [ref=e184]:
            - rowgroup [ref=e185]:
              - row [ref=e186]:
                - cell "2026-09-21" [ref=e187]
                - cell "Reference / note FV-20296" [ref=e189]:
                  - text: Reference / note
                  - generic [ref=e190]: FV-20296
                - cell "Amount $37.80" [ref=e191]:
                  - text: Amount
                  - generic [ref=e192]: $37.80
                - cell [ref=e193]:
                  - text: Action
                  - generic [ref=e194]:
                    - button "Record dispute" [ref=e195] [cursor=pointer]
                    - button "Show details" [ref=e196] [cursor=pointer]
              - row [ref=e199]:
                - cell "2026-09-21" [ref=e200]
                - cell "Reference / note FV-20296-PAYMENT" [ref=e202]:
                  - text: Reference / note
                  - generic [ref=e203]: FV-20296-PAYMENT
                - cell "Amount -$37.80" [ref=e204]:
                  - text: Amount
                  - generic [ref=e205]: "-$37.80"
                - cell [ref=e206]:
                  - text: Action
                  - generic [ref=e207]:
                    - button "Record dispute" [ref=e208] [cursor=pointer]
                    - button "Show details" [ref=e209] [cursor=pointer]
              - row [ref=e212]:
                - cell "2026-10-14" [ref=e213]
                - cell "Reference / note FV-20390" [ref=e215]:
                  - text: Reference / note
                  - generic [ref=e216]: FV-20390
                - cell "Amount $181.22" [ref=e217]:
                  - text: Amount
                  - generic [ref=e218]: $181.22
                - cell [ref=e219]:
                  - text: Action
                  - generic [ref=e220]:
                    - button "Record dispute" [ref=e221] [cursor=pointer]
                    - button "Show details" [ref=e222] [cursor=pointer]
              - row [ref=e225]:
                - cell "2026-10-14" [ref=e226]
                - cell "Reference / note FV-20390-PAYMENT" [ref=e228]:
                  - text: Reference / note
                  - generic [ref=e229]: FV-20390-PAYMENT
                - cell "Amount -$11.43" [ref=e230]:
                  - text: Amount
                  - generic [ref=e231]: "-$11.43"
                - cell [ref=e232]:
                  - text: Action
                  - generic [ref=e233]:
                    - button "Record dispute" [ref=e234] [cursor=pointer]
                    - button "Show details" [ref=e235] [cursor=pointer]
        - generic [ref=e238]:
          - heading "Invoice outstanding amounts" [level=2] [ref=e239]
          - table [ref=e241]:
            - rowgroup [ref=e242]:
              - row [ref=e243]:
                - cell "FV-20296" [ref=e244]
                - cell "Branch North York" [ref=e246]
                - cell "Due date 2026-10-05" [ref=e247]:
                  - text: Due date
                  - generic [ref=e248]: 2026-10-05
                - cell [ref=e249]:
                  - text: Details
                  - button "Show details" [ref=e250] [cursor=pointer]
              - row [ref=e253]:
                - cell "FV-20390" [ref=e254]
                - cell "Branch North York" [ref=e256]
                - cell "Due date 2026-10-28" [ref=e257]:
                  - text: Due date
                  - generic [ref=e258]: 2026-10-28
                - cell [ref=e259]:
                  - text: Details
                  - button "Show details" [ref=e260] [cursor=pointer]
          - paragraph [ref=e263]: "Unallocated opening balances and adjustments: $0.00"
```

# Test source

```ts
  1   | import { writeFile } from "node:fs/promises";
  2   | import { expect, test, type Page, type TestInfo } from "@playwright/test";
  3   | import { chooseOption, setBranch, signIn, uploadInvoice } from "./helpers";
  4   | import {
  5   |   appearance,
  6   |   inspect,
  7   |   type C5Inspection,
  8   | } from "../scripts/c5-browser-proof.mjs";
  9   | 
  10  | test.setTimeout(180000);
  11  | test.use({ actionTimeout: 10000 });
  12  | 
  13  | /** Source census covers conditional calls; this checks real rendered states. */
  14  | function audit(page: Page, info: TestInfo) {
  15  |   const inspections: C5Inspection[] = [];
  16  |   return {
  17  |     async check(screen: string, role = "supervisor") {
  18  |       const modal = await page.locator("dialog[open]").count();
  19  |       const variants = modal
  20  |         ? (["en-light"] as const)
  21  |         : (["en-light", "en-dark", "fa-light"] as const);
  22  |       for (const variant of variants) {
  23  |         // A real modal makes the top bar inert. Extra dialogs are measured in
  24  |         // English light; the required C5 dialogs have all-theme coverage in
  25  |         // c5-presentation.spec.ts and the screenshot capture.
  26  |         if (!modal) await appearance(page, variant);
  27  |         const report = await inspect(
  28  |           page,
  29  |           screen,
  30  |           `${info.project.name}-${variant}`,
  31  |           role,
  32  |         );
  33  |         inspections.push(report);
> 34  |         expect.soft(report.failures, `${screen}: ${variant}`).toEqual([]);
      |                                                               ^ Error: Record supplier dispute form: fa-light
  35  |       }
  36  |       if (!modal) await appearance(page, "en-light");
  37  |     },
  38  |     async save() {
  39  |       const output = info.outputPath("button-audit.json");
  40  |       await writeFile(output, JSON.stringify(inspections, null, 2));
  41  |       await info.attach("Rendered button audit", {
  42  |         path: output,
  43  |         contentType: "application/json",
  44  |       });
  45  |     },
  46  |   };
  47  | }
  48  | 
  49  | async function closeDialog(page: Page) {
  50  |   await page.keyboard.press("Escape");
  51  |   await expect(page.locator("dialog[open]")).toHaveCount(0);
  52  | }
  53  | 
  54  | test("C5 button contract covers Suppliers, every supplier tab and item dialogs", async ({
  55  |   page,
  56  | }, info) => {
  57  |   const proof = audit(page, info);
  58  |   try {
  59  |     await signIn(page, "Supervisor");
  60  |     await setBranch(page, "Branch 1");
  61  |     await page.goto("/#suppliers");
  62  |     await proof.check("Suppliers overview");
  63  |     await page
  64  |       .getByRole("button", { name: "Add supplier", exact: true })
  65  |       .click();
  66  |     await proof.check("Add supplier dialog");
  67  |     await closeDialog(page);
  68  |     await page.goto("/#suppliers?name=Fresh%20Valley%20Foods");
  69  |     for (const tab of [
  70  |       "Overview",
  71  |       "Invoices",
  72  |       "Supplier items",
  73  |       "Received",
  74  |       "Returns and credits",
  75  |       "Shorts",
  76  |       "Price alerts",
  77  |       "Payments",
  78  |       "Notes",
  79  |     ]) {
  80  |       await page.getByRole("tab", { name: tab, exact: true }).click();
  81  |       await proof.check(`Supplier: ${tab}`);
  82  |     }
  83  |     await page.getByRole("button", { name: "Edit", exact: true }).click();
  84  |     await proof.check("Edit supplier dialog");
  85  |     await closeDialog(page);
  86  |     await page
  87  |       .getByRole("tab", { name: "Supplier items", exact: true })
  88  |       .click();
  89  |     await page.getByRole("button", { name: "Add item", exact: true }).click();
  90  |     await proof.check("Add supplier item dialog");
  91  |     await closeDialog(page);
  92  |     const item = page
  93  |       .locator(".supplier-items-table tbody tr.supplier-item-history-row")
  94  |       .first();
  95  |     await expect(item).toBeVisible();
  96  |     await expect(item.locator(".row-chevron")).toBeVisible();
  97  |     await item.focus();
  98  |     await page.keyboard.press("Enter");
  99  |     await expect(
  100 |       page.getByRole("dialog", { name: "Price history", exact: true }),
  101 |     ).toBeVisible();
  102 |     await proof.check("Supplier item price history dialog");
  103 |     await closeDialog(page);
  104 |     await item.getByRole("button", { name: "Edit", exact: true }).click();
  105 |     await expect(
  106 |       page.getByRole("dialog", { name: "Edit item", exact: true }),
  107 |     ).toBeVisible();
  108 |     await proof.check("Edit supplier item dialog");
  109 |     await closeDialog(page);
  110 |     await signIn(page, "Floor Worker");
  111 |     await page.goto("/#suppliers");
  112 |     await proof.check("Suppliers overview", "floor_worker");
  113 |     await page.goto("/#suppliers?name=Fresh%20Valley%20Foods");
  114 |     for (const tab of [
  115 |       "Overview",
  116 |       "Invoices",
  117 |       "Supplier items",
  118 |       "Received",
  119 |       "Returns and credits",
  120 |       "Shorts",
  121 |       "Price alerts",
  122 |       "Notes",
  123 |     ]) {
  124 |       await page.getByRole("tab", { name: tab, exact: true }).click();
  125 |       await proof.check(`Supplier: ${tab}`, "floor_worker");
  126 |       await expect(page.locator(".supplier-tab-card .money")).toHaveCount(0);
  127 |     }
  128 |   } finally {
  129 |     await proof.save();
  130 |   }
  131 | });
  132 | 
  133 | test("C5 button contract covers working Settings groups and their dialogs", async ({
  134 |   page,
```