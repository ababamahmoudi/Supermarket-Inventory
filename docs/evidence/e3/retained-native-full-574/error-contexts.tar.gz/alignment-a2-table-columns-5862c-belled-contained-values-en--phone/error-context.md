# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: alignment-a2.spec.ts >> table columns align and phone cards retain labelled contained values (en)
- Location: tests/alignment-a2.spec.ts:5:3

# Error details

```
Error: products (en)

expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 66

- Array []
+ Array [
+   "table 0, phone card 0, column 0: label null/Product",
+   "table 0, phone card 0, column 1: label null/Product Code",
+   "table 0, phone card 0, column 2: label null/Approved price",
+   "table 0, phone card 0, column 3: label null/Details",
+   "table 0, phone card 1, column 0: label null/Product",
+   "table 0, phone card 1, column 1: label null/Product Code",
+   "table 0, phone card 1, column 2: label null/Approved price",
+   "table 0, phone card 1, column 3: label null/Details",
+   "table 0, phone card 2, column 0: label null/Product",
+   "table 0, phone card 2, column 1: label null/Product Code",
+   "table 0, phone card 2, column 2: label null/Approved price",
+   "table 0, phone card 2, column 3: label null/Details",
+   "table 0, phone card 3, column 0: label null/Product",
+   "table 0, phone card 3, column 1: label null/Product Code",
+   "table 0, phone card 3, column 2: label null/Approved price",
+   "table 0, phone card 3, column 3: label null/Details",
+   "table 0, phone card 4, column 0: label null/Product",
+   "table 0, phone card 4, column 1: label null/Product Code",
+   "table 0, phone card 4, column 2: label null/Approved price",
+   "table 0, phone card 4, column 3: label null/Details",
+   "table 0, phone card 5, column 0: label null/Product",
+   "table 0, phone card 5, column 1: label null/Product Code",
+   "table 0, phone card 5, column 2: label null/Approved price",
+   "table 0, phone card 5, column 3: label null/Details",
+   "table 0, phone card 6, column 0: label null/Product",
+   "table 0, phone card 6, column 1: label null/Product Code",
+   "table 0, phone card 6, column 2: label null/Approved price",
+   "table 0, phone card 6, column 3: label null/Details",
+   "table 0, phone card 7, column 0: label null/Product",
+   "table 0, phone card 7, column 1: label null/Product Code",
+   "table 0, phone card 7, column 2: label null/Approved price",
+   "table 0, phone card 7, column 3: label null/Details",
+   "table 0, phone card 8, column 0: label null/Product",
+   "table 0, phone card 8, column 1: label null/Product Code",
+   "table 0, phone card 8, column 2: label null/Approved price",
+   "table 0, phone card 8, column 3: label null/Details",
+   "table 0, phone card 9, column 0: label null/Product",
+   "table 0, phone card 9, column 1: label null/Product Code",
+   "table 0, phone card 9, column 2: label null/Approved price",
+   "table 0, phone card 9, column 3: label null/Details",
+   "table 0, phone card 10, column 0: label null/Product",
+   "table 0, phone card 10, column 1: label null/Product Code",
+   "table 0, phone card 10, column 2: label null/Approved price",
+   "table 0, phone card 10, column 3: label null/Details",
+   "table 0, phone card 11, column 0: label null/Product",
+   "table 0, phone card 11, column 1: label null/Product Code",
+   "table 0, phone card 11, column 2: label null/Approved price",
+   "table 0, phone card 11, column 3: label null/Details",
+   "table 0, phone card 12, column 0: label null/Product",
+   "table 0, phone card 12, column 1: label null/Product Code",
+   "table 0, phone card 12, column 2: label null/Approved price",
+   "table 0, phone card 12, column 3: label null/Details",
+   "table 0, phone card 13, column 0: label null/Product",
+   "table 0, phone card 13, column 1: label null/Product Code",
+   "table 0, phone card 13, column 2: label null/Approved price",
+   "table 0, phone card 13, column 3: label null/Details",
+   "table 0, phone card 14, column 0: label null/Product",
+   "table 0, phone card 14, column 1: label null/Product Code",
+   "table 0, phone card 14, column 2: label null/Approved price",
+   "table 0, phone card 14, column 3: label null/Details",
+   "table 0, phone card 15, column 0: label null/Product",
+   "table 0, phone card 15, column 1: label null/Product Code",
+   "table 0, phone card 15, column 2: label null/Approved price",
+   "table 0, phone card 15, column 3: label null/Details",
+ ]
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=e5]:
    - banner [ref=e6]:
      - button "Open menu" [ref=e7] [cursor=pointer]
      - combobox "Location" [ref=e11] [cursor=pointer]:
        - generic [ref=e16]: North York
      - button "Notifications, 5 unread" [ref=e19] [cursor=pointer]:
        - generic [ref=e20]: "5"
      - button "User menu" [ref=e25] [cursor=pointer]:
        - generic [aria-hidden] [ref=e27]: DM
      - button "More" [ref=e28] [cursor=pointer]
    - main [ref=e34]:
      - generic [ref=e35]:
        - generic [ref=e36]:
          - generic [ref=e37]:
            - heading "Products" [level=1] [ref=e38]
            - paragraph [ref=e39]: Approved prices, pending changes and branch details in one catalog.
          - button "Add product" [ref=e41] [cursor=pointer]
        - generic [ref=e42]:
          - generic [ref=e43]:
            - searchbox "Search products" [ref=e48]
            - combobox "Pricing category" [ref=e49] [cursor=pointer]:
              - generic [ref=e50]: All pricing categories
            - combobox "AI category" [ref=e53] [cursor=pointer]:
              - generic [ref=e54]: All AI categories
            - combobox "Status" [ref=e57] [cursor=pointer]:
              - generic [ref=e58]: All statuses
            - combobox "Supplier" [ref=e61] [cursor=pointer]:
              - generic [ref=e62]: All suppliers
            - checkbox "Has pending price" [ref=e65] [cursor=pointer]
            - checkbox "Has offer" [ref=e68] [cursor=pointer]
            - checkbox "Manual prices" [ref=e71] [cursor=pointer]
            - checkbox "On sale" [ref=e74] [cursor=pointer]
            - button "Clear filters" [ref=e77] [cursor=pointer]
            - generic [ref=e79]:
              - generic [ref=e80]: 16 products
              - button "Columns" [ref=e81] [cursor=pointer]
          - generic [ref=e85]:
            - table [ref=e87]:
              - rowgroup [ref=e88]:
                - row [ref=e89]:
                  - cell "Basmati Rice 4.5 kg برنج باسماتی ۴٫۵ کیلوگرمی 4.5 kg" [ref=e90]:
                    - link "Basmati Rice 4.5 kg" [ref=e91] [cursor=pointer]:
                      - /url: "#product?code=0001"
                      - strong [ref=e92]:
                        - generic [ref=e94]:
                          - text: Basmati Rice
                          - generic [ref=e95]: 4.5 kg
                    - paragraph [ref=e96]:
                      - generic [ref=e98]:
                        - text: برنج باسماتی
                        - generic [ref=e99]: ۴٫۵ کیلوگرمی
                    - paragraph [ref=e100]:
                      - generic [ref=e101]: 4.5 kg
                  - cell "$23.99" [ref=e104]
                  - cell [ref=e107]:
                    - link "Open Basmati Rice 4.5 kg" [ref=e108] [cursor=pointer]:
                      - /url: "#product?code=0001"
                  - cell "0001 Approved" [ref=e111]:
                    - generic [ref=e112]: "0001"
                    - generic [ref=e114]: Approved
                - row [ref=e117]:
                  - cell "Black Tea 450 g چای سیاه ۴۵۰ گرمی 450 g" [ref=e118]:
                    - link "Black Tea 450 g" [ref=e119] [cursor=pointer]:
                      - /url: "#product?code=0004"
                      - strong [ref=e120]:
                        - generic [ref=e122]:
                          - text: Black Tea
                          - generic [ref=e123]: 450 g
                    - paragraph [ref=e124]:
                      - generic [ref=e126]:
                        - text: چای سیاه
                        - generic [ref=e127]: ۴۵۰ گرمی
                    - paragraph [ref=e128]:
                      - generic [ref=e129]: 450 g
                  - cell "$6.49" [ref=e132]
                  - cell [ref=e135]:
                    - link "Open Black Tea 450 g" [ref=e136] [cursor=pointer]:
                      - /url: "#product?code=0004"
                  - cell "0004 Approved" [ref=e139]:
                    - generic [ref=e140]: "0004"
                    - generic [ref=e142]: Approved
                - row [ref=e145]:
                  - cell "Bulk Almonds بادام فله Sold by weight" [ref=e146]:
                    - link "Bulk Almonds" [ref=e147] [cursor=pointer]:
                      - /url: "#product?code=0016"
                      - strong [ref=e148]:
                        - generic [ref=e149]: Bulk Almonds
                    - paragraph [ref=e150]:
                      - generic [ref=e151]: بادام فله
                    - paragraph [ref=e152]: Sold by weight
                  - cell "$7.49/lb $16.51/kg" [ref=e153]:
                    - generic [ref=e155]:
                      - generic [ref=e156]: $7.49/lb
                      - generic [ref=e157]: $16.51/kg
                  - cell [ref=e158]:
                    - link "Open Bulk Almonds" [ref=e159] [cursor=pointer]:
                      - /url: "#product?code=0016"
                  - cell "0016 Approved" [ref=e162]:
                    - generic [ref=e163]: "0016"
                    - generic [ref=e165]: Approved
                - row [ref=e168]:
                  - cell "Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی 400 g" [ref=e169]:
                    - link "Canned Fava Beans 400 g" [ref=e170] [cursor=pointer]:
                      - /url: "#product?code=0002"
                      - strong [ref=e171]:
                        - generic [ref=e173]:
                          - text: Canned Fava Beans
                          - generic [ref=e174]: 400 g
                    - paragraph [ref=e175]:
                      - generic [ref=e177]:
                        - text: باقالا کنسرو شده
                        - generic [ref=e178]: ۴۰۰ گرمی
                    - paragraph [ref=e179]:
                      - generic [ref=e180]: 400 g
                  - cell "$1.49" [ref=e183]
                  - cell [ref=e186]:
                    - link "Open Canned Fava Beans 400 g" [ref=e187] [cursor=pointer]:
                      - /url: "#product?code=0002"
                  - cell "0002 Approved" [ref=e190]:
                    - generic [ref=e191]: "0002"
                    - generic [ref=e193]: Approved
                - row [ref=e196]:
                  - cell "Dried Barberries 100 g زرشک خشک ۱۰۰ گرمی 100 g" [ref=e197]:
                    - link "Dried Barberries 100 g" [ref=e198] [cursor=pointer]:
                      - /url: "#product?code=0015"
                      - strong [ref=e199]:
                        - generic [ref=e201]:
                          - text: Dried Barberries
                          - generic [ref=e202]: 100 g
                    - paragraph [ref=e203]:
                      - generic [ref=e205]:
                        - text: زرشک خشک
                        - generic [ref=e206]: ۱۰۰ گرمی
                    - paragraph [ref=e207]:
                      - generic [ref=e208]: 100 g
                  - cell "—" [ref=e211]
                  - cell [ref=e213]:
                    - link "Open Dried Barberries 100 g" [ref=e214] [cursor=pointer]:
                      - /url: "#product?code=0015"
                  - cell "0015 Pending $5.49" [ref=e217]:
                    - generic [ref=e218]: "0015"
                    - generic [ref=e222]:
                      - text: Pending
                      - generic [ref=e223]: $5.49
                - row [ref=e224]:
                  - cell "Dried Red Kidney Beans 900 g لوبیا قرمز ۹۰۰ گرمی 900 g" [ref=e225]:
                    - link "Dried Red Kidney Beans 900 g" [ref=e226] [cursor=pointer]:
                      - /url: "#product?code=0007"
                      - strong [ref=e227]:
                        - generic [ref=e229]:
                          - text: Dried Red Kidney Beans
                          - generic [ref=e230]: 900 g
                    - paragraph [ref=e231]:
                      - generic [ref=e233]:
                        - text: لوبیا قرمز
                        - generic [ref=e234]: ۹۰۰ گرمی
                    - paragraph [ref=e235]:
                      - generic [ref=e236]: 900 g
                  - cell "$3.99" [ref=e239]
                  - cell [ref=e242]:
                    - link "Open Dried Red Kidney Beans 900 g" [ref=e243] [cursor=pointer]:
                      - /url: "#product?code=0007"
                  - cell "0007 Approved 2 for $7.00" [ref=e246]:
                    - generic [ref=e247]: "0007"
                    - generic [ref=e250]:
                      - generic [ref=e251]: Approved
                      - generic [ref=e252]: 2 for $7.00
                - row [ref=e254]:
                  - cell "Fruit Soda 6-pack نوشابه میوه‌ای بسته ۶ عددی 6 x 355 ml" [ref=e255]:
                    - link "Fruit Soda 6-pack" [ref=e256] [cursor=pointer]:
                      - /url: "#product?code=0010"
                      - strong [ref=e257]:
                        - generic [ref=e258]: Fruit Soda 6-pack
                    - paragraph [ref=e259]:
                      - generic [ref=e260]: نوشابه میوه‌ای بسته ۶ عددی
                    - paragraph [ref=e261]:
                      - generic [ref=e263]:
                        - text: 6 x
                        - generic [ref=e264]: 355 ml
                  - cell "$4.99" [ref=e265]
                  - cell [ref=e268]:
                    - link "Open Fruit Soda 6-pack" [ref=e269] [cursor=pointer]:
                      - /url: "#product?code=0010"
                  - cell "0010 Approved" [ref=e272]:
                    - generic [ref=e273]: "0010"
                    - generic [ref=e275]: Approved
                - row [ref=e278]:
                  - cell "Ground Sumac 100 g سماق ۱۰۰ گرمی 100 g" [ref=e279]:
                    - link "Ground Sumac 100 g" [ref=e280] [cursor=pointer]:
                      - /url: "#product?code=0005"
                      - strong [ref=e281]:
                        - generic [ref=e283]:
                          - text: Ground Sumac
                          - generic [ref=e284]: 100 g
                    - paragraph [ref=e285]:
                      - generic [ref=e287]:
                        - text: سماق
                        - generic [ref=e288]: ۱۰۰ گرمی
                    - paragraph [ref=e289]:
                      - generic [ref=e290]: 100 g
                  - cell "$1.99" [ref=e293]
                  - cell [ref=e296]:
                    - link "Open Ground Sumac 100 g" [ref=e297] [cursor=pointer]:
                      - /url: "#product?code=0005"
                  - cell "0005 Approved 3 for $5.00" [ref=e300]:
                    - generic [ref=e301]: "0005"
                    - generic [ref=e304]:
                      - generic [ref=e305]: Approved
                      - generic [ref=e306]: 3 for $5.00
                - row [ref=e308]:
                  - cell "Kitchen Sponge 3-pack اسفنج ظرفشویی بسته ۳ عددی 3 pcs" [ref=e309]:
                    - link "Kitchen Sponge 3-pack" [ref=e310] [cursor=pointer]:
                      - /url: "#product?code=0014"
                      - strong [ref=e311]:
                        - generic [ref=e312]: Kitchen Sponge 3-pack
                    - paragraph [ref=e313]:
                      - generic [ref=e314]: اسفنج ظرفشویی بسته ۳ عددی
                    - paragraph [ref=e315]:
                      - generic [ref=e316]: 3 pcs
                  - cell "$2.49" [ref=e317]
                  - cell [ref=e320]:
                    - link "Open Kitchen Sponge 3-pack" [ref=e321] [cursor=pointer]:
                      - /url: "#product?code=0014"
                  - cell "0014 Approved" [ref=e324]:
                    - generic [ref=e325]: "0014"
                    - generic [ref=e327]: Approved
                - row [ref=e330]:
                  - cell "Lavash Bread 500 g نان لواش ۵۰۰ گرمی 500 g" [ref=e331]:
                    - link "Lavash Bread 500 g" [ref=e332] [cursor=pointer]:
                      - /url: "#product?code=0006"
                      - strong [ref=e333]:
                        - generic [ref=e335]:
                          - text: Lavash Bread
                          - generic [ref=e336]: 500 g
                    - paragraph [ref=e337]:
                      - generic [ref=e339]:
                        - text: نان لواش
                        - generic [ref=e340]: ۵۰۰ گرمی
                    - paragraph [ref=e341]:
                      - generic [ref=e342]: 500 g
                  - cell "$1.99" [ref=e345]
                  - cell [ref=e348]:
                    - link "Open Lavash Bread 500 g" [ref=e349] [cursor=pointer]:
                      - /url: "#product?code=0006"
                  - cell "0006 Pending $2.99 3 for $5.00" [ref=e352]:
                    - generic [ref=e353]: "0006"
                    - generic [ref=e356]:
                      - generic [ref=e357]:
                        - text: Pending
                        - generic [ref=e358]: $2.99
                      - generic [ref=e359]: 3 for $5.00
                - row [ref=e361]:
                  - cell "Potato Chips 150 g چیپس سیب‌زمینی ۱۵۰ گرمی 150 g" [ref=e362]:
                    - link "Potato Chips 150 g" [ref=e363] [cursor=pointer]:
                      - /url: "#product?code=0009"
                      - strong [ref=e364]:
                        - generic [ref=e366]:
                          - text: Potato Chips
                          - generic [ref=e367]: 150 g
                    - paragraph [ref=e368]:
                      - generic [ref=e370]:
                        - text: چیپس سیب‌زمینی
                        - generic [ref=e371]: ۱۵۰ گرمی
                    - paragraph [ref=e372]:
                      - generic [ref=e373]: 150 g
                  - cell "$2.99" [ref=e376]
                  - cell [ref=e379]:
                    - link "Open Potato Chips 150 g" [ref=e380] [cursor=pointer]:
                      - /url: "#product?code=0009"
                  - cell "0009 Approved 2 for $5.00" [ref=e383]:
                    - generic [ref=e384]: "0009"
                    - generic [ref=e387]:
                      - generic [ref=e388]: Approved
                      - generic [ref=e389]: 2 for $5.00
                - row [ref=e391]:
                  - cell "Rice Cooker 1.8 L پلوپز ۱٫۸ لیتری 1.8 L" [ref=e392]:
                    - link "Rice Cooker 1.8 L" [ref=e393] [cursor=pointer]:
                      - /url: "#product?code=0013"
                      - strong [ref=e394]:
                        - generic [ref=e396]:
                          - text: Rice Cooker
                          - generic [ref=e397]: 1.8 L
                    - paragraph [ref=e398]:
                      - generic [ref=e400]:
                        - text: پلوپز
                        - generic [ref=e401]: ۱٫۸ لیتری
                    - paragraph [ref=e402]:
                      - generic [ref=e403]: 1.8 L
                  - cell "$52.49" [ref=e406]
                  - cell [ref=e409]:
                    - link "Open Rice Cooker 1.8 L" [ref=e410] [cursor=pointer]:
                      - /url: "#product?code=0013"
                  - cell "0013 Approved" [ref=e413]:
                    - generic [ref=e414]: "0013"
                    - generic [ref=e416]: Approved
                - row [ref=e419]:
                  - cell "Sour Cherry Juice 1 L آب آلبالو ۱ لیتری 1 L" [ref=e420]:
                    - link "Sour Cherry Juice 1 L" [ref=e421] [cursor=pointer]:
                      - /url: "#product?code=0003"
                      - strong [ref=e422]:
                        - generic [ref=e424]:
                          - text: Sour Cherry Juice
                          - generic [ref=e425]: 1 L
                    - paragraph [ref=e426]:
                      - generic [ref=e428]:
                        - text: آب آلبالو
                        - generic [ref=e429]: ۱ لیتری
                    - paragraph [ref=e430]:
                      - generic [ref=e431]: 1 L
                  - cell "$2.99" [ref=e434]
                  - cell [ref=e437]:
                    - link "Open Sour Cherry Juice 1 L" [ref=e438] [cursor=pointer]:
                      - /url: "#product?code=0003"
                  - cell "0003 Approved 2 for $5.00" [ref=e441]:
                    - generic [ref=e442]: "0003"
                    - generic [ref=e445]:
                      - generic [ref=e446]: Approved
                      - generic [ref=e447]: 2 for $5.00
                - row [ref=e449]:
                  - cell "Stainless Steel Pot 24 cm قابلمه استیل ۲۴ سانتی‌متری 24 cm" [ref=e450]:
                    - link "Stainless Steel Pot 24 cm" [ref=e451] [cursor=pointer]:
                      - /url: "#product?code=0012"
                      - strong [ref=e452]:
                        - generic [ref=e453]: Stainless Steel Pot 24 cm
                    - paragraph [ref=e454]:
                      - generic [ref=e455]: قابلمه استیل ۲۴ سانتی‌متری
                    - paragraph [ref=e456]:
                      - generic [ref=e457]: 24 cm
                  - cell "$16.99 Sale Regular $20.99 Until Oct 25" [ref=e458]:
                    - generic [ref=e459]:
                      - generic [ref=e460]: $16.99
                      - generic [ref=e462]:
                        - generic [ref=e463]: Sale
                        - deletion [ref=e464]: Regular $20.99
                        - generic [ref=e465]: Until Oct 25
                  - cell [ref=e466]:
                    - link "Open Stainless Steel Pot 24 cm" [ref=e467] [cursor=pointer]:
                      - /url: "#product?code=0012"
                  - cell "0012 Approved" [ref=e470]:
                    - generic [ref=e471]: "0012"
                    - generic [ref=e473]: Approved
                - row [ref=e476]:
                  - cell "Sunflower Oil 1.8 L روغن آفتابگردان ۱٫۸ لیتری 1.8 L" [ref=e477]:
                    - link "Sunflower Oil 1.8 L" [ref=e478] [cursor=pointer]:
                      - /url: "#product?code=0008"
                      - strong [ref=e479]:
                        - generic [ref=e481]:
                          - text: Sunflower Oil
                          - generic [ref=e482]: 1.8 L
                    - paragraph [ref=e483]:
                      - generic [ref=e485]:
                        - text: روغن آفتابگردان
                        - generic [ref=e486]: ۱٫۸ لیتری
                    - paragraph [ref=e487]:
                      - generic [ref=e488]: 1.8 L
                  - cell "$9.49 Sale requested $7.99 · Oct 15–Oct 28 Waiting for approval" [ref=e491]:
                    - generic [ref=e492]:
                      - generic [ref=e493]: $9.49
                      - generic [ref=e494]:
                        - generic [ref=e495]:
                          - text: Sale requested
                          - generic [ref=e496]: $7.99
                          - text: ·
                          - generic [ref=e497]: Oct 15–Oct 28
                        - generic [ref=e498]: Waiting for approval
                  - cell [ref=e499]:
                    - link "Open Sunflower Oil 1.8 L" [ref=e500] [cursor=pointer]:
                      - /url: "#product?code=0008"
                  - cell "0008 Approved" [ref=e503]:
                    - generic [ref=e504]: "0008"
                    - generic [ref=e506]: Approved
                - row [ref=e509]:
                  - cell "Tea Glass Set (6 pcs) ست استکان چای (۶ عددی) 6 pcs" [ref=e510]:
                    - link "Tea Glass Set (6 pcs)" [ref=e511] [cursor=pointer]:
                      - /url: "#product?code=0011"
                      - strong [ref=e512]:
                        - generic [ref=e513]: Tea Glass Set (6 pcs)
                    - paragraph [ref=e514]:
                      - generic [ref=e515]: ست استکان چای (۶ عددی)
                    - paragraph [ref=e516]:
                      - generic [ref=e517]: 6 pcs
                  - cell "$8.99" [ref=e518]
                  - cell [ref=e521]:
                    - link "Open Tea Glass Set (6 pcs)" [ref=e522] [cursor=pointer]:
                      - /url: "#product?code=0011"
                  - cell "0011 Approved" [ref=e525]:
                    - generic [ref=e526]: "0011"
                    - generic [ref=e528]: Approved
            - generic [ref=e531]:
              - button "Previous" [disabled] [ref=e532]
              - generic [ref=e533]: Page 1 of 1 · 16 products
              - button "Next" [disabled] [ref=e534]
```

# Test source

```ts
  83  |             )
  84  |               continue;
  85  |             if (stacked) {
  86  |               cards++;
  87  |               const bounds = row.getBoundingClientRect();
  88  |               for (const [columnIndex, cell] of [...row.children].entries()) {
  89  |                 const rect = cell.getBoundingClientRect();
  90  |                 const error = Math.max(
  91  |                   0,
  92  |                   bounds.left - rect.left,
  93  |                   rect.right - bounds.right,
  94  |                   cell.scrollWidth - cell.clientWidth,
  95  |                 );
  96  |                 maxError = Math.max(maxError, error);
  97  |                 cells++;
  98  |                 if (error > 2)
  99  |                   failures.push(
  100 |                     `table ${tableIndex}, phone card ${rowIndex}, column ${columnIndex}: containment ${error}px`,
  101 |                   );
  102 |                 const label = cell.getAttribute("data-column-label");
  103 |                 const headerLabel = headers[columnIndex].cloneNode(
  104 |                   true,
  105 |                 ) as HTMLElement;
  106 |                 for (const decoration of headerLabel.querySelectorAll(
  107 |                   '[aria-hidden="true"]',
  108 |                 ))
  109 |                   decoration.remove();
  110 |                 const expectedLabel = headerLabel.textContent
  111 |                   ?.replace(/\s+/g, " ")
  112 |                   .replace(/\s*[↑↓]$/, "")
  113 |                   .trim();
  114 |                 if (expectedLabel && label !== expectedLabel)
  115 |                   failures.push(
  116 |                     `table ${tableIndex}, phone card ${rowIndex}, column ${columnIndex}: label ${label}/${expectedLabel}`,
  117 |                   );
  118 |                 if (
  119 |                   columnIndex > 0 &&
  120 |                   label &&
  121 |                   labelledCard &&
  122 |                   getComputedStyle(cell, "::before").content !==
  123 |                     JSON.stringify(label)
  124 |                 )
  125 |                   failures.push(
  126 |                     `table ${tableIndex}, phone card ${rowIndex}, column ${columnIndex}: missing visible ${label} label`,
  127 |                   );
  128 |                 if (columnIndex > 0 && !labelledCard) {
  129 |                   const captionSelector =
  130 |                     "label,.invoice-line-price,.invoice-line-mobile-caption,.ui-checked-control";
  131 |                   const captions = [
  132 |                     ...(cell.matches(captionSelector) ? [cell] : []),
  133 |                     ...cell.querySelectorAll(captionSelector),
  134 |                   ];
  135 |                   if (
  136 |                     !captions.some(
  137 |                       (caption) => caption.getBoundingClientRect().height > 0,
  138 |                     )
  139 |                   )
  140 |                     failures.push(
  141 |                       `table ${tableIndex}, phone card ${rowIndex}, column ${columnIndex}: missing visible field or price caption`,
  142 |                     );
  143 |                   const totalCaption = cell.querySelector(
  144 |                     ".invoice-line-mobile-caption",
  145 |                   );
  146 |                   if (
  147 |                     totalCaption &&
  148 |                     totalCaption.textContent?.trim() !== expectedLabel
  149 |                   )
  150 |                     failures.push(
  151 |                       `table ${tableIndex}, phone card ${rowIndex}, column ${columnIndex}: caption ${totalCaption.textContent}/${expectedLabel}`,
  152 |                     );
  153 |                 }
  154 |               }
  155 |               continue;
  156 |             }
  157 |             for (const [columnIndex, header] of headers.entries()) {
  158 |               const cell = row.children[columnIndex];
  159 |               const h = header.getBoundingClientRect();
  160 |               const b = cell.getBoundingClientRect();
  161 |               const hs = getComputedStyle(header);
  162 |               const bs = getComputedStyle(cell);
  163 |               const error = Math.max(
  164 |                 Math.abs(h.left - b.left),
  165 |                 Math.abs(h.right - b.right),
  166 |               );
  167 |               maxError = Math.max(maxError, error);
  168 |               cells++;
  169 |               if (
  170 |                 error > 2 ||
  171 |                 hs.paddingInlineStart !== bs.paddingInlineStart ||
  172 |                 hs.paddingInlineEnd !== bs.paddingInlineEnd ||
  173 |                 hs.textAlign !== bs.textAlign
  174 |               )
  175 |                 failures.push(
  176 |                   `table ${tableIndex}, row ${rowIndex}, column ${columnIndex}: edges ${error}px; alignment ${hs.textAlign}/${bs.textAlign}; padding ${hs.paddingInlineStart}/${bs.paddingInlineStart}`,
  177 |                 );
  178 |             }
  179 |           }
  180 |         }
  181 |         return { tables: tables.length, cells, cards, maxError, failures };
  182 |       });
> 183 |       expect(metrics.failures, `${route} (${language})`).toEqual([]);
      |                                                          ^ Error: products (en)
  184 |       expect(metrics.maxError).toBeLessThanOrEqual(2);
  185 |       if (path === "invoices") expect(metrics.cells).toBeGreaterThanOrEqual(30);
  186 |       report.push({
  187 |         route,
  188 |         tables: metrics.tables,
  189 |         cells: metrics.cells,
  190 |         maxError: metrics.maxError,
  191 |         cards: metrics.cards,
  192 |       });
  193 |     }
  194 |     expect(report.reduce((sum, item) => sum + item.cells, 0)).toBeGreaterThan(
  195 |       100,
  196 |     );
  197 |     if (page.viewportSize()!.width < 760)
  198 |       expect(report.reduce((sum, item) => sum + item.cards, 0)).toBeGreaterThan(
  199 |         0,
  200 |       );
  201 |     await testInfo.attach(`alignment-${language}.json`, {
  202 |       body: JSON.stringify(report, null, 2),
  203 |       contentType: "application/json",
  204 |     });
  205 |   });
  206 | }
  207 | 
  208 | test("product editor is centered with focus trapped, Escape and backdrop restore focus", async ({
  209 |   page,
  210 | }) => {
  211 |   await signIn(page, "Supervisor");
  212 |   await page.goto("/#product?code=0009");
  213 |   const trigger = page.getByRole("button", {
  214 |     name: "Edit Potato Chips 150 g",
  215 |     exact: true,
  216 |   });
  217 |   await trigger.click();
  218 |   const dialog = page.getByRole("dialog", {
  219 |     name: "Edit product",
  220 |     exact: true,
  221 |   });
  222 |   await expect(dialog).toBeVisible();
  223 |   const metrics = await dialog.evaluate((node) => {
  224 |     const r = node.getBoundingClientRect();
  225 |     return {
  226 |       x: Math.abs(r.x + r.width / 2 - innerWidth / 2),
  227 |       y: Math.abs(r.y + r.height / 2 - innerHeight / 2),
  228 |       focused: node.contains(document.activeElement),
  229 |     };
  230 |   });
  231 |   expect(metrics.x).toBeLessThanOrEqual(2);
  232 |   expect(metrics.y).toBeLessThanOrEqual(2);
  233 |   expect(metrics.focused).toBe(true);
  234 |   for (let i = 0; i < 20; i++) await page.keyboard.press("Tab");
  235 |   expect(
  236 |     await dialog.evaluate((node) => node.contains(document.activeElement)),
  237 |   ).toBe(true);
  238 |   await page.keyboard.press("Escape");
  239 |   await expect(dialog).not.toBeVisible();
  240 |   await expect(trigger).toBeFocused();
  241 |   await trigger.click();
  242 |   await page.mouse.click(2, 2);
  243 |   await expect(dialog).not.toBeVisible();
  244 |   await expect(trigger).toBeFocused();
  245 | });
  246 | 
```