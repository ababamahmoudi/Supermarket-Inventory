# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: catalog-a2.spec.ts >> Lookup Change price defaults to all stores and records the signed-in Supervisor
- Location: tests/catalog-a2.spec.ts:91:1

# Error details

```
Error: expect(received).toMatchObject(expected)

- Expected  - 5
+ Received  + 5

  Object {
-   "action": "Set regular price",
+   "action": "Create price update",
    "actor_username": "manager",
-   "branch": "all",
+   "branch": "Branch 3",
    "by": "Demo Manager",
-   "entity_id": "0009",
-   "entity_type": "product",
-   "reversible": true,
+   "entity_id": "price-update-9af39fc8-5853-41e3-8b19-15f5e8e75ebc",
+   "entity_type": "price_update",
+   "reversible": false,
  }
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - complementary "Main menu" [ref=e5]:
    - generic [ref=e6]:
      - img "Super Arzon" [ref=e9]
      - generic [ref=e10]: Super Arzon
    - navigation "Pages" [ref=e11]:
      - generic [ref=e12]:
        - button "Daily" [expanded] [ref=e13] [cursor=pointer]
        - generic [ref=e17]:
          - link "Lookup" [ref=e18] [cursor=pointer]:
            - /url: "#lookup"
          - link "Invoices" [ref=e23] [cursor=pointer]:
            - /url: "#invoices"
          - link "Received" [ref=e28] [cursor=pointer]:
            - /url: "#received"
          - link "Returns" [ref=e35] [cursor=pointer]:
            - /url: "#returns"
          - link "Price updates" [ref=e40] [cursor=pointer]:
            - /url: "#price-updates"
            - generic [ref=e46]: "1"
          - link "Labels" [ref=e47] [cursor=pointer]:
            - /url: "#labels"
          - link "Date tracking" [ref=e52] [cursor=pointer]:
            - /url: "#expiry"
          - link "Notes" [ref=e57] [cursor=pointer]:
            - /url: "#notes"
          - link "Branch requests" [ref=e61] [cursor=pointer]:
            - /url: "#requests"
      - button "Catalog" [ref=e67] [cursor=pointer]
      - button "Manager" [ref=e72] [cursor=pointer]
      - button "Admin" [ref=e77] [cursor=pointer]
    - button "User menu" [ref=e82] [cursor=pointer]:
      - generic [ref=e83]:
        - generic [aria-hidden] [ref=e84]: DM
        - generic [ref=e85]:
          - strong [ref=e86]: Demo Manager
          - generic [ref=e87]: Manager
  - generic [ref=e88]:
    - banner [ref=e89]:
      - button "Collapse sidebar" [expanded] [ref=e90] [cursor=pointer]
      - navigation "Breadcrumbs" [ref=e94]:
        - link "Richmond Hill" [ref=e95] [cursor=pointer]:
          - /url: "#dashboard"
        - link "Lookup" [ref=e98] [cursor=pointer]:
          - /url: "#lookup"
      - search [ref=e99]:
        - textbox "Search all products" [ref=e103]:
          - /placeholder: Search products
        - generic [aria-hidden] [ref=e104]: /
      - combobox "Location" [ref=e105] [cursor=pointer]:
        - generic [ref=e110]: Richmond Hill
      - button "Switch to Persian" [ref=e113] [cursor=pointer]: فا
      - button "Switch to dark theme" [ref=e114] [cursor=pointer]
      - button "Comfortable text size" [ref=e117] [cursor=pointer]:
        - generic [aria-hidden] [ref=e118]: Aa
      - button "Notifications, 8 unread" [ref=e119] [cursor=pointer]:
        - generic [ref=e120]: "8"
      - button "Demo" [ref=e125] [cursor=pointer]
    - main [ref=e128]:
      - generic [ref=e129]:
        - generic [ref=e131]:
          - heading "Cashier lookup" [level=1] [ref=e132]
          - paragraph [ref=e133]: Find the approved price to charge now. Search in English or Persian, or scan a barcode.
        - generic [ref=e134]:
          - generic [ref=e135]: Search products
          - generic [ref=e136]:
            - combobox "Search products" [expanded] [ref=e140]: "0009"
            - button "Scan barcode" [ref=e141] [cursor=pointer]
          - generic [ref=e147]:
            - group "AI category" [ref=e148]:
              - button "All" [pressed] [ref=e149] [cursor=pointer]
              - button "Beans & legumes" [ref=e150] [cursor=pointer]
              - button "Bread & bakery" [ref=e151] [cursor=pointer]
              - button "Cleaning" [ref=e152] [cursor=pointer]
              - button "More categories" [ref=e153] [cursor=pointer]: More
            - generic [ref=e156]: 1 product
            - paragraph [ref=e157]: Use ↑ ↓ and Enter to select a product.
            - button "Clear filters" [ref=e158] [cursor=pointer]
        - generic [ref=e159]:
          - generic [ref=e160]:
            - generic [ref=e161]:
              - heading "Potato Chips 150 g" [level=2] [ref=e162]:
                - generic [ref=e164]:
                  - text: Potato Chips
                  - generic [ref=e165]: 150 g
              - paragraph [ref=e166]:
                - generic [ref=e168]:
                  - text: چیپس سیب‌زمینی
                  - generic [ref=e169]: ۱۵۰ گرمی
              - paragraph [ref=e170]:
                - generic [ref=e171]: Product Code 0009
                - generic [ref=e172]: 150 g
            - generic [ref=e175]:
              - button "Change price" [ref=e176] [cursor=pointer]
              - button "Edit Potato Chips 150 g" [ref=e177] [cursor=pointer]: Edit
              - button "Product actions" [ref=e178] [cursor=pointer]
          - generic [ref=e184]:
            - strong [ref=e185]: $3.29
            - generic [ref=e186]:
              - paragraph [ref=e187]: Selling price
              - paragraph [ref=e188]: Before tax
              - generic [ref=e189]: Manual price
          - generic [ref=e190]:
            - paragraph [ref=e191]: Rule price $2.99 · Manual price $3.29
            - paragraph [ref=e192]:
              - text: "Margin %:"
              - generic [ref=e193]: 51.37%
          - region "Dates" [ref=e194]:
            - paragraph [ref=e195]: No open dates in this location.
            - generic [ref=e196]: Last received No deliveries yet
          - generic [ref=e204]: Taxable
        - generic [ref=e206]:
          - heading "Search results" [level=2] [ref=e207]
          - listbox "Product results" [ref=e208]:
            - option "Potato Chips 150 g چیپس سیب‌زمینی ۱۵۰ گرمی Product Code 0009 $3.29 Manual price Taxable" [selected] [ref=e209] [cursor=pointer]:
              - generic [ref=e210]:
                - strong [ref=e211]:
                  - generic [ref=e213]:
                    - text: Potato Chips
                    - generic [ref=e214]: 150 g
                - generic [ref=e215]:
                  - generic [ref=e217]:
                    - text: چیپس سیب‌زمینی
                    - generic [ref=e218]: ۱۵۰ گرمی
                  - generic [ref=e219]: Product Code 0009
              - generic [ref=e220]:
                - generic [ref=e221]: $3.29
                - generic [ref=e222]:
                  - generic [ref=e223]: Manual price
                  - generic [ref=e224]: Taxable
```

# Test source

```ts
  24  |     name: "Change price",
  25  |     exact: true,
  26  |   });
  27  |   await editor.getByRole("radio", { name: /^New regular price/ }).click();
  28  |   return editor;
  29  | }
  30  | 
  31  | test("Supervisor product page uses own route, Back link and shared editor", async ({
  32  |   page,
  33  | }) => {
  34  |   await signIn(page, "Supervisor");
  35  |   await page.goto("/#products");
  36  |   await page
  37  |     .getByRole("main")
  38  |     .getByLabel("Search products", { exact: true })
  39  |     .fill("0009");
  40  |   await page
  41  |     .getByRole("link", { name: "Potato Chips 150 g", exact: true })
  42  |     .click();
  43  |   await expect(page).toHaveURL(/#product\?code=0009$/);
  44  |   await expect(
  45  |     page.getByRole("heading", {
  46  |       level: 1,
  47  |       name: "Potato Chips 150 g",
  48  |       exact: true,
  49  |     }),
  50  |   ).toBeVisible();
  51  |   await page
  52  |     .getByRole("button", { name: "Edit Potato Chips 150 g", exact: true })
  53  |     .click();
  54  |   const editor = page.getByRole("dialog", {
  55  |     name: "Edit product",
  56  |     exact: true,
  57  |   });
  58  |   await editor
  59  |     .getByLabel("English name", { exact: true })
  60  |     .fill("Potato Chips 150 g edited");
  61  |   await editor
  62  |     .getByLabel("Description (English) (optional)", { exact: true })
  63  |     .fill("Crispy potato chips");
  64  |   // Name-only editing must explicitly resolve this undated tracking fixture.
  65  |   await stopTrackingKeepDates(page, editor);
  66  |   await editor
  67  |     .getByRole("button", { name: "Save product", exact: true })
  68  |     .click();
  69  |   await expect(editor).not.toBeVisible();
  70  |   await expect(
  71  |     page.getByRole("heading", {
  72  |       level: 1,
  73  |       name: "Potato Chips 150 g edited",
  74  |       exact: true,
  75  |     }),
  76  |   ).toBeVisible();
  77  |   await page.reload();
  78  |   await expect(
  79  |     page.getByRole("heading", {
  80  |       level: 1,
  81  |       name: "Potato Chips 150 g edited",
  82  |       exact: true,
  83  |     }),
  84  |   ).toBeVisible();
  85  |   await page
  86  |     .getByRole("link", { name: "Back to Products", exact: true })
  87  |     .click();
  88  |   await expect(page).toHaveURL(/#products$/);
  89  | });
  90  | 
  91  | test("Lookup Change price defaults to all stores and records the signed-in Supervisor", async ({
  92  |   page,
  93  | }) => {
  94  |   await signIn(page, "Supervisor");
  95  |   await setBranch(page, "all");
  96  |   await page.goto("/#lookup");
  97  |   await page
  98  |     .getByRole("main")
  99  |     .getByLabel("Search products", { exact: true })
  100 |     .fill("0009");
  101 |   // Aggregate Lookup requires an actual selling store before prices/actions.
  102 |   await chooseOption(
  103 |     page,
  104 |     page.locator(".lookup-page").getByLabel("Location", { exact: true }),
  105 |     "Branch 1",
  106 |     "North York",
  107 |   );
  108 |   const editor = await openRegularPrice(page);
  109 |   await editor.getByLabel("Price", { exact: true }).fill("3.29");
  110 |   await expect(
  111 |     editor.getByRole("button", { name: "All stores", exact: true }),
  112 |   ).toHaveAttribute("aria-pressed", "true");
  113 |   await editor
  114 |     .getByRole("button", { name: "Save new price", exact: true })
  115 |     .click();
  116 |   await expect(editor).not.toBeVisible();
  117 |   await expect(page.locator(".lookup-detail .price")).toHaveText("$3.29");
  118 |   await setBranch(page, "Branch 2");
  119 |   await expect(page.locator(".lookup-detail .price")).toHaveText("$3.29");
  120 |   const audit = await readCanonicalBusinessEvidence(page).then(
  121 |     (canonicalState) =>
  122 |       JSON.parse(JSON.stringify(canonicalState)!).activity.at(-1),
  123 |   );
> 124 |   expect(audit).toMatchObject({
      |                 ^ Error: expect(received).toMatchObject(expected)
  125 |     action: "Set regular price",
  126 |     by: configuredPersonExpectation("manager").name_en,
  127 |     actor_username: configuredPersonExpectation("manager").username,
  128 |     reversible: true,
  129 |     branch: "all",
  130 |     entity_type: "product",
  131 |     entity_id: "0009",
  132 |   });
  133 |   expect(audit.before.selling_price).toBe("2.99");
  134 |   expect(audit.after.selling_price).toBe("3.29");
  135 | });
  136 | 
  137 | test("Change price changes this store only, and validation stays inside the open dialog", async ({
  138 |   page,
  139 | }) => {
  140 |   await signIn(page, "Supervisor");
  141 |   await setBranch(page, "Branch 1");
  142 |   await page.goto("/#lookup");
  143 |   await page
  144 |     .getByRole("main")
  145 |     .getByLabel("Search products", { exact: true })
  146 |     .fill("0009");
  147 |   const editor = await openRegularPrice(page);
  148 |   const before = await readCanonicalBusinessEvidence(page).then(
  149 |     (canonicalState) => JSON.parse(JSON.stringify(canonicalState)!).products,
  150 |   );
  151 |   await editor.getByLabel("Price", { exact: true }).fill("3.291");
  152 |   await editor
  153 |     .getByRole("button", { name: "Save new price", exact: true })
  154 |     .click();
  155 |   await expect(
  156 |     editor.getByRole("alert", { name: "What's missing", exact: true }),
  157 |   ).toContainText("at most two decimals");
  158 |   await expect(editor).toBeVisible();
  159 |   expect(
  160 |     await readCanonicalBusinessEvidence(page).then(
  161 |       (canonicalState) => JSON.parse(JSON.stringify(canonicalState)!).products,
  162 |     ),
  163 |   ).toEqual(before);
  164 |   await editor.getByLabel("Price", { exact: true }).fill("3.29");
  165 |   await editor
  166 |     .getByRole("button", { name: "Only North York", exact: true })
  167 |     .click();
  168 |   await editor
  169 |     .getByRole("button", { name: "Save new price", exact: true })
  170 |     .click();
  171 |   await expect(editor).not.toBeVisible();
  172 |   await expect(page.locator(".lookup-detail .price")).toHaveText("$3.29");
  173 |   await setBranch(page, "Branch 2");
  174 |   await expect(page.locator(".lookup-detail .price")).toHaveText("$2.99");
  175 | });
  176 | 
  177 | test("Floor Worker and Cashier never see product Edit, including direct product links", async ({
  178 |   page,
  179 | }) => {
  180 |   await signIn(page, "Floor Worker");
  181 |   await page.goto("/#products");
  182 |   await expect(page.getByRole("button", { name: /^Edit / })).toHaveCount(0);
  183 |   await page.goto("/#product?code=0009");
  184 |   await expect(
  185 |     page.getByRole("heading", { level: 1, name: "Potato Chips 150 g" }),
  186 |   ).toBeVisible();
  187 |   await expect(page.getByRole("button", { name: /^Edit / })).toHaveCount(0);
  188 |   await signIn(page, "Cashier");
  189 |   await page.goto("/#product?code=0009");
  190 |   await expect(
  191 |     page.getByRole("heading", { level: 1, name: "Cashier lookup" }),
  192 |   ).toBeVisible();
  193 |   await expect(page.getByRole("button", { name: /^Edit / })).toHaveCount(0);
  194 | });
  195 | 
  196 | test("Lookup columns mirror in Persian, with selected row distinct from offer pill", async ({
  197 |   page,
  198 | }) => {
  199 |   await signIn(page, "Cashier");
  200 |   await page
  201 |     .getByRole("main")
  202 |     .getByLabel("Search products", { exact: true })
  203 |     .fill("0009");
  204 |   const row = page.locator(".lookup-result-row.is-selected");
  205 |   let geometry = await row.evaluate((element) => {
  206 |     const name = element
  207 |       .querySelector(".lookup-result-name")!
  208 |       .getBoundingClientRect();
  209 |     const price = element
  210 |       .querySelector(".lookup-result-price")!
  211 |       .getBoundingClientRect();
  212 |     return { nameX: name.x, priceX: price.x, width: price.width };
  213 |   });
  214 |   expect(geometry.priceX).toBeGreaterThan(geometry.nameX);
  215 |   await setLanguage(page, "fa");
  216 |   geometry = await row.evaluate((element) => {
  217 |     const name = element
  218 |       .querySelector(".lookup-result-name")!
  219 |       .getBoundingClientRect();
  220 |     const price = element
  221 |       .querySelector(".lookup-result-price")!
  222 |       .getBoundingClientRect();
  223 |     return { nameX: name.x, priceX: price.x, width: price.width };
  224 |   });
```