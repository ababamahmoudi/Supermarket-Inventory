# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: invoice-a2.spec.ts >> Persian signed money, line numbers and deduction parentheses stay isolated
- Location: tests/invoice-a2.spec.ts:118:1

# Error details

```
Error: locator.check: Clicking the checkbox did not change its state
Call log:
  - waiting for locator('.invoice-line').nth(5).getByRole('checkbox', { name: 'Mark as short', exact: true })
    - locator resolved to <button type="button" role="checkbox" aria-checked="false" class="ui-checked-control">…</button>
  - attempting click action
    - waiting for element to be visible, enabled and stable
    - element is visible, enabled and stable
    - scrolling into view if needed
    - done scrolling
    - performing click action
    - click action done
    - waiting for scheduled navigations to finish
    - navigations have finished

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=e5]:
    - banner [ref=e6]:
      - button "Open menu" [ref=e7] [cursor=pointer]
      - combobox "Location" [ref=e11] [cursor=pointer]:
        - generic [ref=e16]: North York
      - button "Notifications, 0 unread" [ref=e19] [cursor=pointer]
      - button "User menu" [ref=e24] [cursor=pointer]:
        - generic [aria-hidden] [ref=e26]: DN
      - button "More" [ref=e27] [cursor=pointer]
    - main [ref=e33]:
      - generic [ref=e34]:
        - link "Back to Invoices" [ref=e35] [cursor=pointer]:
          - /url: "#invoices"
        - generic [ref=e38]:
          - generic [ref=e39]:
            - heading "Invoices" [level=1] [ref=e40]
            - paragraph [ref=e41]: Deliveries and supplier invoices
          - button "New invoice" [ref=e43] [cursor=pointer]
        - tablist "Invoice views" [ref=e44]:
          - tab "Drafts" [ref=e45] [cursor=pointer]
          - tab "Processing" [ref=e47] [cursor=pointer]
          - tab "Needs review" [selected] [ref=e49] [cursor=pointer]
          - tab "Ready to post" [ref=e51] [cursor=pointer]
          - tab "Posted" [ref=e53] [cursor=pointer]
          - tab "Cancelled" [ref=e55] [cursor=pointer]
        - generic [ref=e57]:
          - complementary "Original invoice" [ref=e58]:
            - generic [ref=e59]:
              - heading "Original invoice" [level=2] [ref=e60]
              - paragraph [ref=e61]: AI invoice reading is simulated
              - generic [ref=e63]:
                - generic [ref=e64]: Upload a PDF or photo
                - generic [ref=e65]:
                  - button "Upload a PDF or photo" [ref=e66]
                  - button "Take photo" [ref=e67]
                  - generic [ref=e68]:
                    - generic [ref=e72]:
                      - strong [ref=e73]: fictional-a2-invoice.png
                      - generic [ref=e74]: 1 KB
                    - button "Remove file" [ref=e75] [cursor=pointer]
                  - generic [ref=e79]:
                    - button "Browse" [ref=e80] [cursor=pointer]
                    - button "Take photo" [ref=e81] [cursor=pointer]
              - group "Original invoice" [ref=e85]:
                - generic [ref=e86]:
                  - button "Zoom out" [ref=e87] [cursor=pointer]
                  - generic [ref=e89]: 100%
                  - button "Zoom in" [ref=e90] [cursor=pointer]
                - button "Fit width" [ref=e92] [cursor=pointer]
                - button "Fit page" [ref=e93] [cursor=pointer]
                - button "Download" [disabled] [ref=e94]
              - status [ref=e98]: Loading original invoice…
              - img "Original invoice image" [ref=e100]
          - generic [ref=e101]:
            - generic [ref=e102]:
              - generic "Delivery summary" [ref=e103]:
                - generic [ref=e104]:
                  - generic [ref=e105]: Subtotal
                  - strong [ref=e106]: $174.52
                - generic [ref=e107]:
                  - generic [ref=e108]: Tax
                  - strong [ref=e109]: $2.50
                - generic [ref=e110]:
                  - generic [ref=e111]: Shorts and refused deduction
                  - strong [ref=e112]: "-$7.23"
                - generic [ref=e113]:
                  - generic [ref=e114]: Payable
                  - strong [ref=e115]: $169.79
              - paragraph [ref=e116]: This is the amount of this invoice, not a supplier balance. Received records only physically delivered units.
            - generic [ref=e117]:
              - heading [level=2] [ref=e118]:
                - button "Invoice details" [ref=e119] [cursor=pointer]
              - paragraph [ref=e122]:
                - generic [ref=e123]: Fresh Valley Foods
                - text: ·
                - generic [ref=e124]: FV-20417
                - text: · North York ·
                - generic [ref=e125]: 2026-10-15
              - paragraph [ref=e126]:
                - generic [ref=e127]: Needs review
                - text: Changes save automatically in this browser.
            - generic [ref=e128]:
              - heading "Review invoice lines" [level=2] [ref=e129]
              - paragraph [ref=e130]: Choose Cases or Units and confirm the product, pack, quantities, cost, and date decision on each line.
              - table [ref=e132]:
                - 'rowgroup "Line 1: Canned Fava Beans 400 g" [ref=e133]':
                  - row [ref=e134] [cursor=pointer]:
                    - cell "1. Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی 0002 · 400 g Matched" [ref=e135]:
                      - generic [ref=e136]:
                        - heading [level=3] [ref=e137]:
                          - button "1. Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی" [expanded] [ref=e138]:
                            - generic [ref=e139]: "1."
                            - generic [ref=e140]:
                              - strong [ref=e141]:
                                - generic [ref=e142]:
                                  - text: Canned Fava Beans
                                  - generic [ref=e143]: 400 g
                              - generic [ref=e145]:
                                - text: باقالا کنسرو شده
                                - generic [ref=e146]: ۴۰۰ گرمی
                        - paragraph [ref=e149]:
                          - text: 0002 ·
                          - generic [ref=e150]: 400 g
                        - generic [ref=e153]: Matched
                    - cell [ref=e155]:
                      - generic [ref=e156]:
                        - generic [ref=e157]: Invoiced
                        - textbox "Invoiced" [ref=e158]: "2"
                      - generic [ref=e159]:
                        - generic [ref=e160]: Delivered
                        - textbox "Delivered" [ref=e161]: "24"
                    - cell [ref=e162]:
                      - generic [ref=e163]:
                        - generic [ref=e164]: Unit cost before tax
                        - textbox "Unit cost before tax" [ref=e165]: "0.98"
                    - cell "Line total $23.52" [ref=e166]:
                      - generic [ref=e167]: Line total
                      - text: $23.52
                    - 'cell "Selling price $1.49 Approved: $1.49" [ref=e168]':
                      - generic [ref=e169]:
                        - generic [ref=e170]: Selling price
                        - strong [ref=e171]: $1.49
                        - paragraph [ref=e172]: "Approved: $1.49"
                  - row [ref=e173]:
                    - cell [ref=e174]:
                      - generic [ref=e175]:
                        - group [ref=e176]:
                          - generic [ref=e177]:
                            - generic [ref=e178]: Quantity unit
                            - combobox "Quantity unit" [ref=e179] [cursor=pointer]:
                              - generic [ref=e180]: Cases
                          - generic [ref=e183]:
                            - generic [ref=e184]: Units per case
                            - textbox "Units per case" [ref=e185]: "12"
                          - generic [ref=e186]:
                            - generic [ref=e187]: Supplier item code (optional)
                            - textbox "Supplier item code (optional)" [ref=e188]
                          - generic [ref=e189]:
                            - generic [ref=e190]: Case cost before tax
                            - textbox "Case cost before tax" [ref=e191]: "11.7600"
                          - paragraph [ref=e192]: 2 × 12 = 24 units
                          - generic [ref=e193]:
                            - generic [ref=e194]: Matched product
                            - combobox "Matched product" [ref=e195] [cursor=pointer]:
                              - generic [ref=e197]:
                                - text: ⁦0002⁩ · ⁦
                                - generic [ref=e198]:
                                  - text: Canned Fava Beans
                                  - generic [ref=e199]: 400 g
                                - text: ⁩
                          - generic [ref=e202]:
                            - generic [ref=e203]: Pricing category
                            - combobox "Pricing category" [ref=e204] [cursor=pointer]:
                              - generic [ref=e205]: Grocery
                        - button "Remove line" [ref=e208] [cursor=pointer]
                        - checkbox "Mark as short" [ref=e209] [cursor=pointer]
                        - group [ref=e212]:
                          - generic [ref=e213]:
                            - generic [ref=e214]: Track date
                            - group "Track date" [ref=e215]:
                              - button "Yes" [pressed] [ref=e216] [cursor=pointer]
                              - button "No" [ref=e218] [cursor=pointer]
                          - generic [ref=e220]:
                            - generic [ref=e221]:
                              - generic [ref=e222]: Date tracking
                              - combobox "Date tracking" [ref=e223] [cursor=pointer]:
                                - generic [ref=e224]: Expiry
                            - generic [ref=e227]:
                              - generic [ref=e228]: Date
                              - button "Date" [ref=e229] [cursor=pointer]:
                                - generic [ref=e230]: Choose date
                            - generic [ref=e233]:
                              - generic [ref=e234]: Lot number (optional)
                              - textbox "Lot number (optional)" [ref=e235]
                        - checkbox "Confirm this invoice line" [ref=e236] [cursor=pointer]
                - 'rowgroup "Line 2: Ground Sumac 100 g" [ref=e239]':
                  - row [ref=e240] [cursor=pointer]:
                    - cell "2. Ground Sumac 100 g سماق ۱۰۰ گرمی 0005 · 100 g Matched" [ref=e241]:
                      - generic [ref=e242]:
                        - heading [level=3] [ref=e243]:
                          - button "2. Ground Sumac 100 g سماق ۱۰۰ گرمی" [expanded] [ref=e244]:
                            - generic [ref=e245]: "2."
                            - generic [ref=e246]:
                              - strong [ref=e247]:
                                - generic [ref=e248]:
                                  - text: Ground Sumac
                                  - generic [ref=e249]: 100 g
                              - generic [ref=e251]:
                                - text: سماق
                                - generic [ref=e252]: ۱۰۰ گرمی
                        - paragraph [ref=e255]:
                          - text: 0005 ·
                          - generic [ref=e256]: 100 g
                        - generic [ref=e259]: Matched
                    - cell [ref=e261]:
                      - generic [ref=e262]:
                        - generic [ref=e263]: Invoiced
                        - textbox "Invoiced" [ref=e264]: "1"
                      - generic [ref=e265]:
                        - generic [ref=e266]: Delivered
                        - textbox "Delivered" [ref=e267]: "12"
                    - cell [ref=e268]:
                      - generic [ref=e269]:
                        - generic [ref=e270]: Unit cost before tax
                        - textbox "Unit cost before tax" [ref=e271]: "1.30"
                    - cell "Line total $15.60" [ref=e272]:
                      - generic [ref=e273]: Line total
                      - text: $15.60
                    - 'cell "Selling price $1.99 Approved: $1.99" [ref=e274]':
                      - generic [ref=e275]:
                        - generic [ref=e276]: Selling price
                        - strong [ref=e277]: $1.99
                        - paragraph [ref=e278]: "Approved: $1.99"
                  - row [ref=e279]:
                    - cell [ref=e280]:
                      - generic [ref=e281]:
                        - group [ref=e282]:
                          - generic [ref=e283]:
                            - generic [ref=e284]: Quantity unit
                            - combobox "Quantity unit" [ref=e285] [cursor=pointer]:
                              - generic [ref=e286]: Cases
                          - generic [ref=e289]:
                            - generic [ref=e290]: Units per case
                            - textbox "Units per case" [ref=e291]: "12"
                          - generic [ref=e292]:
                            - generic [ref=e293]: Supplier item code (optional)
                            - textbox "Supplier item code (optional)" [ref=e294]
                          - generic [ref=e295]:
                            - generic [ref=e296]: Case cost before tax
                            - textbox "Case cost before tax" [ref=e297]: "15.6000"
                          - paragraph [ref=e298]: 1 × 12 = 12 units
                          - generic [ref=e299]:
                            - generic [ref=e300]: Matched product
                            - combobox "Matched product" [ref=e301] [cursor=pointer]:
                              - generic [ref=e303]:
                                - text: ⁦0005⁩ · ⁦
                                - generic [ref=e304]:
                                  - text: Ground Sumac
                                  - generic [ref=e305]: 100 g
                                - text: ⁩
                          - generic [ref=e308]:
                            - generic [ref=e309]: Pricing category
                            - combobox "Pricing category" [ref=e310] [cursor=pointer]:
                              - generic [ref=e311]: Grocery
                        - button "Remove line" [ref=e314] [cursor=pointer]
                        - checkbox "Mark as short" [ref=e315] [cursor=pointer]
                        - group [ref=e318]:
                          - generic [ref=e319]:
                            - generic [ref=e320]: Track date
                            - group "Track date" [ref=e321]:
                              - button "Yes" [pressed] [ref=e322] [cursor=pointer]
                              - button "No" [ref=e324] [cursor=pointer]
                          - generic [ref=e326]:
                            - generic [ref=e327]:
                              - generic [ref=e328]: Date tracking
                              - combobox "Date tracking" [ref=e329] [cursor=pointer]:
                                - generic [ref=e330]: Expiry
                            - generic [ref=e333]:
                              - generic [ref=e334]: Date
                              - button "Date" [ref=e335] [cursor=pointer]:
                                - generic [ref=e336]: Choose date
                            - generic [ref=e339]:
                              - generic [ref=e340]: Lot number (optional)
                              - textbox "Lot number (optional)" [ref=e341]
                        - checkbox "Confirm this invoice line" [ref=e342] [cursor=pointer]
                - 'rowgroup "Line 3: Lavash Bread 500 g" [ref=e345]':
                  - row [ref=e346] [cursor=pointer]:
                    - cell "3. Lavash Bread 500 g نان لواش ۵۰۰ گرمی 0006 · 500 g Matched" [ref=e347]:
                      - generic [ref=e348]:
                        - heading [level=3] [ref=e349]:
                          - button "3. Lavash Bread 500 g نان لواش ۵۰۰ گرمی" [expanded] [ref=e350]:
                            - generic [ref=e351]: "3."
                            - generic [ref=e352]:
                              - strong [ref=e353]:
                                - generic [ref=e354]:
                                  - text: Lavash Bread
                                  - generic [ref=e355]: 500 g
                              - generic [ref=e357]:
                                - text: نان لواش
                                - generic [ref=e358]: ۵۰۰ گرمی
                        - paragraph [ref=e361]:
                          - text: 0006 ·
                          - generic [ref=e362]: 500 g
                        - generic [ref=e365]: Matched
                    - cell [ref=e367]:
                      - generic [ref=e368]:
                        - generic [ref=e369]: Invoiced
                        - textbox "Invoiced" [ref=e370]: "2"
                      - generic [ref=e371]:
                        - generic [ref=e372]: Delivered
                        - textbox "Delivered" [ref=e373]: "20"
                    - cell [ref=e374]:
                      - generic [ref=e375]:
                        - generic [ref=e376]: Unit cost before tax
                        - textbox "Unit cost before tax" [ref=e377]: "1.55"
                    - cell "Line total $31.00" [ref=e378]:
                      - generic [ref=e379]: Line total
                      - text: $31.00
                    - 'cell "Selling price $2.99 Pending Goes to approval when posted Approved: $1.99" [ref=e380]':
                      - generic [ref=e381]:
                        - generic [ref=e382]: Selling price
                        - strong [ref=e383]: $2.99
                        - generic [ref=e384]: Pending
                        - generic [ref=e385]: Goes to approval when posted
                        - paragraph [ref=e386]: "Approved: $1.99"
                  - row [ref=e387]:
                    - cell [ref=e388]:
                      - generic [ref=e389]:
                        - group [ref=e390]:
                          - generic [ref=e391]:
                            - generic [ref=e392]: Quantity unit
                            - combobox "Quantity unit" [ref=e393] [cursor=pointer]:
                              - generic [ref=e394]: Cases
                          - generic [ref=e397]:
                            - generic [ref=e398]: Units per case
                            - textbox "Units per case" [ref=e399]: "10"
                          - generic [ref=e400]:
                            - generic [ref=e401]: Supplier item code (optional)
                            - textbox "Supplier item code (optional)" [ref=e402]
                          - generic [ref=e403]:
                            - generic [ref=e404]: Case cost before tax
                            - textbox "Case cost before tax" [ref=e405]: "15.5000"
                          - paragraph [ref=e406]: 2 × 10 = 20 units
                          - generic [ref=e407]:
                            - generic [ref=e408]: Matched product
                            - combobox "Matched product" [ref=e409] [cursor=pointer]:
                              - generic [ref=e411]:
                                - text: ⁦0006⁩ · ⁦
                                - generic [ref=e412]:
                                  - text: Lavash Bread
                                  - generic [ref=e413]: 500 g
                                - text: ⁩
                          - generic [ref=e416]:
                            - generic [ref=e417]: Pricing category
                            - combobox "Pricing category" [ref=e418] [cursor=pointer]:
                              - generic [ref=e419]: Grocery
                        - button "Remove line" [ref=e422] [cursor=pointer]
                        - checkbox "Mark as short" [ref=e423] [cursor=pointer]
                        - group [ref=e426]:
                          - generic [ref=e427]:
                            - generic [ref=e428]: Track date
                            - group "Track date" [ref=e429]:
                              - button "Yes" [pressed] [ref=e430] [cursor=pointer]
                              - button "No" [ref=e432] [cursor=pointer]
                          - generic [ref=e434]:
                            - generic [ref=e435]:
                              - generic [ref=e436]: Date tracking
                              - combobox "Date tracking" [ref=e437] [cursor=pointer]:
                                - generic [ref=e438]: Expiry
                            - generic [ref=e441]:
                              - generic [ref=e442]: Date
                              - button "Date" [ref=e443] [cursor=pointer]:
                                - generic [ref=e444]: Choose date
                            - generic [ref=e447]:
                              - generic [ref=e448]: Lot number (optional)
                              - textbox "Lot number (optional)" [ref=e449]
                        - checkbox "Confirm this invoice line" [ref=e450] [cursor=pointer]
                - 'rowgroup "Line 4: Sour Cherry Juice 1 L" [ref=e453]':
                  - row [ref=e454] [cursor=pointer]:
                    - cell "4. Sour Cherry Juice 1 L آب آلبالو ۱ لیتری 0003 · 1 L Matched" [ref=e455]:
                      - generic [ref=e456]:
                        - heading [level=3] [ref=e457]:
                          - button "4. Sour Cherry Juice 1 L آب آلبالو ۱ لیتری" [expanded] [ref=e458]:
                            - generic [ref=e459]: "4."
                            - generic [ref=e460]:
                              - strong [ref=e461]:
                                - generic [ref=e462]:
                                  - text: Sour Cherry Juice
                                  - generic [ref=e463]: 1 L
                              - generic [ref=e465]:
                                - text: آب آلبالو
                                - generic [ref=e466]: ۱ لیتری
                        - paragraph [ref=e469]:
                          - text: 0003 ·
                          - generic [ref=e470]: 1 L
                        - generic [ref=e473]: Matched
                    - cell [ref=e475]:
                      - generic [ref=e476]:
                        - generic [ref=e477]: Invoiced
                        - textbox "Invoiced" [ref=e478]: "3"
                      - generic [ref=e479]:
                        - generic [ref=e480]: Delivered
                        - textbox "Delivered" [ref=e481]: "36"
                    - cell [ref=e482]:
                      - generic [ref=e483]:
                        - generic [ref=e484]: Unit cost before tax
                        - textbox "Unit cost before tax" [ref=e485]: "1.80"
                    - cell "Line total $64.80" [ref=e486]:
                      - generic [ref=e487]: Line total
                      - text: $64.80
                    - 'cell "Selling price $2.99 Approved: $2.99" [ref=e488]':
                      - generic [ref=e489]:
                        - generic [ref=e490]: Selling price
                        - strong [ref=e491]: $2.99
                        - paragraph [ref=e492]: "Approved: $2.99"
                  - row [ref=e493]:
                    - cell "Remove line Mark as short Lower-cost receipt Lower-cost receipt Confirm this invoice line" [ref=e494]:
                      - generic [ref=e495]:
                        - group [ref=e496]:
                          - generic [ref=e497]:
                            - generic [ref=e498]: Quantity unit
                            - combobox "Quantity unit" [ref=e499] [cursor=pointer]:
                              - generic [ref=e500]: Cases
                          - generic [ref=e503]:
                            - generic [ref=e504]: Units per case
                            - textbox "Units per case" [ref=e505]: "12"
                          - generic [ref=e506]:
                            - generic [ref=e507]: Supplier item code (optional)
                            - textbox "Supplier item code (optional)" [ref=e508]
                          - generic [ref=e509]:
                            - generic [ref=e510]: Case cost before tax
                            - textbox "Case cost before tax" [ref=e511]: "21.6000"
                          - paragraph [ref=e512]: 3 × 12 = 36 units
                          - generic [ref=e513]:
                            - generic [ref=e514]: Matched product
                            - combobox "Matched product" [ref=e515] [cursor=pointer]:
                              - generic [ref=e517]:
                                - text: ⁦0003⁩ · ⁦
                                - generic [ref=e518]:
                                  - text: Sour Cherry Juice
                                  - generic [ref=e519]: 1 L
                                - text: ⁩
                          - generic [ref=e522]:
                            - generic [ref=e523]: Pricing category
                            - combobox "Pricing category" [ref=e524] [cursor=pointer]:
                              - generic [ref=e525]: Grocery
                        - button "Remove line" [ref=e528] [cursor=pointer]
                        - checkbox "Mark as short" [ref=e529] [cursor=pointer]
                        - generic [ref=e532]:
                          - generic [ref=e533]: Lower-cost receipt
                          - group "Lower-cost receipt" [ref=e534]:
                            - button "Regular receipt" [pressed] [ref=e535] [cursor=pointer]
                            - button "Short-dated (expiry discount)" [ref=e537] [cursor=pointer]
                        - group [ref=e539]:
                          - generic [ref=e540]:
                            - generic [ref=e541]: Track date
                            - group "Track date" [ref=e542]:
                              - button "Yes" [pressed] [ref=e543] [cursor=pointer]
                              - button "No" [ref=e545] [cursor=pointer]
                          - generic [ref=e547]:
                            - generic [ref=e548]:
                              - generic [ref=e549]: Date tracking
                              - combobox "Date tracking" [ref=e550] [cursor=pointer]:
                                - generic [ref=e551]: Expiry
                            - generic [ref=e554]:
                              - generic [ref=e555]: Date
                              - button "Date" [ref=e556] [cursor=pointer]:
                                - generic [ref=e557]: Choose date
                            - generic [ref=e560]:
                              - generic [ref=e561]: Lot number (optional)
                              - textbox "Lot number (optional)" [ref=e562]
                        - checkbox "Confirm this invoice line" [ref=e563] [cursor=pointer]
                - 'rowgroup "Line 5: Dried Barberries 100 g" [ref=e566]':
                  - row [ref=e567] [cursor=pointer]:
                    - cell "5. Dried Barberries 100 g زرشک خشک ۱۰۰ گرمی No Product Code yet Pending new product" [ref=e568]:
                      - generic [ref=e569]:
                        - heading [level=3] [ref=e570]:
                          - button "5. Dried Barberries 100 g زرشک خشک ۱۰۰ گرمی" [expanded] [ref=e571]:
                            - generic [ref=e572]: "5."
                            - generic [ref=e573]:
                              - strong [ref=e574]:
                                - generic [ref=e575]:
                                  - text: Dried Barberries
                                  - generic [ref=e576]: 100 g
                              - generic [ref=e578]:
                                - text: زرشک خشک
                                - generic [ref=e579]: ۱۰۰ گرمی
                        - paragraph [ref=e582]: No Product Code yet
                        - generic [ref=e583]: Pending new product
                    - cell [ref=e585]:
                      - generic [ref=e586]:
                        - generic [ref=e587]: Invoiced
                        - textbox "Invoiced" [ref=e588]: "1"
                      - generic [ref=e589]:
                        - generic [ref=e590]: Delivered
                        - textbox "Delivered" [ref=e591]: "6"
                    - cell [ref=e592]:
                      - generic [ref=e593]:
                        - generic [ref=e594]: Unit cost before tax
                        - textbox "Unit cost before tax" [ref=e595]: "3.40"
                    - cell "Line total $20.40" [ref=e596]:
                      - generic [ref=e597]: Line total
                      - text: $20.40
                    - cell "Selling price $5.49 Pending Goes to approval when posted No approved price yet" [ref=e598]:
                      - generic [ref=e599]:
                        - generic [ref=e600]: Selling price
                        - strong [ref=e601]: $5.49
                        - generic [ref=e602]: Pending
                        - generic [ref=e603]: Goes to approval when posted
                        - paragraph [ref=e604]: No approved price yet
                  - row [ref=e605]:
                    - cell [ref=e606]:
                      - generic [ref=e607]:
                        - group [ref=e608]:
                          - generic [ref=e609]:
                            - generic [ref=e610]: Quantity unit
                            - combobox "Quantity unit" [ref=e611] [cursor=pointer]:
                              - generic [ref=e612]: Cases
                          - generic [ref=e615]:
                            - generic [ref=e616]: Units per case
                            - textbox "Units per case" [ref=e617]: "6"
                          - generic [ref=e618]:
                            - generic [ref=e619]: Supplier item code (optional)
                            - textbox "Supplier item code (optional)" [ref=e620]
                          - generic [ref=e621]:
                            - generic [ref=e622]: Case cost before tax
                            - textbox "Case cost before tax" [ref=e623]: "20.4000"
                          - paragraph [ref=e624]: 1 × 6 = 6 units
                          - generic [ref=e625]:
                            - generic [ref=e626]: Matched product
                            - combobox "Matched product" [ref=e627] [cursor=pointer]:
                              - generic [ref=e628]: Create pending new product
                          - generic [ref=e631]:
                            - generic [ref=e632]: Pricing category
                            - combobox "Pricing category" [ref=e633] [cursor=pointer]:
                              - generic [ref=e634]: Grocery
                          - generic [ref=e637]:
                            - generic [ref=e638]: New product name (English)
                            - textbox "New product name (English)" [ref=e639]: Dried Barberries 100 g
                          - generic [ref=e640]:
                            - generic [ref=e641]: New product name (Persian) (optional)
                            - textbox "New product name (Persian) (optional)" [ref=e642]: زرشک خشک ۱۰۰ گرمی
                        - button "Remove line" [ref=e643] [cursor=pointer]
                        - checkbox "Mark as short" [ref=e644] [cursor=pointer]
                        - group [ref=e647]:
                          - generic [ref=e648]:
                            - generic [ref=e649]: Track date
                            - group "Track date" [ref=e650]:
                              - button "Yes" [ref=e651] [cursor=pointer]
                              - button "No" [ref=e653] [cursor=pointer]
                        - checkbox "Confirm this invoice line" [ref=e655] [cursor=pointer]
                - 'rowgroup "Line 6: Potato Chips 150 g" [ref=e658]':
                  - row [ref=e659] [cursor=pointer]:
                    - 'cell "6. Potato Chips 150 g چیپس سیب‌زمینی ۱۵۰ گرمی 0009 · 150 g Matched Short: 4 Taxable" [ref=e660]':
                      - generic [ref=e661]:
                        - heading [level=3] [ref=e662]:
                          - button "6. Potato Chips 150 g چیپس سیب‌زمینی ۱۵۰ گرمی" [expanded] [ref=e663]:
                            - generic [ref=e664]: "6."
                            - generic [ref=e665]:
                              - strong [ref=e666]:
                                - generic [ref=e667]:
                                  - text: Potato Chips
                                  - generic [ref=e668]: 150 g
                              - generic [ref=e670]:
                                - text: چیپس سیب‌زمینی
                                - generic [ref=e671]: ۱۵۰ گرمی
                        - paragraph [ref=e674]:
                          - text: 0009 ·
                          - generic [ref=e675]: 150 g
                        - generic [ref=e678]:
                          - generic [ref=e679]: Matched
                          - generic [ref=e680]: "Short: 4"
                          - generic [ref=e681]: Taxable
                    - cell [ref=e682]:
                      - generic [ref=e683]:
                        - generic [ref=e684]: Invoiced
                        - textbox "Invoiced" [ref=e685]: "1"
                      - generic [ref=e686]:
                        - generic [ref=e687]: Delivered
                        - textbox "Delivered" [ref=e688]: "8"
                    - cell [ref=e689]:
                      - generic [ref=e690]:
                        - generic [ref=e691]: Unit cost before tax
                        - textbox "Unit cost before tax" [ref=e692]: "1.60"
                    - cell "Line total $19.20" [ref=e693]:
                      - generic [ref=e694]: Line total
                      - text: $19.20
                    - 'cell "Selling price $2.99 Approved: $2.99" [ref=e695]':
                      - generic [ref=e696]:
                        - generic [ref=e697]: Selling price
                        - strong [ref=e698]: $2.99
                        - paragraph [ref=e699]: "Approved: $2.99"
                  - row [ref=e700]:
                    - 'cell "Remove line Mark as short Missing units: 4 · Deduction: $7.23 ($6.40 + $0.83 ) tax Confirm this invoice line" [ref=e701]':
                      - generic [ref=e702]:
                        - group [ref=e703]:
                          - generic [ref=e704]:
                            - generic [ref=e705]: Quantity unit
                            - combobox "Quantity unit" [ref=e706] [cursor=pointer]:
                              - generic [ref=e707]: Cases
                          - generic [ref=e710]:
                            - generic [ref=e711]: Units per case
                            - textbox "Units per case" [ref=e712]: "12"
                          - generic [ref=e713]:
                            - generic [ref=e714]: Supplier item code (optional)
                            - textbox "Supplier item code (optional)" [ref=e715]
                          - generic [ref=e716]:
                            - generic [ref=e717]: Case cost before tax
                            - textbox "Case cost before tax" [ref=e718]: "19.2000"
                          - paragraph [ref=e719]: 1 × 12 = 12 units
                          - generic [ref=e720]:
                            - generic [ref=e721]: Matched product
                            - combobox "Matched product" [ref=e722] [cursor=pointer]:
                              - generic [ref=e724]:
                                - text: ⁦0009⁩ · ⁦
                                - generic [ref=e725]:
                                  - text: Potato Chips
                                  - generic [ref=e726]: 150 g
                                - text: ⁩
                          - generic [ref=e729]:
                            - generic [ref=e730]: Pricing category
                            - combobox "Pricing category" [ref=e731] [cursor=pointer]:
                              - generic [ref=e732]: Grocery (Taxable)
                        - button "Remove line" [ref=e735] [cursor=pointer]
                        - checkbox "Mark as short" [checked] [active] [ref=e736] [cursor=pointer]
                        - paragraph [ref=e741]:
                          - text: "Missing units: 4 · Deduction:"
                          - generic [ref=e742]: $7.23
                          - generic [ref=e743]: ($6.40 + $0.83 )
                          - text: tax
                        - group [ref=e744]:
                          - generic [ref=e745]:
                            - generic [ref=e746]: Track date
                            - group "Track date" [ref=e747]:
                              - button "Yes" [pressed] [ref=e748] [cursor=pointer]
                              - button "No" [ref=e750] [cursor=pointer]
                          - generic [ref=e752]:
                            - generic [ref=e753]:
                              - generic [ref=e754]: Date tracking
                              - combobox "Date tracking" [ref=e755] [cursor=pointer]:
                                - generic [ref=e756]: Expiry
                            - generic [ref=e759]:
                              - generic [ref=e760]: Date
                              - button "Date" [ref=e761] [cursor=pointer]:
                                - generic [ref=e762]: Choose date
                            - generic [ref=e765]:
                              - generic [ref=e766]: Lot number (optional)
                              - textbox "Lot number (optional)" [ref=e767]
                        - checkbox "Confirm this invoice line" [ref=e768] [cursor=pointer]
              - generic [ref=e771]:
                - generic [ref=e772]:
                  - generic [ref=e773]: Add a product to the invoice
                  - combobox "Add a product to the invoice" [ref=e774] [cursor=pointer]:
                    - generic [ref=e776]:
                      - text: ⁦0002⁩ · ⁦
                      - generic [ref=e777]:
                        - text: Canned Fava Beans
                        - generic [ref=e778]: 400 g
                      - text: ⁩
                - button "Add line" [ref=e781] [cursor=pointer]
                - button "+ Add new product" [ref=e782] [cursor=pointer]
            - generic [ref=e783]:
              - heading "Same-supplier lower price" [level=2] [ref=e784]
              - paragraph [ref=e785]: Sour Cherry Juice 1 L · Fresh Valley Foods · Old $1.95 · New $1.80
              - paragraph [ref=e786]: Your answers create a Supervisor alert when you post. Unknown information is allowed with a note.
              - group [ref=e787]:
                - generic [ref=e788]:
                  - generic [ref=e789]: Is the expiry date the same as the goods already in the store?
                  - combobox "Is the expiry date the same as the goods already in the store?" [ref=e790] [cursor=pointer]:
                    - generic [ref=e791]: Choose an answer
          - generic [ref=e795]:
            - button "Save as draft" [ref=e796] [cursor=pointer]
            - button "Post invoice" [ref=e797] [cursor=pointer]
```

# Test source

```ts
  26  |     mimeType: "image/png",
  27  |     buffer: pixel,
  28  |   });
  29  |   await expect(page.locator(".invoice-line")).toHaveCount(6, {
  30  |     timeout: 10000,
  31  |   });
  32  |   // Existing seed lines can render before the uploaded original and its
  33  |   // simulated reading transition finish. Geometry and edits must use the
  34  |   // committed upload rather than the previous workspace during that change.
  35  |   await expect
  36  |     .poll(() =>
  37  |       readCanonicalBusinessEvidence(page).then((canonicalState) => {
  38  |         const invoice = JSON.parse(JSON.stringify(canonicalState)!).invoice;
  39  |         return {
  40  |           fileName: invoice.file_name,
  41  |           originalHash: invoice.file_data?.split(":").at(-1),
  42  |           status: invoice.status,
  43  |         };
  44  |       }),
  45  |     )
  46  |     .toEqual({
  47  |       fileName: "fictional-a2-invoice.png",
  48  |       originalHash: createHash("sha256").update(pixel).digest("hex"),
  49  |       status: "review",
  50  |     });
  51  |   await page.evaluate(async () => {
  52  |     await document.fonts.ready;
  53  |     await new Promise((resolve) =>
  54  |       requestAnimationFrame(() => requestAnimationFrame(resolve)),
  55  |     );
  56  |   });
  57  | }
  58  | test("each invoice line requires one date answer, collapses when confirmed and opens from the row", async ({
  59  |   page,
  60  | }) => {
  61  |   await review(page);
  62  |   const lines = page.locator(".invoice-line");
  63  |   await expect(
  64  |     page.getByRole("checkbox", {
  65  |       name: "Confirm date tracking decision",
  66  |       exact: true,
  67  |     }),
  68  |   ).toHaveCount(0);
  69  |   await expect(
  70  |     page.getByRole("checkbox", {
  71  |       name: "Track a date for this line",
  72  |       exact: true,
  73  |     }),
  74  |   ).toHaveCount(0);
  75  |   await expect(
  76  |     page.getByRole("button", { name: "Post invoice", exact: true }),
  77  |   ).toBeEnabled();
  78  |   await page.getByRole("button", { name: "Post invoice", exact: true }).click();
  79  |   await expect(
  80  |     page.getByRole("alert", { name: "What's missing", exact: true }),
  81  |   ).toBeVisible();
  82  |   const first = lines.first();
  83  |   await first
  84  |     .getByRole("checkbox", { name: "Confirm this invoice line", exact: true })
  85  |     .click();
  86  |   await expect(first).toHaveAttribute("data-expanded", "true");
  87  |   await first.getByRole("button", { name: "No", exact: true }).click();
  88  |   await first
  89  |     .getByRole("checkbox", { name: "Confirm this invoice line", exact: true })
  90  |     .click();
  91  |   await expect(first).toHaveAttribute("data-expanded", "false");
  92  |   await expect(first.locator(".invoice-line-detail")).toHaveCount(0);
  93  |   await first.locator(".invoice-line-toggle").click();
  94  |   await expect(first).toHaveAttribute("data-expanded", "true");
  95  |   await first.locator(".invoice-line-summary td").nth(3).click();
  96  |   await expect(first).toHaveAttribute("data-expanded", "false");
  97  |   await expect(
  98  |     lines.nth(4).getByText("No Product Code yet", { exact: true }),
  99  |   ).toBeVisible();
  100 |   await expect(
  101 |     lines.nth(2).getByText("Pending", { exact: true }),
  102 |   ).toBeVisible();
  103 |   await expect(
  104 |     lines.nth(2).getByText("Goes to approval when posted", { exact: true }),
  105 |   ).toBeVisible();
  106 |   const section = page.locator(".invoice-summary-section");
  107 |   expect(
  108 |     await section
  109 |       .locator(".invoice-summary-note")
  110 |       .evaluate((note) =>
  111 |         Math.round(
  112 |           note.getBoundingClientRect().top -
  113 |             note.previousElementSibling!.getBoundingClientRect().bottom,
  114 |         ),
  115 |       ),
  116 |   ).toBe(16);
  117 | });
  118 | test("Persian signed money, line numbers and deduction parentheses stay isolated", async ({
  119 |   page,
  120 | }) => {
  121 |   await review(page);
  122 |   await page
  123 |     .locator(".invoice-line")
  124 |     .nth(5)
  125 |     .getByRole("checkbox", { name: "Mark as short", exact: true })
> 126 |     .check();
      |      ^ Error: locator.check: Clicking the checkbox did not change its state
  127 |   await setLanguage(page, "fa");
  128 |   const deduction = page
  129 |     .locator(".invoice-summary-grid .ui-summary-tile")
  130 |     .nth(2);
  131 |   await expect(deduction).toContainText("-$7.23");
  132 |   await expect(deduction.locator('bdi[dir="ltr"]')).toContainText("-$7.23");
  133 |   await expect(page.locator(".invoice-line-toggle > bdi").first()).toHaveText(
  134 |     "1.",
  135 |   );
  136 |   const parentheses = page
  137 |     .locator(".invoice-line")
  138 |     .nth(5)
  139 |     .locator(".banner > bdi")
  140 |     .last();
  141 |   await expect(parentheses).toHaveAttribute("dir", "ltr");
  142 |   await expect(parentheses).toContainText("($6.40 + $0.83 )");
  143 | });
  144 | test("the document sticks beside the review and the action bar has a full surface", async ({
  145 |   page,
  146 | }, testInfo) => {
  147 |   test.skip(
  148 |     testInfo.project.name === "phone",
  149 |     "Phone review uses one stacked column.",
  150 |   );
  151 |   await page.setViewportSize({ width: 1920, height: 1080 });
  152 |   await review(page);
  153 |   await page.evaluate(() => window.scrollTo(0, 450));
  154 |   const pane = await page.locator(".invoice-document-pane").boundingBox();
  155 |   const topbar = await page.locator(".topbar").boundingBox();
  156 |   expect(pane!.y).toBeGreaterThanOrEqual(topbar!.y + topbar!.height + 22);
  157 |   expect(pane!.y).toBeLessThanOrEqual(topbar!.y + topbar!.height + 26);
  158 |   const reviewPane = await page.locator(".invoice-review-pane").boundingBox();
  159 |   const footer = await page.locator(".invoice-action-footer").boundingBox();
  160 |   // The C7 bar reserves its own row below the review pane instead of stretching across the original.
  161 |   expect(Math.abs(reviewPane!.width - footer!.width)).toBeLessThanOrEqual(2);
  162 |   expect(Math.abs(reviewPane!.x - footer!.x)).toBeLessThanOrEqual(2);
  163 |   expect(footer!.y).toBeGreaterThanOrEqual(reviewPane!.y + reviewPane!.height);
  164 |   await expect(page.locator(".invoice-action-footer")).toHaveCSS(
  165 |     "position",
  166 |     "static",
  167 |   );
  168 |   expect(
  169 |     await page
  170 |       .locator(".invoice-action-footer")
  171 |       .evaluate((node) => getComputedStyle(node).backgroundColor),
  172 |   ).not.toBe("rgba(0, 0, 0, 0)");
  173 |   expect(
  174 |     await page.evaluate(
  175 |       () => document.documentElement.scrollWidth <= window.innerWidth,
  176 |     ),
  177 |   ).toBe(true);
  178 | });
  179 | 
  180 | test("manual invoice drafts work when randomUUID is unavailable", async ({
  181 |   page,
  182 | }) => {
  183 |   const errors: string[] = [];
  184 |   page.on("pageerror", (error) => errors.push(error.message));
  185 |   await page.addInitScript(() => {
  186 |     Object.defineProperty(globalThis.crypto, "randomUUID", {
  187 |       value: undefined,
  188 |       configurable: true,
  189 |     });
  190 |   });
  191 |   await signIn(page, "Supervisor");
  192 |   await page.goto("/#invoices");
  193 |   await page.getByRole("button", { name: "New invoice", exact: true }).click();
  194 |   await page.getByRole("button", { name: "Manual entry", exact: true }).click();
  195 |   await page.getByRole("button", { name: "Add line", exact: true }).click();
  196 |   expect(
  197 |     await page.evaluate(
  198 |       () => document.documentElement.scrollWidth <= window.innerWidth,
  199 |     ),
  200 |   ).toBe(true);
  201 |   expect(
  202 |     await page.evaluate(
  203 |       () => window.innerWidth === document.documentElement.clientWidth,
  204 |     ),
  205 |   ).toBe(true);
  206 |   await page
  207 |     .getByRole("button", { name: "Save as draft", exact: true })
  208 |     .click();
  209 |   await page.reload();
  210 |   await expect(page.locator(".invoice-line")).toHaveCount(1);
  211 |   const invoice = await readCanonicalBusinessEvidence(page).then(
  212 |     (canonicalState) => JSON.parse(JSON.stringify(canonicalState)!).invoice,
  213 |   );
  214 |   expect(invoice.status).toBe("draft");
  215 |   expect(typeof invoice.id).toBe("string");
  216 |   expect(invoice.id.length).toBeGreaterThan(0);
  217 |   expect(await page.evaluate(() => typeof globalThis.crypto.randomUUID)).toBe(
  218 |     "undefined",
  219 |   );
  220 |   expect(errors).toEqual([]);
  221 | });
  222 | 
  223 | test("fictional invoice answers are available only inside Demo and retain Persian copy", async ({
  224 |   page,
  225 | }) => {
  226 |   await review(page);
```