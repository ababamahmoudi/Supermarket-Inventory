# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: notebooks-b.spec.ts >> Cashier gets only granted custom notebook reads and cannot add or read built-in notebooks
- Location: tests/notebooks-b.spec.ts:184:1

# Error details

```
Test timeout of 60000ms exceeded.
```

```
Error: locator.click: Test timeout of 60000ms exceeded.
Call log:
  - waiting for getByRole('tab', { name: /^Cleaning log( \d+)?$/ })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - complementary "Main menu" [ref=e5]:
    - generic [ref=e6]:
      - img "Super Arzon" [ref=e9]
      - generic [ref=e10]: Super Arzon
    - navigation "Pages" [ref=e11]:
      - generic [ref=e12]:
        - button "Daily" [expanded] [ref=e13] [cursor=pointer]
        - link "Lookup" [ref=e18] [cursor=pointer]:
          - /url: "#lookup"
    - button "User menu" [ref=e24] [cursor=pointer]:
      - generic [ref=e25]:
        - generic [aria-hidden] [ref=e26]: DC
        - generic [ref=e27]:
          - strong [ref=e28]: Demo Cashier
          - generic [ref=e29]: Cashier
  - generic [ref=e30]:
    - banner [ref=e31]:
      - button "Collapse sidebar" [expanded] [ref=e32] [cursor=pointer]
      - navigation "Breadcrumbs" [ref=e36]:
        - link "North York" [ref=e37] [cursor=pointer]:
          - /url: "#lookup"
        - link "Lookup" [ref=e40] [cursor=pointer]:
          - /url: "#lookup"
      - search [ref=e41]:
        - textbox "Search all products" [ref=e45]:
          - /placeholder: Search products
        - generic [aria-hidden] [ref=e46]: /
      - combobox "Location" [ref=e47] [cursor=pointer]:
        - generic [ref=e52]: North York
      - button "Switch to Persian" [ref=e55] [cursor=pointer]: فا
      - button "Switch to dark theme" [ref=e56] [cursor=pointer]
      - button "Comfortable text size" [ref=e59] [cursor=pointer]:
        - generic [aria-hidden] [ref=e60]: Aa
      - button "Notifications, 0 unread" [ref=e61] [cursor=pointer]
      - button "Demo" [ref=e66] [cursor=pointer]
    - main [ref=e69]:
      - generic [ref=e70]:
        - generic [ref=e72]:
          - heading "Cashier lookup" [level=1] [ref=e73]
          - paragraph [ref=e74]: Find the approved price to charge now. Search in English or Persian, or scan a barcode.
        - generic [ref=e75]:
          - generic [ref=e76]: Search products
          - generic [ref=e77]:
            - combobox "Search products" [expanded] [active] [ref=e81]
            - button "Scan barcode" [ref=e82] [cursor=pointer]
          - generic [ref=e88]:
            - group "AI category" [ref=e89]:
              - button "All" [pressed] [ref=e90] [cursor=pointer]
              - button "Beans & legumes" [ref=e91] [cursor=pointer]
              - button "Bread & bakery" [ref=e92] [cursor=pointer]
              - button "Cleaning" [ref=e93] [cursor=pointer]
              - button "More categories" [ref=e94] [cursor=pointer]: More
            - generic [ref=e97]: 16 products
            - paragraph [ref=e98]: Use ↑ ↓ and Enter to select a product.
        - generic [ref=e99]:
          - generic [ref=e101]:
            - heading "Basmati Rice 4.5 kg" [level=2] [ref=e102]:
              - generic [ref=e104]:
                - text: Basmati Rice
                - generic [ref=e105]: 4.5 kg
            - paragraph [ref=e106]:
              - generic [ref=e108]:
                - text: برنج باسماتی
                - generic [ref=e109]: ۴٫۵ کیلوگرمی
            - paragraph [ref=e110]:
              - generic [ref=e111]: Product Code 0001
              - generic [ref=e112]: 4.5 kg
          - generic [ref=e116]:
            - strong [ref=e117]: $23.99
            - generic [ref=e118]:
              - paragraph [ref=e119]: Selling price
              - paragraph [ref=e120]: Before tax
          - region "Dates" [ref=e121]:
            - paragraph [ref=e122]: No open dates in this location.
            - generic [ref=e123]: Last received 2026-10-10
        - generic [ref=e131]:
          - heading "Search results" [level=2] [ref=e132]
          - listbox "Product results" [ref=e133]:
            - option "Basmati Rice 4.5 kg برنج باسماتی ۴٫۵ کیلوگرمی Product Code 0001 $23.99" [selected] [ref=e134] [cursor=pointer]:
              - generic [ref=e135]:
                - strong [ref=e136]:
                  - generic [ref=e138]:
                    - text: Basmati Rice
                    - generic [ref=e139]: 4.5 kg
                - generic [ref=e140]:
                  - generic [ref=e142]:
                    - text: برنج باسماتی
                    - generic [ref=e143]: ۴٫۵ کیلوگرمی
                  - generic [ref=e144]: Product Code 0001
              - generic [ref=e145]: $23.99
            - option "Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی Product Code 0002 $1.49" [ref=e147] [cursor=pointer]:
              - generic [ref=e148]:
                - strong [ref=e149]:
                  - generic [ref=e151]:
                    - text: Canned Fava Beans
                    - generic [ref=e152]: 400 g
                - generic [ref=e153]:
                  - generic [ref=e155]:
                    - text: باقالا کنسرو شده
                    - generic [ref=e156]: ۴۰۰ گرمی
                  - generic [ref=e157]: Product Code 0002
              - generic [ref=e158]: $1.49
            - option "Sour Cherry Juice 1 L آب آلبالو ۱ لیتری Product Code 0003 $2.99 2 for $5.00" [ref=e160] [cursor=pointer]:
              - generic [ref=e161]:
                - strong [ref=e162]:
                  - generic [ref=e164]:
                    - text: Sour Cherry Juice
                    - generic [ref=e165]: 1 L
                - generic [ref=e166]:
                  - generic [ref=e168]:
                    - text: آب آلبالو
                    - generic [ref=e169]: ۱ لیتری
                  - generic [ref=e170]: Product Code 0003
              - generic [ref=e171]:
                - generic [ref=e172]: $2.99
                - generic [ref=e173]: 2 for $5.00
            - option "Black Tea 450 g چای سیاه ۴۵۰ گرمی Product Code 0004 $6.49" [ref=e176] [cursor=pointer]:
              - generic [ref=e177]:
                - strong [ref=e178]:
                  - generic [ref=e180]:
                    - text: Black Tea
                    - generic [ref=e181]: 450 g
                - generic [ref=e182]:
                  - generic [ref=e184]:
                    - text: چای سیاه
                    - generic [ref=e185]: ۴۵۰ گرمی
                  - generic [ref=e186]: Product Code 0004
              - generic [ref=e187]: $6.49
            - option "Ground Sumac 100 g سماق ۱۰۰ گرمی Product Code 0005 $1.99 3 for $5.00" [ref=e189] [cursor=pointer]:
              - generic [ref=e190]:
                - strong [ref=e191]:
                  - generic [ref=e193]:
                    - text: Ground Sumac
                    - generic [ref=e194]: 100 g
                - generic [ref=e195]:
                  - generic [ref=e197]:
                    - text: سماق
                    - generic [ref=e198]: ۱۰۰ گرمی
                  - generic [ref=e199]: Product Code 0005
              - generic [ref=e200]:
                - generic [ref=e201]: $1.99
                - generic [ref=e202]: 3 for $5.00
            - option "Lavash Bread 500 g نان لواش ۵۰۰ گرمی Product Code 0006 $1.99 Pending 3 for $5.00" [ref=e205] [cursor=pointer]:
              - generic [ref=e206]:
                - strong [ref=e207]:
                  - generic [ref=e209]:
                    - text: Lavash Bread
                    - generic [ref=e210]: 500 g
                - generic [ref=e211]:
                  - generic [ref=e213]:
                    - text: نان لواش
                    - generic [ref=e214]: ۵۰۰ گرمی
                  - generic [ref=e215]: Product Code 0006
              - generic [ref=e216]:
                - generic [ref=e217]: $1.99
                - generic [ref=e218]:
                  - generic [ref=e219]: Pending
                  - generic [ref=e220]: 3 for $5.00
            - option "Dried Red Kidney Beans 900 g لوبیا قرمز ۹۰۰ گرمی Product Code 0007 $3.99 2 for $7.00" [ref=e222] [cursor=pointer]:
              - generic [ref=e223]:
                - strong [ref=e224]:
                  - generic [ref=e226]:
                    - text: Dried Red Kidney Beans
                    - generic [ref=e227]: 900 g
                - generic [ref=e228]:
                  - generic [ref=e230]:
                    - text: لوبیا قرمز
                    - generic [ref=e231]: ۹۰۰ گرمی
                  - generic [ref=e232]: Product Code 0007
              - generic [ref=e233]:
                - generic [ref=e234]: $3.99
                - generic [ref=e235]: 2 for $7.00
            - option "Sunflower Oil 1.8 L روغن آفتابگردان ۱٫۸ لیتری Product Code 0008 $9.49 Sale requested $7.99 · Oct 15–Oct 28" [ref=e238] [cursor=pointer]:
              - generic [ref=e239]:
                - strong [ref=e240]:
                  - generic [ref=e242]:
                    - text: Sunflower Oil
                    - generic [ref=e243]: 1.8 L
                - generic [ref=e244]:
                  - generic [ref=e246]:
                    - text: روغن آفتابگردان
                    - generic [ref=e247]: ۱٫۸ لیتری
                  - generic [ref=e248]: Product Code 0008
              - generic [ref=e249]:
                - generic [ref=e250]: $9.49
                - generic [ref=e253]:
                  - text: Sale requested
                  - generic [ref=e254]: $7.99
                  - text: ·
                  - generic [ref=e255]: Oct 15–Oct 28
            - option "Potato Chips 150 g چیپس سیب‌زمینی ۱۵۰ گرمی Product Code 0009 $2.99 Taxable 2 for $5.00" [ref=e256] [cursor=pointer]:
              - generic [ref=e257]:
                - strong [ref=e258]:
                  - generic [ref=e260]:
                    - text: Potato Chips
                    - generic [ref=e261]: 150 g
                - generic [ref=e262]:
                  - generic [ref=e264]:
                    - text: چیپس سیب‌زمینی
                    - generic [ref=e265]: ۱۵۰ گرمی
                  - generic [ref=e266]: Product Code 0009
              - generic [ref=e267]:
                - generic [ref=e268]: $2.99
                - generic [ref=e269]:
                  - generic [ref=e270]: Taxable
                  - generic [ref=e271]: 2 for $5.00
            - option "Fruit Soda 6-pack نوشابه میوه‌ای بسته ۶ عددی Product Code 0010 $4.99 Taxable" [ref=e273] [cursor=pointer]:
              - generic [ref=e274]:
                - strong [ref=e275]:
                  - generic [ref=e276]: Fruit Soda 6-pack
                - generic [ref=e277]:
                  - generic [ref=e278]: نوشابه میوه‌ای بسته ۶ عددی
                  - generic [ref=e279]: Product Code 0010
              - generic [ref=e280]:
                - generic [ref=e281]: $4.99
                - generic [ref=e282]: Taxable
            - option "Tea Glass Set (6 pcs) ست استکان چای (۶ عددی) Product Code 0011 $8.99 Taxable" [ref=e284] [cursor=pointer]:
              - generic [ref=e285]:
                - strong [ref=e286]:
                  - generic [ref=e287]: Tea Glass Set (6 pcs)
                - generic [ref=e288]:
                  - generic [ref=e289]: ست استکان چای (۶ عددی)
                  - generic [ref=e290]: Product Code 0011
              - generic [ref=e291]:
                - generic [ref=e292]: $8.99
                - generic [ref=e293]: Taxable
            - option "Stainless Steel Pot 24 cm قابلمه استیل ۲۴ سانتی‌متری Product Code 0012 $16.99 Sale Regular $20.99 Until Oct 25 Taxable" [ref=e295] [cursor=pointer]:
              - generic [ref=e296]:
                - strong [ref=e297]:
                  - generic [ref=e298]: Stainless Steel Pot 24 cm
                - generic [ref=e299]:
                  - generic [ref=e300]: قابلمه استیل ۲۴ سانتی‌متری
                  - generic [ref=e301]: Product Code 0012
              - generic [ref=e302]:
                - generic [ref=e303]: $16.99
                - generic [ref=e305]:
                  - generic [ref=e306]:
                    - generic [ref=e307]: Sale
                    - deletion [ref=e308]: Regular $20.99
                    - generic [ref=e309]: Until Oct 25
                  - generic [ref=e310]: Taxable
            - option "Rice Cooker 1.8 L پلوپز ۱٫۸ لیتری Product Code 0013 $52.49 Taxable" [ref=e311] [cursor=pointer]:
              - generic [ref=e312]:
                - strong [ref=e313]:
                  - generic [ref=e315]:
                    - text: Rice Cooker
                    - generic [ref=e316]: 1.8 L
                - generic [ref=e317]:
                  - generic [ref=e319]:
                    - text: پلوپز
                    - generic [ref=e320]: ۱٫۸ لیتری
                  - generic [ref=e321]: Product Code 0013
              - generic [ref=e322]:
                - generic [ref=e323]: $52.49
                - generic [ref=e324]: Taxable
            - option "Kitchen Sponge 3-pack اسفنج ظرفشویی بسته ۳ عددی Product Code 0014 $2.49 Taxable" [ref=e326] [cursor=pointer]:
              - generic [ref=e327]:
                - strong [ref=e328]:
                  - generic [ref=e329]: Kitchen Sponge 3-pack
                - generic [ref=e330]:
                  - generic [ref=e331]: اسفنج ظرفشویی بسته ۳ عددی
                  - generic [ref=e332]: Product Code 0014
              - generic [ref=e333]:
                - generic [ref=e334]: $2.49
                - generic [ref=e335]: Taxable
            - option "Bulk Almonds بادام فله Product Code 0016 $7.49/lb $16.51/kg" [ref=e337] [cursor=pointer]:
              - generic [ref=e338]:
                - strong [ref=e339]:
                  - generic [ref=e340]: Bulk Almonds
                - generic [ref=e341]:
                  - generic [ref=e342]: بادام فله
                  - generic [ref=e343]: Product Code 0016
              - generic [ref=e345]:
                - generic [ref=e346]: $7.49/lb
                - generic [ref=e347]: $16.51/kg
            - option "Dried Barberries 100 g زرشک خشک ۱۰۰ گرمی Product Code 0015 No approved price yet Pending" [ref=e348] [cursor=pointer]:
              - generic [ref=e349]:
                - strong [ref=e350]:
                  - generic [ref=e352]:
                    - text: Dried Barberries
                    - generic [ref=e353]: 100 g
                - generic [ref=e354]:
                  - generic [ref=e356]:
                    - text: زرشک خشک
                    - generic [ref=e357]: ۱۰۰ گرمی
                  - generic [ref=e358]: Product Code 0015
              - generic [ref=e359]:
                - generic [ref=e360]: No approved price yet
                - generic [ref=e361]: Pending
```

# Test source

```ts
  1   | import { configuredPersonExpectation } from "./configured-person-expectations";
  2   | import { expect, test } from "@playwright/test";
  3   | import { chooseOption, setBranch, setLanguage, signIn } from "./helpers";
  4   | 
  5   | async function notebookTab(
  6   |   page: import("@playwright/test").Page,
  7   |   name: string,
  8   | ) {
  9   |   await page
  10  |     .getByRole("tab", { name: new RegExp(`^${name}( \\d+)?$`) })
> 11  |     .click();
      |      ^ Error: locator.click: Test timeout of 60000ms exceeded.
  12  | }
  13  | async function createCleaningNotebook(page: import("@playwright/test").Page) {
  14  |   await page.goto("/#notes");
  15  |   await page.getByRole("button", { name: "New notebook", exact: true }).click();
  16  |   const dialog = page.getByRole("dialog", {
  17  |     name: "New notebook",
  18  |     exact: true,
  19  |   });
  20  |   await dialog
  21  |     .getByLabel("Name (English)", { exact: true })
  22  |     .fill("Cleaning log");
  23  |   await dialog
  24  |     .getByLabel("Name (Persian) (optional)", { exact: true })
  25  |     .fill("دفتر نظافت");
  26  |   await chooseOption(
  27  |     page,
  28  |     dialog.getByLabel("Branch", { exact: true }),
  29  |     "North York",
  30  |   );
  31  |   await dialog
  32  |     .getByRole("group", { name: "Who can read", exact: true })
  33  |     .getByRole("checkbox", { name: "Cashier", exact: true })
  34  |     .check();
  35  |   await dialog
  36  |     .getByRole("checkbox", { name: "Measurement", exact: true })
  37  |     .check();
  38  |   await dialog.getByLabel("Measurement unit", { exact: true }).fill("°C");
  39  |   await dialog
  40  |     .getByRole("button", { name: "Save notebook", exact: true })
  41  |     .click();
  42  |   await expect(dialog).not.toBeVisible();
  43  |   await notebookTab(page, "Cleaning log");
  44  |   await page.getByRole("button", { name: "Add note", exact: true }).click();
  45  | }
  46  | 
  47  | test("Notes search has a search icon, a placeholder, bounded fields and touch actions, and the singular note count", async ({
  48  |   page,
  49  | }) => {
  50  |   await signIn(page, "Floor Worker");
  51  |   await page.goto("/#notes");
  52  |   const search = page.getByLabel("Search notes", { exact: true });
  53  |   await expect(search).toHaveAttribute("placeholder", "Search all notebooks");
  54  |   await expect(page.locator(".filter-search-pill svg")).toBeVisible();
  55  |   await search.fill("Sunflower oil");
  56  |   await expect(page.locator(".filter-count")).toHaveText("1 note");
  57  |   await expect(page.locator(".filter-count")).not.toHaveText("1 notes");
  58  |   const controls = await page.locator(".filter-toolbar").evaluate((el) =>
  59  |     Array.from(el.querySelectorAll("input,button,.ui-checked-control"))
  60  |       .filter((control) => control.getBoundingClientRect().height > 0)
  61  |       .map((control) => ({
  62  |         height: control.getBoundingClientRect().height,
  63  |         kind: control.matches("input,.ui-input,.ui-checked-control")
  64  |           ? "field"
  65  |           : control.getAttribute("data-control-kind"),
  66  |       })),
  67  |   );
  68  |   for (const control of controls) {
  69  |     expect(["field", "action", "icon"]).toContain(control.kind);
  70  |     const actionHeight = page.viewportSize()!.width < 760 ? 44 : 40;
  71  |     expect(
  72  |       Math.abs(control.height - (control.kind === "field" ? 44 : actionHeight)),
  73  |     ).toBeLessThanOrEqual(1);
  74  |   }
  75  | });
  76  | 
  77  | test("Supervisor configures a custom notebook and entries persist with author, branch and enabled fields", async ({
  78  |   page,
  79  | }) => {
  80  |   await signIn(page, "Supervisor");
  81  |   await createCleaningNotebook(page);
  82  |   await expect(
  83  |     page.getByLabel("Measurement (°C)", { exact: true }),
  84  |   ).toBeVisible();
  85  |   await expect(
  86  |     page.getByLabel("Product (optional)", { exact: true }),
  87  |   ).toHaveCount(0);
  88  |   await page.getByLabel("Note", { exact: true }).fill("Deli counter cleaned");
  89  |   await page.getByLabel("Measurement (°C)", { exact: true }).fill("3.5");
  90  |   await page.getByRole("button", { name: "Save note", exact: true }).click();
  91  |   const entry = page
  92  |     .locator(".notebook-entry-card")
  93  |     .filter({ hasText: "Deli counter cleaned" });
  94  |   await expect(entry).toContainText(
  95  |     configuredPersonExpectation("manager").name_en,
  96  |   );
  97  |   await expect(entry).toContainText("North York");
  98  |   await expect(entry).toContainText("3.5 °C");
  99  |   await page.reload();
  100 |   await notebookTab(page, "Cleaning log");
  101 |   await expect(entry).toBeVisible();
  102 |   await page
  103 |     .getByRole("button", { name: "Edit notebook", exact: true })
  104 |     .click();
  105 |   const dialog = page.getByRole("dialog", {
  106 |     name: "Edit notebook",
  107 |     exact: true,
  108 |   });
  109 |   await dialog.getByLabel("Measurement unit", { exact: true }).fill("°F");
  110 |   await dialog
  111 |     .getByRole("button", { name: "Save notebook", exact: true })
```