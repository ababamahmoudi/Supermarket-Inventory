# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: returns-a2.spec.ts >> Returns desktop columns align within two pixels and phone card labels/values fit in English and Persian
- Location: tests/returns-a2.spec.ts:305:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=e5]:
    - banner [ref=e6]:
      - button "Open menu" [ref=e7] [cursor=pointer]
      - combobox "Location" [ref=e11] [cursor=pointer]:
        - generic [ref=e16]: North York
      - button "Notifications, 5 unread" [ref=e19] [cursor=pointer]:
        - generic [ref=e20]: "5"
      - button "User menu" [ref=e25] [cursor=pointer]:
        - generic [aria-hidden] [ref=e27]: DM
      - button "More" [ref=e28] [cursor=pointer]
    - main [ref=e34]:
      - generic [ref=e36]:
        - heading "Returns" [level=1] [ref=e37]
        - paragraph [ref=e38]: Supplier returns and credits
      - generic [ref=e39]:
        - tablist "Returns view" [ref=e40]:
          - tab "Open" [selected] [ref=e41] [cursor=pointer]
          - tab "History" [ref=e43] [cursor=pointer]
        - generic "Filter returns" [ref=e45]:
          - textbox "Search returns" [ref=e50]
          - combobox "Supplier" [ref=e51] [cursor=pointer]:
            - generic [ref=e52]: All suppliers
          - combobox "Status" [ref=e55] [cursor=pointer]:
            - generic [ref=e56]: All statuses
          - combobox "Return branch" [ref=e59] [cursor=pointer]:
            - generic [ref=e60]: All branches
          - button "Clear filters" [ref=e63] [cursor=pointer]
          - generic [ref=e65]:
            - generic [ref=e66]: 2 results
            - button "Columns" [ref=e67] [cursor=pointer]
        - table [ref=e71]:
          - rowgroup [ref=e72]:
            - 'row "Return #1 · Fresh Valley Foods" [ref=e73] [cursor=pointer]':
              - cell "Fresh Valley Foods" [ref=e74]
              - cell "Waiting for pickup" [ref=e75]
              - cell [ref=e77]:
                - 'link "View Return #1" [ref=e78]':
                  - /url: "#return?id=demo-return-1"
              - cell "#1 North York 2026-10-14" [ref=e81]:
                - link "#1" [ref=e83]:
                  - /url: "#return?id=demo-return-1"
                - generic [ref=e85]: North York
                - generic [ref=e86]: 2026-10-14
            - 'row "Return #2 · Golden Grain Distributors" [ref=e88] [cursor=pointer]':
              - cell "Golden Grain Distributors" [ref=e89]
              - cell "Waiting for credit" [ref=e90]
              - cell [ref=e92]:
                - 'link "View Return #2" [ref=e93]':
                  - /url: "#return?id=demo-return-2"
              - cell "#2 North York 2026-10-11" [ref=e96]:
                - link "#2" [ref=e98]:
                  - /url: "#return?id=demo-return-2"
                - generic [ref=e100]: North York
                - generic [ref=e101]: 2026-10-11
```

# Test source

```ts
  85  |           ...label.split(/\s+/).map((word) => context.measureText(word).width),
  86  |         );
  87  |         const fragments = [];
  88  |         const walker = document.createTreeWalker(cell, NodeFilter.SHOW_TEXT);
  89  |         let text: Node | null;
  90  |         while ((text = walker.nextNode())) {
  91  |           const parent = text.parentElement;
  92  |           if (
  93  |             !text.textContent?.trim() ||
  94  |             !parent?.getClientRects().length ||
  95  |             parent.closest(".sr-only,[hidden],[aria-hidden=true]")
  96  |           )
  97  |             continue;
  98  |           const range = document.createRange();
  99  |           range.selectNodeContents(text);
  100 |           fragments.push(...range.getClientRects());
  101 |         }
  102 |         const controls = [
  103 |           ...cell.querySelectorAll<HTMLElement>(
  104 |             "button,a,input,[role=combobox],[role=checkbox]",
  105 |           ),
  106 |         ].filter((control) => control.getClientRects().length);
  107 |         // The separate Details cell intentionally renders an icon control.
  108 |         // Count its real visible accessible name, while keeping every text
  109 |         // fragment, caption and control containment check below.
  110 |         const labelledControls = controls.filter((control) => {
  111 |           const labelledBy = control.getAttribute("aria-labelledby");
  112 |           const name =
  113 |             control.getAttribute("aria-label")?.trim() ||
  114 |             labelledBy
  115 |               ?.split(/\s+/)
  116 |               .map(
  117 |                 (id) => document.getElementById(id)?.textContent?.trim() ?? "",
  118 |               )
  119 |               .join(" ")
  120 |               .trim();
  121 |           return (
  122 |             Boolean(name) &&
  123 |             control.checkVisibility({
  124 |               checkOpacity: true,
  125 |               checkVisibilityCSS: true,
  126 |             })
  127 |           );
  128 |         });
  129 |         cardCells.push({
  130 |           label,
  131 |           className: cell.className,
  132 |           width: body.width,
  133 |           widestLabelWord,
  134 |           matched: Boolean(header),
  135 |           labelled:
  136 |             index === 0 ||
  137 |             (caption.content.replace(/^["']|["']$/g, "") === label &&
  138 |               label.length > 0),
  139 |           captionFits: index === 0 || widestLabelWord <= body.width + 2,
  140 |           captionBeforeValue:
  141 |             index === 0 ||
  142 |             [
  143 |               ...fragments,
  144 |               ...controls.map((control) => control.getBoundingClientRect()),
  145 |             ].every(
  146 |               (fragment) =>
  147 |                 fragment.top >=
  148 |                 body.top + Number.parseFloat(caption.fontSize) - 2,
  149 |             ),
  150 |           visibleValueFragments: fragments.length,
  151 |           visibleLabelledControlValues: labelledControls.length,
  152 |           rowContained: contains(tableBox, rowBox),
  153 |           cellContained: contains(rowBox, body),
  154 |           valuesContained: fragments.every((fragment) =>
  155 |             contains(body, fragment),
  156 |           ),
  157 |           controlsContained: controls.every((control) =>
  158 |             contains(body, control.getBoundingClientRect()),
  159 |           ),
  160 |           noCellOverflow: cell.scrollWidth <= cell.clientWidth + 2,
  161 |         });
  162 |       }
  163 |     }
  164 |     return {
  165 |       cards,
  166 |       visibleRows: rows.length,
  167 |       columns,
  168 |       cardCells,
  169 |       uniqueHeaderIdentities: headerMap.size === headers.length,
  170 |       tableContained:
  171 |         tableBox.left >= wrapperBox.left - 2 &&
  172 |         tableBox.right <= wrapperBox.right + 2,
  173 |       noTableOverflow: wrapper.scrollWidth <= wrapper.clientWidth + 2,
  174 |       noPageOverflow: document.documentElement.scrollWidth <= innerWidth + 2,
  175 |     };
  176 |   });
  177 |   expect(geometry.visibleRows).toBeGreaterThan(0);
  178 |   expect(geometry.uniqueHeaderIdentities).toBe(true);
  179 |   expect(geometry.tableContained).toBe(true);
  180 |   expect(geometry.noTableOverflow).toBe(true);
  181 |   expect(geometry.noPageOverflow).toBe(true);
  182 |   if (geometry.cards) {
  183 |     expect(geometry.cardCells.length).toBeGreaterThan(0);
  184 |     for (const cell of geometry.cardCells) {
> 185 |       expect(cell.matched).toBe(true);
      |                            ^ Error: expect(received).toBe(expected) // Object.is equality
  186 |       expect(cell.labelled).toBe(true);
  187 |       expect(cell.captionFits, JSON.stringify(cell)).toBe(true);
  188 |       expect(cell.captionBeforeValue).toBe(true);
  189 |       expect(
  190 |         cell.visibleValueFragments + cell.visibleLabelledControlValues,
  191 |       ).toBeGreaterThan(0);
  192 |       expect(cell.rowContained).toBe(true);
  193 |       expect(cell.cellContained).toBe(true);
  194 |       expect(cell.valuesContained).toBe(true);
  195 |       expect(cell.controlsContained).toBe(true);
  196 |       expect(cell.noCellOverflow).toBe(true);
  197 |     }
  198 |   } else {
  199 |     expect(geometry.columns.length).toBeGreaterThan(0);
  200 |     for (const column of geometry.columns) {
  201 |       expect(column.matched).toBe(true);
  202 |       if (!column.matched) continue;
  203 |       expect(column.left).toBeLessThanOrEqual(2);
  204 |       expect(column.right).toBeLessThanOrEqual(2);
  205 |       expect(column.headerPadding).toEqual(column.bodyPadding);
  206 |       expect(column.headerAlign).toBe(column.bodyAlign);
  207 |     }
  208 |   }
  209 | }
  210 | 
  211 | test("Returns starts with all suppliers and Open records, and opens each return as its own page", async ({
  212 |   page,
  213 | }) => {
  214 |   await signIn(page, "Supervisor");
  215 |   await visitPage(page, "Returns");
  216 |   await expect(page.getByLabel("Supplier", { exact: true })).toHaveText(
  217 |     "All suppliers",
  218 |   );
  219 |   await expect(page.getByLabel("Status", { exact: true })).toHaveText(
  220 |     "All statuses",
  221 |   );
  222 |   await expect(page.getByLabel("Return branch", { exact: true })).toHaveText(
  223 |     "All branches",
  224 |   );
  225 |   const count = await page.locator(".returns-overview-table tbody tr").count();
  226 |   expect(count).toBeGreaterThanOrEqual(2);
  227 |   await page.getByLabel("Search returns", { exact: true }).fill("Fresh Valley");
  228 |   await expect(page.locator(".returns-overview-table tbody tr")).toHaveCount(1);
  229 |   await expect(page.locator(".returns-overview-table tbody")).toContainText(
  230 |     "Fresh Valley Foods",
  231 |   );
  232 |   await page
  233 |     .getByRole("button", { name: "Clear filters", exact: true })
  234 |     .click();
  235 |   await expect(page.locator(".returns-overview-table tbody tr")).toHaveCount(
  236 |     count,
  237 |   );
  238 |   await page.getByRole("link", { name: "#1", exact: true }).click();
  239 |   await expect(page).toHaveURL(/#return\?id=demo-return-1$/);
  240 |   await expect(page.getByRole("heading", { level: 1 })).toHaveText("Return #1");
  241 |   await expect(page.locator(".return-detail-subtitle")).toContainText(
  242 |     "created",
  243 |   );
  244 |   await expect(page.locator(".return-detail-subtitle")).toContainText(
  245 |     "Demo Floor Worker",
  246 |   );
  247 |   await expect(page.locator(".return-detail-subtitle")).not.toContainText("—");
  248 |   await expect(
  249 |     page
  250 |       .locator(".return-header-card")
  251 |       .getByRole("button", { name: "Record pickup", exact: true }),
  252 |   ).toBeVisible();
  253 |   await expect(page.locator(".return-lines-card")).toContainText(
  254 |     "Sour Cherry Juice 1 L",
  255 |   );
  256 |   await expect(
  257 |     page
  258 |       .locator(".return-evidence-card")
  259 |       .getByRole("heading", { name: "Evidence and history", exact: true }),
  260 |   ).toBeVisible();
  261 |   await expect(page.locator(".returns-overview-table")).toHaveCount(0);
  262 |   await page
  263 |     .getByRole("link", { name: "Back to Returns", exact: true })
  264 |     .click();
  265 |   await expect(page.locator(".returns-overview-table tbody tr")).toHaveCount(
  266 |     count,
  267 |   );
  268 | });
  269 | 
  270 | test("Return policy dialog centers, closes with Escape and backdrop, and restores trigger focus", async ({
  271 |   page,
  272 | }) => {
  273 |   await signIn(page, "Floor Worker");
  274 |   await page.goto("/#return?id=demo-return-1");
  275 |   const trigger = page.getByRole("button", {
  276 |     name: "Return policy",
  277 |     exact: true,
  278 |   });
  279 |   await trigger.click();
  280 |   const dialog = page.getByRole("dialog", {
  281 |     name: "Return policy",
  282 |     exact: true,
  283 |   });
  284 |   await expect(dialog).toBeVisible();
  285 |   const centered = await dialog.evaluate((node) => {
```