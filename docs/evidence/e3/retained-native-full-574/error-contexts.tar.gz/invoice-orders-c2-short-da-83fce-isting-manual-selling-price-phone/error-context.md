# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: invoice-orders-c2.spec.ts >> short-dated expiry discount requires a real date and preserves an existing manual selling price
- Location: tests/invoice-orders-c2.spec.ts:250:1

# Error details

```
Test timeout of 60000ms exceeded.
```

```
Error: locator.click: Test timeout of 60000ms exceeded.
Call log:
  - waiting for locator('.invoice-line').first().getByRole('button', { name: 'Short-dated (expiry discount)', exact: true })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=e5]:
    - banner [ref=e6]:
      - button "Open menu" [ref=e7] [cursor=pointer]
      - combobox "Location" [ref=e11] [cursor=pointer]:
        - generic [ref=e16]: North York
      - button "Notifications, 8 unread" [ref=e19] [cursor=pointer]:
        - generic [ref=e20]: "8"
      - button "User menu" [ref=e25] [cursor=pointer]:
        - generic [aria-hidden] [ref=e27]: DM
      - button "More" [ref=e28] [cursor=pointer]
    - main [ref=e34]:
      - generic [ref=e35]:
        - link "Back to Invoices" [ref=e36] [cursor=pointer]:
          - /url: "#invoices"
        - generic [ref=e39]:
          - generic [ref=e40]:
            - heading "Invoices" [level=1] [ref=e41]
            - paragraph [ref=e42]: Deliveries and supplier invoices
          - button "New invoice" [ref=e44] [cursor=pointer]
        - tablist "Invoice views" [ref=e45]:
          - tab "Drafts" [ref=e46] [cursor=pointer]
          - tab "Processing" [ref=e48] [cursor=pointer]
          - tab "Needs review" [selected] [ref=e50] [cursor=pointer]
          - tab "Ready to post" [ref=e52] [cursor=pointer]
          - tab "Posted" [ref=e54] [cursor=pointer]
          - tab "Cancelled" [ref=e56] [cursor=pointer]
        - generic [ref=e58]:
          - complementary "Original invoice" [ref=e59]:
            - generic [ref=e60]:
              - heading "Original invoice" [level=2] [ref=e61]
              - paragraph [ref=e62]: AI invoice reading is simulated
              - generic [ref=e64]:
                - generic [ref=e65]: Upload a PDF or photo
                - generic [ref=e66]:
                  - button "Upload a PDF or photo" [ref=e67]
                  - button "Take photo" [ref=e68]
                  - generic [ref=e69]:
                    - generic [ref=e73]:
                      - strong [ref=e74]: fictional-supplier-invoice.png
                      - generic [ref=e75]: 1 KB
                    - button "Remove file" [ref=e76] [cursor=pointer]
                  - generic [ref=e80]:
                    - button "Browse" [ref=e81] [cursor=pointer]
                    - button "Take photo" [ref=e82] [cursor=pointer]
              - group "Original invoice" [ref=e86]:
                - generic [ref=e87]:
                  - button "Zoom out" [ref=e88] [cursor=pointer]
                  - generic [ref=e90]: 100%
                  - button "Zoom in" [ref=e91] [cursor=pointer]
                - button "Fit width" [ref=e93] [cursor=pointer]
                - button "Fit page" [ref=e94] [cursor=pointer]
                - button "Download" [ref=e95] [cursor=pointer]
              - img "Original invoice image" [ref=e100]
          - generic [ref=e101]:
            - generic [ref=e102]:
              - generic "Delivery summary" [ref=e103]:
                - generic [ref=e104]:
                  - generic [ref=e105]: Subtotal
                  - strong [ref=e106]: $0.98
                - generic [ref=e107]:
                  - generic [ref=e108]: Tax
                  - strong [ref=e109]: $0.00
                - generic [ref=e110]:
                  - generic [ref=e111]: Shorts and refused deduction
                  - strong [ref=e112]: $0.00
                - generic [ref=e113]:
                  - generic [ref=e114]: Payable
                  - strong [ref=e115]: $0.98
              - paragraph [ref=e116]: This is the amount of this invoice, not a supplier balance. Received records only physically delivered units.
            - generic [ref=e117]:
              - heading [level=2] [ref=e118]:
                - button "Invoice details" [ref=e119] [cursor=pointer]
              - paragraph [ref=e122]:
                - generic [ref=e123]: Fresh Valley Foods
                - text: ·
                - generic [ref=e124]: —
                - text: · North York ·
                - generic [ref=e125]: 2026-10-15
              - paragraph [ref=e126]:
                - generic [ref=e127]: Needs review
                - text: Changes save automatically in this browser.
            - generic [ref=e129]:
              - heading "Compare with order" [level=2] [ref=e130]
              - generic [ref=e131]:
                - generic [ref=e132]: Order (optional)
                - combobox "Order (optional)" [ref=e133] [cursor=pointer]:
                  - generic [ref=e134]: No linked order
                - paragraph [ref=e137]: Choose an open order for this supplier and receiving location.
            - generic [ref=e138]:
              - heading "Review invoice lines" [level=2] [ref=e139]
              - paragraph [ref=e140]: Choose Cases or Units and confirm the product, pack, quantities, cost, and date decision on each line.
              - table [ref=e142]:
                - 'rowgroup "Line 1: Canned Fava Beans 400 g" [ref=e143]':
                  - row [ref=e144] [cursor=pointer]:
                    - cell "1. Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی 0002 · 400 g Matched" [ref=e145]:
                      - generic [ref=e146]:
                        - heading [level=3] [ref=e147]:
                          - button "1. Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی" [expanded] [ref=e148]:
                            - generic [ref=e149]: "1."
                            - generic [ref=e150]:
                              - strong [ref=e151]:
                                - generic [ref=e152]:
                                  - text: Canned Fava Beans
                                  - generic [ref=e153]: 400 g
                              - generic [ref=e155]:
                                - text: باقالا کنسرو شده
                                - generic [ref=e156]: ۴۰۰ گرمی
                        - paragraph [ref=e159]:
                          - text: 0002 ·
                          - generic [ref=e160]: 400 g
                        - generic [ref=e163]: Matched
                    - cell [ref=e165]:
                      - generic [ref=e166]:
                        - generic [ref=e167]: Invoiced
                        - textbox "Invoiced" [ref=e168]: "1"
                      - generic [ref=e169]:
                        - generic [ref=e170]: Delivered
                        - textbox "Delivered" [ref=e171]: "1"
                    - cell [ref=e172]:
                      - generic [ref=e173]:
                        - generic [ref=e174]: Unit cost before tax
                        - textbox "Unit cost before tax" [ref=e175]: "0.9800"
                    - cell "Line total $0.98" [ref=e176]:
                      - generic [ref=e177]: Line total
                      - text: $0.98
                    - 'cell "Selling price $2.49 Manual price Rule price $1.49 · Manual price $2.49 Margin %: 60.64% Approved: $2.49" [ref=e178]':
                      - generic [ref=e179]:
                        - generic [ref=e180]: Selling price
                        - strong [ref=e181]: $2.49
                        - generic [ref=e182]: Manual price
                        - generic [ref=e183]:
                          - paragraph [ref=e184]: Rule price $1.49 · Manual price $2.49
                          - paragraph [ref=e185]:
                            - text: "Margin %:"
                            - generic [ref=e186]: 60.64%
                        - paragraph [ref=e187]: "Approved: $2.49"
                  - row [ref=e188]:
                    - cell [ref=e189]:
                      - generic [ref=e190]:
                        - group [ref=e191]:
                          - generic [ref=e192]:
                            - generic [ref=e193]: Quantity unit
                            - combobox "Quantity unit" [ref=e194] [cursor=pointer]:
                              - generic [ref=e195]: Units
                          - generic [ref=e198]:
                            - generic [ref=e199]: Units per case
                            - textbox "Units per case" [ref=e200]: "12"
                          - generic [ref=e201]:
                            - generic [ref=e202]: Supplier item code (optional)
                            - textbox "Supplier item code (optional)" [ref=e203]
                          - paragraph [ref=e204]: 1 unit
                          - generic [ref=e205]:
                            - generic [ref=e206]: Matched product
                            - combobox "Matched product" [ref=e207] [cursor=pointer]:
                              - generic [ref=e209]:
                                - text: ⁦0002⁩ · ⁦
                                - generic [ref=e210]:
                                  - text: Canned Fava Beans
                                  - generic [ref=e211]: 400 g
                                - text: ⁩
                          - generic [ref=e214]:
                            - generic [ref=e215]: Pricing category
                            - combobox "Pricing category" [ref=e216] [cursor=pointer]:
                              - generic [ref=e217]: Grocery
                        - button "Remove line" [ref=e220] [cursor=pointer]
                        - checkbox "Mark as short" [ref=e221] [cursor=pointer]
                        - group [ref=e224]:
                          - generic [ref=e225]:
                            - generic [ref=e226]: Track date
                            - group "Track date" [ref=e227]:
                              - button "Yes" [pressed] [ref=e228] [cursor=pointer]
                              - button "No" [ref=e230] [cursor=pointer]
                          - generic [ref=e232]:
                            - generic [ref=e233]:
                              - generic [ref=e234]: Date tracking
                              - combobox "Date tracking" [ref=e235] [cursor=pointer]:
                                - generic [ref=e236]: Expiry
                            - generic [ref=e239]:
                              - generic [ref=e240]: Date
                              - button "Date" [ref=e241] [cursor=pointer]:
                                - generic [ref=e242]: Choose date
                            - generic [ref=e245]:
                              - generic [ref=e246]: Lot number (optional)
                              - textbox "Lot number (optional)" [ref=e247]
                        - checkbox "Confirm this invoice line" [ref=e248] [cursor=pointer]
              - generic [ref=e251]:
                - generic [ref=e252]:
                  - generic [ref=e253]: Add a product to the invoice
                  - combobox "Add a product to the invoice" [ref=e254] [cursor=pointer]:
                    - generic [ref=e256]:
                      - text: ⁦0002⁩ · ⁦
                      - generic [ref=e257]:
                        - text: Canned Fava Beans
                        - generic [ref=e258]: 400 g
                      - text: ⁩
                - button "Add line" [ref=e261] [cursor=pointer]
                - button "+ Add new product" [ref=e262] [cursor=pointer]
          - generic [ref=e264]:
            - button "Save as draft" [ref=e265] [cursor=pointer]
            - button "Post invoice" [ref=e266] [cursor=pointer]
```

# Test source

```ts
  180 |     name: "Refused / sent back with the driver",
  181 |     exact: true,
  182 |   });
  183 |   if (!(await refusal.count()))
  184 |     await row
  185 |       .getByRole("button", { name: "Show details", exact: true })
  186 |       .click();
  187 |   await comparison
  188 |     .getByRole("button", {
  189 |       name: "Refused / sent back with the driver",
  190 |       exact: true,
  191 |     })
  192 |     .click();
  193 |   await comparison
  194 |     .getByRole("button", { name: "Accept new cost", exact: true })
  195 |     .click();
  196 |   await confirmNoDate(page);
  197 |   await post(page);
  198 |   const after = await stored(page);
  199 |   const currentOrder = after.orders!.find((item) => item.id === order.id)!;
  200 |   expect(currentOrder.status).toBe("received");
  201 |   expect(currentOrder.lines[0].received_units).toBe(12);
  202 |   expect(after.invoice.lines[0]).toMatchObject({
  203 |     qty_received_at_posting: 18,
  204 |     refused_units: 6,
  205 |     extra_delivery_decision: "refuse",
  206 |     order_price_decision: "accept",
  207 |   });
  208 |   expect(after.invoice.payable_after_open_shorts).toBe("13.20");
  209 |   expect(
  210 |     after.alerts.filter((alert) => alert.invoice_id === after.invoice.id),
  211 |   ).toHaveLength(1);
  212 |   expect(
  213 |     after.alerts.find((alert) => alert.invoice_id === after.invoice.id)
  214 |       ?.order_differences,
  215 |   ).toEqual(
  216 |     expect.arrayContaining([
  217 |       expect.objectContaining({ kind: "extra", units: 6, decision: "refuse" }),
  218 |       expect.objectContaining({ kind: "price_change", decision: "accept" }),
  219 |     ]),
  220 |   );
  221 |   await page.reload();
  222 |   const postedLine = page
  223 |     .locator(".posted-invoice-document tbody tr")
  224 |     .filter({ hasText: "Canned Fava Beans 400 g" });
  225 |   await expect(postedLine).toContainText("Delivered quantity: 12");
  226 |   await expect(postedLine).toContainText(
  227 |     "Refused / sent back with the driver · 6 · $6.60",
  228 |   );
  229 |   await expect(postedLine).toContainText("Accept new cost");
  230 |   await expect(postedLine.getByRole("cell").nth(2)).toHaveText("$1.10");
  231 |   await expect(
  232 |     page.locator(
  233 |       ".posted-invoice-document input, .posted-invoice-document select",
  234 |     ),
  235 |   ).toHaveCount(0);
  236 |   await page.goto("/#alerts");
  237 |   await expect(
  238 |     page.getByRole("heading", {
  239 |       name: "Invoice and order differences",
  240 |       exact: true,
  241 |     }),
  242 |   ).toBeVisible();
  243 |   await page.goto("/#received");
  244 |   await page
  245 |     .getByRole("textbox", { name: "Search Received", exact: true })
  246 |     .fill(after.invoice.supplier_invoice_number);
  247 |   await expect(page.locator(".received-table")).toContainText("12 units");
  248 | });
  249 | 
  250 | test("short-dated expiry discount requires a real date and preserves an existing manual selling price", async ({
  251 |   page,
  252 | }) => {
  253 |   await signIn(page, "Supervisor");
  254 |   const editor = await openC8PriceDialog(page, "0002");
  255 |   await editor.getByRole("radio", { name: /^New regular price/ }).check();
  256 |   await editor.getByLabel("Price", { exact: true }).fill("2.49");
  257 |   await editor
  258 |     .getByRole("checkbox", {
  259 |       name: "Add regular labels to the label waitlist",
  260 |       exact: true,
  261 |     })
  262 |     .uncheck();
  263 |   await editor
  264 |     .getByRole("button", { name: "Save new price", exact: true })
  265 |     .click();
  266 |   await expect(editor).not.toBeVisible();
  267 |   await expect
  268 |     .poll(
  269 |       async () =>
  270 |         (await stored(page)).products.find((entry) => entry.code === "0002")
  271 |           ?.manual_prices?.all.price,
  272 |     )
  273 |     .toBe("2.49");
  274 |   const before = await stored(page);
  275 |   const prior = before.products.find((item) => item.code === "0002")!;
  276 |   const line = await manual(page);
  277 |   await line.getByLabel("Unit cost before tax", { exact: true }).fill("0.8000");
  278 |   await line
  279 |     .getByRole("button", { name: "Short-dated (expiry discount)", exact: true })
> 280 |     .click();
      |      ^ Error: locator.click: Test timeout of 60000ms exceeded.
  281 |   await expect(
  282 |     line.getByRole("button", { name: "No", exact: true }),
  283 |   ).toBeDisabled();
  284 |   await expect(
  285 |     page.getByRole("button", { name: "Post invoice", exact: true }),
  286 |   ).toBeEnabled();
  287 |   await page.getByRole("button", { name: "Post invoice", exact: true }).click();
  288 |   await expect(
  289 |     page.getByRole("alert", { name: "What's missing", exact: true }),
  290 |   ).toBeVisible();
  291 |   await expect(
  292 |     line.getByRole("button", { name: "Keep $2.49", exact: true }),
  293 |   ).toHaveCount(0);
  294 |   await line.getByLabel("Date", { exact: true }).click();
  295 |   await page
  296 |     .getByRole("dialog", { name: "Choose date", exact: true })
  297 |     .getByRole("button", { name: "Today", exact: true })
  298 |     .click();
  299 |   await line
  300 |     .getByRole("checkbox", { name: "Confirm this invoice line", exact: true })
  301 |     .click();
  302 |   await post(page);
  303 |   const after = await stored(page);
  304 |   const product = after.products.find((item) => item.code === "0002")!;
  305 |   expect(product.last_cost_before_tax).toBe(prior.last_cost_before_tax);
  306 |   expect(product.selling_price).toBe("2.49");
  307 |   expect(product.manual_prices).toEqual(prior.manual_prices);
  308 |   expect(product.price_provenance).toEqual(prior.price_provenance);
  309 |   expect(after.invoice.payable_after_open_shorts).toBe("0.80");
  310 |   expect(
  311 |     after.expiry.find((entry) => entry.invoice_id === after.invoice.id)?.date,
  312 |   ).toBe(after.invoice.lines[0].date_value);
  313 |   expect(
  314 |     after.approvals.filter(
  315 |       (approval) => approval.source_invoice_id === after.invoice.id,
  316 |     ),
  317 |   ).toHaveLength(0);
  318 |   expect(
  319 |     after.alerts.filter((alert) =>
  320 |       alert.id.startsWith(`${after.invoice.id}:lower:`),
  321 |     ),
  322 |   ).toHaveLength(0);
  323 |   expect(
  324 |     await page.evaluate(
  325 |       () => document.documentElement.scrollWidth <= window.innerWidth,
  326 |     ),
  327 |   ).toBe(true);
  328 | });
  329 | 
```