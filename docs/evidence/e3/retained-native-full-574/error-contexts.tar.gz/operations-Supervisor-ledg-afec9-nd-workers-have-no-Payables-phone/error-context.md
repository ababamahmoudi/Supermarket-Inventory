# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: operations.spec.ts >> Supervisor ledger records a partial cheque, preserves outstanding and exports month-end; workers have no Payables
- Location: tests/operations.spec.ts:239:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('.payables-report').getByText('DEMO-1001', { exact: true }).first()
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('.payables-report').getByText('DEMO-1001', { exact: true }).first() with timeout 5000ms
  - waiting for locator('.payables-report').getByText('DEMO-1001', { exact: true }).first()

```

# Page snapshot

```yaml
- region "Supplier financial report" [ref=e2]:
  - generic [ref=e3]:
    - heading "Fresh Valley Foods" [level=2] [ref=e4]
    - paragraph [ref=e5]: North York · CAD · As of 2026-10-31
  - generic [ref=e6]:
    - generic [ref=e7]:
      - generic [ref=e8]: Supplier balance
      - strong [ref=e9]: $119.79
    - generic [ref=e10]:
      - generic [ref=e11]: Open invoice
      - strong [ref=e12]: "1"
    - generic [ref=e13]:
      - generic [ref=e14]: Overdue
      - strong [ref=e15]: $119.79
    - generic [ref=e16]:
      - generic [ref=e17]: Unapplied supplier credit
      - strong [ref=e18]: $0.00
  - generic [ref=e19]:
    - generic [ref=e20]:
      - heading "Month-end ledger summary" [level=2] [ref=e21]
      - button "Columns" [ref=e22] [cursor=pointer]
    - table [ref=e26]:
      - rowgroup [ref=e27]:
        - row [ref=e28]:
          - cell "2026-09-21" [ref=e29]
          - cell "Reference / note FV-20296" [ref=e31]:
            - text: Reference / note
            - generic [ref=e32]: FV-20296
          - cell "Amount $37.80" [ref=e33]:
            - text: Amount
            - generic [ref=e34]: $37.80
          - text: Action
        - row [ref=e35]:
          - cell "2026-09-21" [ref=e36]
          - cell "Reference / note FV-20296-PAYMENT" [ref=e38]:
            - text: Reference / note
            - generic [ref=e39]: FV-20296-PAYMENT
          - cell "Amount -$37.80" [ref=e40]:
            - text: Amount
            - generic [ref=e41]: "-$37.80"
          - text: Action
        - row [ref=e42]:
          - cell "2026-10-14" [ref=e43]
          - cell "Reference / note FV-20390" [ref=e45]:
            - text: Reference / note
            - generic [ref=e46]: FV-20390
          - cell "Amount $181.22" [ref=e47]:
            - text: Amount
            - generic [ref=e48]: $181.22
          - text: Action
        - row [ref=e49]:
          - cell "2026-10-14" [ref=e50]
          - cell "Reference / note FV-20390-PAYMENT" [ref=e52]:
            - text: Reference / note
            - generic [ref=e53]: FV-20390-PAYMENT
          - cell "Amount -$11.43" [ref=e54]:
            - text: Amount
            - generic [ref=e55]: "-$11.43"
          - text: Action
        - row [ref=e56]:
          - cell "2026-10-15" [ref=e57]
          - cell "Reference / note DEMO-PAY-001" [ref=e59]:
            - text: Reference / note
            - generic [ref=e60]: DEMO-PAY-001
          - cell "Amount -$50.00" [ref=e61]:
            - text: Amount
            - generic [ref=e62]: "-$50.00"
          - text: Action
  - generic [ref=e63]:
    - heading "Invoice outstanding amounts" [level=2] [ref=e64]
    - table [ref=e66]:
      - rowgroup [ref=e67]:
        - row [ref=e68]:
          - cell "FV-20296" [ref=e69]
          - cell "Branch North York" [ref=e71]
          - cell "Due date 2026-10-05" [ref=e72]:
            - text: Due date
            - generic [ref=e73]: 2026-10-05
          - cell [ref=e74]:
            - text: Details
            - button "Show details" [ref=e75] [cursor=pointer]
        - row [ref=e78]:
          - cell "FV-20390" [ref=e79]
          - cell "Branch North York" [ref=e81]
          - cell "Due date 2026-10-28" [ref=e82]:
            - text: Due date
            - generic [ref=e83]: 2026-10-28
          - cell [ref=e84]:
            - text: Details
            - button "Show details" [ref=e85] [cursor=pointer]
    - paragraph [ref=e88]: "Unallocated opening balances and adjustments: $0.00"
```

# Test source

```ts
  225 |   await expect(
  226 |     page.getByText("Fictional supervisor check requested", { exact: true }),
  227 |   ).toHaveCount(0);
  228 |   await page
  229 |     .getByRole("checkbox", {
  230 |       name: "Include done and ordered notes",
  231 |       exact: true,
  232 |     })
  233 |     .check();
  234 |   await expect(
  235 |     page.getByText("Fictional supervisor check requested", { exact: true }),
  236 |   ).toBeVisible();
  237 | });
  238 | 
  239 | test("Supervisor ledger records a partial cheque, preserves outstanding and exports month-end; workers have no Payables", async ({
  240 |   page,
  241 | }) => {
  242 |   await signIn(page, "Supervisor");
  243 |   await visit(page, "Payables");
  244 |   await page
  245 |     .getByRole("row")
  246 |     .filter({ hasText: "Fresh Valley Foods" })
  247 |     .getByRole("link", { name: "Fresh Valley Foods", exact: true })
  248 |     .click();
  249 |   await expect(
  250 |     page.getByText("$169.79", { exact: true }).first(),
  251 |   ).toBeVisible();
  252 |   await page
  253 |     .getByRole("button", { name: "Record external payment", exact: true })
  254 |     .click();
  255 |   await page
  256 |     .getByLabel("Payment receipt reference", { exact: true })
  257 |     .fill("DEMO-PAY-001");
  258 |   await page
  259 |     .getByRole("button", {
  260 |       name: "Preview oldest-due allocations",
  261 |       exact: true,
  262 |     })
  263 |     .click();
  264 |   await page
  265 |     .getByRole("button", { name: "Confirm and record payment", exact: true })
  266 |     .click();
  267 |   await page
  268 |     .getByRole("dialog", { name: "Record external payment", exact: true })
  269 |     .getByRole("button", { name: "Confirm and record payment", exact: true })
  270 |     .click();
  271 |   await expect(page.getByRole("status")).toContainText(
  272 |     "Recorded external payment",
  273 |   );
  274 |   await expect(
  275 |     page.getByText("$119.79", { exact: true }).first(),
  276 |   ).toBeVisible();
  277 |   while (
  278 |     await page
  279 |       .locator(".payables-ledger-table")
  280 |       .getByRole("button", { name: "Show details", exact: true })
  281 |       .count()
  282 |   )
  283 |     await page
  284 |       .locator(".payables-ledger-table")
  285 |       .getByRole("button", { name: "Show details", exact: true })
  286 |       .first()
  287 |       .click();
  288 |   await expect(
  289 |     page
  290 |       .locator(".payables-ledger-table")
  291 |       .getByText("DEMO-1001", { exact: true }),
  292 |   ).toBeVisible();
  293 |   await page
  294 |     .getByRole("tab", { name: "Month-end summary", exact: true })
  295 |     .click();
  296 |   await expect(
  297 |     page.getByRole("heading", {
  298 |       name: "Month-end ledger summary",
  299 |       exact: true,
  300 |     }),
  301 |   ).toBeVisible();
  302 |   const downloadPromise = page.waitForEvent("download");
  303 |   await page.getByRole("button", { name: "Export CSV", exact: true }).click();
  304 |   const download = await downloadPromise;
  305 |   expect(download.suggestedFilename()).toContain("payables-");
  306 |   await page.evaluate(() => {
  307 |     window.print = () => {
  308 |       document.body.dataset.printed = "yes";
  309 |     };
  310 |   });
  311 |   await page
  312 |     .getByRole("button", { name: "Print summary", exact: true })
  313 |     .click();
  314 |   await expect(page.locator("body")).toHaveAttribute("data-printed", "yes");
  315 |   await page.emulateMedia({ media: "print" });
  316 |   await expect(page.locator(".payables-report")).toBeVisible();
  317 |   await expect(page.locator(".payables-report-heading")).toContainText(
  318 |     "Fresh Valley Foods",
  319 |   );
  320 |   await expect(
  321 |     page
  322 |       .locator(".payables-report")
  323 |       .getByText("DEMO-1001", { exact: true })
  324 |       .first(),
> 325 |   ).toBeVisible();
      |     ^ Error: expect(locator).toBeVisible() failed
  326 |   await expect(
  327 |     page.getByRole("heading", {
  328 |       name: "Month-end ledger summary",
  329 |       exact: true,
  330 |     }),
  331 |   ).toBeVisible();
  332 |   await page.emulateMedia({ media: "screen" });
  333 |   await signIn(page, "Floor Worker");
  334 |   await expect(
  335 |     page.getByRole("link", { name: "Payables", exact: true }),
  336 |   ).toHaveCount(0);
  337 | });
  338 | 
  339 | test("dashboard shows four actionable KPIs and scoped lists, and operations render in Persian without page overflow", async ({
  340 |   page,
  341 | }) => {
  342 |   await signIn(page, "Supervisor");
  343 |   await runCanonicalBusinessFixture(
  344 |     page,
  345 |     (state) => {
  346 |       const common = { at: new Date().toISOString(), by: "Demo Supervisor" };
  347 |       state.activity = [
  348 |         {
  349 |           ...common,
  350 |           id: "company-wide-price",
  351 |           company_id: state.config.company.seed_key,
  352 |           branch: "all",
  353 |           action: "Approve price",
  354 |         },
  355 |         {
  356 |           ...common,
  357 |           id: "other-company-offer",
  358 |           company_id: "another-company",
  359 |           branch: "all",
  360 |           action: "Create offer",
  361 |         },
  362 |         {
  363 |           ...common,
  364 |           id: "other-branch-offer",
  365 |           company_id: state.config.company.seed_key,
  366 |           branch: "Branch 2",
  367 |           action: "Stop offer",
  368 |         },
  369 |       ];
  370 |     },
  371 |     undefined,
  372 |   );
  373 |   await page.reload();
  374 |   await visit(page, "Dashboard");
  375 |   await expect(page.getByText("Approve price", { exact: true })).toBeVisible();
  376 |   await expect(page.getByText("Create offer", { exact: true })).toHaveCount(0);
  377 |   await expect(page.getByText("Stop offer", { exact: true })).toHaveCount(0);
  378 |   await expect(page.locator(".dashboard-kpis > .kpi-card")).toHaveCount(4);
  379 |   await expect(page.locator(".kpi-label")).toHaveText([
  380 |     "Approvals waiting",
  381 |     "Open alerts",
  382 |     "Open shorts",
  383 |     "Expiring soon",
  384 |   ]);
  385 |   for (const heading of [
  386 |     "Approvals queue",
  387 |     "Alerts",
  388 |     "Recent invoices",
  389 |     "Returns",
  390 |     "Supplier balances",
  391 |     `Notes for ${configuredRoleLabel(readConfiguredRoleDefinitions(configuration.roles), "manager", "en")}`,
  392 |     "Activity",
  393 |   ])
  394 |     await expect(
  395 |       page.getByRole("heading", { name: heading, exact: true }),
  396 |     ).toBeVisible();
  397 |   await page
  398 |     .getByRole("button", { name: "Expiring soon: 2", exact: true })
  399 |     .click();
  400 |   await expect(
  401 |     page.getByRole("heading", { name: "Date tracking", exact: true, level: 1 }),
  402 |   ).toBeVisible();
  403 |   await setLanguage(page, "fa");
  404 |   await expect(page.locator("html")).toHaveAttribute("dir", "rtl");
  405 |   await expect(
  406 |     page.getByRole("heading", { name: "پیگیری تاریخ", exact: true, level: 1 }),
  407 |   ).toBeVisible();
  408 |   expect(
  409 |     await page.evaluate(
  410 |       () => document.documentElement.scrollWidth <= window.innerWidth,
  411 |     ),
  412 |   ).toBe(true);
  413 | });
  414 | 
  415 | test("invalid pickup evidence, invalid store-use quantities, and invalid financial amounts show errors without changing records or crashing the app", async ({
  416 |   page,
  417 | }) => {
  418 |   const errors: string[] = [];
  419 |   page.on("pageerror", (error) => errors.push(error.message));
  420 |   await signIn(page, "Floor Worker");
  421 |   await openReturn(page, 1);
  422 |   await page
  423 |     .getByRole("button", { name: "Record pickup", exact: true })
  424 |     .click();
  425 |   await page.getByLabel("Actual pickup quantity", { exact: true }).fill("1");
```