# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: c5-presentation.spec.ts >> C5 Klead text actions, intrinsic table actions and uniform topbar (en-light)
- Location: tests/c5-presentation.spec.ts:183:3

# Error details

```
Error: products

expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 18

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=e5]:
    - banner [ref=e6]:
      - button "Open menu" [ref=e7] [cursor=pointer]
      - combobox "Location" [ref=e11] [cursor=pointer]:
        - generic [ref=e16]: North York
      - button "Notifications, 5 unread" [ref=e19] [cursor=pointer]:
        - generic [ref=e20]: "5"
      - button "User menu" [ref=e25] [cursor=pointer]:
        - generic [aria-hidden] [ref=e27]: DM
      - button "More" [active] [ref=e28] [cursor=pointer]
    - main [ref=e34]:
      - generic [ref=e35]:
        - generic [ref=e36]:
          - generic [ref=e37]:
            - heading "Products" [level=1] [ref=e38]
            - paragraph [ref=e39]: Approved prices, pending changes and branch details in one catalog.
          - button "Add product" [ref=e41] [cursor=pointer]
        - generic [ref=e42]:
          - generic [ref=e43]:
            - searchbox "Search products" [ref=e48]
            - combobox "Pricing category" [ref=e49] [cursor=pointer]:
              - generic [ref=e50]: All pricing categories
            - combobox "AI category" [ref=e53] [cursor=pointer]:
              - generic [ref=e54]: All AI categories
            - combobox "Status" [ref=e57] [cursor=pointer]:
              - generic [ref=e58]: All statuses
            - combobox "Supplier" [ref=e61] [cursor=pointer]:
              - generic [ref=e62]: All suppliers
            - checkbox "Has pending price" [ref=e65] [cursor=pointer]
            - checkbox "Has offer" [ref=e68] [cursor=pointer]
            - checkbox "Manual prices" [ref=e71] [cursor=pointer]
            - checkbox "On sale" [ref=e74] [cursor=pointer]
            - button "Clear filters" [ref=e77] [cursor=pointer]
            - generic [ref=e79]:
              - generic [ref=e80]: 16 products
              - button "Columns" [ref=e81] [cursor=pointer]
          - generic [ref=e85]:
            - table [ref=e87]:
              - rowgroup [ref=e88]:
                - row [ref=e89]:
                  - cell "Basmati Rice 4.5 kg برنج باسماتی ۴٫۵ کیلوگرمی 4.5 kg" [ref=e90]:
                    - link "Basmati Rice 4.5 kg" [ref=e91] [cursor=pointer]:
                      - /url: "#product?code=0001"
                      - strong [ref=e92]:
                        - generic [ref=e94]:
                          - text: Basmati Rice
                          - generic [ref=e95]: 4.5 kg
                    - paragraph [ref=e96]:
                      - generic [ref=e98]:
                        - text: برنج باسماتی
                        - generic [ref=e99]: ۴٫۵ کیلوگرمی
                    - paragraph [ref=e100]:
                      - generic [ref=e101]: 4.5 kg
                  - cell "$23.99" [ref=e104]
                  - cell [ref=e107]:
                    - link "Open Basmati Rice 4.5 kg" [ref=e108] [cursor=pointer]:
                      - /url: "#product?code=0001"
                  - cell "0001 Approved" [ref=e111]:
                    - generic [ref=e112]: "0001"
                    - generic [ref=e114]: Approved
                - row [ref=e117]:
                  - cell "Black Tea 450 g چای سیاه ۴۵۰ گرمی 450 g" [ref=e118]:
                    - link "Black Tea 450 g" [ref=e119] [cursor=pointer]:
                      - /url: "#product?code=0004"
                      - strong [ref=e120]:
                        - generic [ref=e122]:
                          - text: Black Tea
                          - generic [ref=e123]: 450 g
                    - paragraph [ref=e124]:
                      - generic [ref=e126]:
                        - text: چای سیاه
                        - generic [ref=e127]: ۴۵۰ گرمی
                    - paragraph [ref=e128]:
                      - generic [ref=e129]: 450 g
                  - cell "$6.49" [ref=e132]
                  - cell [ref=e135]:
                    - link "Open Black Tea 450 g" [ref=e136] [cursor=pointer]:
                      - /url: "#product?code=0004"
                  - cell "0004 Approved" [ref=e139]:
                    - generic [ref=e140]: "0004"
                    - generic [ref=e142]: Approved
                - row [ref=e145]:
                  - cell "Bulk Almonds بادام فله Sold by weight" [ref=e146]:
                    - link "Bulk Almonds" [ref=e147] [cursor=pointer]:
                      - /url: "#product?code=0016"
                      - strong [ref=e148]:
                        - generic [ref=e149]: Bulk Almonds
                    - paragraph [ref=e150]:
                      - generic [ref=e151]: بادام فله
                    - paragraph [ref=e152]: Sold by weight
                  - cell "$7.49/lb $16.51/kg" [ref=e153]:
                    - generic [ref=e155]:
                      - generic [ref=e156]: $7.49/lb
                      - generic [ref=e157]: $16.51/kg
                  - cell [ref=e158]:
                    - link "Open Bulk Almonds" [ref=e159] [cursor=pointer]:
                      - /url: "#product?code=0016"
                  - cell "0016 Approved" [ref=e162]:
                    - generic [ref=e163]: "0016"
                    - generic [ref=e165]: Approved
                - row [ref=e168]:
                  - cell "Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی 400 g" [ref=e169]:
                    - link "Canned Fava Beans 400 g" [ref=e170] [cursor=pointer]:
                      - /url: "#product?code=0002"
                      - strong [ref=e171]:
                        - generic [ref=e173]:
                          - text: Canned Fava Beans
                          - generic [ref=e174]: 400 g
                    - paragraph [ref=e175]:
                      - generic [ref=e177]:
                        - text: باقالا کنسرو شده
                        - generic [ref=e178]: ۴۰۰ گرمی
                    - paragraph [ref=e179]:
                      - generic [ref=e180]: 400 g
                  - cell "$1.49" [ref=e183]
                  - cell [ref=e186]:
                    - link "Open Canned Fava Beans 400 g" [ref=e187] [cursor=pointer]:
                      - /url: "#product?code=0002"
                  - cell "0002 Approved" [ref=e190]:
                    - generic [ref=e191]: "0002"
                    - generic [ref=e193]: Approved
                - row [ref=e196]:
                  - cell "Dried Barberries 100 g زرشک خشک ۱۰۰ گرمی 100 g" [ref=e197]:
                    - link "Dried Barberries 100 g" [ref=e198] [cursor=pointer]:
                      - /url: "#product?code=0015"
                      - strong [ref=e199]:
                        - generic [ref=e201]:
                          - text: Dried Barberries
                          - generic [ref=e202]: 100 g
                    - paragraph [ref=e203]:
                      - generic [ref=e205]:
                        - text: زرشک خشک
                        - generic [ref=e206]: ۱۰۰ گرمی
                    - paragraph [ref=e207]:
                      - generic [ref=e208]: 100 g
                  - cell "—" [ref=e211]
                  - cell [ref=e213]:
                    - link "Open Dried Barberries 100 g" [ref=e214] [cursor=pointer]:
                      - /url: "#product?code=0015"
                  - cell "0015 Pending $5.49" [ref=e217]:
                    - generic [ref=e218]: "0015"
                    - generic [ref=e222]:
                      - text: Pending
                      - generic [ref=e223]: $5.49
                - row [ref=e224]:
                  - cell "Dried Red Kidney Beans 900 g لوبیا قرمز ۹۰۰ گرمی 900 g" [ref=e225]:
                    - link "Dried Red Kidney Beans 900 g" [ref=e226] [cursor=pointer]:
                      - /url: "#product?code=0007"
                      - strong [ref=e227]:
                        - generic [ref=e229]:
                          - text: Dried Red Kidney Beans
                          - generic [ref=e230]: 900 g
                    - paragraph [ref=e231]:
                      - generic [ref=e233]:
                        - text: لوبیا قرمز
                        - generic [ref=e234]: ۹۰۰ گرمی
                    - paragraph [ref=e235]:
                      - generic [ref=e236]: 900 g
                  - cell "$3.99" [ref=e239]
                  - cell [ref=e242]:
                    - link "Open Dried Red Kidney Beans 900 g" [ref=e243] [cursor=pointer]:
                      - /url: "#product?code=0007"
                  - cell "0007 Approved 2 for $7.00" [ref=e246]:
                    - generic [ref=e247]: "0007"
                    - generic [ref=e250]:
                      - generic [ref=e251]: Approved
                      - generic [ref=e252]: 2 for $7.00
                - row [ref=e254]:
                  - cell "Fruit Soda 6-pack نوشابه میوه‌ای بسته ۶ عددی 6 x 355 ml" [ref=e255]:
                    - link "Fruit Soda 6-pack" [ref=e256] [cursor=pointer]:
                      - /url: "#product?code=0010"
                      - strong [ref=e257]:
                        - generic [ref=e258]: Fruit Soda 6-pack
                    - paragraph [ref=e259]:
                      - generic [ref=e260]: نوشابه میوه‌ای بسته ۶ عددی
                    - paragraph [ref=e261]:
                      - generic [ref=e263]:
                        - text: 6 x
                        - generic [ref=e264]: 355 ml
                  - cell "$4.99" [ref=e265]
                  - cell [ref=e268]:
                    - link "Open Fruit Soda 6-pack" [ref=e269] [cursor=pointer]:
                      - /url: "#product?code=0010"
                  - cell "0010 Approved" [ref=e272]:
                    - generic [ref=e273]: "0010"
                    - generic [ref=e275]: Approved
                - row [ref=e278]:
                  - cell "Ground Sumac 100 g سماق ۱۰۰ گرمی 100 g" [ref=e279]:
                    - link "Ground Sumac 100 g" [ref=e280] [cursor=pointer]:
                      - /url: "#product?code=0005"
                      - strong [ref=e281]:
                        - generic [ref=e283]:
                          - text: Ground Sumac
                          - generic [ref=e284]: 100 g
                    - paragraph [ref=e285]:
                      - generic [ref=e287]:
                        - text: سماق
                        - generic [ref=e288]: ۱۰۰ گرمی
                    - paragraph [ref=e289]:
                      - generic [ref=e290]: 100 g
                  - cell "$1.99" [ref=e293]
                  - cell [ref=e296]:
                    - link "Open Ground Sumac 100 g" [ref=e297] [cursor=pointer]:
                      - /url: "#product?code=0005"
                  - cell "0005 Approved 3 for $5.00" [ref=e300]:
                    - generic [ref=e301]: "0005"
                    - generic [ref=e304]:
                      - generic [ref=e305]: Approved
                      - generic [ref=e306]: 3 for $5.00
                - row [ref=e308]:
                  - cell "Kitchen Sponge 3-pack اسفنج ظرفشویی بسته ۳ عددی 3 pcs" [ref=e309]:
                    - link "Kitchen Sponge 3-pack" [ref=e310] [cursor=pointer]:
                      - /url: "#product?code=0014"
                      - strong [ref=e311]:
                        - generic [ref=e312]: Kitchen Sponge 3-pack
                    - paragraph [ref=e313]:
                      - generic [ref=e314]: اسفنج ظرفشویی بسته ۳ عددی
                    - paragraph [ref=e315]:
                      - generic [ref=e316]: 3 pcs
                  - cell "$2.49" [ref=e317]
                  - cell [ref=e320]:
                    - link "Open Kitchen Sponge 3-pack" [ref=e321] [cursor=pointer]:
                      - /url: "#product?code=0014"
                  - cell "0014 Approved" [ref=e324]:
                    - generic [ref=e325]: "0014"
                    - generic [ref=e327]: Approved
                - row [ref=e330]:
                  - cell "Lavash Bread 500 g نان لواش ۵۰۰ گرمی 500 g" [ref=e331]:
                    - link "Lavash Bread 500 g" [ref=e332] [cursor=pointer]:
                      - /url: "#product?code=0006"
                      - strong [ref=e333]:
                        - generic [ref=e335]:
                          - text: Lavash Bread
                          - generic [ref=e336]: 500 g
                    - paragraph [ref=e337]:
                      - generic [ref=e339]:
                        - text: نان لواش
                        - generic [ref=e340]: ۵۰۰ گرمی
                    - paragraph [ref=e341]:
                      - generic [ref=e342]: 500 g
                  - cell "$1.99" [ref=e345]
                  - cell [ref=e348]:
                    - link "Open Lavash Bread 500 g" [ref=e349] [cursor=pointer]:
                      - /url: "#product?code=0006"
                  - cell "0006 Pending $2.99 3 for $5.00" [ref=e352]:
                    - generic [ref=e353]: "0006"
                    - generic [ref=e356]:
                      - generic [ref=e357]:
                        - text: Pending
                        - generic [ref=e358]: $2.99
                      - generic [ref=e359]: 3 for $5.00
                - row [ref=e361]:
                  - cell "Potato Chips 150 g چیپس سیب‌زمینی ۱۵۰ گرمی 150 g" [ref=e362]:
                    - link "Potato Chips 150 g" [ref=e363] [cursor=pointer]:
                      - /url: "#product?code=0009"
                      - strong [ref=e364]:
                        - generic [ref=e366]:
                          - text: Potato Chips
                          - generic [ref=e367]: 150 g
                    - paragraph [ref=e368]:
                      - generic [ref=e370]:
                        - text: چیپس سیب‌زمینی
                        - generic [ref=e371]: ۱۵۰ گرمی
                    - paragraph [ref=e372]:
                      - generic [ref=e373]: 150 g
                  - cell "$2.99" [ref=e376]
                  - cell [ref=e379]:
                    - link "Open Potato Chips 150 g" [ref=e380] [cursor=pointer]:
                      - /url: "#product?code=0009"
                  - cell "0009 Approved 2 for $5.00" [ref=e383]:
                    - generic [ref=e384]: "0009"
                    - generic [ref=e387]:
                      - generic [ref=e388]: Approved
                      - generic [ref=e389]: 2 for $5.00
                - row [ref=e391]:
                  - cell "Rice Cooker 1.8 L پلوپز ۱٫۸ لیتری 1.8 L" [ref=e392]:
                    - link "Rice Cooker 1.8 L" [ref=e393] [cursor=pointer]:
                      - /url: "#product?code=0013"
                      - strong [ref=e394]:
                        - generic [ref=e396]:
                          - text: Rice Cooker
                          - generic [ref=e397]: 1.8 L
                    - paragraph [ref=e398]:
                      - generic [ref=e400]:
                        - text: پلوپز
                        - generic [ref=e401]: ۱٫۸ لیتری
                    - paragraph [ref=e402]:
                      - generic [ref=e403]: 1.8 L
                  - cell "$52.49" [ref=e406]
                  - cell [ref=e409]:
                    - link "Open Rice Cooker 1.8 L" [ref=e410] [cursor=pointer]:
                      - /url: "#product?code=0013"
                  - cell "0013 Approved" [ref=e413]:
                    - generic [ref=e414]: "0013"
                    - generic [ref=e416]: Approved
                - row [ref=e419]:
                  - cell "Sour Cherry Juice 1 L آب آلبالو ۱ لیتری 1 L" [ref=e420]:
                    - link "Sour Cherry Juice 1 L" [ref=e421] [cursor=pointer]:
                      - /url: "#product?code=0003"
                      - strong [ref=e422]:
                        - generic [ref=e424]:
                          - text: Sour Cherry Juice
                          - generic [ref=e425]: 1 L
                    - paragraph [ref=e426]:
                      - generic [ref=e428]:
                        - text: آب آلبالو
                        - generic [ref=e429]: ۱ لیتری
                    - paragraph [ref=e430]:
                      - generic [ref=e431]: 1 L
                  - cell "$2.99" [ref=e434]
                  - cell [ref=e437]:
                    - link "Open Sour Cherry Juice 1 L" [ref=e438] [cursor=pointer]:
                      - /url: "#product?code=0003"
                  - cell "0003 Approved 2 for $5.00" [ref=e441]:
                    - generic [ref=e442]: "0003"
                    - generic [ref=e445]:
                      - generic [ref=e446]: Approved
                      - generic [ref=e447]: 2 for $5.00
                - row [ref=e449]:
                  - cell "Stainless Steel Pot 24 cm قابلمه استیل ۲۴ سانتی‌متری 24 cm" [ref=e450]:
                    - link "Stainless Steel Pot 24 cm" [ref=e451] [cursor=pointer]:
                      - /url: "#product?code=0012"
                      - strong [ref=e452]:
                        - generic [ref=e453]: Stainless Steel Pot 24 cm
                    - paragraph [ref=e454]:
                      - generic [ref=e455]: قابلمه استیل ۲۴ سانتی‌متری
                    - paragraph [ref=e456]:
                      - generic [ref=e457]: 24 cm
                  - cell "$16.99 Sale Regular $20.99 Until Oct 25" [ref=e458]:
                    - generic [ref=e459]:
                      - generic [ref=e460]: $16.99
                      - generic [ref=e462]:
                        - generic [ref=e463]: Sale
                        - deletion [ref=e464]: Regular $20.99
                        - generic [ref=e465]: Until Oct 25
                  - cell [ref=e466]:
                    - link "Open Stainless Steel Pot 24 cm" [ref=e467] [cursor=pointer]:
                      - /url: "#product?code=0012"
                  - cell "0012 Approved" [ref=e470]:
                    - generic [ref=e471]: "0012"
                    - generic [ref=e473]: Approved
                - row [ref=e476]:
                  - cell "Sunflower Oil 1.8 L روغن آفتابگردان ۱٫۸ لیتری 1.8 L" [ref=e477]:
                    - link "Sunflower Oil 1.8 L" [ref=e478] [cursor=pointer]:
                      - /url: "#product?code=0008"
                      - strong [ref=e479]:
                        - generic [ref=e481]:
                          - text: Sunflower Oil
                          - generic [ref=e482]: 1.8 L
                    - paragraph [ref=e483]:
                      - generic [ref=e485]:
                        - text: روغن آفتابگردان
                        - generic [ref=e486]: ۱٫۸ لیتری
                    - paragraph [ref=e487]:
                      - generic [ref=e488]: 1.8 L
                  - cell "$9.49 Sale requested $7.99 · Oct 15–Oct 28 Waiting for approval" [ref=e491]:
                    - generic [ref=e492]:
                      - generic [ref=e493]: $9.49
                      - generic [ref=e494]:
                        - generic [ref=e495]:
                          - text: Sale requested
                          - generic [ref=e496]: $7.99
                          - text: ·
                          - generic [ref=e497]: Oct 15–Oct 28
                        - generic [ref=e498]: Waiting for approval
                  - cell [ref=e499]:
                    - link "Open Sunflower Oil 1.8 L" [ref=e500] [cursor=pointer]:
                      - /url: "#product?code=0008"
                  - cell "0008 Approved" [ref=e503]:
                    - generic [ref=e504]: "0008"
                    - generic [ref=e506]: Approved
                - row [ref=e509]:
                  - cell "Tea Glass Set (6 pcs) ست استکان چای (۶ عددی) 6 pcs" [ref=e510]:
                    - link "Tea Glass Set (6 pcs)" [ref=e511] [cursor=pointer]:
                      - /url: "#product?code=0011"
                      - strong [ref=e512]:
                        - generic [ref=e513]: Tea Glass Set (6 pcs)
                    - paragraph [ref=e514]:
                      - generic [ref=e515]: ست استکان چای (۶ عددی)
                    - paragraph [ref=e516]:
                      - generic [ref=e517]: 6 pcs
                  - cell "$8.99" [ref=e518]
                  - cell [ref=e521]:
                    - link "Open Tea Glass Set (6 pcs)" [ref=e522] [cursor=pointer]:
                      - /url: "#product?code=0011"
                  - cell "0011 Approved" [ref=e525]:
                    - generic [ref=e526]: "0011"
                    - generic [ref=e528]: Approved
            - generic [ref=e531]:
              - button "Previous" [disabled] [ref=e532]
              - generic [ref=e533]: Page 1 of 1 · 16 products
              - button "Next" [disabled] [ref=e534]
```

# Test source

```ts
  36  | ) {
  37  |   const proof = await inspect(
  38  |     page,
  39  |     scene,
  40  |     `${test.info().project.name}-${variant}`,
  41  |     role,
  42  |   );
  43  |   const reports = measurements.get(page) ?? [];
  44  |   reports.push(proof);
  45  |   measurements.set(page, reports);
  46  |   expect(
  47  |     proof.buttons.length,
  48  |     `${scene}: real controls measured`,
  49  |   ).toBeGreaterThan(2);
  50  |   if (proof.viewport.width < 760) {
  51  |     expect(
  52  |       proof.topbar.length,
  53  |       `${scene}: all five priority-bar controls measured`,
  54  |     ).toBe(5);
  55  |     expect(
  56  |       await page
  57  |         .locator(".topbar")
  58  |         .evaluate((element) => element.getBoundingClientRect().height),
  59  |       `${scene}: the phone priority bar stays on one 60px row`,
  60  |     ).toBeCloseTo(60, 0);
  61  |     for (const selector of [
  62  |       "#menu-toggle",
  63  |       ".branch-pill",
  64  |       ".notifications-menu",
  65  |       ".mobile-account-menu",
  66  |       ".mobile-more-menu",
  67  |     ])
  68  |       await expect(page.locator(`.topbar ${selector}`)).toBeVisible();
  69  |     expect(
  70  |       await page
  71  |         .locator(
  72  |           'button[aria-label="User menu"], button[aria-label="منوی کاربر"]',
  73  |         )
  74  |         .evaluateAll(
  75  |           (controls) =>
  76  |             controls.filter((control) => {
  77  |               const rect = control.getBoundingClientRect();
  78  |               return (
  79  |                 rect.width > 0 &&
  80  |                 rect.height > 0 &&
  81  |                 getComputedStyle(control).visibility !== "hidden"
  82  |               );
  83  |             }).length,
  84  |         ),
  85  |       `${scene}: exactly one account is visible, including behind a modal`,
  86  |     ).toBe(1);
  87  |     // The top bar is deliberately inert while a modal is open. Exercise the
  88  |     // collapsed controls in every ordinary screen instead of counting hidden
  89  |     // desktop buttons as phone controls.
  90  |     if (!(await page.locator("dialog[open]").count())) {
  91  |       const persian =
  92  |         (await page.locator("html").getAttribute("lang")) === "fa";
  93  |       const dark =
  94  |         (await page.locator("html").getAttribute("data-theme")) === "dark";
  95  |       const more = page.locator(".mobile-more-menu");
  96  |       if ((await more.getAttribute("aria-expanded")) !== "true")
  97  |         await more.click();
  98  |       for (const name of [
  99  |         persian ? "جست‌وجوی همهٔ محصولات" : "Search all products",
  100 |         persian ? "تغییر به انگلیسی" : "Switch to Persian",
  101 |         persian
  102 |           ? dark
  103 |             ? "تغییر به تم روشن"
  104 |             : "تغییر به تم تیره"
  105 |           : dark
  106 |             ? "Switch to light theme"
  107 |             : "Switch to dark theme",
  108 |         persian ? "اندازهٔ متن راحت" : "Comfortable text size",
  109 |         persian ? "دمو" : "Demo",
  110 |       ])
  111 |         await expect(
  112 |           page.getByRole("menuitem", { name, exact: true }),
  113 |         ).toBeVisible();
  114 |       const demo = page.getByRole("menuitem", {
  115 |         name: persian ? "دمو" : "Demo",
  116 |         exact: true,
  117 |       });
  118 |       await demo.click();
  119 |       await expect(
  120 |         page.getByRole("menuitem", {
  121 |           name: persian ? "بازنشانی دمو" : "Reset demo",
  122 |           exact: true,
  123 |         }),
  124 |       ).toBeVisible();
  125 |       await page.keyboard.press("Escape");
  126 |       await expect(demo).toBeFocused();
  127 |       await page.keyboard.press("Escape");
  128 |       await expect(more).toBeFocused();
  129 |     }
  130 |   } else {
  131 |     expect(
  132 |       proof.topbar.length,
  133 |       `${scene}: all desktop topbar controls measured`,
  134 |     ).toBeGreaterThanOrEqual(7);
  135 |   }
> 136 |   expect(proof.failures, scene).toEqual([]);
      |                                 ^ Error: products
  137 |   return proof;
  138 | }
  139 | 
  140 | for (const variant of ["en-light", "en-dark", "fa-light"] as const) {
  141 |   test(`C5 Waiting for credit is amber for different retained return states (${variant})`, async ({
  142 |     page,
  143 |   }) => {
  144 |     await signIn(page, "Supervisor");
  145 |     await setBranch(page, "Branch 1");
  146 |     await page.goto("/#return?id=demo-return-1");
  147 |     await button(page.locator(".return-header-card"), "Record pickup").click();
  148 |     const pickup = page.locator(".return-action-card");
  149 |     await assertContract(page, "Record return pickup form", "en-light");
  150 |     await pickup
  151 |       .getByLabel("Actual pickup quantity", { exact: true })
  152 |       .fill("3");
  153 |     await field(pickup, "Supplier representative name").fill("Demo Driver");
  154 |     await field(pickup, "Signed paper pickup slip reference").fill(
  155 |       "SIGNED-C5-COLOR-001",
  156 |     );
  157 |     await button(pickup, "Record pickup").click();
  158 |     // This existing status is published only after the actual command completes.
  159 |     await expect(page.getByRole("status")).toHaveText(
  160 |       "Recorded pickup and retained Return memo.",
  161 |     );
  162 |     await page.goto("/#returns");
  163 |     await expect(page.locator(".returns-overview-table")).toBeVisible();
  164 |     await appearance(page, variant);
  165 |     const proof = await assertContract(
  166 |       page,
  167 |       "Waiting for credit across return states",
  168 |       variant,
  169 |     );
  170 |     const credit = proof.statuses.filter(
  171 |       (status) => status.returnStatus === "waiting_for_credit",
  172 |     );
  173 |     expect(credit.length).toBeGreaterThanOrEqual(2);
  174 |     expect(
  175 |       credit.every((status) => status.classes.split(" ").includes("pending")),
  176 |     ).toBe(true);
  177 |     expect(
  178 |       new Set(credit.map((status) => `${status.color}/${status.background}`))
  179 |         .size,
  180 |     ).toBe(1);
  181 |   });
  182 | 
  183 |   test(`C5 Klead text actions, intrinsic table actions and uniform topbar (${variant})`, async ({
  184 |     page,
  185 |   }, info) => {
  186 |     await signIn(page, "Supervisor");
  187 |     await setBranch(page, "Branch 1");
  188 |     await appearance(page, variant);
  189 |     const proofs: C5Inspection[] = [];
  190 |     for (const route of [
  191 |       "invoices",
  192 |       "products",
  193 |       "alerts",
  194 |       "returns",
  195 |       "expiry",
  196 |       "offers",
  197 |       "approvals",
  198 |     ]) {
  199 |       await page.goto(`/#${route}`);
  200 |       proofs.push(await assertContract(page, route, variant));
  201 |       if (route === "products") {
  202 |         await field(
  203 |           page.getByRole("main"),
  204 |           "Search products",
  205 |           "جست‌وجوی محصولات",
  206 |         ).fill("0016");
  207 |         const cost = page.locator(".catalog-products-table .weight-cost");
  208 |         if ((await cost.count()) === 0)
  209 |           await button(
  210 |             page.locator(".catalog-products-table tbody tr").first(),
  211 |             "Show details",
  212 |             "نمایش جزئیات",
  213 |           ).click();
  214 |         await expect(cost).toHaveText("$4.9895/lb");
  215 |         await expect(cost).toHaveAttribute("dir", "ltr");
  216 |         const price = page.locator(".catalog-products-table .weight-price");
  217 |         await expect(price.locator(".weight-price-main")).toHaveText(
  218 |           "$7.49/lb",
  219 |         );
  220 |         await expect(price.locator(".weight-price-secondary")).toHaveText(
  221 |           "$16.51/kg",
  222 |         );
  223 |         proofs.push(
  224 |           await assertContract(page, "Products weighed item", variant),
  225 |         );
  226 |       }
  227 |       if (route === "expiry") {
  228 |         const product = field(
  229 |           page.locator(".date-quick-card"),
  230 |           "Product",
  231 |           "محصول",
  232 |         );
  233 |         await product.fill("0001");
  234 |         const iconClearance = await product.evaluate((element) => {
  235 |           const style = getComputedStyle(element);
  236 |           const bounds = element.getBoundingClientRect();
```