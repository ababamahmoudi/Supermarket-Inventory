# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: settings-b.spec.ts >> Settings presents the exact 13 groups and unfinished groups cannot save
- Location: tests/settings-b.spec.ts:15:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('.settings-form-card').filter({ has: getByText('These settings are planned. Changes are not available yet.', { exact: true }) }).getByText('These settings are planned. Changes are not available yet.', { exact: true })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('.settings-form-card').filter({ has: getByText('These settings are planned. Changes are not available yet.', { exact: true }) }).getByText('These settings are planned. Changes are not available yet.', { exact: true }) with timeout 5000ms
  - waiting for locator('.settings-form-card').filter({ has: getByText('These settings are planned. Changes are not available yet.', { exact: true }) }).getByText('These settings are planned. Changes are not available yet.', { exact: true })

```

```yaml
- link "Skip to content":
  - /url: "#main-content"
- complementary "Main menu":
  - img "Super Arzon"
  - text: Super Arzon
  - navigation "Pages":
    - button "Daily"
    - button "Catalog"
    - button "Manager"
    - button "Admin" [expanded]
    - link "Settings":
      - /url: "#settings"
    - link "History":
      - /url: "#history"
  - button "User menu":
    - strong: Demo Manager
    - text: Manager
- banner:
  - button "Collapse sidebar" [expanded]
  - navigation "Breadcrumbs":
    - link "North York":
      - /url: "#dashboard"
    - link "Settings":
      - /url: "#settings"
  - search:
    - textbox "Search all products":
      - /placeholder: Search products
  - combobox "Location": North York
  - button "Switch to Persian": فا
  - button "Switch to dark theme"
  - button "Comfortable text size"
  - button "Notifications, 5 unread": "5"
  - button "Demo"
- main:
  - heading "Settings" [level=1]
  - navigation "Settings groups":
    - button "Company"
    - button "Branches"
    - button "People"
    - button "Catalog"
    - button "Pricing and approvals"
    - button "Offers"
    - button "Taxes"
    - button "Receiving"
    - button "Returns/date tracking/labels"
    - button "Notes"
    - button "Notifications"
    - button "Modules"
    - button "Data"
  - region "People":
    - heading "People" [level=2]
    - paragraph: Employees, roles and registered store computers.
    - heading "People" [level=2]
    - button "Add person"
    - textbox "Search people"
    - combobox "Role": All roles
    - combobox "Location": All locations
    - table:
      - rowgroup:
        - row "Name Role Actions":
          - columnheader "Name"
          - columnheader "Role"
          - columnheader "Actions"
      - rowgroup:
        - row "Demo Owner owner Owner Edit More actions Show details":
          - cell "Demo Owner owner"
          - cell "Owner"
          - cell "Edit More actions Show details":
            - button "Edit"
            - button "More actions"
            - button "Show details"
        - row "Demo Manager manager Manager Edit More actions Show details":
          - cell "Demo Manager manager"
          - cell "Manager"
          - cell "Edit More actions Show details":
            - button "Edit"
            - button "More actions"
            - button "Show details"
        - row "Demo Richmond Hill Supervisor rh-supervisor Branch Supervisor Edit More actions Show details":
          - cell "Demo Richmond Hill Supervisor rh-supervisor"
          - cell "Branch Supervisor"
          - cell "Edit More actions Show details":
            - button "Edit"
            - button "More actions"
            - button "Show details"
        - row "Demo North York Floor Worker ny-floor Floor Worker Edit More actions Show details":
          - cell "Demo North York Floor Worker ny-floor"
          - cell "Floor Worker"
          - cell "Edit More actions Show details":
            - button "Edit"
            - button "More actions"
            - button "Show details"
        - row "Demo Warehouse Floor Worker wh-floor Floor Worker Edit More actions Show details":
          - cell "Demo Warehouse Floor Worker wh-floor"
          - cell "Floor Worker"
          - cell "Edit More actions Show details":
            - button "Edit"
            - button "More actions"
            - button "Show details"
        - row "Demo Cashier cashier Cashier Edit More actions Show details":
          - cell "Demo Cashier cashier"
          - cell "Cashier"
          - cell "Edit More actions Show details":
            - button "Edit"
            - button "More actions"
            - button "Show details"
    - heading "Registered store computers" [level=2]
    - button "Register computer"
    - table:
      - rowgroup:
        - row "Name Location Actions":
          - columnheader "Name"
          - columnheader "Location"
          - columnheader "Actions"
      - rowgroup:
        - row "North York demo computer This computer North York Edit More actions Show details":
          - cell "North York demo computer This computer"
          - cell "North York"
          - cell "Edit More actions Show details":
            - button "Edit"
            - button "More actions"
            - button "Show details"
```

# Test source

```ts
  1   | import { readCanonicalBusinessEvidence } from "./business-evidence";
  2   | import { expect, test, type Page } from "@playwright/test";
  3   | import { chooseOption, signIn, visitPage } from "./helpers";
  4   | async function group(page: Page, label: string) {
  5   |   await page
  6   |     .getByRole("navigation", { name: "Settings groups" })
  7   |     .getByRole("button", { name: label, exact: true })
  8   |     .click();
  9   | }
  10  | async function open(page: Page) {
  11  |   await signIn(page, "Supervisor");
  12  |   await visitPage(page, "Settings");
  13  | }
  14  | 
  15  | test("Settings presents the exact 13 groups and unfinished groups cannot save", async ({
  16  |   page,
  17  | }) => {
  18  |   await open(page);
  19  |   await expect(
  20  |     page
  21  |       .getByRole("navigation", { name: "Settings groups" })
  22  |       .getByRole("button"),
  23  |   ).toHaveText([
  24  |     "Company",
  25  |     "Branches",
  26  |     "People",
  27  |     "Catalog",
  28  |     "Pricing and approvals",
  29  |     "Offers",
  30  |     "Taxes",
  31  |     "Receiving",
  32  |     "Returns/date tracking/labels",
  33  |     "Notes",
  34  |     "Notifications",
  35  |     "Modules",
  36  |     "Data",
  37  |   ]);
  38  |   for (const label of [
  39  |     "People",
  40  |     "Pricing and approvals",
  41  |     "Taxes",
  42  |     "Receiving",
  43  |     "Notifications",
  44  |     "Data",
  45  |   ]) {
  46  |     await group(page, label);
  47  |     const planned = page.locator(".settings-form-card").filter({
  48  |       has: page.getByText(
  49  |         "These settings are planned. Changes are not available yet.",
  50  |         { exact: true },
  51  |       ),
  52  |     });
  53  |     await expect(
  54  |       planned.getByText(
  55  |         "These settings are planned. Changes are not available yet.",
  56  |         { exact: true },
  57  |       ),
> 58  |     ).toBeVisible();
      |       ^ Error: expect(locator).toBeVisible() failed
  59  |     await expect(
  60  |       planned.getByRole("button", { name: "Save changes", exact: true }),
  61  |     ).toHaveCount(0);
  62  |     await expect(planned.locator("input, [role=switch]")).toHaveCount(0);
  63  |     if (label === "Pricing and approvals") {
  64  |       await expect(
  65  |         page.getByRole("heading", { name: "Weighed items", exact: true }),
  66  |       ).toBeVisible();
  67  |       await expect(
  68  |         page.getByRole("combobox", { name: "Main display unit", exact: true }),
  69  |       ).toHaveText("lb");
  70  |       await expect(
  71  |         page.getByRole("switch", { name: "Show second unit", exact: true }),
  72  |       ).toBeChecked();
  73  |       await expect(
  74  |         page.getByRole("switch", { name: "Use rounding bands", exact: true }),
  75  |       ).toBeChecked();
  76  |     }
  77  |   }
  78  | });
  79  | test("company settings save deliberately, persist and record before/after History", async ({
  80  |   page,
  81  | }) => {
  82  |   await open(page);
  83  |   await group(page, "Company");
  84  |   await page.getByLabel("Name (English)", { exact: true }).fill("Arzon Market");
  85  |   await page
  86  |     .getByLabel("Name (Persian)", { exact: true })
  87  |     .fill("فروشگاه ارزان");
  88  |   expect(
  89  |     await readCanonicalBusinessEvidence(page).then(
  90  |       (canonicalState) =>
  91  |         JSON.parse(JSON.stringify(canonicalState)!).config.company.name_en,
  92  |     ),
  93  |   ).toBe("Super Arzon");
  94  |   await page.getByRole("button", { name: "Save changes", exact: true }).click();
  95  |   await expect(page.locator(".settings-changed-line")).toContainText(
  96  |     "Changed by",
  97  |   );
  98  |   await page.reload();
  99  |   await group(page, "Company");
  100 |   await expect(page.getByLabel("Name (English)", { exact: true })).toHaveValue(
  101 |     "Arzon Market",
  102 |   );
  103 |   const activity = await readCanonicalBusinessEvidence(page).then(
  104 |     (canonicalState) =>
  105 |       JSON.parse(JSON.stringify(canonicalState)!).activity.find(
  106 |         (entry: { entity_id: string }) => entry.entity_id === "company",
  107 |       ),
  108 |   );
  109 |   expect(activity).toMatchObject({
  110 |     reversible: true,
  111 |     company_id: "super-arzon",
  112 |     branch: "all",
  113 |     before: { name_en: "Super Arzon" },
  114 |     after: { name_en: "Arzon Market" },
  115 |   });
  116 |   await page.getByLabel("Time zone", { exact: true }).fill("Invalid/Zone");
  117 |   await page.getByRole("button", { name: "Save changes", exact: true }).click();
  118 |   await expect(
  119 |     page.getByRole("alert", { name: "What's missing", exact: true }),
  120 |   ).toContainText("Enter a valid time zone");
  121 |   expect(
  122 |     await readCanonicalBusinessEvidence(page).then(
  123 |       (canonicalState) =>
  124 |         JSON.parse(JSON.stringify(canonicalState)!).config.company.timezone,
  125 |     ),
  126 |   ).toBe("America/Toronto");
  127 | });
  128 | test("new branch configuration works in the live branch switcher and retains history after deactivation", async ({
  129 |   page,
  130 | }) => {
  131 |   await open(page);
  132 |   await group(page, "Branches");
  133 |   await page.getByRole("button", { name: "Add location", exact: true }).click();
  134 |   const dialog = page.getByRole("dialog", {
  135 |     name: "Add location",
  136 |     exact: true,
  137 |   });
  138 |   await dialog
  139 |     .getByLabel("Name (English)", { exact: true })
  140 |     .fill("North Market");
  141 |   await dialog.getByLabel("Name (Persian)", { exact: true }).fill("بازار شمال");
  142 |   await dialog.getByLabel("Address", { exact: true }).fill("100 Market Road");
  143 |   await dialog
  144 |     .getByRole("button", { name: "Save changes", exact: true })
  145 |     .click();
  146 |   await expect(dialog).not.toBeVisible();
  147 |   await chooseOption(
  148 |     page,
  149 |     page.locator(".topbar").getByLabel("Location", { exact: true }),
  150 |     "Branch 4",
  151 |     "North Market",
  152 |   );
  153 |   await expect(
  154 |     page.locator(".topbar").getByLabel("Location", { exact: true }),
  155 |   ).toContainText("North Market");
  156 |   await page.reload();
  157 |   const row = page.getByRole("row").filter({
  158 |     has: page.getByRole("rowheader", {
```