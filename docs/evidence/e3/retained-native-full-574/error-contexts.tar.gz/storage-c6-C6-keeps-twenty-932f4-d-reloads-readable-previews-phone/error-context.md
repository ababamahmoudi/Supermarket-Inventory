# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: storage-c6.spec.ts >> C6 keeps twenty distinct 3MB photos out of text storage, preserves exact originals and reloads readable previews
- Location: tests/storage-c6.spec.ts:335:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 1
Received: undefined
```

# Page snapshot

```yaml
- generic [ref=f1e3]:
  - link "Skip to content" [ref=f1e4] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=f1e5]:
    - banner [ref=f1e6]:
      - button "Open menu" [ref=f1e7] [cursor=pointer]
      - combobox "Location" [ref=f1e11] [cursor=pointer]:
        - generic [ref=f1e16]: North York
      - button "Notifications, 5 unread" [ref=f1e19] [cursor=pointer]:
        - generic [ref=f1e20]: "5"
      - button "User menu" [ref=f1e25] [cursor=pointer]:
        - generic [aria-hidden] [ref=f1e27]: DM
      - button "More" [ref=f1e28] [cursor=pointer]
    - main [ref=f1e34]:
      - generic [ref=f1e35]:
        - link "Back to Invoices" [ref=f1e36] [cursor=pointer]:
          - /url: "#invoices"
        - generic [ref=f1e39]:
          - generic [ref=f1e40]:
            - heading "Invoices" [level=1] [ref=f1e41]
            - paragraph [ref=f1e42]: Deliveries and supplier invoices
          - button "New invoice" [ref=f1e44] [cursor=pointer]
        - tablist "Invoice views" [ref=f1e45]:
          - tab "Drafts" [ref=f1e46] [cursor=pointer]
          - tab "Processing" [ref=f1e48] [cursor=pointer]
          - tab "Needs review" [selected] [ref=f1e50] [cursor=pointer]
          - tab "Ready to post" [ref=f1e52] [cursor=pointer]
          - tab "Posted" [ref=f1e54] [cursor=pointer]
          - tab "Cancelled" [ref=f1e56] [cursor=pointer]
        - generic [ref=f1e58]:
          - complementary "Original invoice" [ref=f1e59]:
            - generic [ref=f1e60]:
              - heading "Original invoice" [level=2] [ref=f1e61]
              - paragraph [ref=f1e62]: AI invoice reading is simulated
              - generic [ref=f1e64]:
                - generic [ref=f1e65]: Upload a PDF or photo
                - generic [ref=f1e66]:
                  - button "Upload a PDF or photo" [ref=f1e67]
                  - button "Take photo" [ref=f1e68]
                  - generic [ref=f1e69]:
                    - generic [ref=f1e73]:
                      - strong [ref=f1e74]: fictional-storage-photo-20.jpg
                      - generic [ref=f1e75]: 3.0 MB
                    - button "Remove file" [ref=f1e76] [cursor=pointer]
                  - generic [ref=f1e80]:
                    - button "Browse" [ref=f1e81] [cursor=pointer]
                    - button "Take photo" [ref=f1e82] [cursor=pointer]
              - group "Original invoice" [ref=f1e86]:
                - generic [ref=f1e87]:
                  - button "Zoom out" [ref=f1e88] [cursor=pointer]
                  - generic [ref=f1e90]: 100%
                  - button "Zoom in" [ref=f1e91] [cursor=pointer]
                - button "Fit width" [ref=f1e93] [cursor=pointer]
                - button "Fit page" [ref=f1e94] [cursor=pointer]
                - button "Download" [active] [ref=f1e95] [cursor=pointer]
              - img "Original invoice image" [ref=f1e100]
          - generic [ref=f1e101]:
            - generic [ref=f1e102]:
              - generic "Delivery summary" [ref=f1e103]:
                - generic [ref=f1e104]:
                  - generic [ref=f1e105]: Subtotal
                  - strong [ref=f1e106]: $0.00
                - generic [ref=f1e107]:
                  - generic [ref=f1e108]: Tax
                  - strong [ref=f1e109]: $0.00
                - generic [ref=f1e110]:
                  - generic [ref=f1e111]: Shorts and refused deduction
                  - strong [ref=f1e112]: $0.00
                - generic [ref=f1e113]:
                  - generic [ref=f1e114]: Payable
                  - strong [ref=f1e115]: $0.00
              - paragraph [ref=f1e116]: This is the amount of this invoice, not a supplier balance. Received records only physically delivered units.
            - generic [ref=f1e117]:
              - heading [level=2] [ref=f1e118]:
                - button "Invoice details" [ref=f1e119] [cursor=pointer]
              - paragraph [ref=f1e122]:
                - text: ·
                - generic [ref=f1e123]: —
                - text: · North York ·
                - generic [ref=f1e124]: 2026-10-15
              - paragraph [ref=f1e125]:
                - generic [ref=f1e126]: Needs review
                - text: Changes save automatically in this browser.
            - generic [ref=f1e128]:
              - heading "Compare with order" [level=2] [ref=f1e129]
              - generic [ref=f1e130]:
                - generic [ref=f1e131]: Order (optional)
                - combobox "Order (optional)" [ref=f1e132] [cursor=pointer]:
                  - generic [ref=f1e133]: No linked order
                - paragraph [ref=f1e136]: Choose an open order for this supplier and receiving location.
            - generic [ref=f1e137]:
              - heading "Review invoice lines" [level=2] [ref=f1e138]
              - paragraph [ref=f1e139]: Choose Cases or Units and confirm the product, pack, quantities, cost, and date decision on each line.
              - paragraph [ref=f1e145]: No lines. Add a product below to start your manual draft.
              - generic:
                - table
              - generic [ref=f1e146]:
                - generic [ref=f1e147]:
                  - generic [ref=f1e148]: Add a product to the invoice
                  - combobox "Add a product to the invoice" [ref=f1e149] [cursor=pointer]:
                    - generic [ref=f1e151]:
                      - text: ⁦0002⁩ · ⁦
                      - generic [ref=f1e152]:
                        - text: Canned Fava Beans
                        - generic [ref=f1e153]: 400 g
                      - text: ⁩
                - button "Add line" [ref=f1e156] [cursor=pointer]
                - button "+ Add new product" [ref=f1e157] [cursor=pointer]
          - generic [ref=f1e159]:
            - button "Save as draft" [ref=f1e160] [cursor=pointer]
            - button "Post invoice" [ref=f1e161] [cursor=pointer]
```

# Test source

```ts
  376 |     await expect(image).toBeVisible();
  377 |     await expect
  378 |       .poll(() =>
  379 |         image.evaluate((element: HTMLImageElement) => element.naturalWidth),
  380 |       )
  381 |       .toBe(2000);
  382 |     await expect(page.getByText(storageFailure)).toHaveCount(0);
  383 |   }
  384 |   expect(new Set(uploaded.map((file) => file.sha256)).size).toBe(20);
  385 |   expect(new Set(uploaded.map((file) => file.reference)).size).toBe(20);
  386 |   const before = await retainedFiles(
  387 |     page,
  388 |     uploaded.map((file) => file.reference),
  389 |   );
  390 |   expect(before).toHaveLength(20);
  391 |   for (const [index, file] of before.entries()) {
  392 |     expect(file.size).toBe(uploaded[index].size);
  393 |     expect(file.hash).toBe(uploaded[index].sha256);
  394 |     expect(file.recorded_hash).toBe(file.hash);
  395 |     expect(
  396 |       Math.max(file.preview_width, file.preview_height),
  397 |     ).toBeLessThanOrEqual(2000);
  398 |     expect(file.preview_size).toBeLessThan(file.size);
  399 |   }
  400 |   const bytesBefore = await textBytes(page);
  401 |   if (bytesBefore >= 5 * 1024 * 1024) {
  402 |     const profile = await page.evaluate(
  403 |       (state) => {
  404 |         const fields = Object.entries(state)
  405 |           .map(([key, value]) => ({
  406 |             key,
  407 |             bytes: JSON.stringify(value).length * 2,
  408 |           }))
  409 |           .sort((a, b) => b.bytes - a.bytes);
  410 |         const keys = Array.from({ length: localStorage.length }, (_, index) =>
  411 |           localStorage.key(index)!,
  412 |         ).map((key) => ({
  413 |           key,
  414 |           bytes: (key.length + localStorage.getItem(key)!.length) * 2,
  415 |         }));
  416 |         const actions: Record<string, number> = {};
  417 |         for (const entry of state.activity)
  418 |           actions[entry.action] =
  419 |             (actions[entry.action] ?? 0) + JSON.stringify(entry).length * 2;
  420 |         return {
  421 |           keys,
  422 |           fields,
  423 |           activity_count: state.activity.length,
  424 |           action_bytes: actions,
  425 |         };
  426 |       },
  427 |       await saved(page),
  428 |     );
  429 |     await testInfo.attach("Text storage size profile", {
  430 |       body: JSON.stringify(profile, null, 2),
  431 |       contentType: "application/json",
  432 |     });
  433 |   }
  434 |   expect(bytesBefore).toBeLessThan(5 * 1024 * 1024);
  435 |   await page.reload();
  436 |   await waitForSavedFiles(page);
  437 |   const after = await retainedFiles(
  438 |     page,
  439 |     uploaded.map((file) => file.reference),
  440 |   );
  441 |   expect(after).toEqual(before);
  442 |   const state = await saved(page);
  443 |   const allInvoices = [...state.invoices!, state.invoice];
  444 |   for (const file of uploaded)
  445 |     expect(
  446 |       allInvoices.some(
  447 |         (invoice: { id: string; file_data?: string }) =>
  448 |           invoice.id === file.id && invoice.file_data === file.reference,
  449 |       ),
  450 |     ).toBe(true);
  451 |   await expect
  452 |     .poll(() =>
  453 |       page
  454 |         .getByRole("img", { name: "Original invoice image", exact: true })
  455 |         .evaluate((element: HTMLImageElement) => element.naturalWidth),
  456 |     )
  457 |     .toBe(2000);
  458 |   const downloadEvent = page.waitForEvent("download");
  459 |   await page
  460 |     .locator(".invoice-original-controls")
  461 |     .getByRole("button", { name: "Download", exact: true })
  462 |     .click();
  463 |   const download = await downloadEvent;
  464 |   const path = await download.path();
  465 |   expect(path).not.toBeNull();
  466 |   expect(digest(await readFile(path!))).toBe(uploaded.at(-1)!.sha256);
  467 |   expect(download.suggestedFilename()).toBe(uploaded.at(-1)!.name);
  468 |   // The dictionary must hydrate real History actions and their conflict guards
  469 |   // before a user can revert after refresh; merely retaining files is not enough.
  470 |   // E1 persists the real decoded History in canonical IDB. Keep the original
  471 |   // dictionary losslessness oracle against that same actual History, then
  472 |   // exercise its real retained reversal after reload below.
  473 |   const encoded = encodeHistoryStorage(state) as DemoState & {
  474 |     prototype_history_dictionary?: { version: number };
  475 |   };
> 476 |   expect(encoded.prototype_history_dictionary?.version).toBe(1);
      |                                                         ^ Error: expect(received).toBe(expected) // Object.is equality
  477 |   expect(decodeHistoryStorage(encoded)).toEqual(state);
  478 |   const originalName = state.products.find(
  479 |     (product: { code: string }) => product.code === "0006",
  480 |   )!.name_en;
  481 |   await page.goto("/#lookup");
  482 |   await page
  483 |     .getByRole("combobox", { name: "Search products", exact: true })
  484 |     .fill("0006");
  485 |   await page.getByRole("button", { name: /^Edit Lavash Bread/ }).click();
  486 |   const editor = page.getByRole("dialog", {
  487 |     name: "Edit product",
  488 |     exact: true,
  489 |   });
  490 |   await editor
  491 |     .getByLabel("English name", { exact: true })
  492 |     .fill(`${originalName} storage reload proof`);
  493 |   await editor
  494 |     .getByRole("button", { name: "Save product", exact: true })
  495 |     .click();
  496 |   await expect
  497 |     .poll(
  498 |       async () =>
  499 |         (await saved(page)).products.find(
  500 |           (product: { code: string }) => product.code === "0006",
  501 |         )!.name_en,
  502 |     )
  503 |     .toContain("storage reload proof");
  504 |   await page.reload();
  505 |   await page.goto("/#history");
  506 |   const row = page
  507 |     .locator(".history-table tbody tr")
  508 |     .filter({
  509 |       has: page.getByRole("button", { name: "Revert", exact: true }),
  510 |     })
  511 |     .first();
  512 |   if (!(await row.getByText("Save product", { exact: true }).isVisible())) {
  513 |     const details = row.getByRole("button", {
  514 |       name: "Show details",
  515 |       exact: true,
  516 |     });
  517 |     const panelId = await details.getAttribute("aria-controls");
  518 |     await details.click();
  519 |     await expect(page.locator(`[id=${JSON.stringify(panelId)}]`)).toContainText(
  520 |       "Save product",
  521 |     );
  522 |   } else {
  523 |     await expect(row.getByText("Save product", { exact: true })).toBeVisible();
  524 |   }
  525 |   await row.getByRole("button", { name: "Revert", exact: true }).click();
  526 |   await page
  527 |     .getByRole("dialog", { name: "Revert change", exact: true })
  528 |     .getByRole("button", { name: "Revert change", exact: true })
  529 |     .click();
  530 |   await expect
  531 |     .poll(
  532 |       async () =>
  533 |         (await saved(page)).products.find(
  534 |           (product: { code: string }) => product.code === "0006",
  535 |         )!.name_en,
  536 |     )
  537 |     .toBe(originalName);
  538 |   expect(
  539 |     await retainedFiles(
  540 |       page,
  541 |       uploaded.map((file) => file.reference),
  542 |     ),
  543 |   ).toEqual(before);
  544 |   const bytesAfter = await textBytes(page);
  545 |   expect(bytesAfter).toBeLessThan(5 * 1024 * 1024);
  546 |   expect(errors).toEqual([]);
  547 |   const proofPath = testInfo.outputPath("twenty-real-photos-proof.json");
  548 |   await writeFile(
  549 |     proofPath,
  550 |     JSON.stringify(
  551 |       {
  552 |         files: after,
  553 |         text_bytes_before: bytesBefore,
  554 |         text_bytes_after: bytesAfter,
  555 |         reload_readable: true,
  556 |         downloaded_source_hash: uploaded.at(-1)!.sha256,
  557 |         history_revert_after_reload: true,
  558 |         browser_errors: errors,
  559 |       },
  560 |       null,
  561 |       2,
  562 |     ),
  563 |   );
  564 |   await testInfo.attach("20 real 3MB photos and exact source retention", {
  565 |     path: proofPath,
  566 |     contentType: "application/json",
  567 |   });
  568 | });
  569 | 
  570 | test("C6 resolves an uploaded company logo before an immediate label Print, and retains the source after reload", async ({
  571 |   page,
  572 | }, testInfo) => {
  573 |   test.setTimeout(120_000);
  574 |   const errors: string[] = [];
  575 |   page.on("pageerror", (error) => errors.push(error.message));
  576 |   page.on("console", (message) => {
```