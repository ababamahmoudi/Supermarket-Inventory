# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: notebooks-b.spec.ts >> Cashier gets only granted custom notebook reads and cannot add or read built-in notebooks
- Location: tests/notebooks-b.spec.ts:184:1

# Error details

```
Test timeout of 60000ms exceeded.
```

```
Error: locator.click: Test timeout of 60000ms exceeded.
Call log:
  - waiting for getByRole('tab', { name: /^Cleaning log( \d+)?$/ })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=e5]:
    - banner [ref=e6]:
      - button "Open menu" [ref=e7] [cursor=pointer]
      - combobox "Location" [ref=e11] [cursor=pointer]:
        - generic [ref=e16]: North York
      - button "Notifications, 0 unread" [ref=e19] [cursor=pointer]
      - button "User menu" [ref=e24] [cursor=pointer]:
        - generic [aria-hidden] [ref=e26]: DC
      - button "More" [ref=e27] [cursor=pointer]
    - main [ref=e33]:
      - generic [ref=e34]:
        - generic [ref=e36]:
          - heading "Cashier lookup" [level=1] [ref=e37]
          - paragraph [ref=e38]: Find the approved price to charge now. Search in English or Persian, or scan a barcode.
        - generic [ref=e39]:
          - generic [ref=e40]: Search products
          - generic [ref=e41]:
            - combobox "Search products" [expanded] [active] [ref=e45]
            - button "Scan barcode" [ref=e46] [cursor=pointer]
          - generic [ref=e52]:
            - group "AI category" [ref=e53]:
              - button "All" [pressed] [ref=e54] [cursor=pointer]
              - button "Beans & legumes" [ref=e55] [cursor=pointer]
              - button "Bread & bakery" [ref=e56] [cursor=pointer]
              - button "Cleaning" [ref=e57] [cursor=pointer]
              - button "More categories" [ref=e58] [cursor=pointer]: More
            - generic [ref=e61]: 16 products
            - paragraph [ref=e62]: Use ↑ ↓ and Enter to select a product.
        - generic [ref=e63]:
          - generic [ref=e65]:
            - heading "Basmati Rice 4.5 kg" [level=2] [ref=e66]:
              - generic [ref=e68]:
                - text: Basmati Rice
                - generic [ref=e69]: 4.5 kg
            - paragraph [ref=e70]:
              - generic [ref=e72]:
                - text: برنج باسماتی
                - generic [ref=e73]: ۴٫۵ کیلوگرمی
            - paragraph [ref=e74]:
              - generic [ref=e75]: Product Code 0001
              - generic [ref=e76]: 4.5 kg
          - generic [ref=e80]:
            - strong [ref=e81]: $23.99
            - generic [ref=e82]:
              - paragraph [ref=e83]: Selling price
              - paragraph [ref=e84]: Before tax
          - region "Dates" [ref=e85]:
            - paragraph [ref=e86]: No open dates in this location.
            - generic [ref=e87]: Last received 2026-10-10
        - generic [ref=e95]:
          - heading "Search results" [level=2] [ref=e96]
          - listbox "Product results" [ref=e97]:
            - option "Basmati Rice 4.5 kg برنج باسماتی ۴٫۵ کیلوگرمی $23.99" [selected] [ref=e98] [cursor=pointer]:
              - generic [ref=e99]:
                - strong [ref=e100]:
                  - generic [ref=e102]:
                    - text: Basmati Rice
                    - generic [ref=e103]: 4.5 kg
                - generic [ref=e106]:
                  - text: برنج باسماتی
                  - generic [ref=e107]: ۴٫۵ کیلوگرمی
              - generic [ref=e108]: $23.99
            - option "Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی $1.49" [ref=e110] [cursor=pointer]:
              - generic [ref=e111]:
                - strong [ref=e112]:
                  - generic [ref=e114]:
                    - text: Canned Fava Beans
                    - generic [ref=e115]: 400 g
                - generic [ref=e118]:
                  - text: باقالا کنسرو شده
                  - generic [ref=e119]: ۴۰۰ گرمی
              - generic [ref=e120]: $1.49
            - option "Sour Cherry Juice 1 L آب آلبالو ۱ لیتری $2.99 2 for $5.00" [ref=e122] [cursor=pointer]:
              - generic [ref=e123]:
                - strong [ref=e124]:
                  - generic [ref=e126]:
                    - text: Sour Cherry Juice
                    - generic [ref=e127]: 1 L
                - generic [ref=e130]:
                  - text: آب آلبالو
                  - generic [ref=e131]: ۱ لیتری
              - generic [ref=e132]:
                - generic [ref=e133]: $2.99
                - generic [ref=e134]: 2 for $5.00
            - option "Black Tea 450 g چای سیاه ۴۵۰ گرمی $6.49" [ref=e137] [cursor=pointer]:
              - generic [ref=e138]:
                - strong [ref=e139]:
                  - generic [ref=e141]:
                    - text: Black Tea
                    - generic [ref=e142]: 450 g
                - generic [ref=e145]:
                  - text: چای سیاه
                  - generic [ref=e146]: ۴۵۰ گرمی
              - generic [ref=e147]: $6.49
            - option "Ground Sumac 100 g سماق ۱۰۰ گرمی $1.99 3 for $5.00" [ref=e149] [cursor=pointer]:
              - generic [ref=e150]:
                - strong [ref=e151]:
                  - generic [ref=e153]:
                    - text: Ground Sumac
                    - generic [ref=e154]: 100 g
                - generic [ref=e157]:
                  - text: سماق
                  - generic [ref=e158]: ۱۰۰ گرمی
              - generic [ref=e159]:
                - generic [ref=e160]: $1.99
                - generic [ref=e161]: 3 for $5.00
            - option "Lavash Bread 500 g نان لواش ۵۰۰ گرمی $1.99 Pending 3 for $5.00" [ref=e164] [cursor=pointer]:
              - generic [ref=e165]:
                - strong [ref=e166]:
                  - generic [ref=e168]:
                    - text: Lavash Bread
                    - generic [ref=e169]: 500 g
                - generic [ref=e172]:
                  - text: نان لواش
                  - generic [ref=e173]: ۵۰۰ گرمی
              - generic [ref=e174]:
                - generic [ref=e175]: $1.99
                - generic [ref=e176]:
                  - generic [ref=e177]: Pending
                  - generic [ref=e178]: 3 for $5.00
            - option "Dried Red Kidney Beans 900 g لوبیا قرمز ۹۰۰ گرمی $3.99 2 for $7.00" [ref=e180] [cursor=pointer]:
              - generic [ref=e181]:
                - strong [ref=e182]:
                  - generic [ref=e184]:
                    - text: Dried Red Kidney Beans
                    - generic [ref=e185]: 900 g
                - generic [ref=e188]:
                  - text: لوبیا قرمز
                  - generic [ref=e189]: ۹۰۰ گرمی
              - generic [ref=e190]:
                - generic [ref=e191]: $3.99
                - generic [ref=e192]: 2 for $7.00
            - option "Sunflower Oil 1.8 L روغن آفتابگردان ۱٫۸ لیتری $9.49 Sale requested $7.99 · Oct 15–Oct 28" [ref=e195] [cursor=pointer]:
              - generic [ref=e196]:
                - strong [ref=e197]:
                  - generic [ref=e199]:
                    - text: Sunflower Oil
                    - generic [ref=e200]: 1.8 L
                - generic [ref=e203]:
                  - text: روغن آفتابگردان
                  - generic [ref=e204]: ۱٫۸ لیتری
              - generic [ref=e205]:
                - generic [ref=e206]: $9.49
                - generic [ref=e209]:
                  - text: Sale requested
                  - generic [ref=e210]: $7.99
                  - text: ·
                  - generic [ref=e211]: Oct 15–Oct 28
            - option "Potato Chips 150 g چیپس سیب‌زمینی ۱۵۰ گرمی $2.99 Taxable 2 for $5.00" [ref=e212] [cursor=pointer]:
              - generic [ref=e213]:
                - strong [ref=e214]:
                  - generic [ref=e216]:
                    - text: Potato Chips
                    - generic [ref=e217]: 150 g
                - generic [ref=e220]:
                  - text: چیپس سیب‌زمینی
                  - generic [ref=e221]: ۱۵۰ گرمی
              - generic [ref=e222]:
                - generic [ref=e223]: $2.99
                - generic [ref=e224]:
                  - generic [ref=e225]: Taxable
                  - generic [ref=e226]: 2 for $5.00
            - option "Fruit Soda 6-pack نوشابه میوه‌ای بسته ۶ عددی $4.99 Taxable" [ref=e228] [cursor=pointer]:
              - generic [ref=e229]:
                - strong [ref=e230]:
                  - generic [ref=e231]: Fruit Soda 6-pack
                - generic [ref=e232]: نوشابه میوه‌ای بسته ۶ عددی
              - generic [ref=e234]:
                - generic [ref=e235]: $4.99
                - generic [ref=e236]: Taxable
            - option "Tea Glass Set (6 pcs) ست استکان چای (۶ عددی) $8.99 Taxable" [ref=e238] [cursor=pointer]:
              - generic [ref=e239]:
                - strong [ref=e240]:
                  - generic [ref=e241]: Tea Glass Set (6 pcs)
                - generic [ref=e242]: ست استکان چای (۶ عددی)
              - generic [ref=e244]:
                - generic [ref=e245]: $8.99
                - generic [ref=e246]: Taxable
            - option "Stainless Steel Pot 24 cm قابلمه استیل ۲۴ سانتی‌متری $16.99 Sale Regular $20.99 Until Oct 25 Taxable" [ref=e248] [cursor=pointer]:
              - generic [ref=e249]:
                - strong [ref=e250]:
                  - generic [ref=e251]: Stainless Steel Pot 24 cm
                - generic [ref=e252]: قابلمه استیل ۲۴ سانتی‌متری
              - generic [ref=e254]:
                - generic [ref=e255]: $16.99
                - generic [ref=e257]:
                  - generic [ref=e258]:
                    - generic [ref=e259]: Sale
                    - deletion [ref=e260]: Regular $20.99
                    - generic [ref=e261]: Until Oct 25
                  - generic [ref=e262]: Taxable
            - option "Rice Cooker 1.8 L پلوپز ۱٫۸ لیتری $52.49 Taxable" [ref=e263] [cursor=pointer]:
              - generic [ref=e264]:
                - strong [ref=e265]:
                  - generic [ref=e267]:
                    - text: Rice Cooker
                    - generic [ref=e268]: 1.8 L
                - generic [ref=e271]:
                  - text: پلوپز
                  - generic [ref=e272]: ۱٫۸ لیتری
              - generic [ref=e273]:
                - generic [ref=e274]: $52.49
                - generic [ref=e275]: Taxable
            - option "Kitchen Sponge 3-pack اسفنج ظرفشویی بسته ۳ عددی $2.49 Taxable" [ref=e277] [cursor=pointer]:
              - generic [ref=e278]:
                - strong [ref=e279]:
                  - generic [ref=e280]: Kitchen Sponge 3-pack
                - generic [ref=e281]: اسفنج ظرفشویی بسته ۳ عددی
              - generic [ref=e283]:
                - generic [ref=e284]: $2.49
                - generic [ref=e285]: Taxable
            - option "Bulk Almonds بادام فله $7.49/lb $16.51/kg" [ref=e287] [cursor=pointer]:
              - generic [ref=e288]:
                - strong [ref=e289]:
                  - generic [ref=e290]: Bulk Almonds
                - generic [ref=e291]: بادام فله
              - generic [ref=e294]:
                - generic [ref=e295]: $7.49/lb
                - generic [ref=e296]: $16.51/kg
            - option "Dried Barberries 100 g زرشک خشک ۱۰۰ گرمی No approved price yet Pending" [ref=e297] [cursor=pointer]:
              - generic [ref=e298]:
                - strong [ref=e299]:
                  - generic [ref=e301]:
                    - text: Dried Barberries
                    - generic [ref=e302]: 100 g
                - generic [ref=e305]:
                  - text: زرشک خشک
                  - generic [ref=e306]: ۱۰۰ گرمی
              - generic [ref=e307]:
                - generic [ref=e308]: No approved price yet
                - generic [ref=e309]: Pending
```

# Test source

```ts
  1   | import { configuredPersonExpectation } from "./configured-person-expectations";
  2   | import { expect, test } from "@playwright/test";
  3   | import { chooseOption, setBranch, setLanguage, signIn } from "./helpers";
  4   | 
  5   | async function notebookTab(
  6   |   page: import("@playwright/test").Page,
  7   |   name: string,
  8   | ) {
  9   |   await page
  10  |     .getByRole("tab", { name: new RegExp(`^${name}( \\d+)?$`) })
> 11  |     .click();
      |      ^ Error: locator.click: Test timeout of 60000ms exceeded.
  12  | }
  13  | async function createCleaningNotebook(page: import("@playwright/test").Page) {
  14  |   await page.goto("/#notes");
  15  |   await page.getByRole("button", { name: "New notebook", exact: true }).click();
  16  |   const dialog = page.getByRole("dialog", {
  17  |     name: "New notebook",
  18  |     exact: true,
  19  |   });
  20  |   await dialog
  21  |     .getByLabel("Name (English)", { exact: true })
  22  |     .fill("Cleaning log");
  23  |   await dialog
  24  |     .getByLabel("Name (Persian) (optional)", { exact: true })
  25  |     .fill("دفتر نظافت");
  26  |   await chooseOption(
  27  |     page,
  28  |     dialog.getByLabel("Branch", { exact: true }),
  29  |     "North York",
  30  |   );
  31  |   await dialog
  32  |     .getByRole("group", { name: "Who can read", exact: true })
  33  |     .getByRole("checkbox", { name: "Cashier", exact: true })
  34  |     .check();
  35  |   await dialog
  36  |     .getByRole("checkbox", { name: "Measurement", exact: true })
  37  |     .check();
  38  |   await dialog.getByLabel("Measurement unit", { exact: true }).fill("°C");
  39  |   await dialog
  40  |     .getByRole("button", { name: "Save notebook", exact: true })
  41  |     .click();
  42  |   await expect(dialog).not.toBeVisible();
  43  |   await notebookTab(page, "Cleaning log");
  44  |   await page.getByRole("button", { name: "Add note", exact: true }).click();
  45  | }
  46  | 
  47  | test("Notes search has a search icon, a placeholder, bounded fields and touch actions, and the singular note count", async ({
  48  |   page,
  49  | }) => {
  50  |   await signIn(page, "Floor Worker");
  51  |   await page.goto("/#notes");
  52  |   const search = page.getByLabel("Search notes", { exact: true });
  53  |   await expect(search).toHaveAttribute("placeholder", "Search all notebooks");
  54  |   await expect(page.locator(".filter-search-pill svg")).toBeVisible();
  55  |   await search.fill("Sunflower oil");
  56  |   await expect(page.locator(".filter-count")).toHaveText("1 note");
  57  |   await expect(page.locator(".filter-count")).not.toHaveText("1 notes");
  58  |   const controls = await page.locator(".filter-toolbar").evaluate((el) =>
  59  |     Array.from(el.querySelectorAll("input,button,.ui-checked-control"))
  60  |       .filter((control) => control.getBoundingClientRect().height > 0)
  61  |       .map((control) => ({
  62  |         height: control.getBoundingClientRect().height,
  63  |         kind: control.matches("input,.ui-input,.ui-checked-control")
  64  |           ? "field"
  65  |           : control.getAttribute("data-control-kind"),
  66  |       })),
  67  |   );
  68  |   for (const control of controls) {
  69  |     expect(["field", "action", "icon"]).toContain(control.kind);
  70  |     const actionHeight = page.viewportSize()!.width < 760 ? 44 : 40;
  71  |     expect(
  72  |       Math.abs(control.height - (control.kind === "field" ? 44 : actionHeight)),
  73  |     ).toBeLessThanOrEqual(1);
  74  |   }
  75  | });
  76  | 
  77  | test("Supervisor configures a custom notebook and entries persist with author, branch and enabled fields", async ({
  78  |   page,
  79  | }) => {
  80  |   await signIn(page, "Supervisor");
  81  |   await createCleaningNotebook(page);
  82  |   await expect(
  83  |     page.getByLabel("Measurement (°C)", { exact: true }),
  84  |   ).toBeVisible();
  85  |   await expect(
  86  |     page.getByLabel("Product (optional)", { exact: true }),
  87  |   ).toHaveCount(0);
  88  |   await page.getByLabel("Note", { exact: true }).fill("Deli counter cleaned");
  89  |   await page.getByLabel("Measurement (°C)", { exact: true }).fill("3.5");
  90  |   await page.getByRole("button", { name: "Save note", exact: true }).click();
  91  |   const entry = page
  92  |     .locator(".notebook-entry-card")
  93  |     .filter({ hasText: "Deli counter cleaned" });
  94  |   await expect(entry).toContainText(
  95  |     configuredPersonExpectation("manager").name_en,
  96  |   );
  97  |   await expect(entry).toContainText("North York");
  98  |   await expect(entry).toContainText("3.5 °C");
  99  |   await page.reload();
  100 |   await notebookTab(page, "Cleaning log");
  101 |   await expect(entry).toBeVisible();
  102 |   await page
  103 |     .getByRole("button", { name: "Edit notebook", exact: true })
  104 |     .click();
  105 |   const dialog = page.getByRole("dialog", {
  106 |     name: "Edit notebook",
  107 |     exact: true,
  108 |   });
  109 |   await dialog.getByLabel("Measurement unit", { exact: true }).fill("°F");
  110 |   await dialog
  111 |     .getByRole("button", { name: "Save notebook", exact: true })
```