# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: manual-prices-c1.spec.ts >> manual price stays visible to staff while catalog cost, margin and cost history stay Supervisor-only
- Location: tests/manual-prices-c1.spec.ts:15:1

# Error details

```
Test timeout of 60000ms exceeded.
```

```
Error: locator.click: Test timeout of 60000ms exceeded.
Call log:
  - waiting for locator('.catalog-products-table').locator('tbody tr').filter({ hasText: '0009' }).first().getByRole('button', { name: 'Show details', exact: true })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=e5]:
    - banner [ref=e6]:
      - button "Open menu" [ref=e7] [cursor=pointer]
      - combobox "Location" [ref=e11] [cursor=pointer]:
        - generic [ref=e16]: All locations
      - button "Notifications, 5 unread" [ref=e19] [cursor=pointer]:
        - generic [ref=e20]: "5"
      - button "User menu" [ref=e25] [cursor=pointer]:
        - generic [aria-hidden] [ref=e27]: DM
      - button "More" [ref=e28] [cursor=pointer]
    - main [ref=e34]:
      - generic [ref=e35]:
        - generic [ref=e36]:
          - generic [ref=e37]:
            - heading "Products" [level=1] [ref=e38]
            - paragraph [ref=e39]: Approved prices, pending changes and branch details in one catalog.
          - button "Add product" [ref=e41] [cursor=pointer]
        - generic [ref=e42]:
          - generic [ref=e43]:
            - searchbox "Search products" [active] [ref=e48]: "0009"
            - combobox "Pricing category" [ref=e49] [cursor=pointer]:
              - generic [ref=e50]: All pricing categories
            - combobox "AI category" [ref=e53] [cursor=pointer]:
              - generic [ref=e54]: All AI categories
            - combobox "Status" [ref=e57] [cursor=pointer]:
              - generic [ref=e58]: All statuses
            - combobox "Supplier" [ref=e61] [cursor=pointer]:
              - generic [ref=e62]: All suppliers
            - checkbox "Has pending price" [ref=e65] [cursor=pointer]
            - checkbox "Has offer" [ref=e68] [cursor=pointer]
            - checkbox "Manual prices" [ref=e71] [cursor=pointer]
            - checkbox "On sale" [ref=e74] [cursor=pointer]
            - button "Clear filters" [ref=e77] [cursor=pointer]
            - generic [ref=e79]:
              - generic [ref=e80]: 1 product
              - button "Columns" [ref=e81] [cursor=pointer]
          - generic [ref=e85]:
            - table [ref=e87]:
              - rowgroup [ref=e88]:
                - row [ref=e89]:
                  - cell "Potato Chips 150 g چیپس سیب‌زمینی ۱۵۰ گرمی 150 g" [ref=e90]:
                    - link "Potato Chips 150 g" [ref=e91] [cursor=pointer]:
                      - /url: "#product?code=0009"
                      - strong [ref=e92]:
                        - generic [ref=e94]:
                          - text: Potato Chips
                          - generic [ref=e95]: 150 g
                    - paragraph [ref=e96]:
                      - generic [ref=e98]:
                        - text: چیپس سیب‌زمینی
                        - generic [ref=e99]: ۱۵۰ گرمی
                    - paragraph [ref=e100]:
                      - generic [ref=e101]: 150 g
                  - cell "$2.99" [ref=e104]
                  - cell [ref=e107]:
                    - link "Open Potato Chips 150 g" [ref=e108] [cursor=pointer]:
                      - /url: "#product?code=0009"
                  - cell "0009 Approved" [ref=e111]:
                    - generic [ref=e112]: "0009"
                    - generic [ref=e114]: Approved
            - generic [ref=e117]:
              - button "Previous" [disabled] [ref=e118]
              - generic [ref=e119]: Page 1 of 1 · 1 product
              - button "Next" [disabled] [ref=e120]
```

# Test source

```ts
  1   | import { expect, test, type Page } from "@playwright/test";
  2   | import { resetDemo, setBranch, setLanguage, signIn } from "./helpers";
  3   | 
  4   | async function showManualPrice(page: Page) {
  5   |   const table = page.locator(".catalog-products-table");
  6   |   const badge = table.locator(".manual-price-pill");
  7   |   if (!(await badge.isVisible()))
  8   |     await table
  9   |       .getByRole("button", { name: "Show details", exact: true })
  10  |       .first()
  11  |       .click();
  12  |   await expect(badge).toHaveText("Manual price");
  13  | }
  14  | 
  15  | test("manual price stays visible to staff while catalog cost, margin and cost history stay Supervisor-only", async ({
  16  |   page,
  17  | }) => {
  18  |   await signIn(page, "Supervisor");
  19  |   await setBranch(page, "all");
  20  |   await page.goto("/#products");
  21  |   await page.getByLabel("Search products", { exact: true }).fill("0009");
  22  |   const table = page.locator(".catalog-products-table");
  23  |   const productRow = table
  24  |     .locator("tbody tr")
  25  |     .filter({ hasText: "0009" })
  26  |     .first();
  27  |   for (const label of ["Store cost", "Margin %"]) {
  28  |     const heading = table.getByRole("columnheader", {
  29  |       name: label,
  30  |       exact: true,
  31  |     });
  32  |     const cell = productRow.locator(`td[data-column-label="${label}"]`);
  33  |     if (await heading.count()) await expect(heading).toBeVisible();
  34  |     else if (await cell.isVisible()) {
  35  |       await expect(cell).toHaveAttribute("data-column-label", label);
  36  |       await expect(cell).not.toBeEmpty();
  37  |     } else {
  38  |       await productRow
  39  |         .getByRole("button", { name: "Show details", exact: true })
> 40  |         .click();
      |          ^ Error: locator.click: Test timeout of 60000ms exceeded.
  41  |       await expect(
  42  |         table.locator(".table-expanded-row").getByText(label, { exact: true }),
  43  |       ).toBeVisible();
  44  |       await productRow
  45  |         .getByRole("button", { name: "Hide details", exact: true })
  46  |         .click();
  47  |     }
  48  |   }
  49  |   await page
  50  |     .getByRole("link", { name: "Potato Chips 150 g", exact: true })
  51  |     .click();
  52  |   await page
  53  |     .locator(".product-header-actions")
  54  |     .getByRole("button", { name: "Change price", exact: true })
  55  |     .click();
  56  |   const editor = page.getByRole("dialog", {
  57  |     name: "Change price",
  58  |     exact: true,
  59  |   });
  60  |   await editor.getByRole("radio", { name: /^New regular price/ }).click();
  61  |   await editor.getByLabel("Price", { exact: true }).fill("3.29");
  62  |   await editor
  63  |     .getByRole("button", { name: "Save new price", exact: true })
  64  |     .click();
  65  |   await expect(editor).not.toBeVisible();
  66  |   await page
  67  |     .getByRole("link", { name: "Back to Products", exact: true })
  68  |     .click();
  69  |   await page.getByLabel("Manual prices", { exact: true }).check();
  70  |   await expect(page.locator(".catalog-products-table tbody tr")).toHaveCount(1);
  71  |   await showManualPrice(page);
  72  |   await page
  73  |     .getByRole("link", { name: "Potato Chips 150 g", exact: true })
  74  |     .click();
  75  |   await expect(
  76  |     page.getByRole("heading", { name: "Cost history", exact: true }),
  77  |   ).toBeVisible();
  78  |   await expect(
  79  |     page.getByRole("heading", { name: "Deliveries", exact: true }),
  80  |   ).toBeVisible();
  81  |   await expect(page.locator(".product-last-received-summary")).toContainText(
  82  |     "Last received",
  83  |   );
  84  |   await expect(
  85  |     page.getByRole("heading", { name: "Stock estimate", exact: true }),
  86  |   ).toHaveCount(0);
  87  |   await expect(page.locator(".manual-price-comparison")).toHaveText(
  88  |     "Rule price $2.99 · Manual price $3.29",
  89  |   );
  90  |   await expect(page.locator(".manual-price-margin")).toBeVisible();
  91  | 
  92  |   await signIn(page, "Floor Worker");
  93  |   await page.goto("/#products");
  94  |   await page.getByLabel("Search products", { exact: true }).fill("0009");
  95  |   await expect(
  96  |     page.getByRole("columnheader", { name: "Store cost", exact: true }),
  97  |   ).toHaveCount(0);
  98  |   await expect(
  99  |     page.getByRole("columnheader", { name: "Margin %", exact: true }),
  100 |   ).toHaveCount(0);
  101 |   await expect(
  102 |     page.locator(
  103 |       '.catalog-products-table td[data-column-label="Store cost"], .catalog-products-table td[data-column-label="Margin %"]',
  104 |     ),
  105 |   ).toHaveCount(0);
  106 |   await showManualPrice(page);
  107 |   await page
  108 |     .getByRole("link", { name: "Potato Chips 150 g", exact: true })
  109 |     .click();
  110 |   await expect(
  111 |     page.getByRole("heading", { name: "Cost history", exact: true }),
  112 |   ).toHaveCount(0);
  113 |   await expect(page.locator(".manual-price-margin")).toHaveCount(0);
  114 | 
  115 |   await signIn(page, "Cashier");
  116 |   await page.goto("/#lookup");
  117 |   await page.getByLabel("Search products", { exact: true }).fill("0009");
  118 |   await expect(page.locator(".lookup-detail .manual-price-pill")).toHaveText(
  119 |     "Manual price",
  120 |   );
  121 |   await expect(
  122 |     page.locator(".lookup-detail .manual-price-comparison"),
  123 |   ).toHaveText("Rule price $2.99 · Manual price $3.29");
  124 |   await expect(page.locator(".manual-price-margin")).toHaveCount(0);
  125 |   await page.reload();
  126 |   await page.getByLabel("Search products", { exact: true }).fill("0009");
  127 |   await expect(page.locator(".lookup-detail .price")).toHaveText("$3.29");
  128 |   await setLanguage(page, "fa");
  129 |   await expect(page.locator(".lookup-detail .manual-price-pill")).toHaveText(
  130 |     "قیمت دستی",
  131 |   );
  132 |   await expect(
  133 |     page.locator(".lookup-detail .manual-price-comparison bdi"),
  134 |   ).toHaveText(["$2.99", "$3.29"]);
  135 |   await setLanguage(page, "en");
  136 |   await resetDemo(page);
  137 |   await page.goto("/#lookup");
  138 |   await page.getByLabel("Search products", { exact: true }).fill("0009");
  139 |   await expect(page.locator(".lookup-detail .manual-price-pill")).toHaveCount(
  140 |     0,
```