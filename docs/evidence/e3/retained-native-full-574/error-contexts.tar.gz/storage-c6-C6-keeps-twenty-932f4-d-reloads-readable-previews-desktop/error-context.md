# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: storage-c6.spec.ts >> C6 keeps twenty distinct 3MB photos out of text storage, preserves exact originals and reloads readable previews
- Location: tests/storage-c6.spec.ts:335:1

# Error details

```
Error: Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - complementary "Main menu" [ref=e5]:
    - generic [ref=e6]:
      - img "Super Arzon" [ref=e9]
      - generic [ref=e10]: Super Arzon
    - navigation "Pages" [ref=e11]:
      - generic [ref=e12]:
        - button "Daily" [expanded] [ref=e13] [cursor=pointer]
        - generic [ref=e17]:
          - link "Lookup" [ref=e18] [cursor=pointer]:
            - /url: "#lookup"
          - link "Invoices" [ref=e23] [cursor=pointer]:
            - /url: "#invoices"
          - link "Received" [ref=e28] [cursor=pointer]:
            - /url: "#received"
          - link "Returns" [ref=e35] [cursor=pointer]:
            - /url: "#returns"
          - link "Price updates" [ref=e40] [cursor=pointer]:
            - /url: "#price-updates"
          - link "Labels" [ref=e46] [cursor=pointer]:
            - /url: "#labels"
          - link "Date tracking" [ref=e51] [cursor=pointer]:
            - /url: "#expiry"
          - link "Notes" [ref=e56] [cursor=pointer]:
            - /url: "#notes"
            - generic [ref=e60]: "2"
          - link "Branch requests" [ref=e61] [cursor=pointer]:
            - /url: "#requests"
      - button "Catalog" [ref=e67] [cursor=pointer]
      - button "Manager" [ref=e72] [cursor=pointer]
      - button "Admin" [ref=e77] [cursor=pointer]
    - button "User menu" [ref=e82] [cursor=pointer]:
      - generic [ref=e83]:
        - generic [aria-hidden] [ref=e84]: DM
        - generic [ref=e85]:
          - strong [ref=e86]: Demo Manager
          - generic [ref=e87]: Manager
  - generic [ref=e88]:
    - banner [ref=e89]:
      - button "Collapse sidebar" [expanded] [ref=e90] [cursor=pointer]
      - navigation "Breadcrumbs" [ref=e94]:
        - link "North York" [ref=e95] [cursor=pointer]:
          - /url: "#dashboard"
        - link "Invoices" [ref=e98] [cursor=pointer]:
          - /url: "#invoices"
      - search [ref=e99]:
        - textbox "Search all products" [ref=e103]:
          - /placeholder: Search products
        - generic [aria-hidden] [ref=e104]: /
      - combobox "Location" [ref=e105] [cursor=pointer]:
        - generic [ref=e110]: North York
      - button "Switch to Persian" [ref=e113] [cursor=pointer]: فا
      - button "Switch to dark theme" [ref=e114] [cursor=pointer]
      - button "Comfortable text size" [ref=e117] [cursor=pointer]:
        - generic [aria-hidden] [ref=e118]: Aa
      - button "Notifications, 5 unread" [ref=e119] [cursor=pointer]:
        - generic [ref=e120]: "5"
      - button "Demo" [ref=e125] [cursor=pointer]
    - main [ref=e128]:
      - generic [ref=e129]:
        - link "Back to Invoices" [ref=e130] [cursor=pointer]:
          - /url: "#invoices"
        - generic [ref=e133]:
          - generic [ref=e134]:
            - heading "Invoices" [level=1] [ref=e135]
            - paragraph [ref=e136]: Deliveries and supplier invoices
          - button "New invoice" [ref=e138] [cursor=pointer]
        - tablist "Invoice views" [ref=e139]:
          - tab "Drafts" [selected] [ref=e140] [cursor=pointer]
          - tab "Processing" [ref=e142] [cursor=pointer]
          - tab "Needs review" [ref=e144] [cursor=pointer]
          - tab "Ready to post" [ref=e146] [cursor=pointer]
          - tab "Posted" [ref=e148] [cursor=pointer]
          - tab "Cancelled" [ref=e150] [cursor=pointer]
        - generic [ref=e152]:
          - complementary "Original invoice" [ref=e153]:
            - generic [ref=e154]:
              - heading "Original invoice" [level=2] [ref=e155]
              - paragraph [ref=e156]: AI invoice reading is simulated
              - generic "New invoice entry method" [ref=e157]:
                - button "Upload" [ref=e158] [cursor=pointer]
                - button "Manual entry" [ref=e159] [cursor=pointer]
              - generic [ref=e161]:
                - generic [ref=e162]: Upload a PDF or photo
                - generic [ref=e163]:
                  - button "Upload a PDF or photo" [ref=e164]
                  - button "Take photo" [ref=e165]
                  - paragraph [ref=e170]: Drop a PDF or photo here, or browse
                  - button "Browse" [ref=e172] [cursor=pointer]
              - paragraph [ref=e173]: No original attached
              - button "Attach original" [ref=e174] [cursor=pointer]
          - generic [ref=e175]:
            - generic [ref=e176]:
              - heading "Drafts" [level=2] [ref=e177]
              - table [ref=e179]:
                - rowgroup [ref=e184]:
                  - row [ref=e185]:
                    - columnheader "Invoice" [ref=e186]
                    - columnheader "Status" [ref=e187]
                    - columnheader "Details" [ref=e188]
                - rowgroup [ref=e189]:
                  - row [ref=e190]:
                    - cell "—" [ref=e191]
                    - cell "Draft" [ref=e192]
                    - cell [ref=e195]:
                      - button "Show details" [ref=e196] [cursor=pointer]
            - generic [ref=e199]:
              - generic "Delivery summary" [ref=e200]:
                - generic [ref=e201]:
                  - generic [ref=e202]: Subtotal
                  - strong [ref=e203]: $0.00
                - generic [ref=e204]:
                  - generic [ref=e205]: Tax
                  - strong [ref=e206]: $0.00
                - generic [ref=e207]:
                  - generic [ref=e208]: Shorts and refused deduction
                  - strong [ref=e209]: $0.00
                - generic [ref=e210]:
                  - generic [ref=e211]: Payable
                  - strong [ref=e212]: $0.00
              - paragraph [ref=e213]: This is the amount of this invoice, not a supplier balance. Received records only physically delivered units.
            - generic [ref=e214]:
              - heading [level=2] [ref=e215]:
                - button "Invoice details" [expanded] [ref=e216] [cursor=pointer]
              - paragraph [ref=e219]:
                - text: ·
                - generic [ref=e220]: —
                - text: · North York ·
                - generic [ref=e221]: 2026-10-15
              - paragraph [ref=e222]:
                - generic [ref=e223]: Needs review
                - text: Changes save automatically in this browser.
              - group [ref=e224]:
                - generic [ref=e225]:
                  - generic [ref=e226]: Supplier
                  - combobox "Supplier" [ref=e227] [cursor=pointer]:
                    - generic [ref=e228]: Choose supplier
                - generic [ref=e231]:
                  - generic [ref=e232]: Supplier invoice number (optional)
                  - textbox "Supplier invoice number (optional)" [ref=e233]:
                    - /placeholder: Assigned on posting if blank
                - generic [ref=e234]:
                  - generic [ref=e235]: Invoice date
                  - button "Invoice date" [ref=e236] [cursor=pointer]:
                    - generic [ref=e237]: 2026-10-15
                - generic [ref=e240]:
                  - generic [ref=e241]:
                    - generic [ref=e242]: Received date
                    - button "Received date" [ref=e243] [cursor=pointer]:
                      - generic [ref=e244]: 2026-10-15
                  - generic [ref=e247]:
                    - generic [ref=e248]: Received time
                    - textbox "Received time" [ref=e249]:
                      - /placeholder: HH:mm
                      - text: 14:03
                    - paragraph [ref=e250]: Store local time, 24-hour HH:mm
                - generic [ref=e251]:
                  - generic [ref=e252]: Receiving employee
                  - combobox "Receiving employee" [ref=e253] [cursor=pointer]:
                    - generic [ref=e254]: Demo Manager
                - generic [ref=e257]:
                  - generic [ref=e258]: Location
                  - combobox "Location" [ref=e259] [cursor=pointer]:
                    - generic [ref=e260]: North York
                - generic [ref=e263]:
                  - generic [ref=e264]: Ship to (optional)
                  - textbox "Ship to (optional)" [ref=e265]
                - generic [ref=e266]:
                  - generic [ref=e267]: Subtotal
                  - textbox "Subtotal" [ref=e268]: "0.00"
                - generic [ref=e269]:
                  - generic [ref=e270]: Tax
                  - textbox "Tax" [ref=e271]: "0.00"
                - generic [ref=e272]:
                  - generic [ref=e273]: Final total
                  - textbox "Final total" [ref=e274]: "0.00"
                - generic [ref=e275]:
                  - generic [ref=e276]: Due date (optional)
                  - button "Due date (optional)" [ref=e277] [cursor=pointer]:
                    - generic [ref=e278]: 2026-10-29
                - generic [ref=e282]:
                  - generic [ref=e283]: Payment terms (optional)
                  - combobox "Payment terms (optional)" [ref=e284] [cursor=pointer]:
                    - generic [ref=e285]: Choose payment terms
            - generic [ref=e289]:
              - heading "Compare with order" [level=2] [ref=e290]
              - generic [ref=e291]:
                - generic [ref=e292]: Order (optional)
                - combobox "Order (optional)" [ref=e293] [cursor=pointer]:
                  - generic [ref=e294]: No linked order
                - paragraph [ref=e297]: Choose an open order for this supplier and receiving location.
            - generic [ref=e298]:
              - heading "Review invoice lines" [level=2] [ref=e299]
              - paragraph [ref=e300]: Choose Cases or Units and confirm the product, pack, quantities, cost, and date decision on each line.
              - paragraph [ref=e306]: No lines. Add a product below to start your manual draft.
              - generic:
                - table
              - generic [ref=e307]:
                - generic [ref=e308]:
                  - generic [ref=e309]: Add a product to the invoice
                  - combobox "Add a product to the invoice" [ref=e310] [cursor=pointer]:
                    - generic [ref=e312]:
                      - text: ⁦0002⁩ · ⁦
                      - generic [ref=e313]:
                        - text: Canned Fava Beans
                        - generic [ref=e314]: 400 g
                      - text: ⁩
                - button "Add line" [ref=e317] [cursor=pointer]
                - button "+ Add new product" [ref=e318] [cursor=pointer]
          - generic [ref=e320]:
            - button "Save as draft" [ref=e321] [cursor=pointer]
            - button "Post invoice" [ref=e322] [cursor=pointer]
```

# Test source

```ts
  229 | async function textBytes(page: Page) {
  230 |   return page.evaluate(() =>
  231 |     Array.from({ length: localStorage.length }, (_, index) =>
  232 |       localStorage.key(index)!,
  233 |     ).reduce(
  234 |       (sum, key) =>
  235 |         sum + (key.length + (localStorage.getItem(key)?.length ?? 0)) * 2,
  236 |       0,
  237 |     ),
  238 |   );
  239 | }
  240 | 
  241 | async function retainedRawBackups(page: Page) {
  242 |   return page.evaluate(async (databaseName) => {
  243 |     const database = await new Promise<IDBDatabase>((resolve, reject) => {
  244 |       const request = indexedDB.open(databaseName);
  245 |       request.onupgradeneeded = () => {
  246 |         request.transaction?.abort();
  247 |         reject(
  248 |           new Error("Backup evidence must not initialize a file database."),
  249 |         );
  250 |       };
  251 |       request.onsuccess = () => resolve(request.result);
  252 |       request.onerror = () => reject(request.error);
  253 |     });
  254 |     try {
  255 |       const records = await new Promise<
  256 |         { company_id: string; storage_key: string; raw: Blob; sha256: string }[]
  257 |       >((resolve, reject) => {
  258 |         const request = database
  259 |           .transaction("backups", "readonly")
  260 |           .objectStore("backups")
  261 |           .getAll();
  262 |         request.onsuccess = () => resolve(request.result);
  263 |         request.onerror = () => reject(request.error);
  264 |       });
  265 |       return Promise.all(
  266 |         records.map(async (record) => ({
  267 |           company_id: record.company_id,
  268 |           storage_key: record.storage_key,
  269 |           raw: await record.raw.text(),
  270 |           sha256: record.sha256,
  271 |         })),
  272 |       );
  273 |     } finally {
  274 |       database.close();
  275 |     }
  276 |   }, databaseName);
  277 | }
  278 | 
  279 | async function canonicalBusinessExists(page: Page) {
  280 |   return page.evaluate(
  281 |     ({ databaseName, companyId }) =>
  282 |       new Promise<boolean>((resolve, reject) => {
  283 |         const request = indexedDB.open(databaseName);
  284 |         request.onupgradeneeded = () => {
  285 |           request.transaction?.abort();
  286 |           reject(new Error("Evidence must not create a canonical database."));
  287 |         };
  288 |         request.onerror = () => reject(request.error);
  289 |         request.onsuccess = () => {
  290 |           const database = request.result;
  291 |           const transaction = database.transaction("business", "readonly");
  292 |           const read = transaction.objectStore("business").get(companyId);
  293 |           let exists = false;
  294 |           read.onsuccess = () => {
  295 |             exists = read.result !== undefined;
  296 |           };
  297 |           transaction.oncomplete = () => {
  298 |             database.close();
  299 |             resolve(exists);
  300 |           };
  301 |           transaction.onabort = transaction.onerror = () => {
  302 |             database.close();
  303 |             reject(
  304 |               transaction.error ??
  305 |                 new Error("Cannot inspect canonical publication."),
  306 |             );
  307 |           };
  308 |         };
  309 |       }),
  310 |     {
  311 |       databaseName: AUTHORITY_DATABASE_NAME,
  312 |       companyId: companyId,
  313 |     },
  314 |   );
  315 | }
  316 | async function openManual(page: Page) {
  317 |   const previousInvoiceId = (await saved(page)).invoice.id;
  318 |   await page.getByRole("button", { name: "New invoice", exact: true }).click();
  319 |   await page.getByRole("button", { name: "Manual entry", exact: true }).click();
  320 |   await expect
  321 |     .poll(async () => {
  322 |       const current = (await saved(page)).invoice;
  323 |       return (
  324 |         current.id !== previousInvoiceId &&
  325 |         current.entry_mode === "manual" &&
  326 |         current.status === "draft"
  327 |       );
  328 |     })
> 329 |     .toBe(true);
      |      ^ Error: Timeout 5000ms exceeded while waiting on the predicate
  330 |   await expect(
  331 |     page.getByRole("heading", { name: "Review invoice lines", exact: true }),
  332 |   ).toBeVisible();
  333 | }
  334 | 
  335 | test("C6 keeps twenty distinct 3MB photos out of text storage, preserves exact originals and reloads readable previews", async ({
  336 |   page,
  337 | }, testInfo) => {
  338 |   test.setTimeout(300_000);
  339 |   const errors: string[] = [];
  340 |   page.on("pageerror", (error) => errors.push(error.message));
  341 |   await signIn(page, "Supervisor");
  342 |   await waitForSavedFiles(page);
  343 |   await page.goto("/#invoices");
  344 |   const uploaded: {
  345 |     id: string;
  346 |     reference: string;
  347 |     sha256: string;
  348 |     size: number;
  349 |     name: string;
  350 |   }[] = [];
  351 |   for (let index = 0; index < 20; index++) {
  352 |     await openManual(page);
  353 |     const photo = await makePhoto(page, index);
  354 |     await page
  355 |       .getByLabel("Upload a PDF or photo", { exact: true })
  356 |       .setInputFiles({
  357 |         name: photo.name,
  358 |         mimeType: "image/jpeg",
  359 |         buffer: photo.buffer,
  360 |       });
  361 |     await expect
  362 |       .poll(async () => (await saved(page))?.invoice.file_data)
  363 |       .toMatch(new RegExp(`^idb-file:v1:.*:${photo.sha256}$`));
  364 |     const invoice = (await saved(page)).invoice;
  365 |     uploaded.push({
  366 |       id: invoice.id,
  367 |       reference: invoice.file_data!,
  368 |       sha256: photo.sha256,
  369 |       size: photo.size,
  370 |       name: photo.name,
  371 |     });
  372 |     const image = page.getByRole("img", {
  373 |       name: "Original invoice image",
  374 |       exact: true,
  375 |     });
  376 |     await expect(image).toBeVisible();
  377 |     await expect
  378 |       .poll(() =>
  379 |         image.evaluate((element: HTMLImageElement) => element.naturalWidth),
  380 |       )
  381 |       .toBe(2000);
  382 |     await expect(page.getByText(storageFailure)).toHaveCount(0);
  383 |   }
  384 |   expect(new Set(uploaded.map((file) => file.sha256)).size).toBe(20);
  385 |   expect(new Set(uploaded.map((file) => file.reference)).size).toBe(20);
  386 |   const before = await retainedFiles(
  387 |     page,
  388 |     uploaded.map((file) => file.reference),
  389 |   );
  390 |   expect(before).toHaveLength(20);
  391 |   for (const [index, file] of before.entries()) {
  392 |     expect(file.size).toBe(uploaded[index].size);
  393 |     expect(file.hash).toBe(uploaded[index].sha256);
  394 |     expect(file.recorded_hash).toBe(file.hash);
  395 |     expect(
  396 |       Math.max(file.preview_width, file.preview_height),
  397 |     ).toBeLessThanOrEqual(2000);
  398 |     expect(file.preview_size).toBeLessThan(file.size);
  399 |   }
  400 |   const bytesBefore = await textBytes(page);
  401 |   if (bytesBefore >= 5 * 1024 * 1024) {
  402 |     const profile = await page.evaluate(
  403 |       (state) => {
  404 |         const fields = Object.entries(state)
  405 |           .map(([key, value]) => ({
  406 |             key,
  407 |             bytes: JSON.stringify(value).length * 2,
  408 |           }))
  409 |           .sort((a, b) => b.bytes - a.bytes);
  410 |         const keys = Array.from({ length: localStorage.length }, (_, index) =>
  411 |           localStorage.key(index)!,
  412 |         ).map((key) => ({
  413 |           key,
  414 |           bytes: (key.length + localStorage.getItem(key)!.length) * 2,
  415 |         }));
  416 |         const actions: Record<string, number> = {};
  417 |         for (const entry of state.activity)
  418 |           actions[entry.action] =
  419 |             (actions[entry.action] ?? 0) + JSON.stringify(entry).length * 2;
  420 |         return {
  421 |           keys,
  422 |           fields,
  423 |           activity_count: state.activity.length,
  424 |           action_bytes: actions,
  425 |         };
  426 |       },
  427 |       await saved(page),
  428 |     );
  429 |     await testInfo.attach("Text storage size profile", {
```