# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: b-polish.spec.ts >> Part 1 pills and dashboard branch values stay on one line
- Location: tests/b-polish.spec.ts:260:1

# Error details

```
Error: expect(received).toBeGreaterThan(expected)

Expected: > 0
Received:   0
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=e5]:
    - banner [ref=e6]:
      - button "Open menu" [ref=e7] [cursor=pointer]
      - combobox "Location" [ref=e11] [cursor=pointer]:
        - generic [ref=e16]: North York
      - button "Notifications, 5 unread" [ref=e19] [cursor=pointer]:
        - generic [ref=e20]: "5"
      - button "User menu" [ref=e25] [cursor=pointer]:
        - generic [aria-hidden] [ref=e27]: DM
      - button "More" [ref=e28] [cursor=pointer]
    - main [ref=e34]:
      - generic [ref=e35]:
        - generic [ref=e36]:
          - heading "Manager dashboard" [level=1] [ref=e37]
          - paragraph [ref=e38]: Your branch priorities, approvals, and recent activity.
        - button "Review approvals" [ref=e40] [cursor=pointer]
      - generic [ref=e41]:
        - generic [ref=e42]:
          - generic [ref=e43]:
            - 'button "Approvals waiting: 3" [ref=e44] [cursor=pointer]':
              - generic [ref=e45]: Approvals waiting
              - strong [ref=e51]: "3"
              - generic "1 price change · 1 new product" [ref=e52]
            - 'button "Open alerts: 3" [ref=e55] [cursor=pointer]':
              - generic [ref=e56]: Open alerts
              - strong [ref=e61]: "3"
              - generic "0 lower prices · 1 conflict" [ref=e62]
            - 'button "Open shorts: 0" [ref=e65] [cursor=pointer]':
              - generic [ref=e66]: Open shorts
              - strong [ref=e72]: "0"
              - generic "Items waiting for delivery" [ref=e73]
            - 'button "Expiring soon: 2" [ref=e76] [cursor=pointer]':
              - generic [ref=e77]: Expiring soon
              - strong [ref=e83]: "2"
              - generic "Within each product's reminder window" [ref=e84]
          - generic [ref=e87]:
            - generic [ref=e88]:
              - heading "Approvals queue" [level=2] [ref=e89]
              - generic [ref=e90]:
                - generic [ref=e91]:
                  - generic [ref=e92]:
                    - heading "Sunflower Oil 1.8 L روغن آفتابگردان ۱٫۸ لیتری" [level=3] [ref=e93]:
                      - generic [ref=e94]:
                        - strong [ref=e95]:
                          - generic [ref=e96]:
                            - text: Sunflower Oil
                            - generic [ref=e97]: 1.8 L
                        - generic [ref=e99]:
                          - text: روغن آفتابگردان
                          - generic [ref=e100]: ۱٫۸ لیتری
                    - generic [ref=e101]: Sale request
                  - generic [ref=e102]:
                    - strong [ref=e103]: $7.99
                    - generic [ref=e104]: North York
                    - generic [ref=e105]: 2026-10-15 – 2026-10-28
                  - paragraph [ref=e106]: "Requested by: Demo North York Floor Worker · Why? slow seller"
                  - paragraph [ref=e107]:
                    - text: Margin at this price
                    - generic [ref=e108]: 24%
                  - generic [ref=e109]:
                    - paragraph [ref=e110]: This price is below the minimum margin.
                    - checkbox "Use this price anyway" [ref=e111] [cursor=pointer]
                  - generic [ref=e114]:
                    - button "Approve" [ref=e115] [cursor=pointer]
                    - button "Change and approve" [ref=e116] [cursor=pointer]
                    - button "Reject" [ref=e117] [cursor=pointer]
                - generic [ref=e118]:
                  - generic [ref=e119]:
                    - generic [ref=e120]:
                      - strong [ref=e121]:
                        - generic [ref=e122]:
                          - text: Lavash Bread
                          - generic [ref=e123]: 500 g
                      - generic [ref=e125]:
                        - text: نان لواش
                        - generic [ref=e126]: ۵۰۰ گرمی
                    - generic [ref=e127]: "0006"
                  - generic [ref=e128]: Price change
                  - generic [ref=e129]:
                    - generic [ref=e130]:
                      - text: Old
                      - generic [ref=e131]: $1.99
                    - generic [ref=e132]:
                      - text: New
                      - generic [ref=e133]: $2.99
                  - generic [ref=e134]: North York
                  - generic [ref=e135]:
                    - button "Approve" [ref=e136] [cursor=pointer]
                    - button "More" [ref=e137] [cursor=pointer]
                - generic [ref=e143]:
                  - generic [ref=e144]:
                    - generic [ref=e145]:
                      - strong [ref=e146]:
                        - generic [ref=e147]:
                          - text: Dried Barberries
                          - generic [ref=e148]: 100 g
                      - generic [ref=e150]:
                        - text: زرشک خشک
                        - generic [ref=e151]: ۱۰۰ گرمی
                    - generic [ref=e152]: "0015"
                  - generic [ref=e153]: New product
                  - generic [ref=e154]:
                    - generic [ref=e155]:
                      - text: Old
                      - generic [ref=e156]: —
                    - generic [ref=e157]:
                      - text: New
                      - generic [ref=e158]: $5.49
                  - generic [ref=e159]: North York
                  - generic [ref=e160]:
                    - button "Approve" [ref=e161] [cursor=pointer]
                    - button "More" [ref=e162] [cursor=pointer]
            - generic [ref=e168]:
              - heading "Alerts" [level=2] [ref=e169]
              - generic [ref=e170]:
                - generic [ref=e171]:
                  - generic [ref=e172]:
                    - strong [ref=e173]:
                      - generic [ref=e175]:
                        - text: Black Tea
                        - generic [ref=e176]: 450 g
                    - generic [ref=e177]: All branches
                  - generic [ref=e178]: Conflict
                  - button "Review" [ref=e181] [cursor=pointer]
                - generic [ref=e184]:
                  - generic [ref=e185]:
                    - strong [ref=e186]:
                      - generic [ref=e188]:
                        - text: Lavash Bread
                        - generic [ref=e189]: 500 g
                    - generic [ref=e190]: North York
                  - generic [ref=e191]: Date tracking
                  - button "Review" [ref=e194] [cursor=pointer]
                - generic [ref=e197]:
                  - generic [ref=e198]:
                    - strong [ref=e199]:
                      - generic [ref=e201]:
                        - text: Sour Cherry Juice
                        - generic [ref=e202]: 1 L
                    - generic [ref=e203]: North York
                  - generic [ref=e204]: Date tracking
                  - button "Review" [ref=e207] [cursor=pointer]
          - generic [ref=e210]:
            - generic [ref=e211]:
              - heading "Recent invoices" [level=2] [ref=e212]
              - table [ref=e214]:
                - rowgroup [ref=e215]:
                  - row [ref=e216]:
                    - cell "Fresh Valley Foods" [ref=e217]
                    - cell "Posted" [ref=e218]
                    - cell [ref=e220]:
                      - link "View" [ref=e221] [cursor=pointer]:
                        - /url: "#invoices?id=a2-fixture%3AFV-20390"
                    - cell "FV-20390 North York 2026-10-14" [ref=e224]:
                      - generic [ref=e225]: FV-20390
                      - generic [ref=e227]: North York
                      - generic [ref=e228]: 2026-10-14
                  - row [ref=e230]:
                    - cell "Golden Grain Distributors" [ref=e231]
                    - cell "Posted" [ref=e232]
                    - cell [ref=e234]:
                      - link "View" [ref=e235] [cursor=pointer]:
                        - /url: "#invoices?id=a2-fixture%3AGG-11879"
                    - cell "GG-11879 North York 2026-10-10" [ref=e238]:
                      - generic [ref=e239]: GG-11879
                      - generic [ref=e241]: North York
                      - generic [ref=e242]: 2026-10-10
                  - row [ref=e244]:
                    - cell "Sunrise Beverages" [ref=e245]
                    - cell "Posted" [ref=e246]
                    - cell [ref=e248]:
                      - link "View" [ref=e249] [cursor=pointer]:
                        - /url: "#invoices?id=a2-fixture%3ASB-7862"
                    - cell "SB-7862 North York 2026-10-06" [ref=e252]:
                      - generic [ref=e253]: SB-7862
                      - generic [ref=e255]: North York
                      - generic [ref=e256]: 2026-10-06
                  - row [ref=e258]:
                    - cell "Sunrise Beverages" [ref=e259]
                    - cell "Posted" [ref=e260]
                    - cell [ref=e262]:
                      - link "View" [ref=e263] [cursor=pointer]:
                        - /url: "#invoices?id=a2-fixture%3ASB-7848"
                    - cell "SB-7848 North York 2026-10-05" [ref=e266]:
                      - generic [ref=e267]: SB-7848
                      - generic [ref=e269]: North York
                      - generic [ref=e270]: 2026-10-05
                  - row [ref=e272]:
                    - cell "HomeWare Imports" [ref=e273]
                    - cell "Posted" [ref=e274]
                    - cell [ref=e276]:
                      - link "View" [ref=e277] [cursor=pointer]:
                        - /url: "#invoices?id=a2-fixture%3AHW-4910"
                    - cell "HW-4910 Newmarket 2026-09-28" [ref=e280]:
                      - generic [ref=e281]: HW-4910
                      - generic [ref=e283]: Newmarket
                      - generic [ref=e284]: 2026-09-28
            - generic [ref=e286]:
              - generic [ref=e287]:
                - heading "Returns" [level=2] [ref=e288]
                - button "View all returns" [ref=e289] [cursor=pointer]
              - generic [ref=e292]:
                - generic [ref=e293] [cursor=pointer]:
                  - generic [ref=e294]:
                    - strong [ref=e295]: Fresh Valley Foods
                    - generic [ref=e296]:
                      - text: North York ·
                      - generic [ref=e299]:
                        - text: Sour Cherry Juice
                        - generic [ref=e300]: 1 L
                  - generic [ref=e301]: Open
                  - link "View" [ref=e304]:
                    - /url: "#return?id=demo-return-1"
                - generic [ref=e307] [cursor=pointer]:
                  - generic [ref=e308]:
                    - strong [ref=e309]: Golden Grain Distributors
                    - generic [ref=e310]:
                      - text: North York ·
                      - generic [ref=e313]:
                        - text: Basmati Rice
                        - generic [ref=e314]: 4.5 kg
                  - generic [ref=e315]: Partially resolved
                  - link "View" [ref=e318]:
                    - /url: "#return?id=demo-return-2"
          - generic [ref=e321]:
            - heading "Supplier balances" [level=2] [ref=e322]
            - table [ref=e324]:
              - rowgroup [ref=e325]:
                - row [ref=e326] [cursor=pointer]:
                  - cell "HomeWare Imports" [ref=e327]
                  - cell "Balance $1,260.00" [ref=e329]:
                    - text: Balance
                    - generic [ref=e330]: $1,260.00
                  - cell "Open invoices 1" [ref=e331]:
                    - text: Open invoices
                    - generic [ref=e332]: "1"
                  - cell [ref=e333]:
                    - text: Action
                    - generic [ref=e334]:
                      - link "View" [ref=e335]:
                        - /url: "#payables"
                      - button "Show details" [ref=e338]
                - row [ref=e341] [cursor=pointer]:
                  - cell "Golden Grain Distributors" [ref=e342]
                  - cell "Balance $842.10" [ref=e344]:
                    - text: Balance
                    - generic [ref=e345]: $842.10
                  - cell "Open invoices 2" [ref=e346]:
                    - text: Open invoices
                    - generic [ref=e347]: "2"
                  - cell [ref=e348]:
                    - text: Action
                    - generic [ref=e349]:
                      - link "View" [ref=e350]:
                        - /url: "#payables"
                      - button "Show details" [ref=e353]
                - row [ref=e356] [cursor=pointer]:
                  - cell "Fresh Valley Foods" [ref=e357]
                  - cell "Balance $169.79" [ref=e359]:
                    - text: Balance
                    - generic [ref=e360]: $169.79
                  - cell "Open invoices 1" [ref=e361]:
                    - text: Open invoices
                    - generic [ref=e362]: "1"
                  - cell [ref=e363]:
                    - text: Action
                    - generic [ref=e364]:
                      - link "View" [ref=e365]:
                        - /url: "#payables"
                      - button "Show details" [ref=e368]
                - row [ref=e371] [cursor=pointer]:
                  - cell "Sunrise Beverages" [ref=e372]
                  - cell "Balance $96.40" [ref=e374]:
                    - text: Balance
                    - generic [ref=e375]: $96.40
                  - cell "Open invoices 1" [ref=e376]:
                    - text: Open invoices
                    - generic [ref=e377]: "1"
                  - cell [ref=e378]:
                    - text: Action
                    - generic [ref=e379]:
                      - link "View" [ref=e380]:
                        - /url: "#payables"
                      - button "Show details" [ref=e383]
                - row [ref=e386] [cursor=pointer]:
                  - cell "Corner Spice Co." [ref=e387]
                  - cell "Balance $0.00" [ref=e389]:
                    - text: Balance
                    - generic [ref=e390]: $0.00
                  - cell "Open invoices 0" [ref=e391]:
                    - text: Open invoices
                    - generic [ref=e392]: "0"
                  - cell [ref=e393]:
                    - text: Action
                    - generic [ref=e394]:
                      - link "View" [ref=e395]:
                        - /url: "#payables"
                      - button "Show details" [ref=e398]
          - generic [ref=e401]:
            - generic [ref=e402]:
              - heading "Purchases by supplier, this month" [level=2] [ref=e403]
              - list [ref=e404]:
                - listitem [ref=e405]:
                  - generic [ref=e406]:
                    - generic [ref=e407]: Golden Grain Distributors
                    - generic [ref=e408]: $636.00
                - listitem [ref=e411]:
                  - generic [ref=e412]:
                    - generic [ref=e413]: Fresh Valley Foods
                    - generic [ref=e414]: $181.22
                - listitem [ref=e417]:
                  - generic [ref=e418]:
                    - generic [ref=e419]: Sunrise Beverages
                    - generic [ref=e420]: $133.59
              - paragraph [ref=e423]: Net purchases · CAD
            - generic [ref=e424]:
              - heading "Purchases, last 8 weeks" [level=2] [ref=e425]
              - img "Net purchases by week" [ref=e427]:
                - 'generic "2026-08-21 – 2026-08-27: $25.20" [ref=e430]'
                - 'generic "2026-08-28 – 2026-09-03: $0.00" [ref=e431]'
                - 'generic "2026-09-04 – 2026-09-10: $368.00" [ref=e432]'
                - 'generic "2026-09-11 – 2026-09-17: $0.00" [ref=e433]'
                - 'generic "2026-09-18 – 2026-09-24: $1,332.78" [ref=e434]'
                - 'generic "2026-09-25 – 2026-10-01: $0.00" [ref=e435]'
                - 'generic "2026-10-02 – 2026-10-08: $133.59" [ref=e436]'
                - 'generic "2026-10-09 – 2026-10-15: $817.22" [ref=e437]'
              - generic [ref=e438]:
                - generic [ref=e439]: 2026-08-21
                - generic [ref=e440]: 2026-09-04
                - generic [ref=e441]: 2026-09-18
                - generic [ref=e442]: 2026-10-09
              - paragraph [ref=e443]: Net purchases · CAD
          - generic [ref=e444]:
            - generic [ref=e445]:
              - heading "Arrived this week" [level=2] [ref=e446]
              - generic [ref=e447] [cursor=pointer]:
                - generic [ref=e448]:
                  - strong [ref=e449]:
                    - generic [ref=e450]:
                      - strong [ref=e451]:
                        - generic [ref=e452]:
                          - text: Canned Fava Beans
                          - generic [ref=e453]: 400 g
                      - generic [ref=e455]:
                        - text: باقالا کنسرو شده
                        - generic [ref=e456]: ۴۰۰ گرمی
                  - generic [ref=e457]:
                    - text: North York · 2026-10-14 ·
                    - generic [ref=e458]: FV-20390
                - generic [ref=e459]: 24 units
                - link "View" [ref=e462]:
                  - /url: "#received?product=0002"
              - generic [ref=e465] [cursor=pointer]:
                - generic [ref=e466]:
                  - strong [ref=e467]:
                    - generic [ref=e468]:
                      - strong [ref=e469]:
                        - generic [ref=e470]:
                          - text: Ground Sumac
                          - generic [ref=e471]: 100 g
                      - generic [ref=e473]:
                        - text: سماق
                        - generic [ref=e474]: ۱۰۰ گرمی
                  - generic [ref=e475]:
                    - text: North York · 2026-10-14 ·
                    - generic [ref=e476]: FV-20390
                - generic [ref=e477]: 12 units
                - link "View" [ref=e480]:
                  - /url: "#received?product=0005"
              - generic [ref=e483] [cursor=pointer]:
                - generic [ref=e484]:
                  - strong [ref=e485]:
                    - generic [ref=e486]:
                      - strong [ref=e487]:
                        - generic [ref=e488]:
                          - text: Lavash Bread
                          - generic [ref=e489]: 500 g
                      - generic [ref=e491]:
                        - text: نان لواش
                        - generic [ref=e492]: ۵۰۰ گرمی
                  - generic [ref=e493]:
                    - text: North York · 2026-10-14 ·
                    - generic [ref=e494]: FV-20390
                - generic [ref=e495]: 20 units
                - link "View" [ref=e498]:
                  - /url: "#received?product=0006"
              - generic [ref=e501] [cursor=pointer]:
                - generic [ref=e502]:
                  - strong [ref=e503]:
                    - generic [ref=e504]:
                      - strong [ref=e505]:
                        - generic [ref=e506]:
                          - text: Sour Cherry Juice
                          - generic [ref=e507]: 1 L
                      - generic [ref=e509]:
                        - text: آب آلبالو
                        - generic [ref=e510]: ۱ لیتری
                  - generic [ref=e511]:
                    - text: North York · 2026-10-14 ·
                    - generic [ref=e512]: FV-20390
                - generic [ref=e513]: 36 units
                - link "View" [ref=e516]:
                  - /url: "#received?product=0003"
              - generic [ref=e519] [cursor=pointer]:
                - generic [ref=e520]:
                  - strong [ref=e521]:
                    - generic [ref=e522]:
                      - strong [ref=e523]:
                        - generic [ref=e524]:
                          - text: Dried Barberries
                          - generic [ref=e525]: 100 g
                      - generic [ref=e527]:
                        - text: زرشک خشک
                        - generic [ref=e528]: ۱۰۰ گرمی
                  - generic [ref=e529]:
                    - text: North York · 2026-10-14 ·
                    - generic [ref=e530]: FV-20390
                - generic [ref=e531]: 6 units
                - link "View" [ref=e534]:
                  - /url: "#received?product=0015"
              - generic [ref=e537] [cursor=pointer]:
                - generic [ref=e538]:
                  - strong [ref=e539]:
                    - generic [ref=e540]:
                      - strong [ref=e541]:
                        - generic [ref=e542]:
                          - text: Potato Chips
                          - generic [ref=e543]: 150 g
                      - generic [ref=e545]:
                        - text: چیپس سیب‌زمینی
                        - generic [ref=e546]: ۱۵۰ گرمی
                  - generic [ref=e547]:
                    - text: North York · 2026-10-14 ·
                    - generic [ref=e548]: FV-20390
                - generic [ref=e549]: 12 units
                - link "View" [ref=e552]:
                  - /url: "#received?product=0009"
            - generic [ref=e555]:
              - heading "Price changes this week" [level=2] [ref=e556]
              - generic [ref=e557] [cursor=pointer]:
                - generic [ref=e558]:
                  - strong [ref=e559]:
                    - generic [ref=e561]:
                      - text: Black Tea
                      - generic [ref=e562]: 450 g
                  - generic [ref=e563]: Demo Supervisor · North York · 2026-10-14 · $6.49
                - generic [ref=e564]: Approved
                - link "View" [ref=e567]:
                  - /url: "#product?code=0004"
              - generic [ref=e570] [cursor=pointer]:
                - generic [ref=e571]:
                  - strong [ref=e572]:
                    - generic [ref=e574]:
                      - text: Dried Red Kidney Beans
                      - generic [ref=e575]: 900 g
                  - generic [ref=e576]: Demo Supervisor · North York · 2026-10-13 · $3.99
                - generic [ref=e577]: Approved
                - link "View" [ref=e580]:
                  - /url: "#product?code=0007"
        - complementary "Notes and activity" [ref=e583]:
          - generic [ref=e584]:
            - generic [ref=e585]:
              - heading "Price updates to apply" [level=2] [ref=e586]
              - button "View all 0" [ref=e587] [cursor=pointer]:
                - text: View all
                - generic [ref=e588]: "0"
            - paragraph [ref=e594]: No pending price updates.
          - generic [ref=e595]:
            - heading "Notes for Manager" [level=2] [ref=e596]
            - generic [ref=e598] [cursor=pointer]:
              - generic [ref=e599]:
                - strong [ref=e600]: Customer asked about the tea glass set price; please confirm.
                - generic [ref=e601]:
                  - text: Demo Floor Worker · North York ·
                  - time [ref=e602]: Just now
              - generic [ref=e603]: Open
              - link "View" [ref=e606]:
                - /url: "#notes"
          - generic [ref=e609]:
            - heading "Activity" [level=2] [ref=e610]
            - list [ref=e611]:
              - listitem [ref=e612]:
                - generic [aria-hidden] [ref=e613]: S
                - generic [ref=e614]:
                  - strong [ref=e615]: Start sale
                  - generic [ref=e616]: Stainless Steel Pot 24 cm
                  - generic [ref=e618]: System · North York
                  - time [ref=e619]: Just now
              - listitem [ref=e620]:
                - generic [aria-hidden] [ref=e621]: DS
                - generic [ref=e622]:
                  - strong [ref=e623]: Approve price
                  - generic [ref=e626]:
                    - text: Black Tea
                    - generic [ref=e627]: 450 g
                  - generic [ref=e628]: Demo Supervisor · North York
                  - time [ref=e629]: 1 d ago
              - listitem [ref=e630]:
                - generic [aria-hidden] [ref=e631]: DS
                - generic [ref=e632]:
                  - strong [ref=e633]: Approve price
                  - generic [ref=e636]:
                    - text: Dried Red Kidney Beans
                    - generic [ref=e637]: 900 g
                  - generic [ref=e638]: Demo Supervisor · North York
                  - time [ref=e639]: 2 d ago
```

# Test source

```ts
  204 |             const cellBounds = cell.getBoundingClientRect();
  205 |             const headerStyle = getComputedStyle(header);
  206 |             const cellStyle = getComputedStyle(cell);
  207 |             return {
  208 |               leftDifference: Math.abs(bounds.left - cellBounds.left),
  209 |               rightDifference: Math.abs(bounds.right - cellBounds.right),
  210 |               paddingDifference: Math.max(
  211 |                 Math.abs(
  212 |                   parseFloat(headerStyle.paddingInlineStart) -
  213 |                     parseFloat(cellStyle.paddingInlineStart),
  214 |                 ),
  215 |                 Math.abs(
  216 |                   parseFloat(headerStyle.paddingInlineEnd) -
  217 |                     parseFloat(cellStyle.paddingInlineEnd),
  218 |                 ),
  219 |               ),
  220 |             };
  221 |           }),
  222 |         };
  223 |       });
  224 |     expect(spacing.toolbarInsideCard).toBe(true);
  225 |     expect(spacing.gap).toBeGreaterThanOrEqual(0);
  226 |     expect(spacing.gap).toBeLessThanOrEqual(isMobile ? 16 : 24);
  227 |     expect(spacing.toolbarTopInset).toBeGreaterThanOrEqual(
  228 |       spacing.cardPadding - 1,
  229 |     );
  230 |     for (const [index, inset] of spacing.horizontalInsets.entries())
  231 |       expect(inset).toBeCloseTo(spacing.cardHorizontalPadding[index % 2], 0);
  232 |     expect(spacing.tableBottomInset).toBeGreaterThanOrEqual(0);
  233 |     for (const [index, inset] of spacing.firstCellTextInsets.entries())
  234 |       expect(inset).toBeGreaterThanOrEqual(spacing.firstCellPadding[index] - 1);
  235 |     expect(spacing.columnCount).toBeGreaterThan(0);
  236 |     if (!isMobile) {
  237 |       expect(spacing.columns).toHaveLength(spacing.columnCount);
  238 |       for (const column of spacing.columns) {
  239 |         expect(column.leftDifference).toBeLessThanOrEqual(1);
  240 |         expect(column.rightDifference).toBeLessThanOrEqual(1);
  241 |         expect(column.paddingDifference).toBeLessThanOrEqual(1);
  242 |       }
  243 |     }
  244 |     const { toolbarGroups } = await inspect(page, "Products", language);
  245 |     expect(toolbarGroups).toHaveLength(1);
  246 |     for (const group of toolbarGroups) {
  247 |       expect(
  248 |         group.gap,
  249 |         `${language}: count beside Columns`,
  250 |       ).toBeGreaterThanOrEqual(-0.5);
  251 |       expect(
  252 |         group.gap,
  253 |         `${language}: count beside Columns`,
  254 |       ).toBeLessThanOrEqual(16.5);
  255 |       expect(group.centerDifference).toBeLessThanOrEqual(1);
  256 |     }
  257 |   });
  258 | }
  259 | 
  260 | test("Part 1 pills and dashboard branch values stay on one line", async ({
  261 |   page,
  262 | }) => {
  263 |   await signIn(page, "Supervisor");
  264 |   for (const route of ["expiry", "dashboard"]) {
  265 |     await page.goto(`/#${route}`);
  266 |     await expect(page.locator("main h1")).toBeVisible();
  267 |     await settled(page);
  268 |     const pills = await page.locator("main .ui-badge").evaluateAll((elements) =>
  269 |       elements.map((element) => ({
  270 |         text: element.textContent,
  271 |         whiteSpace: getComputedStyle(element).whiteSpace,
  272 |       })),
  273 |     );
  274 |     for (const pill of pills)
  275 |       expect(pill.whiteSpace, pill.text ?? "pill").toBe("nowrap");
  276 |   }
  277 |   const invoices = page.locator(".dashboard-invoices");
  278 |   await expect(invoices.locator("tbody tr").first()).toBeVisible();
  279 |   // Responsive tables expose width-hidden Branch values in expanded details.
  280 |   for (const toggle of await invoices.locator(".table-details-toggle").all())
  281 |     await toggle.click();
  282 |   const branchCells = await page
  283 |     .locator(".dashboard-invoices")
  284 |     .evaluate((card) => {
  285 |       const values = [
  286 |         ...card.querySelectorAll('tbody td[data-column-key="branch"]'),
  287 |         ...[...card.querySelectorAll(".table-expanded-row dl > div")]
  288 |           .filter(
  289 |             (group) => group.querySelector("dt")?.textContent === "Branch",
  290 |           )
  291 |           .map((group) => group.querySelector("dd")!),
  292 |       ];
  293 |       return values.map((cell) => {
  294 |         const range = document.createRange();
  295 |         range.selectNodeContents(cell);
  296 |         return {
  297 |           text: cell.textContent,
  298 |           lineCount: new Set(
  299 |             [...range.getClientRects()].map((rect) => Math.round(rect.top)),
  300 |           ).size,
  301 |         };
  302 |       });
  303 |     });
> 304 |   expect(branchCells.length).toBeGreaterThan(0);
      |                              ^ Error: expect(received).toBeGreaterThan(expected)
  305 |   for (const cell of branchCells) {
  306 |     expect(configuration.branches.map((branch) => branch.name)).toContain(
  307 |       cell.text?.trim(),
  308 |     );
  309 |     expect(cell.lineCount, cell.text ?? "branch").toBeLessThanOrEqual(1);
  310 |   }
  311 | });
  312 | 
  313 | test("Part 1 invoice names and approved-price notes fit on one line", async ({
  314 |   page,
  315 | }) => {
  316 |   await signIn(page, "Floor Worker");
  317 |   await page.goto("/#invoices");
  318 |   await uploadInvoice(page);
  319 |   await expect(page.locator(".invoice-line")).toHaveCount(6);
  320 |   await expect(
  321 |     page.locator(".invoice-line-toggle .product-name strong"),
  322 |   ).toHaveCount(6);
  323 |   const names = await page
  324 |     .locator(".invoice-line-toggle .product-name strong")
  325 |     .evaluateAll((elements) =>
  326 |       elements.map((element) => {
  327 |         const range = document.createRange();
  328 |         range.selectNodeContents(element);
  329 |         const rects = [...range.getClientRects()];
  330 |         return {
  331 |           text: element.textContent,
  332 |           lines: new Set(rects.map((rect) => Math.round(rect.top))).size,
  333 |         };
  334 |       }),
  335 |     );
  336 |   expect(names.length).toBeGreaterThan(0);
  337 |   for (const name of names)
  338 |     expect(name.lines, name.text ?? "product name").toBe(1);
  339 |   await page.locator(".invoice-line-toggle").first().click();
  340 |   const note = page
  341 |     .locator(".invoice-line-price .muted")
  342 |     .filter({ hasText: /^Approved:/ })
  343 |     .first();
  344 |   await expect(note).toBeVisible();
  345 |   await expect(note).toContainText("$");
  346 |   const lines = await note.evaluate((element) => {
  347 |     const range = document.createRange();
  348 |     range.selectNodeContents(element);
  349 |     return new Set(
  350 |       [...range.getClientRects()].map((rect) => Math.round(rect.top)),
  351 |     ).size;
  352 |   });
  353 |   expect(lines).toBe(1);
  354 | });
  355 | 
  356 | test("Part 1 purchase charts show week dates and hover/focus amounts with equal-height desktop cards", async ({
  357 |   page,
  358 | }, testInfo) => {
  359 |   await signIn(page, "Supervisor");
  360 |   await page.goto("/#dashboard");
  361 |   const chart = page.locator(".dashboard-purchases").filter({
  362 |     has: page.getByRole("heading", {
  363 |       name: "Purchases, last 8 weeks",
  364 |       exact: true,
  365 |     }),
  366 |   });
  367 |   await expect(chart.locator(".purchase-week-totals")).toHaveCount(0);
  368 |   await expect(chart.locator(".purchase-week-labels")).toContainText(
  369 |     /\d{4}-\d{2}-\d{2}/,
  370 |   );
  371 |   const point = chart.locator(".purchase-point").last();
  372 |   await point.focus();
  373 |   await expect(chart.getByRole("tooltip")).toContainText("$");
  374 |   await expect(chart.getByRole("tooltip")).toContainText(/\d{4}-\d{2}-\d{2}/);
  375 |   await page
  376 |     .getByRole("heading", {
  377 |       name: `${configuredRoleLabel(readConfiguredRoleDefinitions(configuration.roles), "manager", "en")} dashboard`,
  378 |       exact: true,
  379 |     })
  380 |     .click();
  381 |   await expect(chart.getByRole("tooltip")).toHaveCount(0);
  382 |   await point.hover();
  383 |   await expect(chart.getByRole("tooltip")).toBeVisible();
  384 |   if (testInfo.project.name === "desktop") {
  385 |     const heights = await page
  386 |       .locator(".dashboard-purchases")
  387 |       .evaluateAll((cards) =>
  388 |         cards.map((card) => card.getBoundingClientRect().height),
  389 |       );
  390 |     expect(heights).toHaveLength(2);
  391 |     expect(Math.abs(heights[0] - heights[1])).toBeLessThanOrEqual(2);
  392 |   }
  393 | });
  394 | 
  395 | test("Part 1 Open return exposes pickup and cancellation, then resolution after pickup, with the normal title size", async ({
  396 |   page,
  397 | }) => {
  398 |   await signIn(page, "Floor Worker");
  399 |   await page.goto("/#return?id=demo-return-1");
  400 |   const detail = page.locator(".return-detail");
  401 |   await expect(detail).toBeVisible();
  402 |   await expect(
  403 |     detail.getByRole("button", { name: "Record pickup", exact: true }),
  404 |   ).toHaveCount(1);
```