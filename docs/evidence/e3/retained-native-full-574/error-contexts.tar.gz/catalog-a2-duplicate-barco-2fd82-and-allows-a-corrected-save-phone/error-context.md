# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: catalog-a2.spec.ts >> duplicate barcode reports one scoped conflict and allows a corrected save
- Location: tests/catalog-a2.spec.ts:242:1

# Error details

```
Test timeout of 60000ms exceeded.
```

```
Error: locator.click: Test timeout of 60000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: 'Edit Potato Chips 150 g', exact: true })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=e5]:
    - banner [ref=e6]:
      - button "Open menu" [ref=e7] [cursor=pointer]
      - combobox "Location" [ref=e11] [cursor=pointer]:
        - generic [ref=e16]: North York
      - button "Notifications, 5 unread" [ref=e19] [cursor=pointer]:
        - generic [ref=e20]: "5"
      - button "User menu" [ref=e25] [cursor=pointer]:
        - generic [aria-hidden] [ref=e27]: DM
      - button "More" [ref=e28] [cursor=pointer]
    - main [ref=e34]:
      - generic [ref=e35]:
        - generic [ref=e36]:
          - generic [ref=e37]:
            - heading "Products" [level=1] [ref=e38]
            - paragraph [ref=e39]: Approved prices, pending changes and branch details in one catalog.
          - button "Add product" [ref=e41] [cursor=pointer]
        - generic [ref=e42]:
          - generic [ref=e43]:
            - searchbox "Search products" [active] [ref=e48]: "0009"
            - combobox "Pricing category" [ref=e49] [cursor=pointer]:
              - generic [ref=e50]: All pricing categories
            - combobox "AI category" [ref=e53] [cursor=pointer]:
              - generic [ref=e54]: All AI categories
            - combobox "Status" [ref=e57] [cursor=pointer]:
              - generic [ref=e58]: All statuses
            - combobox "Supplier" [ref=e61] [cursor=pointer]:
              - generic [ref=e62]: All suppliers
            - checkbox "Has pending price" [ref=e65] [cursor=pointer]
            - checkbox "Has offer" [ref=e68] [cursor=pointer]
            - checkbox "Manual prices" [ref=e71] [cursor=pointer]
            - checkbox "On sale" [ref=e74] [cursor=pointer]
            - button "Clear filters" [ref=e77] [cursor=pointer]
            - generic [ref=e79]:
              - generic [ref=e80]: 1 product
              - button "Columns" [ref=e81] [cursor=pointer]
          - generic [ref=e85]:
            - table [ref=e87]:
              - rowgroup [ref=e88]:
                - row [ref=e89]:
                  - cell "Potato Chips 150 g چیپس سیب‌زمینی ۱۵۰ گرمی 150 g" [ref=e90]:
                    - link "Potato Chips 150 g" [ref=e91] [cursor=pointer]:
                      - /url: "#product?code=0009"
                      - strong [ref=e92]:
                        - generic [ref=e94]:
                          - text: Potato Chips
                          - generic [ref=e95]: 150 g
                    - paragraph [ref=e96]:
                      - generic [ref=e98]:
                        - text: چیپس سیب‌زمینی
                        - generic [ref=e99]: ۱۵۰ گرمی
                    - paragraph [ref=e100]:
                      - generic [ref=e101]: 150 g
                  - cell "$2.99" [ref=e104]
                  - cell [ref=e107]:
                    - link "Open Potato Chips 150 g" [ref=e108] [cursor=pointer]:
                      - /url: "#product?code=0009"
                  - cell "0009 Approved 2 for $5.00" [ref=e111]:
                    - generic [ref=e112]: "0009"
                    - generic [ref=e115]:
                      - generic [ref=e116]: Approved
                      - generic [ref=e117]: 2 for $5.00
            - generic [ref=e119]:
              - button "Previous" [disabled] [ref=e120]
              - generic [ref=e121]: Page 1 of 1 · 1 product
              - button "Next" [disabled] [ref=e122]
```

# Test source

```ts
  160 |     await readCanonicalBusinessEvidence(page).then(
  161 |       (canonicalState) => JSON.parse(JSON.stringify(canonicalState)!).products,
  162 |     ),
  163 |   ).toEqual(before);
  164 |   await editor.getByLabel("Price", { exact: true }).fill("3.29");
  165 |   await editor
  166 |     .getByRole("button", { name: "Only North York", exact: true })
  167 |     .click();
  168 |   await editor
  169 |     .getByRole("button", { name: "Save new price", exact: true })
  170 |     .click();
  171 |   await expect(editor).not.toBeVisible();
  172 |   await expect(page.locator(".lookup-detail .price")).toHaveText("$3.29");
  173 |   await setBranch(page, "Branch 2");
  174 |   await expect(page.locator(".lookup-detail .price")).toHaveText("$2.99");
  175 | });
  176 | 
  177 | test("Floor Worker and Cashier never see product Edit, including direct product links", async ({
  178 |   page,
  179 | }) => {
  180 |   await signIn(page, "Floor Worker");
  181 |   await page.goto("/#products");
  182 |   await expect(page.getByRole("button", { name: /^Edit / })).toHaveCount(0);
  183 |   await page.goto("/#product?code=0009");
  184 |   await expect(
  185 |     page.getByRole("heading", { level: 1, name: "Potato Chips 150 g" }),
  186 |   ).toBeVisible();
  187 |   await expect(page.getByRole("button", { name: /^Edit / })).toHaveCount(0);
  188 |   await signIn(page, "Cashier");
  189 |   await page.goto("/#product?code=0009");
  190 |   await expect(
  191 |     page.getByRole("heading", { level: 1, name: "Cashier lookup" }),
  192 |   ).toBeVisible();
  193 |   await expect(page.getByRole("button", { name: /^Edit / })).toHaveCount(0);
  194 | });
  195 | 
  196 | test("Lookup columns mirror in Persian, with selected row distinct from offer pill", async ({
  197 |   page,
  198 | }) => {
  199 |   await signIn(page, "Cashier");
  200 |   await page
  201 |     .getByRole("main")
  202 |     .getByLabel("Search products", { exact: true })
  203 |     .fill("0009");
  204 |   const row = page.locator(".lookup-result-row.is-selected");
  205 |   let geometry = await row.evaluate((element) => {
  206 |     const name = element
  207 |       .querySelector(".lookup-result-name")!
  208 |       .getBoundingClientRect();
  209 |     const price = element
  210 |       .querySelector(".lookup-result-price")!
  211 |       .getBoundingClientRect();
  212 |     return { nameX: name.x, priceX: price.x, width: price.width };
  213 |   });
  214 |   expect(geometry.priceX).toBeGreaterThan(geometry.nameX);
  215 |   await setLanguage(page, "fa");
  216 |   geometry = await row.evaluate((element) => {
  217 |     const name = element
  218 |       .querySelector(".lookup-result-name")!
  219 |       .getBoundingClientRect();
  220 |     const price = element
  221 |       .querySelector(".lookup-result-price")!
  222 |       .getBoundingClientRect();
  223 |     return { nameX: name.x, priceX: price.x, width: price.width };
  224 |   });
  225 |   expect(geometry.nameX).toBeGreaterThan(geometry.priceX);
  226 |   const fills = await row.evaluate((element) => ({
  227 |     rowRadius: getComputedStyle(element).borderRadius,
  228 |     pillRadius: getComputedStyle(element.querySelector(".offer-pill")!)
  229 |       .borderRadius,
  230 |     pillHeight: element.querySelector(".offer-pill")!.getBoundingClientRect()
  231 |       .height,
  232 |     bar: getComputedStyle(element, "::before").width,
  233 |   }));
  234 |   expect(fills.rowRadius).not.toBe(fills.pillRadius);
  235 |   expect(parseFloat(fills.pillRadius)).toBeGreaterThanOrEqual(
  236 |     fills.pillHeight / 2,
  237 |   );
  238 |   await expect(row.locator(".offer-pill")).not.toBeEmpty();
  239 |   expect(fills.bar).toBe("3px");
  240 | });
  241 | 
  242 | test("duplicate barcode reports one scoped conflict and allows a corrected save", async ({
  243 |   page,
  244 | }) => {
  245 |   await signIn(page, "Supervisor");
  246 |   await setBranch(page, "Branch 1");
  247 |   await page.goto("/#products");
  248 |   await page
  249 |     .getByRole("main")
  250 |     .getByLabel("Search products", { exact: true })
  251 |     .fill("0009");
  252 |   const before = await readCanonicalBusinessEvidence(page).then(
  253 |     (canonicalState) => JSON.parse(JSON.stringify(canonicalState)!).products,
  254 |   );
  255 |   const owner = before.find(
  256 |     (product: { code: string }) => product.code === "0001",
  257 |   );
  258 |   await page
  259 |     .getByRole("button", { name: "Edit Potato Chips 150 g", exact: true })
> 260 |     .click();
      |      ^ Error: locator.click: Test timeout of 60000ms exceeded.
  261 |   const editor = page.getByRole("dialog", {
  262 |     name: "Edit product",
  263 |     exact: true,
  264 |   });
  265 |   await editor.getByLabel("English name", { exact: true }).fill("Edited chips");
  266 |   await editor.getByLabel("Barcode", { exact: true }).fill(owner.barcode);
  267 |   // Resolve tracking first so this failure proves the barcode business guard.
  268 |   await stopTrackingKeepDates(page, editor);
  269 |   for (let attempt = 0; attempt < 2; attempt++) {
  270 |     await editor
  271 |       .getByRole("button", { name: "Save product", exact: true })
  272 |       .click();
  273 |     await expect(
  274 |       editor.getByRole("alert", { name: "What's missing", exact: true }),
  275 |     ).toContainText("This barcode belongs to another product");
  276 |   }
  277 |   const blocked = await readCanonicalBusinessEvidence(page).then(
  278 |     (canonicalState) => JSON.parse(JSON.stringify(canonicalState)!),
  279 |   );
  280 |   expect(blocked.products).toEqual(before);
  281 |   expect(
  282 |     blocked.approvals.filter(
  283 |       (item: { type: string; product_code: string }) =>
  284 |         item.type === "barcode_conflict" && item.product_code === "0009",
  285 |     ),
  286 |   ).toHaveLength(1);
  287 |   expect(blocked.approvals.at(-1)).toMatchObject({
  288 |     branch: "Branch 1",
  289 |     barcode: owner.barcode,
  290 |     conflicting_product_code: owner.code,
  291 |     triggered_by: configuredPersonExpectation("manager").name_en,
  292 |   });
  293 |   await editor.getByLabel("Barcode", { exact: true }).fill("new-chips-barcode");
  294 |   await editor
  295 |     .getByRole("button", { name: "Save product", exact: true })
  296 |     .click();
  297 |   await expect(editor).not.toBeVisible();
  298 |   const saved = await readCanonicalBusinessEvidence(page).then(
  299 |     (canonicalState) => JSON.parse(JSON.stringify(canonicalState)!).products,
  300 |   );
  301 |   expect(
  302 |     saved.find((product: { code: string }) => product.code === "0009"),
  303 |   ).toMatchObject({
  304 |     name_en: "Edited chips",
  305 |     barcode: "new-chips-barcode",
  306 |   });
  307 |   expect(
  308 |     saved.find((product: { code: string }) => product.code === owner.code),
  309 |   ).toEqual(owner);
  310 | });
  311 | 
```