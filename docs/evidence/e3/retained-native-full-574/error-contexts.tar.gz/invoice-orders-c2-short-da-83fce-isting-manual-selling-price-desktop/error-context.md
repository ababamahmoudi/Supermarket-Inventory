# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: invoice-orders-c2.spec.ts >> short-dated expiry discount requires a real date and preserves an existing manual selling price
- Location: tests/invoice-orders-c2.spec.ts:250:1

# Error details

```
Test timeout of 60000ms exceeded.
```

```
Error: locator.click: Test timeout of 60000ms exceeded.
Call log:
  - waiting for locator('.invoice-line').first().getByRole('button', { name: 'Short-dated (expiry discount)', exact: true })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - complementary "Main menu" [ref=e5]:
    - generic [ref=e6]:
      - img "Super Arzon" [ref=e9]
      - generic [ref=e10]: Super Arzon
    - navigation "Pages" [ref=e11]:
      - generic [ref=e12]:
        - button "Daily" [expanded] [ref=e13] [cursor=pointer]
        - generic [ref=e17]:
          - link "Lookup" [ref=e18] [cursor=pointer]:
            - /url: "#lookup"
          - link "Invoices" [ref=e23] [cursor=pointer]:
            - /url: "#invoices"
          - link "Received" [ref=e28] [cursor=pointer]:
            - /url: "#received"
          - link "Returns" [ref=e35] [cursor=pointer]:
            - /url: "#returns"
          - link "Price updates" [ref=e40] [cursor=pointer]:
            - /url: "#price-updates"
            - generic [ref=e46]: "1"
          - link "Labels" [ref=e47] [cursor=pointer]:
            - /url: "#labels"
          - link "Date tracking" [ref=e52] [cursor=pointer]:
            - /url: "#expiry"
          - link "Notes" [ref=e57] [cursor=pointer]:
            - /url: "#notes"
            - generic [ref=e61]: "2"
          - link "Branch requests" [ref=e62] [cursor=pointer]:
            - /url: "#requests"
      - button "Catalog" [ref=e68] [cursor=pointer]
      - button "Manager" [ref=e73] [cursor=pointer]
      - button "Admin" [ref=e78] [cursor=pointer]
    - button "User menu" [ref=e83] [cursor=pointer]:
      - generic [ref=e84]:
        - generic [aria-hidden] [ref=e85]: DM
        - generic [ref=e86]:
          - strong [ref=e87]: Demo Manager
          - generic [ref=e88]: Manager
  - generic [ref=e89]:
    - banner [ref=e90]:
      - button "Collapse sidebar" [expanded] [ref=e91] [cursor=pointer]
      - navigation "Breadcrumbs" [ref=e95]:
        - link "North York" [ref=e96] [cursor=pointer]:
          - /url: "#dashboard"
        - link "Invoices" [ref=e99] [cursor=pointer]:
          - /url: "#invoices"
      - search [ref=e100]:
        - textbox "Search all products" [ref=e104]:
          - /placeholder: Search products
        - generic [aria-hidden] [ref=e105]: /
      - combobox "Location" [ref=e106] [cursor=pointer]:
        - generic [ref=e111]: North York
      - button "Switch to Persian" [ref=e114] [cursor=pointer]: فا
      - button "Switch to dark theme" [ref=e115] [cursor=pointer]
      - button "Comfortable text size" [ref=e118] [cursor=pointer]:
        - generic [aria-hidden] [ref=e119]: Aa
      - button "Notifications, 8 unread" [ref=e120] [cursor=pointer]:
        - generic [ref=e121]: "8"
      - button "Demo" [ref=e126] [cursor=pointer]
    - main [ref=e129]:
      - generic [ref=e130]:
        - link "Back to Invoices" [ref=e131] [cursor=pointer]:
          - /url: "#invoices"
        - generic [ref=e134]:
          - generic [ref=e135]:
            - heading "Invoices" [level=1] [ref=e136]
            - paragraph [ref=e137]: Deliveries and supplier invoices
          - button "New invoice" [ref=e139] [cursor=pointer]
        - tablist "Invoice views" [ref=e140]:
          - tab "Drafts" [ref=e141] [cursor=pointer]
          - tab "Processing" [ref=e143] [cursor=pointer]
          - tab "Needs review" [selected] [ref=e145] [cursor=pointer]
          - tab "Ready to post" [ref=e147] [cursor=pointer]
          - tab "Posted" [ref=e149] [cursor=pointer]
          - tab "Cancelled" [ref=e151] [cursor=pointer]
        - generic [ref=e153]:
          - complementary "Original invoice" [ref=e154]:
            - generic [ref=e155]:
              - heading "Original invoice" [level=2] [ref=e156]
              - paragraph [ref=e157]: AI invoice reading is simulated
              - generic [ref=e159]:
                - generic [ref=e160]: Upload a PDF or photo
                - generic [ref=e161]:
                  - button "Upload a PDF or photo" [ref=e162]
                  - button "Take photo" [ref=e163]
                  - generic [ref=e164]:
                    - generic [ref=e168]:
                      - strong [ref=e169]: fictional-supplier-invoice.png
                      - generic [ref=e170]: 1 KB
                    - button "Remove file" [ref=e171] [cursor=pointer]
                  - button "Browse" [ref=e176] [cursor=pointer]
              - group "Original invoice" [ref=e177]:
                - generic [ref=e178]:
                  - button "Zoom out" [ref=e179] [cursor=pointer]
                  - generic [ref=e181]: 100%
                  - button "Zoom in" [ref=e182] [cursor=pointer]
                - button "Fit width" [ref=e184] [cursor=pointer]
                - button "Fit page" [ref=e185] [cursor=pointer]
                - button "Download" [ref=e186] [cursor=pointer]
              - img "Original invoice image" [ref=e191]
          - generic [ref=e192]:
            - generic [ref=e193]:
              - generic "Delivery summary" [ref=e194]:
                - generic [ref=e195]:
                  - generic [ref=e196]: Subtotal
                  - strong [ref=e197]: $0.98
                - generic [ref=e198]:
                  - generic [ref=e199]: Tax
                  - strong [ref=e200]: $0.00
                - generic [ref=e201]:
                  - generic [ref=e202]: Shorts and refused deduction
                  - strong [ref=e203]: $0.00
                - generic [ref=e204]:
                  - generic [ref=e205]: Payable
                  - strong [ref=e206]: $0.98
              - paragraph [ref=e207]: This is the amount of this invoice, not a supplier balance. Received records only physically delivered units.
            - generic [ref=e208]:
              - heading [level=2] [ref=e209]:
                - button "Invoice details" [ref=e210] [cursor=pointer]
              - paragraph [ref=e213]:
                - generic [ref=e214]: Fresh Valley Foods
                - text: ·
                - generic [ref=e215]: —
                - text: · North York ·
                - generic [ref=e216]: 2026-10-15
              - paragraph [ref=e217]:
                - generic [ref=e218]: Needs review
                - text: Changes save automatically in this browser.
            - generic [ref=e220]:
              - heading "Compare with order" [level=2] [ref=e221]
              - generic [ref=e222]:
                - generic [ref=e223]: Order (optional)
                - combobox "Order (optional)" [ref=e224] [cursor=pointer]:
                  - generic [ref=e225]: No linked order
                - paragraph [ref=e228]: Choose an open order for this supplier and receiving location.
            - generic [ref=e229]:
              - heading "Review invoice lines" [level=2] [ref=e230]
              - paragraph [ref=e231]: Choose Cases or Units and confirm the product, pack, quantities, cost, and date decision on each line.
              - table [ref=e233]:
                - 'rowgroup "Line 1: Canned Fava Beans 400 g" [ref=e234]':
                  - row [ref=e235] [cursor=pointer]:
                    - cell "1. Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی 0002 · 400 g Matched" [ref=e236]:
                      - generic [ref=e237]:
                        - heading [level=3] [ref=e238]:
                          - button "1. Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی" [expanded] [ref=e239]:
                            - generic [ref=e240]: "1."
                            - generic [ref=e241]:
                              - strong [ref=e242]:
                                - generic [ref=e243]:
                                  - text: Canned Fava Beans
                                  - generic [ref=e244]: 400 g
                              - generic [ref=e246]:
                                - text: باقالا کنسرو شده
                                - generic [ref=e247]: ۴۰۰ گرمی
                        - paragraph [ref=e250]:
                          - text: 0002 ·
                          - generic [ref=e251]: 400 g
                        - generic [ref=e254]: Matched
                    - cell [ref=e257]:
                      - generic [ref=e258]:
                        - generic [ref=e259]: Invoiced
                        - textbox "Invoiced" [ref=e260]: "1"
                      - generic [ref=e261]:
                        - generic [ref=e262]: Delivered
                        - textbox "Delivered" [ref=e263]: "1"
                    - cell [ref=e264]:
                      - generic [ref=e265]:
                        - generic [ref=e266]: Unit cost before tax
                        - textbox "Unit cost before tax" [ref=e267]: "0.9800"
                    - cell "Line total $0.98" [ref=e268]:
                      - generic [ref=e269]: Line total
                      - text: $0.98
                    - 'cell "Selling price $2.49 Manual price Rule price $1.49 · Manual price $2.49 Margin %: 60.64% Approved: $2.49" [ref=e270]':
                      - generic [ref=e271]:
                        - generic [ref=e272]: Selling price
                        - strong [ref=e273]: $2.49
                        - generic [ref=e274]: Manual price
                        - generic [ref=e276]:
                          - paragraph [ref=e277]: Rule price $1.49 · Manual price $2.49
                          - paragraph [ref=e278]:
                            - text: "Margin %:"
                            - generic [ref=e279]: 60.64%
                        - paragraph [ref=e280]: "Approved: $2.49"
                  - row [ref=e281]:
                    - cell [ref=e282]:
                      - generic [ref=e283]:
                        - group [ref=e284]:
                          - generic [ref=e285]:
                            - generic [ref=e286]: Quantity unit
                            - combobox "Quantity unit" [ref=e287] [cursor=pointer]:
                              - generic [ref=e288]: Units
                          - generic [ref=e291]:
                            - generic [ref=e292]: Units per case
                            - textbox "Units per case" [ref=e293]: "12"
                          - generic [ref=e294]:
                            - generic [ref=e295]: Supplier item code (optional)
                            - textbox "Supplier item code (optional)" [ref=e296]
                          - paragraph [ref=e297]: 1 unit
                          - generic [ref=e298]:
                            - generic [ref=e299]: Matched product
                            - combobox "Matched product" [ref=e300] [cursor=pointer]:
                              - generic [ref=e302]:
                                - text: ⁦0002⁩ · ⁦
                                - generic [ref=e303]:
                                  - text: Canned Fava Beans
                                  - generic [ref=e304]: 400 g
                                - text: ⁩
                          - generic [ref=e307]:
                            - generic [ref=e308]: Pricing category
                            - combobox "Pricing category" [ref=e309] [cursor=pointer]:
                              - generic [ref=e310]: Grocery
                        - button "Remove line" [ref=e313] [cursor=pointer]
                        - checkbox "Mark as short" [ref=e314] [cursor=pointer]
                        - group [ref=e317]:
                          - generic [ref=e318]:
                            - generic [ref=e319]: Track date
                            - group "Track date" [ref=e320]:
                              - button "Yes" [pressed] [ref=e321] [cursor=pointer]
                              - button "No" [ref=e323] [cursor=pointer]
                          - generic [ref=e325]:
                            - generic [ref=e326]:
                              - generic [ref=e327]: Date tracking
                              - combobox "Date tracking" [ref=e328] [cursor=pointer]:
                                - generic [ref=e329]: Expiry
                            - generic [ref=e332]:
                              - generic [ref=e333]: Date
                              - button "Date" [ref=e334] [cursor=pointer]:
                                - generic [ref=e335]: Choose date
                            - generic [ref=e338]:
                              - generic [ref=e339]: Lot number (optional)
                              - textbox "Lot number (optional)" [ref=e340]
                        - checkbox "Confirm this invoice line" [ref=e341] [cursor=pointer]
              - generic [ref=e344]:
                - generic [ref=e345]:
                  - generic [ref=e346]: Add a product to the invoice
                  - combobox "Add a product to the invoice" [ref=e347] [cursor=pointer]:
                    - generic [ref=e349]:
                      - text: ⁦0002⁩ · ⁦
                      - generic [ref=e350]:
                        - text: Canned Fava Beans
                        - generic [ref=e351]: 400 g
                      - text: ⁩
                - button "Add line" [ref=e354] [cursor=pointer]
                - button "+ Add new product" [ref=e355] [cursor=pointer]
          - generic [ref=e357]:
            - button "Save as draft" [ref=e358] [cursor=pointer]
            - button "Post invoice" [ref=e359] [cursor=pointer]
```

# Test source

```ts
  180 |     name: "Refused / sent back with the driver",
  181 |     exact: true,
  182 |   });
  183 |   if (!(await refusal.count()))
  184 |     await row
  185 |       .getByRole("button", { name: "Show details", exact: true })
  186 |       .click();
  187 |   await comparison
  188 |     .getByRole("button", {
  189 |       name: "Refused / sent back with the driver",
  190 |       exact: true,
  191 |     })
  192 |     .click();
  193 |   await comparison
  194 |     .getByRole("button", { name: "Accept new cost", exact: true })
  195 |     .click();
  196 |   await confirmNoDate(page);
  197 |   await post(page);
  198 |   const after = await stored(page);
  199 |   const currentOrder = after.orders!.find((item) => item.id === order.id)!;
  200 |   expect(currentOrder.status).toBe("received");
  201 |   expect(currentOrder.lines[0].received_units).toBe(12);
  202 |   expect(after.invoice.lines[0]).toMatchObject({
  203 |     qty_received_at_posting: 18,
  204 |     refused_units: 6,
  205 |     extra_delivery_decision: "refuse",
  206 |     order_price_decision: "accept",
  207 |   });
  208 |   expect(after.invoice.payable_after_open_shorts).toBe("13.20");
  209 |   expect(
  210 |     after.alerts.filter((alert) => alert.invoice_id === after.invoice.id),
  211 |   ).toHaveLength(1);
  212 |   expect(
  213 |     after.alerts.find((alert) => alert.invoice_id === after.invoice.id)
  214 |       ?.order_differences,
  215 |   ).toEqual(
  216 |     expect.arrayContaining([
  217 |       expect.objectContaining({ kind: "extra", units: 6, decision: "refuse" }),
  218 |       expect.objectContaining({ kind: "price_change", decision: "accept" }),
  219 |     ]),
  220 |   );
  221 |   await page.reload();
  222 |   const postedLine = page
  223 |     .locator(".posted-invoice-document tbody tr")
  224 |     .filter({ hasText: "Canned Fava Beans 400 g" });
  225 |   await expect(postedLine).toContainText("Delivered quantity: 12");
  226 |   await expect(postedLine).toContainText(
  227 |     "Refused / sent back with the driver · 6 · $6.60",
  228 |   );
  229 |   await expect(postedLine).toContainText("Accept new cost");
  230 |   await expect(postedLine.getByRole("cell").nth(2)).toHaveText("$1.10");
  231 |   await expect(
  232 |     page.locator(
  233 |       ".posted-invoice-document input, .posted-invoice-document select",
  234 |     ),
  235 |   ).toHaveCount(0);
  236 |   await page.goto("/#alerts");
  237 |   await expect(
  238 |     page.getByRole("heading", {
  239 |       name: "Invoice and order differences",
  240 |       exact: true,
  241 |     }),
  242 |   ).toBeVisible();
  243 |   await page.goto("/#received");
  244 |   await page
  245 |     .getByRole("textbox", { name: "Search Received", exact: true })
  246 |     .fill(after.invoice.supplier_invoice_number);
  247 |   await expect(page.locator(".received-table")).toContainText("12 units");
  248 | });
  249 | 
  250 | test("short-dated expiry discount requires a real date and preserves an existing manual selling price", async ({
  251 |   page,
  252 | }) => {
  253 |   await signIn(page, "Supervisor");
  254 |   const editor = await openC8PriceDialog(page, "0002");
  255 |   await editor.getByRole("radio", { name: /^New regular price/ }).check();
  256 |   await editor.getByLabel("Price", { exact: true }).fill("2.49");
  257 |   await editor
  258 |     .getByRole("checkbox", {
  259 |       name: "Add regular labels to the label waitlist",
  260 |       exact: true,
  261 |     })
  262 |     .uncheck();
  263 |   await editor
  264 |     .getByRole("button", { name: "Save new price", exact: true })
  265 |     .click();
  266 |   await expect(editor).not.toBeVisible();
  267 |   await expect
  268 |     .poll(
  269 |       async () =>
  270 |         (await stored(page)).products.find((entry) => entry.code === "0002")
  271 |           ?.manual_prices?.all.price,
  272 |     )
  273 |     .toBe("2.49");
  274 |   const before = await stored(page);
  275 |   const prior = before.products.find((item) => item.code === "0002")!;
  276 |   const line = await manual(page);
  277 |   await line.getByLabel("Unit cost before tax", { exact: true }).fill("0.8000");
  278 |   await line
  279 |     .getByRole("button", { name: "Short-dated (expiry discount)", exact: true })
> 280 |     .click();
      |      ^ Error: locator.click: Test timeout of 60000ms exceeded.
  281 |   await expect(
  282 |     line.getByRole("button", { name: "No", exact: true }),
  283 |   ).toBeDisabled();
  284 |   await expect(
  285 |     page.getByRole("button", { name: "Post invoice", exact: true }),
  286 |   ).toBeEnabled();
  287 |   await page.getByRole("button", { name: "Post invoice", exact: true }).click();
  288 |   await expect(
  289 |     page.getByRole("alert", { name: "What's missing", exact: true }),
  290 |   ).toBeVisible();
  291 |   await expect(
  292 |     line.getByRole("button", { name: "Keep $2.49", exact: true }),
  293 |   ).toHaveCount(0);
  294 |   await line.getByLabel("Date", { exact: true }).click();
  295 |   await page
  296 |     .getByRole("dialog", { name: "Choose date", exact: true })
  297 |     .getByRole("button", { name: "Today", exact: true })
  298 |     .click();
  299 |   await line
  300 |     .getByRole("checkbox", { name: "Confirm this invoice line", exact: true })
  301 |     .click();
  302 |   await post(page);
  303 |   const after = await stored(page);
  304 |   const product = after.products.find((item) => item.code === "0002")!;
  305 |   expect(product.last_cost_before_tax).toBe(prior.last_cost_before_tax);
  306 |   expect(product.selling_price).toBe("2.49");
  307 |   expect(product.manual_prices).toEqual(prior.manual_prices);
  308 |   expect(product.price_provenance).toEqual(prior.price_provenance);
  309 |   expect(after.invoice.payable_after_open_shorts).toBe("0.80");
  310 |   expect(
  311 |     after.expiry.find((entry) => entry.invoice_id === after.invoice.id)?.date,
  312 |   ).toBe(after.invoice.lines[0].date_value);
  313 |   expect(
  314 |     after.approvals.filter(
  315 |       (approval) => approval.source_invoice_id === after.invoice.id,
  316 |     ),
  317 |   ).toHaveLength(0);
  318 |   expect(
  319 |     after.alerts.filter((alert) =>
  320 |       alert.id.startsWith(`${after.invoice.id}:lower:`),
  321 |     ),
  322 |   ).toHaveLength(0);
  323 |   expect(
  324 |     await page.evaluate(
  325 |       () => document.documentElement.scrollWidth <= window.innerWidth,
  326 |     ),
  327 |   ).toBe(true);
  328 | });
  329 | 
```