# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: filters-a2.spec.ts >> Payables filters supplier totals and keeps selected report in the same branch
- Location: tests/filters-a2.spec.ts:221:1

# Error details

```
Error: expect(received).toBeGreaterThan(expected)

Expected: > 0
Received:   0

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=e5]:
    - banner [ref=e6]:
      - button "Open menu" [ref=e7] [cursor=pointer]
      - combobox "Location" [ref=e11] [cursor=pointer]:
        - generic [ref=e16]: Richmond Hill
      - button "Notifications, 5 unread" [ref=e19] [cursor=pointer]:
        - generic [ref=e20]: "5"
      - button "User menu" [ref=e25] [cursor=pointer]:
        - generic [aria-hidden] [ref=e27]: DM
      - button "More" [ref=e28] [cursor=pointer]
    - main [ref=e34]:
      - generic [ref=e35]:
        - generic [ref=e36]:
          - heading "Payables" [level=1] [ref=e37]
          - paragraph [ref=e38]: Supplier balances and payment records by branch.
        - button "Record external payment" [ref=e40] [cursor=pointer]
      - generic [ref=e41]:
        - heading "Suppliers" [level=2] [ref=e42]
        - generic "Payables filters" [ref=e43]:
          - textbox "Search suppliers" [ref=e48]: fresh
          - combobox "Payables branch" [ref=e49] [cursor=pointer]:
            - generic [ref=e50]: Richmond Hill
          - checkbox "Overdue only" [ref=e53] [cursor=pointer]
          - checkbox "With balance" [ref=e56] [cursor=pointer]
          - button "Clear filters" [ref=e59] [cursor=pointer]
          - generic [ref=e61]:
            - generic [ref=e62]: 1 supplier
            - button "Columns" [ref=e63] [cursor=pointer]
        - table [ref=e67]:
          - rowgroup [ref=e68]:
            - row "Fresh Valley Foods" [ref=e69]:
              - cell [ref=e70]:
                - link "Fresh Valley Foods" [ref=e72] [cursor=pointer]:
                  - /url: "#payables"
              - cell "$0.00" [ref=e73]
              - cell [ref=e74]:
                - link "View Fresh Valley Foods" [ref=e75] [cursor=pointer]:
                  - /url: "#payables"
              - cell "Richmond Hill —" [ref=e78]:
                - generic [ref=e79]: Richmond Hill
                - generic [ref=e80]: —
      - generic [ref=e82]:
        - generic [ref=e84]:
          - generic [ref=e85]: Supplier
          - combobox "Supplier" [ref=e86] [cursor=pointer]:
            - generic [ref=e87]: Fresh Valley Foods
        - tablist "View" [ref=e90]:
          - tab "Current ledger" [selected] [ref=e91] [cursor=pointer]
          - tab "Month-end summary" [ref=e93] [cursor=pointer]
        - generic [ref=e95]:
          - button "Print summary" [ref=e96] [cursor=pointer]
          - button "Export CSV" [ref=e97] [cursor=pointer]
          - button "Record opening balance, credit, or adjustment" [ref=e98] [cursor=pointer]
          - button "View all suppliers" [ref=e99] [cursor=pointer]
      - region "Supplier financial report" [ref=e100]:
        - generic [ref=e101]:
          - heading "Fresh Valley Foods" [level=2] [ref=e102]
          - paragraph [ref=e103]: Richmond Hill · CAD · As of 2026-10-15
        - generic [ref=e104]:
          - generic [ref=e105]:
            - generic [ref=e106]: Supplier balance
            - strong [ref=e107]: $0.00
          - generic [ref=e108]:
            - generic [ref=e109]: Open invoices
            - strong [ref=e110]: "0"
          - generic [ref=e111]:
            - generic [ref=e112]: Overdue
            - strong [ref=e113]: $0.00
          - generic [ref=e114]:
            - generic [ref=e115]: Unapplied supplier credit
            - strong [ref=e116]: $0.00
        - paragraph [ref=e122]: No ledger entries yet. Post an invoice in Invoices to show the invoice and its short deduction here.
```

# Test source

```ts
  1   | import { expect, test, type Locator } from "@playwright/test";
  2   | import { chooseOption, setBranch, setLanguage, signIn } from "./helpers";
  3   | 
  4   | test.setTimeout(60000);
  5   | 
  6   | async function responsiveColumn(row: Locator, label: string) {
  7   |   await expect(row).toBeVisible();
  8   |   await expect
  9   |     .poll(
  10  |       async () =>
  11  |         await row
  12  |           .locator(`td[data-column-label="${label}"], .table-details-toggle`)
  13  |           .count(),
  14  |     )
> 15  |     .toBeGreaterThan(0);
      |      ^ Error: expect(received).toBeGreaterThan(expected)
  16  |   const cell = row.locator(`td[data-column-label="${label}"]`);
  17  |   if (await cell.count()) {
  18  |     await expect(cell).toBeVisible();
  19  |     return cell;
  20  |   }
  21  |   const showDetails = row.getByRole("button", {
  22  |     name: "Show details",
  23  |     exact: true,
  24  |   });
  25  |   if (await showDetails.isVisible()) await showDetails.click();
  26  |   const value = row
  27  |     .locator("xpath=following-sibling::tr[1]")
  28  |     .locator("dl > div")
  29  |     .filter({ has: row.page().getByText(label, { exact: true }) })
  30  |     .locator("dd");
  31  |   await expect(value).toBeVisible();
  32  |   return value;
  33  | }
  34  | 
  35  | test("Offers combines name/code/label search, category, supplier, type and status without changing prices", async ({
  36  |   page,
  37  | }) => {
  38  |   await signIn(page, "supervisor");
  39  |   await page.goto("/#offers");
  40  |   const filters = page.getByLabel("Offer filters", { exact: true });
  41  |   const current = page.locator("section.card").filter({
  42  |     has: page.getByRole("heading", { name: "Current offers", exact: true }),
  43  |   });
  44  |   await expect(current.locator("tbody tr[data-product-code]")).toHaveCount(7);
  45  |   expect(
  46  |     await current
  47  |       .locator("tbody tr[data-product-code]")
  48  |       .evaluateAll((rows) =>
  49  |         rows.map((row) => row.getAttribute("data-product-code")).sort(),
  50  |       ),
  51  |   ).toEqual(["0003", "0005", "0006", "0007", "0008", "0009", "0012"]);
  52  |   await expect(
  53  |     current.locator('tbody tr[data-offer-kind="sale"]'),
  54  |   ).toContainText("Stainless Steel Pot");
  55  |   await expect(
  56  |     current.locator('tbody tr[data-offer-kind="request"]'),
  57  |   ).toContainText("Sunflower Oil");
  58  |   await chooseOption(
  59  |     page,
  60  |     filters.getByLabel("Offer type", { exact: true }),
  61  |     "multi_buy",
  62  |     "Multi-buy",
  63  |   );
  64  |   await expect(current.locator("tbody tr[data-product-code]")).toHaveCount(5);
  65  |   await filters.getByLabel("Search offers", { exact: true }).fill("0003");
  66  |   await expect(current.locator("tbody tr[data-product-code]")).toHaveCount(1);
  67  |   await expect(current).toContainText("Sour Cherry Juice");
  68  |   await filters.getByLabel("Search offers", { exact: true }).fill("آب آلبالو");
  69  |   await expect(current.locator("tbody tr[data-product-code]")).toHaveCount(1);
  70  |   await filters.getByLabel("Search offers", { exact: true }).fill("2 for $5");
  71  |   await expect(current.locator("tbody tr[data-product-code]")).toHaveCount(2);
  72  |   await chooseOption(
  73  |     page,
  74  |     filters.getByLabel("Offer category", { exact: true }),
  75  |     "Juices",
  76  |   );
  77  |   await chooseOption(
  78  |     page,
  79  |     filters.getByLabel("Offer supplier", { exact: true }),
  80  |     "Fresh Valley Foods",
  81  |   );
  82  |   await chooseOption(
  83  |     page,
  84  |     filters.getByLabel("Offer type", { exact: true }),
  85  |     "multi_buy",
  86  |     "Multi-buy",
  87  |   );
  88  |   await expect(current.locator("tbody tr[data-product-code]")).toHaveCount(1);
  89  |   await expect(filters.locator(".filter-count")).toHaveText("1 offer");
  90  |   await current
  91  |     .locator('tbody tr[data-product-code="0003"]')
  92  |     .getByRole("button", { name: "More", exact: true })
  93  |     .click();
  94  |   await page.getByRole("menuitem", { name: /^Stop offer ·/ }).click();
  95  |   await page
  96  |     .getByRole("dialog", { name: "Stop offer", exact: true })
  97  |     .getByRole("button", { name: "Stop offer", exact: true })
  98  |     .click();
  99  |   await expect(current.locator("tbody tr[data-product-code]")).toHaveCount(0);
  100 |   await page.getByRole("tab", { name: "Past offers", exact: true }).click();
  101 |   const past = page.locator("section.card").filter({
  102 |     has: page.getByRole("heading", { name: "Past offers", exact: true }),
  103 |   });
  104 |   await chooseOption(
  105 |     page,
  106 |     filters.getByLabel("Offer status", { exact: true }),
  107 |     "stopped",
  108 |     "Stopped",
  109 |   );
  110 |   await expect(past.locator("tbody tr[data-product-code]")).toHaveCount(1);
  111 |   const stoppedOffer = past.locator('tr[data-product-code="0003"]');
  112 |   await expect(stoppedOffer).toHaveCount(1);
  113 |   await expect(stoppedOffer).toContainText("Sour Cherry Juice");
  114 |   const stoppedOfferValue = await responsiveColumn(stoppedOffer, "Offer");
  115 |   await expect(stoppedOfferValue).toContainText("2 for $5.00");
```