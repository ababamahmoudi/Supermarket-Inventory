# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: alignment-a2.spec.ts >> table columns align and phone cards retain labelled contained values (fa)
- Location: tests/alignment-a2.spec.ts:5:3

# Error details

```
Error: products (fa)

expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 66

- Array []
+ Array [
+   "table 0, phone card 0, column 0: label null/محصول",
+   "table 0, phone card 0, column 1: label null/کد محصول",
+   "table 0, phone card 0, column 2: label null/قیمت تأییدشده",
+   "table 0, phone card 0, column 3: label null/جزئیات",
+   "table 0, phone card 1, column 0: label null/محصول",
+   "table 0, phone card 1, column 1: label null/کد محصول",
+   "table 0, phone card 1, column 2: label null/قیمت تأییدشده",
+   "table 0, phone card 1, column 3: label null/جزئیات",
+   "table 0, phone card 2, column 0: label null/محصول",
+   "table 0, phone card 2, column 1: label null/کد محصول",
+   "table 0, phone card 2, column 2: label null/قیمت تأییدشده",
+   "table 0, phone card 2, column 3: label null/جزئیات",
+   "table 0, phone card 3, column 0: label null/محصول",
+   "table 0, phone card 3, column 1: label null/کد محصول",
+   "table 0, phone card 3, column 2: label null/قیمت تأییدشده",
+   "table 0, phone card 3, column 3: label null/جزئیات",
+   "table 0, phone card 4, column 0: label null/محصول",
+   "table 0, phone card 4, column 1: label null/کد محصول",
+   "table 0, phone card 4, column 2: label null/قیمت تأییدشده",
+   "table 0, phone card 4, column 3: label null/جزئیات",
+   "table 0, phone card 5, column 0: label null/محصول",
+   "table 0, phone card 5, column 1: label null/کد محصول",
+   "table 0, phone card 5, column 2: label null/قیمت تأییدشده",
+   "table 0, phone card 5, column 3: label null/جزئیات",
+   "table 0, phone card 6, column 0: label null/محصول",
+   "table 0, phone card 6, column 1: label null/کد محصول",
+   "table 0, phone card 6, column 2: label null/قیمت تأییدشده",
+   "table 0, phone card 6, column 3: label null/جزئیات",
+   "table 0, phone card 7, column 0: label null/محصول",
+   "table 0, phone card 7, column 1: label null/کد محصول",
+   "table 0, phone card 7, column 2: label null/قیمت تأییدشده",
+   "table 0, phone card 7, column 3: label null/جزئیات",
+   "table 0, phone card 8, column 0: label null/محصول",
+   "table 0, phone card 8, column 1: label null/کد محصول",
+   "table 0, phone card 8, column 2: label null/قیمت تأییدشده",
+   "table 0, phone card 8, column 3: label null/جزئیات",
+   "table 0, phone card 9, column 0: label null/محصول",
+   "table 0, phone card 9, column 1: label null/کد محصول",
+   "table 0, phone card 9, column 2: label null/قیمت تأییدشده",
+   "table 0, phone card 9, column 3: label null/جزئیات",
+   "table 0, phone card 10, column 0: label null/محصول",
+   "table 0, phone card 10, column 1: label null/کد محصول",
+   "table 0, phone card 10, column 2: label null/قیمت تأییدشده",
+   "table 0, phone card 10, column 3: label null/جزئیات",
+   "table 0, phone card 11, column 0: label null/محصول",
+   "table 0, phone card 11, column 1: label null/کد محصول",
+   "table 0, phone card 11, column 2: label null/قیمت تأییدشده",
+   "table 0, phone card 11, column 3: label null/جزئیات",
+   "table 0, phone card 12, column 0: label null/محصول",
+   "table 0, phone card 12, column 1: label null/کد محصول",
+   "table 0, phone card 12, column 2: label null/قیمت تأییدشده",
+   "table 0, phone card 12, column 3: label null/جزئیات",
+   "table 0, phone card 13, column 0: label null/محصول",
+   "table 0, phone card 13, column 1: label null/کد محصول",
+   "table 0, phone card 13, column 2: label null/قیمت تأییدشده",
+   "table 0, phone card 13, column 3: label null/جزئیات",
+   "table 0, phone card 14, column 0: label null/محصول",
+   "table 0, phone card 14, column 1: label null/کد محصول",
+   "table 0, phone card 14, column 2: label null/قیمت تأییدشده",
+   "table 0, phone card 14, column 3: label null/جزئیات",
+   "table 0, phone card 15, column 0: label null/محصول",
+   "table 0, phone card 15, column 1: label null/کد محصول",
+   "table 0, phone card 15, column 2: label null/قیمت تأییدشده",
+   "table 0, phone card 15, column 3: label null/جزئیات",
+ ]
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "رفتن به محتوا" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=e5]:
    - banner [ref=e6]:
      - button "باز کردن منو" [ref=e7] [cursor=pointer]
      - combobox "مکان" [ref=e11] [cursor=pointer]:
        - generic [ref=e16]: نورث یورک
      - button "اعلان‌ها، 5 خوانده‌نشده" [ref=e19] [cursor=pointer]:
        - generic [ref=e20]: "5"
      - button "منوی کاربر" [ref=e25] [cursor=pointer]:
        - generic [aria-hidden] [ref=e27]: مآ
      - button "بیشتر" [active] [ref=e28] [cursor=pointer]
    - main [ref=e34]:
      - generic [ref=e35]:
        - generic [ref=e36]:
          - generic [ref=e37]:
            - heading "محصولات" [level=1] [ref=e38]
            - paragraph [ref=e39]: قیمت‌های تأییدشده، تغییرات در انتظار تأیید و جزئیات شعبه در یک فهرست.
          - button "افزودن محصول" [ref=e41] [cursor=pointer]
        - generic [ref=e42]:
          - generic [ref=e43]:
            - searchbox "جست‌وجوی محصولات" [ref=e48]
            - combobox "دستهٔ قیمت‌گذاری" [ref=e49] [cursor=pointer]:
              - generic [ref=e50]: همهٔ دسته‌های قیمت‌گذاری
            - combobox "دستهٔ هوش مصنوعی" [ref=e53] [cursor=pointer]:
              - generic [ref=e54]: همهٔ دسته‌های هوش مصنوعی
            - combobox "وضعیت" [ref=e57] [cursor=pointer]:
              - generic [ref=e58]: همهٔ وضعیت‌ها
            - combobox "تأمین‌کننده" [ref=e61] [cursor=pointer]:
              - generic [ref=e62]: همهٔ تأمین‌کنندگان
            - checkbox "دارای قیمت در انتظار تأیید" [ref=e65] [cursor=pointer]
            - checkbox "دارای پیشنهاد" [ref=e68] [cursor=pointer]
            - checkbox "قیمت‌های دستی" [ref=e71] [cursor=pointer]
            - checkbox "در حراج" [ref=e74] [cursor=pointer]
            - button "پاک کردن فیلترها" [ref=e77] [cursor=pointer]
            - generic [ref=e79]:
              - generic [ref=e80]: 16 محصول
              - button "ستون‌ها" [ref=e81] [cursor=pointer]
          - generic [ref=e85]:
            - table [ref=e87]:
              - rowgroup [ref=e88]:
                - row [ref=e89]:
                  - cell "آب آلبالو ۱ لیتری Sour Cherry Juice 1 L 1 L" [ref=e90]:
                    - link "آب آلبالو ۱ لیتری" [ref=e91] [cursor=pointer]:
                      - /url: "#product?code=0003"
                      - strong [ref=e92]:
                        - generic [ref=e94]:
                          - text: آب آلبالو
                          - generic [ref=e95]: ۱ لیتری
                    - paragraph [ref=e96]:
                      - generic [ref=e98]:
                        - text: Sour Cherry Juice
                        - generic [ref=e99]: 1 L
                    - paragraph [ref=e100]:
                      - generic [ref=e101]: 1 L
                  - cell "$2.99" [ref=e104]
                  - cell [ref=e107]:
                    - link "باز کردن آب آلبالو ۱ لیتری" [ref=e108] [cursor=pointer]:
                      - /url: "#product?code=0003"
                  - cell "0003 تأییدشده ۲ عدد $5.00" [ref=e111]:
                    - generic [ref=e112]: "0003"
                    - generic [ref=e115]:
                      - generic [ref=e116]: تأییدشده
                      - generic [ref=e117]: ۲ عدد $5.00
                - row [ref=e119]:
                  - cell "اسفنج ظرفشویی بسته ۳ عددی Kitchen Sponge 3-pack 3 pcs" [ref=e120]:
                    - link "اسفنج ظرفشویی بسته ۳ عددی" [ref=e121] [cursor=pointer]:
                      - /url: "#product?code=0014"
                      - strong [ref=e122]:
                        - generic [ref=e123]: اسفنج ظرفشویی بسته ۳ عددی
                    - paragraph [ref=e124]:
                      - generic [ref=e125]: Kitchen Sponge 3-pack
                    - paragraph [ref=e126]:
                      - generic [ref=e127]: 3 pcs
                  - cell "$2.49" [ref=e128]
                  - cell [ref=e131]:
                    - link "باز کردن اسفنج ظرفشویی بسته ۳ عددی" [ref=e132] [cursor=pointer]:
                      - /url: "#product?code=0014"
                  - cell "0014 تأییدشده" [ref=e135]:
                    - generic [ref=e136]: "0014"
                    - generic [ref=e138]: تأییدشده
                - row [ref=e141]:
                  - cell "بادام فله Bulk Almonds فروش وزنی" [ref=e142]:
                    - link "بادام فله" [ref=e143] [cursor=pointer]:
                      - /url: "#product?code=0016"
                      - strong [ref=e144]:
                        - generic [ref=e145]: بادام فله
                    - paragraph [ref=e146]:
                      - generic [ref=e147]: Bulk Almonds
                    - paragraph [ref=e148]: فروش وزنی
                  - cell "$7.49/lb $16.51/kg" [ref=e149]:
                    - generic [ref=e151]:
                      - generic [ref=e152]: $7.49/lb
                      - generic [ref=e153]: $16.51/kg
                  - cell [ref=e154]:
                    - link "باز کردن بادام فله" [ref=e155] [cursor=pointer]:
                      - /url: "#product?code=0016"
                  - cell "0016 تأییدشده" [ref=e158]:
                    - generic [ref=e159]: "0016"
                    - generic [ref=e161]: تأییدشده
                - row [ref=e164]:
                  - cell "باقالا کنسرو شده ۴۰۰ گرمی Canned Fava Beans 400 g 400 g" [ref=e165]:
                    - link "باقالا کنسرو شده ۴۰۰ گرمی" [ref=e166] [cursor=pointer]:
                      - /url: "#product?code=0002"
                      - strong [ref=e167]:
                        - generic [ref=e169]:
                          - text: باقالا کنسرو شده
                          - generic [ref=e170]: ۴۰۰ گرمی
                    - paragraph [ref=e171]:
                      - generic [ref=e173]:
                        - text: Canned Fava Beans
                        - generic [ref=e174]: 400 g
                    - paragraph [ref=e175]:
                      - generic [ref=e176]: 400 g
                  - cell "$1.49" [ref=e179]
                  - cell [ref=e182]:
                    - link "باز کردن باقالا کنسرو شده ۴۰۰ گرمی" [ref=e183] [cursor=pointer]:
                      - /url: "#product?code=0002"
                  - cell "0002 تأییدشده" [ref=e186]:
                    - generic [ref=e187]: "0002"
                    - generic [ref=e189]: تأییدشده
                - row [ref=e192]:
                  - cell "برنج باسماتی ۴٫۵ کیلوگرمی Basmati Rice 4.5 kg 4.5 kg" [ref=e193]:
                    - link "برنج باسماتی ۴٫۵ کیلوگرمی" [ref=e194] [cursor=pointer]:
                      - /url: "#product?code=0001"
                      - strong [ref=e195]:
                        - generic [ref=e197]:
                          - text: برنج باسماتی
                          - generic [ref=e198]: ۴٫۵ کیلوگرمی
                    - paragraph [ref=e199]:
                      - generic [ref=e201]:
                        - text: Basmati Rice
                        - generic [ref=e202]: 4.5 kg
                    - paragraph [ref=e203]:
                      - generic [ref=e204]: 4.5 kg
                  - cell "$23.99" [ref=e207]
                  - cell [ref=e210]:
                    - link "باز کردن برنج باسماتی ۴٫۵ کیلوگرمی" [ref=e211] [cursor=pointer]:
                      - /url: "#product?code=0001"
                  - cell "0001 تأییدشده" [ref=e214]:
                    - generic [ref=e215]: "0001"
                    - generic [ref=e217]: تأییدشده
                - row [ref=e220]:
                  - cell "پلوپز ۱٫۸ لیتری Rice Cooker 1.8 L 1.8 L" [ref=e221]:
                    - link "پلوپز ۱٫۸ لیتری" [ref=e222] [cursor=pointer]:
                      - /url: "#product?code=0013"
                      - strong [ref=e223]:
                        - generic [ref=e225]:
                          - text: پلوپز
                          - generic [ref=e226]: ۱٫۸ لیتری
                    - paragraph [ref=e227]:
                      - generic [ref=e229]:
                        - text: Rice Cooker
                        - generic [ref=e230]: 1.8 L
                    - paragraph [ref=e231]:
                      - generic [ref=e232]: 1.8 L
                  - cell "$52.49" [ref=e235]
                  - cell [ref=e238]:
                    - link "باز کردن پلوپز ۱٫۸ لیتری" [ref=e239] [cursor=pointer]:
                      - /url: "#product?code=0013"
                  - cell "0013 تأییدشده" [ref=e242]:
                    - generic [ref=e243]: "0013"
                    - generic [ref=e245]: تأییدشده
                - row [ref=e248]:
                  - cell "چای سیاه ۴۵۰ گرمی Black Tea 450 g 450 g" [ref=e249]:
                    - link "چای سیاه ۴۵۰ گرمی" [ref=e250] [cursor=pointer]:
                      - /url: "#product?code=0004"
                      - strong [ref=e251]:
                        - generic [ref=e253]:
                          - text: چای سیاه
                          - generic [ref=e254]: ۴۵۰ گرمی
                    - paragraph [ref=e255]:
                      - generic [ref=e257]:
                        - text: Black Tea
                        - generic [ref=e258]: 450 g
                    - paragraph [ref=e259]:
                      - generic [ref=e260]: 450 g
                  - cell "$6.49" [ref=e263]
                  - cell [ref=e266]:
                    - link "باز کردن چای سیاه ۴۵۰ گرمی" [ref=e267] [cursor=pointer]:
                      - /url: "#product?code=0004"
                  - cell "0004 تأییدشده" [ref=e270]:
                    - generic [ref=e271]: "0004"
                    - generic [ref=e273]: تأییدشده
                - row [ref=e276]:
                  - cell "چیپس سیب‌زمینی ۱۵۰ گرمی Potato Chips 150 g 150 g" [ref=e277]:
                    - link "چیپس سیب‌زمینی ۱۵۰ گرمی" [ref=e278] [cursor=pointer]:
                      - /url: "#product?code=0009"
                      - strong [ref=e279]:
                        - generic [ref=e281]:
                          - text: چیپس سیب‌زمینی
                          - generic [ref=e282]: ۱۵۰ گرمی
                    - paragraph [ref=e283]:
                      - generic [ref=e285]:
                        - text: Potato Chips
                        - generic [ref=e286]: 150 g
                    - paragraph [ref=e287]:
                      - generic [ref=e288]: 150 g
                  - cell "$2.99" [ref=e291]
                  - cell [ref=e294]:
                    - link "باز کردن چیپس سیب‌زمینی ۱۵۰ گرمی" [ref=e295] [cursor=pointer]:
                      - /url: "#product?code=0009"
                  - cell "0009 تأییدشده ۲ عدد $5.00" [ref=e298]:
                    - generic [ref=e299]: "0009"
                    - generic [ref=e302]:
                      - generic [ref=e303]: تأییدشده
                      - generic [ref=e304]: ۲ عدد $5.00
                - row [ref=e306]:
                  - cell "روغن آفتابگردان ۱٫۸ لیتری Sunflower Oil 1.8 L 1.8 L" [ref=e307]:
                    - link "روغن آفتابگردان ۱٫۸ لیتری" [ref=e308] [cursor=pointer]:
                      - /url: "#product?code=0008"
                      - strong [ref=e309]:
                        - generic [ref=e311]:
                          - text: روغن آفتابگردان
                          - generic [ref=e312]: ۱٫۸ لیتری
                    - paragraph [ref=e313]:
                      - generic [ref=e315]:
                        - text: Sunflower Oil
                        - generic [ref=e316]: 1.8 L
                    - paragraph [ref=e317]:
                      - generic [ref=e318]: 1.8 L
                  - cell "$9.49 حراج درخواست‌شده $7.99 · 15 اکتبر–28 اکتبر در انتظار تأیید" [ref=e321]:
                    - generic [ref=e322]:
                      - generic [ref=e323]: $9.49
                      - generic [ref=e324]:
                        - generic [ref=e325]:
                          - text: حراج درخواست‌شده
                          - generic [ref=e326]: $7.99
                          - text: ·
                          - generic [ref=e327]: 15 اکتبر–28 اکتبر
                        - generic [ref=e328]: در انتظار تأیید
                  - cell [ref=e329]:
                    - link "باز کردن روغن آفتابگردان ۱٫۸ لیتری" [ref=e330] [cursor=pointer]:
                      - /url: "#product?code=0008"
                  - cell "0008 تأییدشده" [ref=e333]:
                    - generic [ref=e334]: "0008"
                    - generic [ref=e336]: تأییدشده
                - row [ref=e339]:
                  - cell "زرشک خشک ۱۰۰ گرمی Dried Barberries 100 g 100 g" [ref=e340]:
                    - link "زرشک خشک ۱۰۰ گرمی" [ref=e341] [cursor=pointer]:
                      - /url: "#product?code=0015"
                      - strong [ref=e342]:
                        - generic [ref=e344]:
                          - text: زرشک خشک
                          - generic [ref=e345]: ۱۰۰ گرمی
                    - paragraph [ref=e346]:
                      - generic [ref=e348]:
                        - text: Dried Barberries
                        - generic [ref=e349]: 100 g
                    - paragraph [ref=e350]:
                      - generic [ref=e351]: 100 g
                  - cell "—" [ref=e354]
                  - cell [ref=e356]:
                    - link "باز کردن زرشک خشک ۱۰۰ گرمی" [ref=e357] [cursor=pointer]:
                      - /url: "#product?code=0015"
                  - cell "0015 در انتظار تأیید $5.49" [ref=e360]:
                    - generic [ref=e361]: "0015"
                    - generic [ref=e365]:
                      - text: در انتظار تأیید
                      - generic [ref=e366]: $5.49
                - row [ref=e367]:
                  - cell "ست استکان چای (۶ عددی) Tea Glass Set (6 pcs) 6 pcs" [ref=e368]:
                    - link "ست استکان چای (۶ عددی)" [ref=e369] [cursor=pointer]:
                      - /url: "#product?code=0011"
                      - strong [ref=e370]:
                        - generic [ref=e371]: ست استکان چای (۶ عددی)
                    - paragraph [ref=e372]:
                      - generic [ref=e373]: Tea Glass Set (6 pcs)
                    - paragraph [ref=e374]:
                      - generic [ref=e375]: 6 pcs
                  - cell "$8.99" [ref=e376]
                  - cell [ref=e379]:
                    - link "باز کردن ست استکان چای (۶ عددی)" [ref=e380] [cursor=pointer]:
                      - /url: "#product?code=0011"
                  - cell "0011 تأییدشده" [ref=e383]:
                    - generic [ref=e384]: "0011"
                    - generic [ref=e386]: تأییدشده
                - row [ref=e389]:
                  - cell "سماق ۱۰۰ گرمی Ground Sumac 100 g 100 g" [ref=e390]:
                    - link "سماق ۱۰۰ گرمی" [ref=e391] [cursor=pointer]:
                      - /url: "#product?code=0005"
                      - strong [ref=e392]:
                        - generic [ref=e394]:
                          - text: سماق
                          - generic [ref=e395]: ۱۰۰ گرمی
                    - paragraph [ref=e396]:
                      - generic [ref=e398]:
                        - text: Ground Sumac
                        - generic [ref=e399]: 100 g
                    - paragraph [ref=e400]:
                      - generic [ref=e401]: 100 g
                  - cell "$1.99" [ref=e404]
                  - cell [ref=e407]:
                    - link "باز کردن سماق ۱۰۰ گرمی" [ref=e408] [cursor=pointer]:
                      - /url: "#product?code=0005"
                  - cell "0005 تأییدشده ۳ عدد $5.00" [ref=e411]:
                    - generic [ref=e412]: "0005"
                    - generic [ref=e415]:
                      - generic [ref=e416]: تأییدشده
                      - generic [ref=e417]: ۳ عدد $5.00
                - row [ref=e419]:
                  - cell "قابلمه استیل ۲۴ سانتی‌متری Stainless Steel Pot 24 cm 24 cm" [ref=e420]:
                    - link "قابلمه استیل ۲۴ سانتی‌متری" [ref=e421] [cursor=pointer]:
                      - /url: "#product?code=0012"
                      - strong [ref=e422]:
                        - generic [ref=e423]: قابلمه استیل ۲۴ سانتی‌متری
                    - paragraph [ref=e424]:
                      - generic [ref=e425]: Stainless Steel Pot 24 cm
                    - paragraph [ref=e426]:
                      - generic [ref=e427]: 24 cm
                  - cell "$16.99 حراج عادی $20.99 تا 25 اکتبر" [ref=e428]:
                    - generic [ref=e429]:
                      - generic [ref=e430]: $16.99
                      - generic [ref=e432]:
                        - generic [ref=e433]: حراج
                        - deletion [ref=e434]: عادی $20.99
                        - generic [ref=e435]: تا 25 اکتبر
                  - cell [ref=e436]:
                    - link "باز کردن قابلمه استیل ۲۴ سانتی‌متری" [ref=e437] [cursor=pointer]:
                      - /url: "#product?code=0012"
                  - cell "0012 تأییدشده" [ref=e440]:
                    - generic [ref=e441]: "0012"
                    - generic [ref=e443]: تأییدشده
                - row [ref=e446]:
                  - cell "لوبیا قرمز ۹۰۰ گرمی Dried Red Kidney Beans 900 g 900 g" [ref=e447]:
                    - link "لوبیا قرمز ۹۰۰ گرمی" [ref=e448] [cursor=pointer]:
                      - /url: "#product?code=0007"
                      - strong [ref=e449]:
                        - generic [ref=e451]:
                          - text: لوبیا قرمز
                          - generic [ref=e452]: ۹۰۰ گرمی
                    - paragraph [ref=e453]:
                      - generic [ref=e455]:
                        - text: Dried Red Kidney Beans
                        - generic [ref=e456]: 900 g
                    - paragraph [ref=e457]:
                      - generic [ref=e458]: 900 g
                  - cell "$3.99" [ref=e461]
                  - cell [ref=e464]:
                    - link "باز کردن لوبیا قرمز ۹۰۰ گرمی" [ref=e465] [cursor=pointer]:
                      - /url: "#product?code=0007"
                  - cell "0007 تأییدشده ۲ عدد $7.00" [ref=e468]:
                    - generic [ref=e469]: "0007"
                    - generic [ref=e472]:
                      - generic [ref=e473]: تأییدشده
                      - generic [ref=e474]: ۲ عدد $7.00
                - row [ref=e476]:
                  - cell "نان لواش ۵۰۰ گرمی Lavash Bread 500 g 500 g" [ref=e477]:
                    - link "نان لواش ۵۰۰ گرمی" [ref=e478] [cursor=pointer]:
                      - /url: "#product?code=0006"
                      - strong [ref=e479]:
                        - generic [ref=e481]:
                          - text: نان لواش
                          - generic [ref=e482]: ۵۰۰ گرمی
                    - paragraph [ref=e483]:
                      - generic [ref=e485]:
                        - text: Lavash Bread
                        - generic [ref=e486]: 500 g
                    - paragraph [ref=e487]:
                      - generic [ref=e488]: 500 g
                  - cell "$1.99" [ref=e491]
                  - cell [ref=e494]:
                    - link "باز کردن نان لواش ۵۰۰ گرمی" [ref=e495] [cursor=pointer]:
                      - /url: "#product?code=0006"
                  - cell "0006 در انتظار تأیید $2.99 ۳ عدد $5.00" [ref=e498]:
                    - generic [ref=e499]: "0006"
                    - generic [ref=e502]:
                      - generic [ref=e503]:
                        - text: در انتظار تأیید
                        - generic [ref=e504]: $2.99
                      - generic [ref=e505]: ۳ عدد $5.00
                - row [ref=e507]:
                  - cell "نوشابه میوه‌ای بسته ۶ عددی Fruit Soda 6-pack 6 x 355 ml" [ref=e508]:
                    - link "نوشابه میوه‌ای بسته ۶ عددی" [ref=e509] [cursor=pointer]:
                      - /url: "#product?code=0010"
                      - strong [ref=e510]:
                        - generic [ref=e511]: نوشابه میوه‌ای بسته ۶ عددی
                    - paragraph [ref=e512]:
                      - generic [ref=e513]: Fruit Soda 6-pack
                    - paragraph [ref=e514]:
                      - generic [ref=e516]:
                        - text: 6 x
                        - generic [ref=e517]: 355 ml
                  - cell "$4.99" [ref=e518]
                  - cell [ref=e521]:
                    - link "باز کردن نوشابه میوه‌ای بسته ۶ عددی" [ref=e522] [cursor=pointer]:
                      - /url: "#product?code=0010"
                  - cell "0010 تأییدشده" [ref=e525]:
                    - generic [ref=e526]: "0010"
                    - generic [ref=e528]: تأییدشده
            - generic [ref=e531]:
              - button "قبلی" [disabled] [ref=e532]
              - generic [ref=e533]: صفحهٔ 1 از 1 · 16 محصول
              - button "بعدی" [disabled] [ref=e534]
```

# Test source

```ts
  83  |             )
  84  |               continue;
  85  |             if (stacked) {
  86  |               cards++;
  87  |               const bounds = row.getBoundingClientRect();
  88  |               for (const [columnIndex, cell] of [...row.children].entries()) {
  89  |                 const rect = cell.getBoundingClientRect();
  90  |                 const error = Math.max(
  91  |                   0,
  92  |                   bounds.left - rect.left,
  93  |                   rect.right - bounds.right,
  94  |                   cell.scrollWidth - cell.clientWidth,
  95  |                 );
  96  |                 maxError = Math.max(maxError, error);
  97  |                 cells++;
  98  |                 if (error > 2)
  99  |                   failures.push(
  100 |                     `table ${tableIndex}, phone card ${rowIndex}, column ${columnIndex}: containment ${error}px`,
  101 |                   );
  102 |                 const label = cell.getAttribute("data-column-label");
  103 |                 const headerLabel = headers[columnIndex].cloneNode(
  104 |                   true,
  105 |                 ) as HTMLElement;
  106 |                 for (const decoration of headerLabel.querySelectorAll(
  107 |                   '[aria-hidden="true"]',
  108 |                 ))
  109 |                   decoration.remove();
  110 |                 const expectedLabel = headerLabel.textContent
  111 |                   ?.replace(/\s+/g, " ")
  112 |                   .replace(/\s*[↑↓]$/, "")
  113 |                   .trim();
  114 |                 if (expectedLabel && label !== expectedLabel)
  115 |                   failures.push(
  116 |                     `table ${tableIndex}, phone card ${rowIndex}, column ${columnIndex}: label ${label}/${expectedLabel}`,
  117 |                   );
  118 |                 if (
  119 |                   columnIndex > 0 &&
  120 |                   label &&
  121 |                   labelledCard &&
  122 |                   getComputedStyle(cell, "::before").content !==
  123 |                     JSON.stringify(label)
  124 |                 )
  125 |                   failures.push(
  126 |                     `table ${tableIndex}, phone card ${rowIndex}, column ${columnIndex}: missing visible ${label} label`,
  127 |                   );
  128 |                 if (columnIndex > 0 && !labelledCard) {
  129 |                   const captionSelector =
  130 |                     "label,.invoice-line-price,.invoice-line-mobile-caption,.ui-checked-control";
  131 |                   const captions = [
  132 |                     ...(cell.matches(captionSelector) ? [cell] : []),
  133 |                     ...cell.querySelectorAll(captionSelector),
  134 |                   ];
  135 |                   if (
  136 |                     !captions.some(
  137 |                       (caption) => caption.getBoundingClientRect().height > 0,
  138 |                     )
  139 |                   )
  140 |                     failures.push(
  141 |                       `table ${tableIndex}, phone card ${rowIndex}, column ${columnIndex}: missing visible field or price caption`,
  142 |                     );
  143 |                   const totalCaption = cell.querySelector(
  144 |                     ".invoice-line-mobile-caption",
  145 |                   );
  146 |                   if (
  147 |                     totalCaption &&
  148 |                     totalCaption.textContent?.trim() !== expectedLabel
  149 |                   )
  150 |                     failures.push(
  151 |                       `table ${tableIndex}, phone card ${rowIndex}, column ${columnIndex}: caption ${totalCaption.textContent}/${expectedLabel}`,
  152 |                     );
  153 |                 }
  154 |               }
  155 |               continue;
  156 |             }
  157 |             for (const [columnIndex, header] of headers.entries()) {
  158 |               const cell = row.children[columnIndex];
  159 |               const h = header.getBoundingClientRect();
  160 |               const b = cell.getBoundingClientRect();
  161 |               const hs = getComputedStyle(header);
  162 |               const bs = getComputedStyle(cell);
  163 |               const error = Math.max(
  164 |                 Math.abs(h.left - b.left),
  165 |                 Math.abs(h.right - b.right),
  166 |               );
  167 |               maxError = Math.max(maxError, error);
  168 |               cells++;
  169 |               if (
  170 |                 error > 2 ||
  171 |                 hs.paddingInlineStart !== bs.paddingInlineStart ||
  172 |                 hs.paddingInlineEnd !== bs.paddingInlineEnd ||
  173 |                 hs.textAlign !== bs.textAlign
  174 |               )
  175 |                 failures.push(
  176 |                   `table ${tableIndex}, row ${rowIndex}, column ${columnIndex}: edges ${error}px; alignment ${hs.textAlign}/${bs.textAlign}; padding ${hs.paddingInlineStart}/${bs.paddingInlineStart}`,
  177 |                 );
  178 |             }
  179 |           }
  180 |         }
  181 |         return { tables: tables.length, cells, cards, maxError, failures };
  182 |       });
> 183 |       expect(metrics.failures, `${route} (${language})`).toEqual([]);
      |                                                          ^ Error: products (fa)
  184 |       expect(metrics.maxError).toBeLessThanOrEqual(2);
  185 |       if (path === "invoices") expect(metrics.cells).toBeGreaterThanOrEqual(30);
  186 |       report.push({
  187 |         route,
  188 |         tables: metrics.tables,
  189 |         cells: metrics.cells,
  190 |         maxError: metrics.maxError,
  191 |         cards: metrics.cards,
  192 |       });
  193 |     }
  194 |     expect(report.reduce((sum, item) => sum + item.cells, 0)).toBeGreaterThan(
  195 |       100,
  196 |     );
  197 |     if (page.viewportSize()!.width < 760)
  198 |       expect(report.reduce((sum, item) => sum + item.cards, 0)).toBeGreaterThan(
  199 |         0,
  200 |       );
  201 |     await testInfo.attach(`alignment-${language}.json`, {
  202 |       body: JSON.stringify(report, null, 2),
  203 |       contentType: "application/json",
  204 |     });
  205 |   });
  206 | }
  207 | 
  208 | test("product editor is centered with focus trapped, Escape and backdrop restore focus", async ({
  209 |   page,
  210 | }) => {
  211 |   await signIn(page, "Supervisor");
  212 |   await page.goto("/#product?code=0009");
  213 |   const trigger = page.getByRole("button", {
  214 |     name: "Edit Potato Chips 150 g",
  215 |     exact: true,
  216 |   });
  217 |   await trigger.click();
  218 |   const dialog = page.getByRole("dialog", {
  219 |     name: "Edit product",
  220 |     exact: true,
  221 |   });
  222 |   await expect(dialog).toBeVisible();
  223 |   const metrics = await dialog.evaluate((node) => {
  224 |     const r = node.getBoundingClientRect();
  225 |     return {
  226 |       x: Math.abs(r.x + r.width / 2 - innerWidth / 2),
  227 |       y: Math.abs(r.y + r.height / 2 - innerHeight / 2),
  228 |       focused: node.contains(document.activeElement),
  229 |     };
  230 |   });
  231 |   expect(metrics.x).toBeLessThanOrEqual(2);
  232 |   expect(metrics.y).toBeLessThanOrEqual(2);
  233 |   expect(metrics.focused).toBe(true);
  234 |   for (let i = 0; i < 20; i++) await page.keyboard.press("Tab");
  235 |   expect(
  236 |     await dialog.evaluate((node) => node.contains(document.activeElement)),
  237 |   ).toBe(true);
  238 |   await page.keyboard.press("Escape");
  239 |   await expect(dialog).not.toBeVisible();
  240 |   await expect(trigger).toBeFocused();
  241 |   await trigger.click();
  242 |   await page.mouse.click(2, 2);
  243 |   await expect(dialog).not.toBeVisible();
  244 |   await expect(trigger).toBeFocused();
  245 | });
  246 | 
```