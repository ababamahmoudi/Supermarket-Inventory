# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: c5-conditional-audit.spec.ts >> C5 conditional label selection, template restore, and print confirmation
- Location: tests/c5-conditional-audit.spec.ts:140:1

# Error details

```
Error: Selected product add-to-waitlist action

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 3

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+ ]
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=e5]:
    - banner [ref=e6]:
      - button "Open menu" [ref=e7] [cursor=pointer]
      - combobox "Location" [ref=e11] [cursor=pointer]:
        - generic [ref=e16]: North York
      - button "Notifications, 0 unread" [ref=e19] [cursor=pointer]
      - button "User menu" [ref=e24] [cursor=pointer]:
        - generic [aria-hidden] [ref=e26]: DN
      - button "More" [ref=e27] [cursor=pointer]
    - main [ref=e33]:
      - generic [ref=e35]:
        - heading "Labels" [level=1] [ref=e36]
        - paragraph [ref=e37]: Add products to the waitlist, then preview and print.
      - tablist "Labels sections" [ref=e38]:
        - tab "Products" [ref=e39] [cursor=pointer]
        - tab "Waitlist 2" [selected] [ref=e41] [cursor=pointer]:
          - generic [ref=e42]: Waitlist
          - generic [ref=e43]: "2"
        - tab "Templates" [ref=e44] [cursor=pointer]
      - generic [ref=e46]:
        - generic [ref=e47]:
          - heading "Waitlist" [level=2] [ref=e48]
          - tablist "Label styles" [ref=e49]:
            - tab "Regular 1" [ref=e50] [cursor=pointer]:
              - generic [ref=e51]: Regular
              - generic [ref=e52]: "1"
            - tab "Promo 1" [selected] [ref=e53] [cursor=pointer]:
              - generic [ref=e54]: Promo
              - generic [ref=e55]: "1"
          - generic [ref=e56]:
            - generic [ref=e57]: 2 products · 2 labels
            - button "Clear waitlist" [ref=e58] [cursor=pointer]
          - table [ref=e60]:
            - rowgroup [ref=e61]:
              - row [ref=e62]:
                - cell "Stainless Steel Pot 24 cm قابلمه استیل ۲۴ سانتی‌متری" [ref=e63]:
                  - generic [ref=e64]:
                    - strong [ref=e65]: Stainless Steel Pot 24 cm
                    - generic [ref=e66]: قابلمه استیل ۲۴ سانتی‌متری
                - cell "Product Code 0012" [ref=e67]:
                  - text: Product Code
                  - generic [ref=e68]: "0012"
                - cell "Selling price $16.99" [ref=e69]:
                  - text: Selling price
                  - generic [ref=e70]: $16.99
                - cell [ref=e72]:
                  - text: Actions
                  - generic [ref=e73]:
                    - button "Remove" [ref=e74] [cursor=pointer]
                    - button "Show details" [ref=e75] [cursor=pointer]
        - generic [ref=e78]:
          - heading "Preview and print" [level=2] [ref=e79]
          - generic [ref=e80]:
            - generic [ref=e81]:
              - generic [ref=e82]: Saved template
              - combobox "Saved template" [ref=e83] [cursor=pointer]:
                - generic [ref=e84]: Template 1
            - generic [ref=e87]:
              - generic [ref=e88]: Starting slot
              - textbox "Starting slot" [ref=e89]: "5"
          - generic [ref=e90]:
            - region "Live A4 preview" [ref=e91]:
              - generic [ref=e92]:
                - strong [ref=e93]:
                  - text: 18 labels per sheet
                  - generic [ref=e94]: (3 × 6)
                - generic [ref=e95]: Select the first unused slot.
              - img "A4 preview" [ref=e96]:
                - button "Starting slot 1" [ref=e98] [cursor=pointer]:
                  - generic: Used
                - button "Starting slot 2" [ref=e100] [cursor=pointer]:
                  - generic: Used
                - button "Starting slot 3" [ref=e102] [cursor=pointer]:
                  - generic: Used
                - button "Starting slot 4" [ref=e104] [cursor=pointer]:
                  - generic: Used
                - button "Starting slot 5" [pressed] [ref=e106] [cursor=pointer]:
                  - generic: "5"
                  - generic: "0012"
                  - generic: "16.99"
                - button "Starting slot 6" [ref=e108] [cursor=pointer]:
                  - generic: "6"
                - button "Starting slot 7" [ref=e110] [cursor=pointer]:
                  - generic: "7"
                - button "Starting slot 8" [ref=e112] [cursor=pointer]:
                  - generic: "8"
                - button "Starting slot 9" [ref=e114] [cursor=pointer]:
                  - generic: "9"
                - button "Starting slot 10" [ref=e116] [cursor=pointer]:
                  - generic: "10"
                - button "Starting slot 11" [ref=e118] [cursor=pointer]:
                  - generic: "11"
                - button "Starting slot 12" [ref=e120] [cursor=pointer]:
                  - generic: "12"
                - button "Starting slot 13" [ref=e122] [cursor=pointer]:
                  - generic: "13"
                - button "Starting slot 14" [ref=e124] [cursor=pointer]:
                  - generic: "14"
                - button "Starting slot 15" [ref=e126] [cursor=pointer]:
                  - generic: "15"
                - button "Starting slot 16" [ref=e128] [cursor=pointer]:
                  - generic: "16"
                - button "Starting slot 17" [ref=e130] [cursor=pointer]:
                  - generic: "17"
                - button "Starting slot 18" [ref=e132] [cursor=pointer]:
                  - generic: "18"
            - generic [ref=e134]:
              - heading "Grayscale preview" [level=3] [ref=e135]
              - paragraph [ref=e136]: 1 sheet · Print at 100% / Actual size, A4, no browser margins or headers.
              - generic [ref=e141]:
                - generic [ref=e142]:
                  - generic [ref=e143]: $16.99
                  - generic [ref=e146]: SPECIAL
                  - generic [ref=e149]:
                    - strong [ref=e150]: Stainless Steel Pot 24 cm
                    - generic [ref=e151]: قابلمه استیل ۲۴ سانتی‌متری
                  - generic [ref=e152]:
                    - text: "Product Code: 0012 ·"
                    - generic [ref=e153]: 24 cm
                  - generic [ref=e154]: Taxable
                - img "Super Arzon" [ref=e157]
          - button "Print labels" [ref=e159] [cursor=pointer]
```

# Test source

```ts
  1   | import { readCanonicalBusinessEvidence } from "./business-evidence";
  2   | import { writeFile } from "node:fs/promises";
  3   | import { expect, test, type Page } from "@playwright/test";
  4   | import configuration from "../../seed/arzon-config.json" with { type: "json" };
  5   | import Decimal from "decimal.js";
  6   | import { chooseOption, setBranch, signIn } from "./helpers";
  7   | import { inspect, type C5Inspection } from "../scripts/c5-browser-proof.mjs";
  8   | 
  9   | test.setTimeout(180000);
  10  | test.use({ actionTimeout: 10000 });
  11  | const reports = new WeakMap<Page, C5Inspection[]>();
  12  | 
  13  | async function measure(page: Page, screen: string, role = "manager") {
  14  |   const observation = await inspect(
  15  |     page,
  16  |     screen,
  17  |     `${test.info().project.name}-en-light`,
  18  |     role,
  19  |   );
  20  |   const observations = reports.get(page) ?? [];
  21  |   observations.push(observation);
  22  |   reports.set(page, observations);
> 23  |   expect.soft(observation.failures, screen).toEqual([]);
      |                                             ^ Error: Selected product add-to-waitlist action
  24  | }
  25  | 
  26  | test.afterEach(async ({ page }, info) => {
  27  |   const observations = reports.get(page) ?? [];
  28  |   const path = info.outputPath("button-audit.json");
  29  |   await writeFile(path, JSON.stringify(observations, null, 2) + "\n");
  30  |   await info.attach("Conditional rendered button audit", {
  31  |     path,
  32  |     contentType: "application/json",
  33  |   });
  34  | });
  35  | 
  36  | test("C5 conditional request decisions and later lifecycle actions", async ({
  37  |   page,
  38  | }) => {
  39  |   await signIn(page, "Floor Worker");
  40  |   await page.goto("/#requests");
  41  |   await page.getByRole("button", { name: "New request", exact: true }).click();
  42  |   await chooseOption(
  43  |     page,
  44  |     page.getByLabel("Sending location", { exact: true }),
  45  |     "Warehouse",
  46  |   );
  47  |   await page.getByLabel("Search products", { exact: true }).fill("0003");
  48  |   await measure(page, "Request catalog search result", "floor_worker");
  49  |   await page
  50  |     .locator(".request-search-results")
  51  |     .getByRole("button", { name: "Add", exact: true })
  52  |     .click();
  53  |   await page
  54  |     .locator(".request-draft-line")
  55  |     .first()
  56  |     .getByLabel("Quantity", { exact: true })
  57  |     .fill("2");
  58  |   await page.getByRole("button", { name: "Send", exact: true }).click();
  59  |   const reference = await page.locator(".request-detail h2").innerText();
  60  |   await measure(page, "Requested branch request", "floor_worker");
  61  |   await signIn(page, "Manager");
  62  |   await setBranch(page, "Warehouse");
  63  |   await page.goto("/#requests");
  64  |   await page.getByRole("tab", { name: "Incoming", exact: true }).click();
  65  |   await page
  66  |     .getByRole("row")
  67  |     .filter({ hasText: reference })
  68  |     .getByRole("button", { name: reference, exact: true })
  69  |     .click();
  70  |   await page.getByRole("button", { name: "Short", exact: true }).click();
  71  |   await page.getByLabel("Quantity being sent", { exact: true }).fill("1");
  72  |   await measure(page, "Request Short decision and Mark as sent");
  73  |   await page.getByRole("button", { name: "Mark as sent", exact: true }).click();
  74  |   await expect(page.locator(".request-detail-heading .badge")).toContainText(
  75  |     "Sent",
  76  |   );
  77  |   await signIn(page, "Floor Worker");
  78  |   await page.goto("/#requests");
  79  |   await page
  80  |     .getByRole("row")
  81  |     .filter({ hasText: reference })
  82  |     .getByRole("button", { name: reference, exact: true })
  83  |     .click();
  84  |   await page.getByRole("button", { name: "Missing", exact: true }).click();
  85  |   await page.getByLabel("Quantity arrived", { exact: true }).fill("0");
  86  |   await measure(
  87  |     page,
  88  |     "Request Missing decision and Mark as received",
  89  |     "floor_worker",
  90  |   );
  91  |   await page
  92  |     .getByRole("button", { name: "Mark as received", exact: true })
  93  |     .click();
  94  |   await expect(page.locator(".request-detail-heading .badge")).toContainText(
  95  |     "Received",
  96  |   );
  97  |   await measure(page, "Received request and Close request", "floor_worker");
  98  |   await page
  99  |     .getByRole("button", { name: "Close request", exact: true })
  100 |     .click();
  101 |   await measure(
  102 |     page,
  103 |     "Closed request and residual-copy action",
  104 |     "floor_worker",
  105 |   );
  106 |   await page
  107 |     .getByRole("button", { name: "Copy short or missing items", exact: true })
  108 |     .click();
  109 |   await measure(page, "Copied short or missing draft", "floor_worker");
  110 | });
  111 | 
  112 | test("C5 conditional reauthentication dialog", async ({ page }) => {
  113 |   await page.clock.install({ time: new Date() });
  114 |   await signIn(page, "Manager");
  115 |   await page.goto("/#settings");
  116 |   // Advance the real browser source clock beyond the configured freshness
  117 |   // window, keeping activity inside the idle-lock window. No identity, role,
  118 |   // session timestamp or authority record is manufactured or overwritten.
  119 |   for (
  120 |     let minute = 0;
  121 |     minute <= configuration.session.reprompt_password_after_minutes;
  122 |     minute++
  123 |   ) {
```