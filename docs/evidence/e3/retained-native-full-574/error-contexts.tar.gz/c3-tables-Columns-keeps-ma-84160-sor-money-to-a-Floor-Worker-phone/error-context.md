# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: c3-tables.spec.ts >> Columns keeps mandatory names, persists by user and never exposes Supervisor money to a Floor Worker
- Location: tests/c3-tables.spec.ts:292:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: /^(Sign in|ورود)$/ })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('heading', { name: /^(Sign in|ورود)$/ }) with timeout 5000ms
  - waiting for getByRole('heading', { name: /^(Sign in|ورود)$/ })

```

```yaml
- link "Skip to content":
  - /url: "#main-content"
- banner:
  - button "Open menu"
  - combobox "Location": North York
  - button "Notifications, 5 unread": "5"
  - button "User menu"
  - button "More"
- main:
  - heading "Manager dashboard" [level=1]
  - paragraph: Your branch priorities, approvals, and recent activity.
  - button "Review approvals"
  - 'button "Approvals waiting: 3"':
    - text: Approvals waiting
    - strong: "3"
    - text: 1 price change · 1 new product
  - 'button "Open alerts: 3"':
    - text: Open alerts
    - strong: "3"
    - text: 0 lower prices · 1 conflict
  - 'button "Open shorts: 0"':
    - text: Open shorts
    - strong: "0"
    - text: Items waiting for delivery
  - 'button "Expiring soon: 2"':
    - text: Expiring soon
    - strong: "2"
    - text: Within each product's reminder window
  - heading "Approvals queue" [level=2]
  - heading "Sunflower Oil 1.8 L روغن آفتابگردان ۱٫۸ لیتری" [level=3]:
    - strong: Sunflower Oil 1.8 L
    - text: روغن آفتابگردان ۱٫۸ لیتری
  - text: Sale request
  - strong: $7.99
  - text: North York 2026-10-15 – 2026-10-28
  - paragraph: "Requested by: Demo North York Floor Worker · Why? slow seller"
  - paragraph: Margin at this price 24%
  - paragraph: This price is below the minimum margin.
  - checkbox "Use this price anyway"
  - button "Approve"
  - button "Change and approve"
  - button "Reject"
  - strong: Lavash Bread 500 g
  - text: نان لواش ۵۰۰ گرمی 0006 Price change Old $1.99 New $2.99 North York
  - button "Approve"
  - button "More"
  - strong: Dried Barberries 100 g
  - text: زرشک خشک ۱۰۰ گرمی 0015 New product Old — New $5.49 North York
  - button "Approve"
  - button "More"
  - heading "Alerts" [level=2]
  - strong: Black Tea 450 g
  - text: All branches Conflict
  - button "Review"
  - strong: Lavash Bread 500 g
  - text: North York Date tracking
  - button "Review"
  - strong: Sour Cherry Juice 1 L
  - text: North York Date tracking
  - button "Review"
  - heading "Recent invoices" [level=2]
  - table:
    - rowgroup:
      - row "Fresh Valley Foods Posted View FV-20390 North York 2026-10-14":
        - cell "Fresh Valley Foods"
        - cell "Posted"
        - cell "View":
          - link "View":
            - /url: "#invoices?id=a2-fixture%3AFV-20390"
        - cell "FV-20390 North York 2026-10-14"
      - row "Golden Grain Distributors Posted View GG-11879 North York 2026-10-10":
        - cell "Golden Grain Distributors"
        - cell "Posted"
        - cell "View":
          - link "View":
            - /url: "#invoices?id=a2-fixture%3AGG-11879"
        - cell "GG-11879 North York 2026-10-10"
      - row "Sunrise Beverages Posted View SB-7862 North York 2026-10-06":
        - cell "Sunrise Beverages"
        - cell "Posted"
        - cell "View":
          - link "View":
            - /url: "#invoices?id=a2-fixture%3ASB-7862"
        - cell "SB-7862 North York 2026-10-06"
      - row "Sunrise Beverages Posted View SB-7848 North York 2026-10-05":
        - cell "Sunrise Beverages"
        - cell "Posted"
        - cell "View":
          - link "View":
            - /url: "#invoices?id=a2-fixture%3ASB-7848"
        - cell "SB-7848 North York 2026-10-05"
      - row "HomeWare Imports Posted View HW-4910 Newmarket 2026-09-28":
        - cell "HomeWare Imports"
        - cell "Posted"
        - cell "View":
          - link "View":
            - /url: "#invoices?id=a2-fixture%3AHW-4910"
        - cell "HW-4910 Newmarket 2026-09-28"
  - heading "Returns" [level=2]
  - button "View all returns"
  - strong: Fresh Valley Foods
  - text: North York · Sour Cherry Juice 1 L Open
  - link "View":
    - /url: "#return?id=demo-return-1"
  - strong: Golden Grain Distributors
  - text: North York · Basmati Rice 4.5 kg Partially resolved
  - link "View":
    - /url: "#return?id=demo-return-2"
  - heading "Supplier balances" [level=2]
  - table:
    - rowgroup:
      - row "HomeWare Imports Balance $1,260.00 Open invoices 1 Action View Show details":
        - cell "HomeWare Imports"
        - cell "Balance $1,260.00"
        - cell "Open invoices 1"
        - cell "Action View Show details":
          - text: Action
          - link "View":
            - /url: "#payables"
          - button "Show details"
      - row "Golden Grain Distributors Balance $842.10 Open invoices 2 Action View Show details":
        - cell "Golden Grain Distributors"
        - cell "Balance $842.10"
        - cell "Open invoices 2"
        - cell "Action View Show details":
          - text: Action
          - link "View":
            - /url: "#payables"
          - button "Show details"
      - row "Fresh Valley Foods Balance $169.79 Open invoices 1 Action View Show details":
        - cell "Fresh Valley Foods"
        - cell "Balance $169.79"
        - cell "Open invoices 1"
        - cell "Action View Show details":
          - text: Action
          - link "View":
            - /url: "#payables"
          - button "Show details"
      - row "Sunrise Beverages Balance $96.40 Open invoices 1 Action View Show details":
        - cell "Sunrise Beverages"
        - cell "Balance $96.40"
        - cell "Open invoices 1"
        - cell "Action View Show details":
          - text: Action
          - link "View":
            - /url: "#payables"
          - button "Show details"
      - row "Corner Spice Co. Balance $0.00 Open invoices 0 Action View Show details":
        - cell "Corner Spice Co."
        - cell "Balance $0.00"
        - cell "Open invoices 0"
        - cell "Action View Show details":
          - text: Action
          - link "View":
            - /url: "#payables"
          - button "Show details"
  - heading "Purchases by supplier, this month" [level=2]
  - list:
    - listitem: Golden Grain Distributors $636.00
    - listitem: Fresh Valley Foods $181.22
    - listitem: Sunrise Beverages $133.59
  - paragraph: Net purchases · CAD
  - heading "Purchases, last 8 weeks" [level=2]
  - img "Net purchases by week"
  - text: 2026-08-21 2026-09-04 2026-09-18 2026-10-09
  - paragraph: Net purchases · CAD
  - heading "Arrived this week" [level=2]
  - strong:
    - strong: Canned Fava Beans 400 g
    - text: باقالا کنسرو شده ۴۰۰ گرمی
  - text: North York · 2026-10-14 · FV-20390 24 units
  - link "View":
    - /url: "#received?product=0002"
  - strong:
    - strong: Ground Sumac 100 g
    - text: سماق ۱۰۰ گرمی
  - text: North York · 2026-10-14 · FV-20390 12 units
  - link "View":
    - /url: "#received?product=0005"
  - strong:
    - strong: Lavash Bread 500 g
    - text: نان لواش ۵۰۰ گرمی
  - text: North York · 2026-10-14 · FV-20390 20 units
  - link "View":
    - /url: "#received?product=0006"
  - strong:
    - strong: Sour Cherry Juice 1 L
    - text: آب آلبالو ۱ لیتری
  - text: North York · 2026-10-14 · FV-20390 36 units
  - link "View":
    - /url: "#received?product=0003"
  - strong:
    - strong: Dried Barberries 100 g
    - text: زرشک خشک ۱۰۰ گرمی
  - text: North York · 2026-10-14 · FV-20390 6 units
  - link "View":
    - /url: "#received?product=0015"
  - strong:
    - strong: Potato Chips 150 g
    - text: چیپس سیب‌زمینی ۱۵۰ گرمی
  - text: North York · 2026-10-14 · FV-20390 12 units
  - link "View":
    - /url: "#received?product=0009"
  - heading "Price changes this week" [level=2]
  - strong: Black Tea 450 g
  - text: Demo Supervisor · North York · 2026-10-14 · $6.49 Approved
  - link "View":
    - /url: "#product?code=0004"
  - strong: Dried Red Kidney Beans 900 g
  - text: Demo Supervisor · North York · 2026-10-13 · $3.99 Approved
  - link "View":
    - /url: "#product?code=0007"
  - complementary "Notes and activity":
    - heading "Price updates to apply" [level=2]
    - button "View all 0"
    - paragraph: No pending price updates.
    - heading "Notes for Manager" [level=2]
    - strong: Customer asked about the tea glass set price; please confirm.
    - text: Demo Floor Worker · North York ·
    - time: Just now
    - text: Open
    - link "View":
      - /url: "#notes"
    - heading "Activity" [level=2]
    - list:
      - listitem:
        - strong: Start sale
        - text: Stainless Steel Pot 24 cm System · North York
        - time: Just now
      - listitem:
        - strong: Approve price
        - text: Black Tea 450 g Demo Supervisor · North York
        - time: 1 d ago
      - listitem:
        - strong: Approve price
        - text: Dried Red Kidney Beans 900 g Demo Supervisor · North York
        - time: 2 d ago
```

# Test source

```ts
  1   | import { createHash } from "node:crypto";
  2   | import { readCanonicalBusinessEvidence } from "./business-evidence";
  3   | import { expect, type Locator, type Page } from "@playwright/test";
  4   | import demoSeed from "../../seed/demo-data.json" with { type: "json" };
  5   | import configuration from "../../seed/arzon-config.json" with { type: "json" };
  6   | import { AUTH_IDENTITY_KEY } from "../src/auth-preferences.e1";
  7   | 
  8   | export type DemoRole =
  9   |   | "Cashier"
  10  |   | "Floor Worker"
  11  |   | "Supervisor"
  12  |   | "cashier"
  13  |   | "floor_worker"
  14  |   | "supervisor"
  15  |   | "Owner"
  16  |   | "Manager"
  17  |   | "Branch Supervisor"
  18  |   | "owner"
  19  |   | "manager"
  20  |   | "branch_supervisor"
  21  |   | "ny-floor"
  22  |   | "wh-floor";
  23  | 
  24  | export async function openShellAction(page: Page, name: string) {
  25  |   const direct = page.getByRole("button", { name, exact: true });
  26  |   if (await direct.isVisible()) return direct;
  27  |   const item = page.getByRole("menuitem", { name, exact: true });
  28  |   if (!(await item.isVisible()))
  29  |     await page.locator(".mobile-more-menu").click();
  30  |   await expect(item).toBeVisible();
  31  |   return item;
  32  | }
  33  | 
  34  | export async function signIn(page: Page, role: DemoRole) {
  35  |   // Retained Supervisor cases exercise the same configured Manager person;
  36  |   // the legacy name is not an authority role or a fabricated seventh account.
  37  |   const username = {
  38  |     Cashier: "cashier",
  39  |     "Floor Worker": "ny-floor",
  40  |     Supervisor: "manager",
  41  |     cashier: "cashier",
  42  |     floor_worker: "ny-floor",
  43  |     supervisor: "manager",
  44  |     Owner: "owner",
  45  |     Manager: "manager",
  46  |     "Branch Supervisor": "rh-supervisor",
  47  |     owner: "owner",
  48  |     manager: "manager",
  49  |     branch_supervisor: "rh-supervisor",
  50  |     "ny-floor": "ny-floor",
  51  |     "wh-floor": "wh-floor",
  52  |   }[role];
  53  |   const account = demoSeed.demo_users.find(
  54  |     (user) => user.username === username,
  55  |   );
  56  |   if (!account)
  57  |     throw new Error(`Configured Demo person is missing: ${username}`);
  58  |   if (await page.locator(".topbar").isVisible()) {
  59  |     const fa = (await page.locator("html").getAttribute("lang")) === "fa";
  60  |     await (await openShellAction(page, fa ? "دمو" : "Demo")).click();
  61  |     await page
  62  |       .getByRole("menuitem", {
  63  |         name: fa
  64  |           ? `تغییر به ${account.name_fa}`
  65  |           : `Switch to ${account.name_en}`,
  66  |         exact: true,
  67  |       })
  68  |       .click();
  69  |   } else {
  70  |     await page.goto("/");
  71  |     const heading = page.getByRole("heading", { name: /^(Sign in|ورود)$/ });
> 72  |     await expect(heading).toBeVisible();
      |                           ^ Error: expect(locator).toBeVisible() failed
  73  |     const fa = (await heading.innerText()) === "ورود";
  74  |     await page
  75  |       .getByLabel(fa ? "نام کاربری" : "Username", { exact: true })
  76  |       .fill(account.username);
  77  |     await page
  78  |       .getByLabel(fa ? "گذرواژه" : "Password", { exact: true })
  79  |       .fill(account.password ?? "demo1234");
  80  |     await page
  81  |       .getByRole("button", { name: fa ? "ورود" : "Sign in", exact: true })
  82  |       .click();
  83  |     if (["owner", "manager", "branch_supervisor"].includes(account.role)) {
  84  |       // The normal privileged flow includes the real simulated challenge;
  85  |       // only the explicitly invoked Demo menu uses its configured shortcut.
  86  |       if (account.setup.second_step_method === "authenticator") {
  87  |         await page
  88  |           .getByLabel(fa ? "کد برنامهٔ احراز هویت" : "Authenticator app code", {
  89  |             exact: true,
  90  |           })
  91  |           .fill(configuration.session.simulated_authenticator_code);
  92  |         await page
  93  |           .getByRole("button", { name: fa ? "ادامه" : "Continue", exact: true })
  94  |           .click();
  95  |       } else {
  96  |         await page
  97  |           .getByRole("button", {
  98  |             name: fa
  99  |               ? "استفاده از کلید ورود شبیه‌سازی‌شده"
  100 |               : "Use simulated passkey",
  101 |             exact: true,
  102 |           })
  103 |           .click();
  104 |       }
  105 |     }
  106 |   }
  107 |   await expect(page.locator(".topbar")).toBeVisible();
  108 |   const fa = (await page.locator("html").getAttribute("lang")) === "fa";
  109 |   await expect(page.locator(".user-chip-copy strong")).toHaveText(
  110 |     fa ? account.name_fa : account.name_en,
  111 |   );
  112 |   // These controls only mount after actual session completion and the current
  113 |   // protected projection. E1 canonical business persistence is IndexedDB.
  114 |   await expect(
  115 |     page
  116 |       .locator(".topbar")
  117 |       .getByRole("combobox", { name: fa ? "مکان" : "Location", exact: true }),
  118 |   ).toBeEnabled();
  119 | }
  120 | 
  121 | export async function chooseOption(
  122 |   page: Page,
  123 |   control: Locator,
  124 |   value: string,
  125 |   label = value,
  126 | ) {
  127 |   await expect(control).toHaveAttribute("role", "combobox");
  128 |   await control.click();
  129 |   await page.getByRole("option", { name: label, exact: true }).click();
  130 | }
  131 | 
  132 | export async function setBranch(page: Page, branch: string) {
  133 |   const fa = (await page.locator("html").getAttribute("lang")) === "fa";
  134 |   const control = page
  135 |     .locator(".topbar")
  136 |     .getByRole("combobox", { name: fa ? "مکان" : "Location", exact: true });
  137 |   if (branch === "all") {
  138 |     await control.click();
  139 |     await page
  140 |       .getByRole("option", {
  141 |         name: fa
  142 |           ? /^(همه مکان‌ها|همه مکان‌های من)$/
  143 |           : /^All (locations|my locations)$/,
  144 |       })
  145 |       .click();
  146 |     await expect(control).toBeEnabled();
  147 |     return;
  148 |   }
  149 |   const location = configuration.branches.find((row) => row.id === branch);
  150 |   await chooseOption(
  151 |     page,
  152 |     control,
  153 |     branch,
  154 |     (fa ? location?.name_fa : location?.name) ?? branch,
  155 |   );
  156 |   await expect(control).toBeEnabled();
  157 | }
  158 | 
  159 | export async function setLanguage(page: Page, language: "en" | "fa") {
  160 |   if ((await page.locator("html").getAttribute("lang")) === language) return;
  161 |   await (
  162 |     await openShellAction(
  163 |       page,
  164 |       language === "fa" ? "Switch to Persian" : "تغییر به انگلیسی",
  165 |     )
  166 |   ).click();
  167 | }
  168 | 
  169 | export async function resetDemo(page: Page) {
  170 |   const fa = (await page.locator("html").getAttribute("lang")) === "fa";
  171 |   const locationName = fa ? "مکان" : "Location";
  172 |   const beforeLocation = (
```