# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: suppliers-a2.spec.ts >> Cashier cannot open Suppliers through a direct address
- Location: tests/suppliers-a2.spec.ts:157:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: 'Cashier lookup', exact: true })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('heading', { name: 'Cashier lookup', exact: true }) with timeout 5000ms
  - waiting for getByRole('heading', { name: 'Cashier lookup', exact: true })

```

```yaml
- link "Skip to content":
  - /url: "#main-content"
- complementary "Main menu":
  - img "Super Arzon"
  - text: Super Arzon
  - navigation "Pages":
    - button "Daily" [expanded]
    - link "Lookup":
      - /url: "#lookup"
  - button "User menu":
    - strong: Demo Cashier
    - text: Cashier
- banner:
  - button "Collapse sidebar" [expanded]
  - navigation "Breadcrumbs":
    - link "North York":
      - /url: "#lookup"
    - link "Lookup":
      - /url: "#lookup"
    - link "Fresh Valley Foods":
      - /url: "#suppliers?name=Fresh%20Valley%20Foods"
  - search:
    - textbox "Search all products":
      - /placeholder: Search products
  - combobox "Location": North York
  - button "Switch to Persian": فا
  - button "Switch to dark theme"
  - button "Comfortable text size"
  - button "Notifications, 0 unread"
  - button "Demo"
- main:
  - paragraph: You do not have permission for this action.
```

# Test source

```ts
  67  |   await expect(page).toHaveURL(/#suppliers\?name=Fresh%20Valley%20Foods/);
  68  |   await expect(
  69  |     page.getByRole("heading", { name: "Fresh Valley Foods", exact: true }),
  70  |   ).toBeVisible();
  71  |   await page.getByRole("tab", { name: "Invoices", exact: true }).click();
  72  |   const content = page.locator(".supplier-tab-card");
  73  |   await expectSupplierField(content, "Outstanding");
  74  |   const invoiceRow = content
  75  |     .getByRole("row")
  76  |     .filter({ hasText: "FV-20390" })
  77  |     .first();
  78  |   if ((await invoiceRow.innerText()).includes("$169.79")) {
  79  |     await expect(invoiceRow).toContainText("$169.79");
  80  |   } else {
  81  |     const disclosure = invoiceRow.locator(".table-details-toggle");
  82  |     const panelId = await disclosure.getAttribute("aria-controls");
  83  |     if ((await disclosure.getAttribute("aria-expanded")) !== "true")
  84  |       await disclosure.click();
  85  |     await expect(
  86  |       content.locator(`[id=${JSON.stringify(panelId)}]`),
  87  |     ).toContainText("$169.79");
  88  |   }
  89  |   await page.getByRole("tab", { name: "Supplier items", exact: true }).click();
  90  |   await expectSupplierField(content, "Last bought / case");
  91  |   await expectSupplierField(content, "Last bought / unit");
  92  |   await page.getByRole("tab", { name: "Payments", exact: true }).click();
  93  |   await expectSupplierField(content, "Amount");
  94  |   await page
  95  |     .getByRole("button", { name: "Back to Suppliers", exact: true })
  96  |     .click();
  97  |   await setBranch(page, "Richmond Hill");
  98  |   await expect(
  99  |     page.locator(".suppliers-overview .money").filter({ hasText: "$169.79" }),
  100 |   ).toHaveCount(0);
  101 | });
  102 | 
  103 | for (const language of ["en", "fa"] as const) {
  104 |   test(`Floor Worker supplier overview and every tab omit financial DOM in ${language}`, async ({
  105 |     page,
  106 |   }) => {
  107 |     await signIn(page, "Floor Worker");
  108 |     await page.goto("/#suppliers");
  109 |     if (language === "fa") await setLanguage(page, "fa");
  110 |     const overview = page.locator(".suppliers-overview");
  111 |     await expect(overview.locator(".money")).toHaveCount(0);
  112 |     await expect(
  113 |       overview.getByRole("columnheader", {
  114 |         name: /^(Balance|Overdue|Next due date|مانده|سررسید گذشته|سررسید بعدی)/,
  115 |       }),
  116 |     ).toHaveCount(0);
  117 |     await overview
  118 |       .getByRole("row")
  119 |       .filter({ hasText: "Fresh Valley Foods" })
  120 |       .getByRole("link", {
  121 |         name: "Fresh Valley Foods",
  122 |         exact: true,
  123 |       })
  124 |       .click();
  125 |     await expect(
  126 |       page.getByRole("heading", { name: "Fresh Valley Foods", exact: true }),
  127 |     ).toBeVisible();
  128 |     await expect(page.locator(".supplier-kpis .money")).toHaveCount(0);
  129 |     await expect(
  130 |       page.getByRole("tab", {
  131 |         name: language === "en" ? "Payments" : "پرداخت‌ها",
  132 |         exact: true,
  133 |       }),
  134 |     ).toHaveCount(0);
  135 |     const tabs = page.locator(".supplier-tabs").getByRole("tab");
  136 |     const count = await tabs.count();
  137 |     expect(count).toBe(8);
  138 |     for (let index = 0; index < count; index += 1) {
  139 |       await tabs.nth(index).click();
  140 |       const content = page.locator(".supplier-tab-card");
  141 |       await expect(content.locator(".money")).toHaveCount(0);
  142 |       await expect(
  143 |         content.getByRole("columnheader", {
  144 |           name: /^(Total|Outstanding|Last cost|Cost history|Credit or compensation|Amount|جمع|مانده پرداخت|آخرین هزینه|تاریخچه هزینه|اعتبار یا جبران|مبلغ)$/,
  145 |         }),
  146 |       ).toHaveCount(0);
  147 |       const branchCells = content.getByRole("cell", {
  148 |         name: /^(Richmond Hill|Newmarket|Warehouse|ریچموند هیل|نیومارکت|انبار)$/,
  149 |       });
  150 |       await expect(branchCells).toHaveCount(0);
  151 |     }
  152 |     const supplierName = page.locator(".page-header h1 bdi");
  153 |     await expect(supplierName).toHaveAttribute("dir", "ltr");
  154 |   });
  155 | }
  156 | 
  157 | test("Cashier cannot open Suppliers through a direct address", async ({
  158 |   page,
  159 | }) => {
  160 |   await signIn(page, "Cashier");
  161 |   await page.goto("/#suppliers?name=Fresh%20Valley%20Foods");
  162 |   await expect(
  163 |     page.locator(".suppliers-overview, .supplier-header-card"),
  164 |   ).toHaveCount(0);
  165 |   await expect(
  166 |     page.getByRole("heading", { name: "Cashier lookup", exact: true }),
> 167 |   ).toBeVisible();
      |     ^ Error: expect(locator).toBeVisible() failed
  168 | });
  169 | 
```