# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: c5-button-audit.spec.ts >> C5 button contract covers primary product, date, approval and invoice dialogs
- Location: tests/c5-button-audit.spec.ts:427:1

# Error details

```
Error: Add product dialog: en-light

expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 18

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

```
TimeoutError: locator.click: Timeout 10000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: 'Edit Potato Chips 150 g', exact: true })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=e5]:
    - banner [ref=e6]:
      - button "Open menu" [ref=e7] [cursor=pointer]
      - combobox "Location" [ref=e11] [cursor=pointer]:
        - generic [ref=e16]: North York
      - button "Notifications, 5 unread" [ref=e19] [cursor=pointer]:
        - generic [ref=e20]: "5"
      - button "User menu" [ref=e25] [cursor=pointer]:
        - generic [aria-hidden] [ref=e27]: DM
      - button "More" [ref=e28] [cursor=pointer]
    - main [ref=e34]:
      - generic [ref=e35]:
        - generic [ref=e36]:
          - generic [ref=e37]:
            - heading "Products" [level=1] [ref=e38]
            - paragraph [ref=e39]: Approved prices, pending changes and branch details in one catalog.
          - button "Add product" [ref=e41] [cursor=pointer]
        - generic [ref=e42]:
          - generic [ref=e43]:
            - searchbox "Search products" [active] [ref=e48]: "0009"
            - combobox "Pricing category" [ref=e49] [cursor=pointer]:
              - generic [ref=e50]: All pricing categories
            - combobox "AI category" [ref=e53] [cursor=pointer]:
              - generic [ref=e54]: All AI categories
            - combobox "Status" [ref=e57] [cursor=pointer]:
              - generic [ref=e58]: All statuses
            - combobox "Supplier" [ref=e61] [cursor=pointer]:
              - generic [ref=e62]: All suppliers
            - checkbox "Has pending price" [ref=e65] [cursor=pointer]
            - checkbox "Has offer" [ref=e68] [cursor=pointer]
            - checkbox "Manual prices" [ref=e71] [cursor=pointer]
            - checkbox "On sale" [ref=e74] [cursor=pointer]
            - button "Clear filters" [ref=e77] [cursor=pointer]
            - generic [ref=e79]:
              - generic [ref=e80]: 1 product
              - button "Columns" [ref=e81] [cursor=pointer]
          - generic [ref=e85]:
            - table [ref=e87]:
              - rowgroup [ref=e88]:
                - row [ref=e89]:
                  - cell "Potato Chips 150 g چیپس سیب‌زمینی ۱۵۰ گرمی 150 g" [ref=e90]:
                    - link "Potato Chips 150 g" [ref=e91] [cursor=pointer]:
                      - /url: "#product?code=0009"
                      - strong [ref=e92]:
                        - generic [ref=e94]:
                          - text: Potato Chips
                          - generic [ref=e95]: 150 g
                    - paragraph [ref=e96]:
                      - generic [ref=e98]:
                        - text: چیپس سیب‌زمینی
                        - generic [ref=e99]: ۱۵۰ گرمی
                    - paragraph [ref=e100]:
                      - generic [ref=e101]: 150 g
                  - cell "$2.99" [ref=e104]
                  - cell [ref=e107]:
                    - link "Open Potato Chips 150 g" [ref=e108] [cursor=pointer]:
                      - /url: "#product?code=0009"
                  - cell "0009 Approved 2 for $5.00" [ref=e111]:
                    - generic [ref=e112]: "0009"
                    - generic [ref=e115]:
                      - generic [ref=e116]: Approved
                      - generic [ref=e117]: 2 for $5.00
            - generic [ref=e119]:
              - button "Previous" [disabled] [ref=e120]
              - generic [ref=e121]: Page 1 of 1 · 1 product
              - button "Next" [disabled] [ref=e122]
```

# Test source

```ts
  343 |       .getByRole("button", { name: "تغییر به انگلیسی", exact: true })
  344 |       .click();
  345 |     // Fresh E1 has six complete Demo people. Exercise first sign-in by
  346 |     // inviting an actual seventh person through the protected Owner screen.
  347 |     await signIn(page, "Owner");
  348 |     await page.goto("/#settings?group=people");
  349 |     await page.getByRole("button", { name: "Add person", exact: true }).click();
  350 |     const editor = page.getByRole("dialog", {
  351 |       name: "Add person",
  352 |       exact: true,
  353 |     });
  354 |     await editor
  355 |       .getByLabel("English name", { exact: true })
  356 |       .fill("Demo New Employee");
  357 |     await editor.getByLabel("Username", { exact: true }).fill("newemployee");
  358 |     await editor
  359 |       .getByLabel("Email", { exact: true })
  360 |       .fill("newemployee@example.test");
  361 |     await editor
  362 |       .getByRole("checkbox", { name: "North York", exact: true })
  363 |       .check();
  364 |     await editor.getByRole("button", { name: "Save", exact: true }).click();
  365 |     const setup = page.getByRole("dialog", {
  366 |       name: "One-time setup code",
  367 |       exact: true,
  368 |     });
  369 |     await expect(setup).toBeVisible();
  370 |     const setupCode = (
  371 |       await setup.locator(".one-time-setup-code").innerText()
  372 |     ).trim();
  373 |     expect(setupCode).not.toBe("");
  374 |     await setup.getByRole("button", { name: "Close", exact: true }).click();
  375 |     const ownerMenu = page.getByRole("button", {
  376 |       name: "User menu",
  377 |       exact: true,
  378 |     });
  379 |     if (!(await ownerMenu.isVisible()))
  380 |       await page.locator("#menu-toggle").click();
  381 |     await ownerMenu.click();
  382 |     await page.getByRole("menuitem", { name: "Sign out", exact: true }).click();
  383 |     await page.getByLabel("Username", { exact: true }).fill("newemployee");
  384 |     await page.getByLabel("Password", { exact: true }).fill(setupCode);
  385 |     await page.getByRole("button", { name: "Sign in", exact: true }).click();
  386 |     await expect(
  387 |       page.getByRole("heading", { name: "Choose a new password", exact: true }),
  388 |     ).toBeVisible();
  389 |     await measure("Choose a new password", "en-light", "floor_worker");
  390 |     await page
  391 |       .getByRole("button", { name: "Switch to Persian", exact: true })
  392 |       .click();
  393 |     await measure("Choose a new password", "fa-light", "floor_worker");
  394 |     await page
  395 |       .getByRole("button", { name: "تغییر به انگلیسی", exact: true })
  396 |       .click();
  397 |     await page.getByRole("button", { name: "Sign out", exact: true }).click();
  398 |     await signIn(page, "Supervisor");
  399 |     await setBranch(page, "Branch 1");
  400 |     await appearance(page, "en-dark");
  401 |     const userMenu = page.getByRole("button", {
  402 |       name: "User menu",
  403 |       exact: true,
  404 |     });
  405 |     if (!(await userMenu.isVisible()))
  406 |       await page.locator("#menu-toggle").click();
  407 |     await userMenu.click();
  408 |     await page.getByRole("menuitem", { name: "Lock", exact: true }).click();
  409 |     await expect(
  410 |       page.getByRole("heading", { name: "Screen locked", exact: true }),
  411 |     ).toBeVisible();
  412 |     await measure("Screen locked", "en-dark", "supervisor");
  413 |     await page
  414 |       .getByRole("button", { name: "Switch to Persian", exact: true })
  415 |       .click();
  416 |     await measure("Screen locked", "fa-dark", "supervisor");
  417 |   } finally {
  418 |     const output = info.outputPath("button-audit.json");
  419 |     await writeFile(output, JSON.stringify(reports, null, 2));
  420 |     await info.attach("Rendered auth button audit", {
  421 |       path: output,
  422 |       contentType: "application/json",
  423 |     });
  424 |   }
  425 | });
  426 | 
  427 | test("C5 button contract covers primary product, date, approval and invoice dialogs", async ({
  428 |   page,
  429 | }, info) => {
  430 |   const proof = audit(page, info);
  431 |   try {
  432 |     await signIn(page, "Supervisor");
  433 |     await setBranch(page, "Branch 1");
  434 |     await page.goto("/#products");
  435 |     await page
  436 |       .getByRole("button", { name: "Add product", exact: true })
  437 |       .click();
  438 |     await proof.check("Add product dialog");
  439 |     await closeDialog(page);
  440 |     await page.getByLabel("Search products", { exact: true }).fill("0009");
  441 |     await page
  442 |       .getByRole("button", { name: "Edit Potato Chips 150 g", exact: true })
> 443 |       .click();
      |        ^ TimeoutError: locator.click: Timeout 10000ms exceeded.
  444 |     await proof.check("Edit product dialog");
  445 |     await closeDialog(page);
  446 | 
  447 |     await page.goto("/#expiry");
  448 |     const dateRow = page
  449 |       .locator(".expiry-table tbody tr")
  450 |       .filter({
  451 |         has: page.getByRole("button", { name: "Remove", exact: true }),
  452 |       })
  453 |       .first();
  454 |     await dateRow.getByRole("button", { name: "Remove", exact: true }).click();
  455 |     await expect(
  456 |       page.getByRole("dialog", { name: "Remove date", exact: true }),
  457 |     ).toBeVisible();
  458 |     await proof.check("Remove date reason dialog");
  459 |     await closeDialog(page);
  460 |     await dateRow.getByRole("button", { name: "More", exact: true }).click();
  461 |     await page
  462 |       .getByRole("menuitem", {
  463 |         name: "Stop tracking this product",
  464 |         exact: true,
  465 |       })
  466 |       .click();
  467 |     await expect(
  468 |       page.getByRole("dialog", {
  469 |         name: "Stop tracking this product",
  470 |         exact: true,
  471 |       }),
  472 |     ).toBeVisible();
  473 |     await proof.check("Stop tracking this product dialog");
  474 |     await closeDialog(page);
  475 | 
  476 |     await page.goto("/#alerts");
  477 |     await page
  478 |       .getByRole("button", { name: "Apply this price to all", exact: true })
  479 |       .first()
  480 |       .click();
  481 |     await expect(
  482 |       page.getByRole("dialog", {
  483 |         name: "Apply price to all branches",
  484 |         exact: true,
  485 |       }),
  486 |     ).toBeVisible();
  487 |     await proof.check("Apply conflict price to all branches dialog");
  488 |     await closeDialog(page);
  489 | 
  490 |     await page.goto("/#approvals");
  491 |     const approval = page.locator("section.card").filter({
  492 |       has: page.getByRole("heading", {
  493 |         name: "Lavash Bread 500 g",
  494 |         exact: true,
  495 |       }),
  496 |     });
  497 |     await approval
  498 |       .getByRole("button", { name: "Approve price", exact: true })
  499 |       .click();
  500 |     await expect(
  501 |       page.getByRole("dialog", { name: "Review approval", exact: true }),
  502 |     ).toBeVisible();
  503 |     await proof.check("Review approval confirmation");
  504 |     await closeDialog(page);
  505 |     await approval.getByRole("button", { name: "Reject", exact: true }).click();
  506 |     await expect(
  507 |       page.getByRole("dialog", { name: "Reject proposal", exact: true }),
  508 |     ).toBeVisible();
  509 |     await proof.check("Reject proposal confirmation");
  510 |     await closeDialog(page);
  511 | 
  512 |     await page.goto("/#invoices");
  513 |     await page
  514 |       .getByRole("button", { name: "New invoice", exact: true })
  515 |       .click();
  516 |     await proof.check("New invoice upload entry");
  517 |     await uploadInvoice(page);
  518 |     await expect(page.locator(".invoice-line")).toHaveCount(6);
  519 |     await proof.check("Simulated invoice upload review");
  520 |   } finally {
  521 |     await proof.save();
  522 |   }
  523 | });
  524 | 
```