# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: invoices.spec.ts >> simulated upload, review, lower-price answer and two partial chip deliveries conserve stock and cents
- Location: tests/invoices.spec.ts:64:1

# Error details

```
Error: locator.check: Clicking the checkbox did not change its state
Call log:
  - waiting for locator('.invoice-line').nth(5).getByRole('checkbox', { name: 'Mark as short', exact: true })
    - locator resolved to <button type="button" role="checkbox" aria-checked="false" class="ui-checked-control">…</button>
  - attempting click action
    - waiting for element to be visible, enabled and stable
    - element is visible, enabled and stable
    - scrolling into view if needed
    - done scrolling
    - performing click action
    - click action done
    - waiting for scheduled navigations to finish
    - navigations have finished

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=e5]:
    - banner [ref=e6]:
      - button "Open menu" [ref=e7] [cursor=pointer]
      - combobox "Location" [ref=e11] [cursor=pointer]:
        - generic [ref=e16]: North York
      - button "Notifications, 0 unread" [ref=e19] [cursor=pointer]
      - button "User menu" [ref=e24] [cursor=pointer]:
        - generic [aria-hidden] [ref=e26]: DN
      - button "More" [ref=e27] [cursor=pointer]
    - main [ref=e33]:
      - generic [ref=e34]:
        - link "Back to Invoices" [ref=e35] [cursor=pointer]:
          - /url: "#invoices"
        - generic [ref=e38]:
          - generic [ref=e39]:
            - heading "Invoices" [level=1] [ref=e40]
            - paragraph [ref=e41]: Deliveries and supplier invoices
          - button "New invoice" [ref=e43] [cursor=pointer]
        - tablist "Invoice views" [ref=e44]:
          - tab "Drafts" [ref=e45] [cursor=pointer]
          - tab "Processing" [ref=e47] [cursor=pointer]
          - tab "Needs review" [selected] [ref=e49] [cursor=pointer]
          - tab "Ready to post" [ref=e51] [cursor=pointer]
          - tab "Posted" [ref=e53] [cursor=pointer]
          - tab "Cancelled" [ref=e55] [cursor=pointer]
        - generic [ref=e57]:
          - complementary "Original invoice" [ref=e58]:
            - generic [ref=e59]:
              - heading "Original invoice" [level=2] [ref=e60]
              - paragraph [ref=e61]: AI invoice reading is simulated
              - generic [ref=e63]:
                - generic [ref=e64]: Upload a PDF or photo
                - generic [ref=e65]:
                  - button "Upload a PDF or photo" [ref=e66]
                  - button "Take photo" [ref=e67]
                  - generic [ref=e68]:
                    - generic [ref=e72]:
                      - strong [ref=e73]: fictional-supplier-invoice.png
                      - generic [ref=e74]: 1 KB
                    - button "Remove file" [ref=e75] [cursor=pointer]
                  - generic [ref=e79]:
                    - button "Browse" [ref=e80] [cursor=pointer]
                    - button "Take photo" [ref=e81] [cursor=pointer]
              - group "Original invoice" [ref=e85]:
                - generic [ref=e86]:
                  - button "Zoom out" [ref=e87] [cursor=pointer]
                  - generic [ref=e89]: 100%
                  - button "Zoom in" [ref=e90] [cursor=pointer]
                - button "Fit width" [ref=e92] [cursor=pointer]
                - button "Fit page" [ref=e93] [cursor=pointer]
                - button "Download" [ref=e94] [cursor=pointer]
              - img "Original invoice image" [ref=e99]
          - generic [ref=e100]:
            - generic [ref=e101]:
              - generic "Delivery summary" [ref=e102]:
                - generic [ref=e103]:
                  - generic [ref=e104]: Subtotal
                  - strong [ref=e105]: $174.52
                - generic [ref=e106]:
                  - generic [ref=e107]: Tax
                  - strong [ref=e108]: $2.50
                - generic [ref=e109]:
                  - generic [ref=e110]: Shorts and refused deduction
                  - strong [ref=e111]: $0.00
                - generic [ref=e112]:
                  - generic [ref=e113]: Payable
                  - strong [ref=e114]: $177.02
              - paragraph [ref=e115]: This is the amount of this invoice, not a supplier balance. Received records only physically delivered units.
            - generic [ref=e116]:
              - heading [level=2] [ref=e117]:
                - button "Invoice details" [ref=e118] [cursor=pointer]
              - paragraph [ref=e121]:
                - generic [ref=e122]: Fresh Valley Foods
                - text: ·
                - generic [ref=e123]: FV-20417
                - text: · North York ·
                - generic [ref=e124]: 2026-10-15
              - paragraph [ref=e125]:
                - generic [ref=e126]: Needs review
                - text: Changes save automatically in this browser.
            - generic [ref=e128]:
              - heading "Compare with order" [level=2] [ref=e129]
              - generic [ref=e130]:
                - generic [ref=e131]: Order (optional)
                - combobox "Order (optional)" [ref=e132] [cursor=pointer]:
                  - generic [ref=e133]: No linked order
                - paragraph [ref=e136]: Choose an open order for this supplier and receiving location.
            - generic [ref=e137]:
              - heading "Review invoice lines" [level=2] [ref=e138]
              - paragraph [ref=e139]: Choose Cases or Units and confirm the product, pack, quantities, cost, and date decision on each line.
              - table [ref=e141]:
                - 'rowgroup "Line 1: Canned Fava Beans 400 g" [ref=e142]':
                  - row [ref=e143] [cursor=pointer]:
                    - cell "1. Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی 0002 · 400 g Matched" [ref=e144]:
                      - generic [ref=e145]:
                        - heading [level=3] [ref=e146]:
                          - button "1. Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی" [expanded] [ref=e147]:
                            - generic [ref=e148]: "1."
                            - generic [ref=e149]:
                              - strong [ref=e150]:
                                - generic [ref=e151]:
                                  - text: Canned Fava Beans
                                  - generic [ref=e152]: 400 g
                              - generic [ref=e154]:
                                - text: باقالا کنسرو شده
                                - generic [ref=e155]: ۴۰۰ گرمی
                        - paragraph [ref=e158]:
                          - text: 0002 ·
                          - generic [ref=e159]: 400 g
                        - generic [ref=e162]: Matched
                    - cell [ref=e164]:
                      - generic [ref=e165]:
                        - generic [ref=e166]: Invoiced
                        - textbox "Invoiced" [ref=e167]: "2"
                      - generic [ref=e168]:
                        - generic [ref=e169]: Delivered
                        - textbox "Delivered" [ref=e170]: "24"
                    - cell [ref=e171]:
                      - generic [ref=e172]:
                        - generic [ref=e173]: Unit cost before tax
                        - textbox "Unit cost before tax" [ref=e174]: "0.98"
                    - cell "Line total $23.52" [ref=e175]:
                      - generic [ref=e176]: Line total
                      - text: $23.52
                    - 'cell "Selling price $1.49 Approved: $1.49" [ref=e177]':
                      - generic [ref=e178]:
                        - generic [ref=e179]: Selling price
                        - strong [ref=e180]: $1.49
                        - paragraph [ref=e181]: "Approved: $1.49"
                  - row [ref=e182]:
                    - cell [ref=e183]:
                      - generic [ref=e184]:
                        - group [ref=e185]:
                          - generic [ref=e186]:
                            - generic [ref=e187]: Quantity unit
                            - combobox "Quantity unit" [ref=e188] [cursor=pointer]:
                              - generic [ref=e189]: Cases
                          - generic [ref=e192]:
                            - generic [ref=e193]: Units per case
                            - textbox "Units per case" [ref=e194]: "12"
                          - generic [ref=e195]:
                            - generic [ref=e196]: Supplier item code (optional)
                            - textbox "Supplier item code (optional)" [ref=e197]
                          - generic [ref=e198]:
                            - generic [ref=e199]: Case cost before tax
                            - textbox "Case cost before tax" [ref=e200]: "11.7600"
                          - paragraph [ref=e201]: 2 × 12 = 24 units
                          - generic [ref=e202]:
                            - generic [ref=e203]: Matched product
                            - combobox "Matched product" [ref=e204] [cursor=pointer]:
                              - generic [ref=e206]:
                                - text: ⁦0002⁩ · ⁦
                                - generic [ref=e207]:
                                  - text: Canned Fava Beans
                                  - generic [ref=e208]: 400 g
                                - text: ⁩
                          - generic [ref=e211]:
                            - generic [ref=e212]: Pricing category
                            - combobox "Pricing category" [ref=e213] [cursor=pointer]:
                              - generic [ref=e214]: Grocery
                        - button "Remove line" [ref=e217] [cursor=pointer]
                        - checkbox "Mark as short" [ref=e218] [cursor=pointer]
                        - group [ref=e221]:
                          - generic [ref=e222]:
                            - generic [ref=e223]: Track date
                            - group "Track date" [ref=e224]:
                              - button "Yes" [pressed] [ref=e225] [cursor=pointer]
                              - button "No" [ref=e227] [cursor=pointer]
                          - generic [ref=e229]:
                            - generic [ref=e230]:
                              - generic [ref=e231]: Date tracking
                              - combobox "Date tracking" [ref=e232] [cursor=pointer]:
                                - generic [ref=e233]: Expiry
                            - generic [ref=e236]:
                              - generic [ref=e237]: Date
                              - button "Date" [ref=e238] [cursor=pointer]:
                                - generic [ref=e239]: Choose date
                            - generic [ref=e242]:
                              - generic [ref=e243]: Lot number (optional)
                              - textbox "Lot number (optional)" [ref=e244]
                        - checkbox "Confirm this invoice line" [ref=e245] [cursor=pointer]
                - 'rowgroup "Line 2: Ground Sumac 100 g" [ref=e248]':
                  - row [ref=e249] [cursor=pointer]:
                    - cell "2. Ground Sumac 100 g سماق ۱۰۰ گرمی 0005 · 100 g Matched" [ref=e250]:
                      - generic [ref=e251]:
                        - heading [level=3] [ref=e252]:
                          - button "2. Ground Sumac 100 g سماق ۱۰۰ گرمی" [expanded] [ref=e253]:
                            - generic [ref=e254]: "2."
                            - generic [ref=e255]:
                              - strong [ref=e256]:
                                - generic [ref=e257]:
                                  - text: Ground Sumac
                                  - generic [ref=e258]: 100 g
                              - generic [ref=e260]:
                                - text: سماق
                                - generic [ref=e261]: ۱۰۰ گرمی
                        - paragraph [ref=e264]:
                          - text: 0005 ·
                          - generic [ref=e265]: 100 g
                        - generic [ref=e268]: Matched
                    - cell [ref=e270]:
                      - generic [ref=e271]:
                        - generic [ref=e272]: Invoiced
                        - textbox "Invoiced" [ref=e273]: "1"
                      - generic [ref=e274]:
                        - generic [ref=e275]: Delivered
                        - textbox "Delivered" [ref=e276]: "12"
                    - cell [ref=e277]:
                      - generic [ref=e278]:
                        - generic [ref=e279]: Unit cost before tax
                        - textbox "Unit cost before tax" [ref=e280]: "1.30"
                    - cell "Line total $15.60" [ref=e281]:
                      - generic [ref=e282]: Line total
                      - text: $15.60
                    - 'cell "Selling price $1.99 Approved: $1.99" [ref=e283]':
                      - generic [ref=e284]:
                        - generic [ref=e285]: Selling price
                        - strong [ref=e286]: $1.99
                        - paragraph [ref=e287]: "Approved: $1.99"
                  - row [ref=e288]:
                    - cell [ref=e289]:
                      - generic [ref=e290]:
                        - group [ref=e291]:
                          - generic [ref=e292]:
                            - generic [ref=e293]: Quantity unit
                            - combobox "Quantity unit" [ref=e294] [cursor=pointer]:
                              - generic [ref=e295]: Cases
                          - generic [ref=e298]:
                            - generic [ref=e299]: Units per case
                            - textbox "Units per case" [ref=e300]: "12"
                          - generic [ref=e301]:
                            - generic [ref=e302]: Supplier item code (optional)
                            - textbox "Supplier item code (optional)" [ref=e303]
                          - generic [ref=e304]:
                            - generic [ref=e305]: Case cost before tax
                            - textbox "Case cost before tax" [ref=e306]: "15.6000"
                          - paragraph [ref=e307]: 1 × 12 = 12 units
                          - generic [ref=e308]:
                            - generic [ref=e309]: Matched product
                            - combobox "Matched product" [ref=e310] [cursor=pointer]:
                              - generic [ref=e312]:
                                - text: ⁦0005⁩ · ⁦
                                - generic [ref=e313]:
                                  - text: Ground Sumac
                                  - generic [ref=e314]: 100 g
                                - text: ⁩
                          - generic [ref=e317]:
                            - generic [ref=e318]: Pricing category
                            - combobox "Pricing category" [ref=e319] [cursor=pointer]:
                              - generic [ref=e320]: Grocery
                        - button "Remove line" [ref=e323] [cursor=pointer]
                        - checkbox "Mark as short" [ref=e324] [cursor=pointer]
                        - group [ref=e327]:
                          - generic [ref=e328]:
                            - generic [ref=e329]: Track date
                            - group "Track date" [ref=e330]:
                              - button "Yes" [pressed] [ref=e331] [cursor=pointer]
                              - button "No" [ref=e333] [cursor=pointer]
                          - generic [ref=e335]:
                            - generic [ref=e336]:
                              - generic [ref=e337]: Date tracking
                              - combobox "Date tracking" [ref=e338] [cursor=pointer]:
                                - generic [ref=e339]: Expiry
                            - generic [ref=e342]:
                              - generic [ref=e343]: Date
                              - button "Date" [ref=e344] [cursor=pointer]:
                                - generic [ref=e345]: Choose date
                            - generic [ref=e348]:
                              - generic [ref=e349]: Lot number (optional)
                              - textbox "Lot number (optional)" [ref=e350]
                        - checkbox "Confirm this invoice line" [ref=e351] [cursor=pointer]
                - 'rowgroup "Line 3: Lavash Bread 500 g" [ref=e354]':
                  - row [ref=e355] [cursor=pointer]:
                    - cell "3. Lavash Bread 500 g نان لواش ۵۰۰ گرمی 0006 · 500 g Matched" [ref=e356]:
                      - generic [ref=e357]:
                        - heading [level=3] [ref=e358]:
                          - button "3. Lavash Bread 500 g نان لواش ۵۰۰ گرمی" [expanded] [ref=e359]:
                            - generic [ref=e360]: "3."
                            - generic [ref=e361]:
                              - strong [ref=e362]:
                                - generic [ref=e363]:
                                  - text: Lavash Bread
                                  - generic [ref=e364]: 500 g
                              - generic [ref=e366]:
                                - text: نان لواش
                                - generic [ref=e367]: ۵۰۰ گرمی
                        - paragraph [ref=e370]:
                          - text: 0006 ·
                          - generic [ref=e371]: 500 g
                        - generic [ref=e374]: Matched
                    - cell [ref=e376]:
                      - generic [ref=e377]:
                        - generic [ref=e378]: Invoiced
                        - textbox "Invoiced" [ref=e379]: "2"
                      - generic [ref=e380]:
                        - generic [ref=e381]: Delivered
                        - textbox "Delivered" [ref=e382]: "20"
                    - cell [ref=e383]:
                      - generic [ref=e384]:
                        - generic [ref=e385]: Unit cost before tax
                        - textbox "Unit cost before tax" [ref=e386]: "1.55"
                    - cell "Line total $31.00" [ref=e387]:
                      - generic [ref=e388]: Line total
                      - text: $31.00
                    - 'cell "Selling price $2.99 Pending Goes to approval when posted Approved: $1.99" [ref=e389]':
                      - generic [ref=e390]:
                        - generic [ref=e391]: Selling price
                        - strong [ref=e392]: $2.99
                        - generic [ref=e393]: Pending
                        - generic [ref=e394]: Goes to approval when posted
                        - paragraph [ref=e395]: "Approved: $1.99"
                  - row [ref=e396]:
                    - cell [ref=e397]:
                      - generic [ref=e398]:
                        - group [ref=e399]:
                          - generic [ref=e400]:
                            - generic [ref=e401]: Quantity unit
                            - combobox "Quantity unit" [ref=e402] [cursor=pointer]:
                              - generic [ref=e403]: Cases
                          - generic [ref=e406]:
                            - generic [ref=e407]: Units per case
                            - textbox "Units per case" [ref=e408]: "10"
                          - generic [ref=e409]:
                            - generic [ref=e410]: Supplier item code (optional)
                            - textbox "Supplier item code (optional)" [ref=e411]
                          - generic [ref=e412]:
                            - generic [ref=e413]: Case cost before tax
                            - textbox "Case cost before tax" [ref=e414]: "15.5000"
                          - paragraph [ref=e415]: 2 × 10 = 20 units
                          - generic [ref=e416]:
                            - generic [ref=e417]: Matched product
                            - combobox "Matched product" [ref=e418] [cursor=pointer]:
                              - generic [ref=e420]:
                                - text: ⁦0006⁩ · ⁦
                                - generic [ref=e421]:
                                  - text: Lavash Bread
                                  - generic [ref=e422]: 500 g
                                - text: ⁩
                          - generic [ref=e425]:
                            - generic [ref=e426]: Pricing category
                            - combobox "Pricing category" [ref=e427] [cursor=pointer]:
                              - generic [ref=e428]: Grocery
                        - button "Remove line" [ref=e431] [cursor=pointer]
                        - checkbox "Mark as short" [ref=e432] [cursor=pointer]
                        - group [ref=e435]:
                          - generic [ref=e436]:
                            - generic [ref=e437]: Track date
                            - group "Track date" [ref=e438]:
                              - button "Yes" [pressed] [ref=e439] [cursor=pointer]
                              - button "No" [ref=e441] [cursor=pointer]
                          - generic [ref=e443]:
                            - generic [ref=e444]:
                              - generic [ref=e445]: Date tracking
                              - combobox "Date tracking" [ref=e446] [cursor=pointer]:
                                - generic [ref=e447]: Expiry
                            - generic [ref=e450]:
                              - generic [ref=e451]: Date
                              - button "Date" [ref=e452] [cursor=pointer]:
                                - generic [ref=e453]: Choose date
                            - generic [ref=e456]:
                              - generic [ref=e457]: Lot number (optional)
                              - textbox "Lot number (optional)" [ref=e458]
                        - checkbox "Confirm this invoice line" [ref=e459] [cursor=pointer]
                - 'rowgroup "Line 4: Sour Cherry Juice 1 L" [ref=e462]':
                  - row [ref=e463] [cursor=pointer]:
                    - cell "4. Sour Cherry Juice 1 L آب آلبالو ۱ لیتری 0003 · 1 L Matched" [ref=e464]:
                      - generic [ref=e465]:
                        - heading [level=3] [ref=e466]:
                          - button "4. Sour Cherry Juice 1 L آب آلبالو ۱ لیتری" [expanded] [ref=e467]:
                            - generic [ref=e468]: "4."
                            - generic [ref=e469]:
                              - strong [ref=e470]:
                                - generic [ref=e471]:
                                  - text: Sour Cherry Juice
                                  - generic [ref=e472]: 1 L
                              - generic [ref=e474]:
                                - text: آب آلبالو
                                - generic [ref=e475]: ۱ لیتری
                        - paragraph [ref=e478]:
                          - text: 0003 ·
                          - generic [ref=e479]: 1 L
                        - generic [ref=e482]: Matched
                    - cell [ref=e484]:
                      - generic [ref=e485]:
                        - generic [ref=e486]: Invoiced
                        - textbox "Invoiced" [ref=e487]: "3"
                      - generic [ref=e488]:
                        - generic [ref=e489]: Delivered
                        - textbox "Delivered" [ref=e490]: "36"
                    - cell [ref=e491]:
                      - generic [ref=e492]:
                        - generic [ref=e493]: Unit cost before tax
                        - textbox "Unit cost before tax" [ref=e494]: "1.80"
                    - cell "Line total $64.80" [ref=e495]:
                      - generic [ref=e496]: Line total
                      - text: $64.80
                    - 'cell "Selling price $2.99 Approved: $2.99" [ref=e497]':
                      - generic [ref=e498]:
                        - generic [ref=e499]: Selling price
                        - strong [ref=e500]: $2.99
                        - paragraph [ref=e501]: "Approved: $2.99"
                  - row [ref=e502]:
                    - cell "Remove line Mark as short Lower-cost receipt Lower-cost receipt Confirm this invoice line" [ref=e503]:
                      - generic [ref=e504]:
                        - group [ref=e505]:
                          - generic [ref=e506]:
                            - generic [ref=e507]: Quantity unit
                            - combobox "Quantity unit" [ref=e508] [cursor=pointer]:
                              - generic [ref=e509]: Cases
                          - generic [ref=e512]:
                            - generic [ref=e513]: Units per case
                            - textbox "Units per case" [ref=e514]: "12"
                          - generic [ref=e515]:
                            - generic [ref=e516]: Supplier item code (optional)
                            - textbox "Supplier item code (optional)" [ref=e517]
                          - generic [ref=e518]:
                            - generic [ref=e519]: Case cost before tax
                            - textbox "Case cost before tax" [ref=e520]: "21.6000"
                          - paragraph [ref=e521]: 3 × 12 = 36 units
                          - generic [ref=e522]:
                            - generic [ref=e523]: Matched product
                            - combobox "Matched product" [ref=e524] [cursor=pointer]:
                              - generic [ref=e526]:
                                - text: ⁦0003⁩ · ⁦
                                - generic [ref=e527]:
                                  - text: Sour Cherry Juice
                                  - generic [ref=e528]: 1 L
                                - text: ⁩
                          - generic [ref=e531]:
                            - generic [ref=e532]: Pricing category
                            - combobox "Pricing category" [ref=e533] [cursor=pointer]:
                              - generic [ref=e534]: Grocery
                        - button "Remove line" [ref=e537] [cursor=pointer]
                        - checkbox "Mark as short" [ref=e538] [cursor=pointer]
                        - generic [ref=e541]:
                          - generic [ref=e542]: Lower-cost receipt
                          - group "Lower-cost receipt" [ref=e543]:
                            - button "Regular receipt" [pressed] [ref=e544] [cursor=pointer]
                            - button "Short-dated (expiry discount)" [ref=e546] [cursor=pointer]
                        - group [ref=e548]:
                          - generic [ref=e549]:
                            - generic [ref=e550]: Track date
                            - group "Track date" [ref=e551]:
                              - button "Yes" [pressed] [ref=e552] [cursor=pointer]
                              - button "No" [ref=e554] [cursor=pointer]
                          - generic [ref=e556]:
                            - generic [ref=e557]:
                              - generic [ref=e558]: Date tracking
                              - combobox "Date tracking" [ref=e559] [cursor=pointer]:
                                - generic [ref=e560]: Expiry
                            - generic [ref=e563]:
                              - generic [ref=e564]: Date
                              - button "Date" [ref=e565] [cursor=pointer]:
                                - generic [ref=e566]: Choose date
                            - generic [ref=e569]:
                              - generic [ref=e570]: Lot number (optional)
                              - textbox "Lot number (optional)" [ref=e571]
                        - checkbox "Confirm this invoice line" [ref=e572] [cursor=pointer]
                - 'rowgroup "Line 5: Dried Barberries 100 g" [ref=e575]':
                  - row [ref=e576] [cursor=pointer]:
                    - cell "5. Dried Barberries 100 g زرشک خشک ۱۰۰ گرمی No Product Code yet Pending new product" [ref=e577]:
                      - generic [ref=e578]:
                        - heading [level=3] [ref=e579]:
                          - button "5. Dried Barberries 100 g زرشک خشک ۱۰۰ گرمی" [expanded] [ref=e580]:
                            - generic [ref=e581]: "5."
                            - generic [ref=e582]:
                              - strong [ref=e583]:
                                - generic [ref=e584]:
                                  - text: Dried Barberries
                                  - generic [ref=e585]: 100 g
                              - generic [ref=e587]:
                                - text: زرشک خشک
                                - generic [ref=e588]: ۱۰۰ گرمی
                        - paragraph [ref=e591]: No Product Code yet
                        - generic [ref=e592]: Pending new product
                    - cell [ref=e594]:
                      - generic [ref=e595]:
                        - generic [ref=e596]: Invoiced
                        - textbox "Invoiced" [ref=e597]: "1"
                      - generic [ref=e598]:
                        - generic [ref=e599]: Delivered
                        - textbox "Delivered" [ref=e600]: "6"
                    - cell [ref=e601]:
                      - generic [ref=e602]:
                        - generic [ref=e603]: Unit cost before tax
                        - textbox "Unit cost before tax" [ref=e604]: "3.40"
                    - cell "Line total $20.40" [ref=e605]:
                      - generic [ref=e606]: Line total
                      - text: $20.40
                    - cell "Selling price $5.49 Pending Goes to approval when posted No approved price yet" [ref=e607]:
                      - generic [ref=e608]:
                        - generic [ref=e609]: Selling price
                        - strong [ref=e610]: $5.49
                        - generic [ref=e611]: Pending
                        - generic [ref=e612]: Goes to approval when posted
                        - paragraph [ref=e613]: No approved price yet
                  - row [ref=e614]:
                    - cell [ref=e615]:
                      - generic [ref=e616]:
                        - group [ref=e617]:
                          - generic [ref=e618]:
                            - generic [ref=e619]: Quantity unit
                            - combobox "Quantity unit" [ref=e620] [cursor=pointer]:
                              - generic [ref=e621]: Cases
                          - generic [ref=e624]:
                            - generic [ref=e625]: Units per case
                            - textbox "Units per case" [ref=e626]: "6"
                          - generic [ref=e627]:
                            - generic [ref=e628]: Supplier item code (optional)
                            - textbox "Supplier item code (optional)" [ref=e629]
                          - generic [ref=e630]:
                            - generic [ref=e631]: Case cost before tax
                            - textbox "Case cost before tax" [ref=e632]: "20.4000"
                          - paragraph [ref=e633]: 1 × 6 = 6 units
                          - generic [ref=e634]:
                            - generic [ref=e635]: Matched product
                            - combobox "Matched product" [ref=e636] [cursor=pointer]:
                              - generic [ref=e637]: Create pending new product
                          - generic [ref=e640]:
                            - generic [ref=e641]: Pricing category
                            - combobox "Pricing category" [ref=e642] [cursor=pointer]:
                              - generic [ref=e643]: Grocery
                          - generic [ref=e646]:
                            - generic [ref=e647]: New product name (English)
                            - textbox "New product name (English)" [ref=e648]: Dried Barberries 100 g
                          - generic [ref=e649]:
                            - generic [ref=e650]: New product name (Persian) (optional)
                            - textbox "New product name (Persian) (optional)" [ref=e651]: زرشک خشک ۱۰۰ گرمی
                        - button "Remove line" [ref=e652] [cursor=pointer]
                        - checkbox "Mark as short" [ref=e653] [cursor=pointer]
                        - group [ref=e656]:
                          - generic [ref=e657]:
                            - generic [ref=e658]: Track date
                            - group "Track date" [ref=e659]:
                              - button "Yes" [ref=e660] [cursor=pointer]
                              - button "No" [ref=e662] [cursor=pointer]
                        - checkbox "Confirm this invoice line" [ref=e664] [cursor=pointer]
                - 'rowgroup "Line 6: Potato Chips 150 g" [ref=e667]':
                  - row [ref=e668] [cursor=pointer]:
                    - cell "6. Potato Chips 150 g چیپس سیب‌زمینی ۱۵۰ گرمی 0009 · 150 g Matched Taxable" [ref=e669]:
                      - generic [ref=e670]:
                        - heading [level=3] [ref=e671]:
                          - button "6. Potato Chips 150 g چیپس سیب‌زمینی ۱۵۰ گرمی" [expanded] [ref=e672]:
                            - generic [ref=e673]: "6."
                            - generic [ref=e674]:
                              - strong [ref=e675]:
                                - generic [ref=e676]:
                                  - text: Potato Chips
                                  - generic [ref=e677]: 150 g
                              - generic [ref=e679]:
                                - text: چیپس سیب‌زمینی
                                - generic [ref=e680]: ۱۵۰ گرمی
                        - paragraph [ref=e683]:
                          - text: 0009 ·
                          - generic [ref=e684]: 150 g
                        - generic [ref=e687]:
                          - generic [ref=e688]: Matched
                          - generic [ref=e689]: Taxable
                    - cell [ref=e690]:
                      - generic [ref=e691]:
                        - generic [ref=e692]: Invoiced
                        - textbox "Invoiced" [ref=e693]: "1"
                      - generic [ref=e694]:
                        - generic [ref=e695]: Delivered
                        - textbox "Delivered" [ref=e696]: "12"
                    - cell [ref=e697]:
                      - generic [ref=e698]:
                        - generic [ref=e699]: Unit cost before tax
                        - textbox "Unit cost before tax" [ref=e700]: "1.60"
                    - cell "Line total $19.20" [ref=e701]:
                      - generic [ref=e702]: Line total
                      - text: $19.20
                    - 'cell "Selling price $2.99 Approved: $2.99" [ref=e703]':
                      - generic [ref=e704]:
                        - generic [ref=e705]: Selling price
                        - strong [ref=e706]: $2.99
                        - paragraph [ref=e707]: "Approved: $2.99"
                  - row [ref=e708]:
                    - cell [ref=e709]:
                      - generic [ref=e710]:
                        - group [ref=e711]:
                          - generic [ref=e712]:
                            - generic [ref=e713]: Quantity unit
                            - combobox "Quantity unit" [ref=e714] [cursor=pointer]:
                              - generic [ref=e715]: Cases
                          - generic [ref=e718]:
                            - generic [ref=e719]: Units per case
                            - textbox "Units per case" [ref=e720]: "12"
                          - generic [ref=e721]:
                            - generic [ref=e722]: Supplier item code (optional)
                            - textbox "Supplier item code (optional)" [ref=e723]
                          - generic [ref=e724]:
                            - generic [ref=e725]: Case cost before tax
                            - textbox "Case cost before tax" [ref=e726]: "19.2000"
                          - paragraph [ref=e727]: 1 × 12 = 12 units
                          - generic [ref=e728]:
                            - generic [ref=e729]: Matched product
                            - combobox "Matched product" [ref=e730] [cursor=pointer]:
                              - generic [ref=e732]:
                                - text: ⁦0009⁩ · ⁦
                                - generic [ref=e733]:
                                  - text: Potato Chips
                                  - generic [ref=e734]: 150 g
                                - text: ⁩
                          - generic [ref=e737]:
                            - generic [ref=e738]: Pricing category
                            - combobox "Pricing category" [ref=e739] [cursor=pointer]:
                              - generic [ref=e740]: Grocery (Taxable)
                        - button "Remove line" [ref=e743] [cursor=pointer]
                        - checkbox "Mark as short" [active] [ref=e744] [cursor=pointer]
                        - group [ref=e747]:
                          - generic [ref=e748]:
                            - generic [ref=e749]: Track date
                            - group "Track date" [ref=e750]:
                              - button "Yes" [pressed] [ref=e751] [cursor=pointer]
                              - button "No" [ref=e753] [cursor=pointer]
                          - generic [ref=e755]:
                            - generic [ref=e756]:
                              - generic [ref=e757]: Date tracking
                              - combobox "Date tracking" [ref=e758] [cursor=pointer]:
                                - generic [ref=e759]: Expiry
                            - generic [ref=e762]:
                              - generic [ref=e763]: Date
                              - button "Date" [ref=e764] [cursor=pointer]:
                                - generic [ref=e765]: Choose date
                            - generic [ref=e768]:
                              - generic [ref=e769]: Lot number (optional)
                              - textbox "Lot number (optional)" [ref=e770]
                        - checkbox "Confirm this invoice line" [ref=e771] [cursor=pointer]
              - generic [ref=e774]:
                - generic [ref=e775]:
                  - generic [ref=e776]: Add a product to the invoice
                  - combobox "Add a product to the invoice" [ref=e777] [cursor=pointer]:
                    - generic [ref=e779]:
                      - text: ⁦0002⁩ · ⁦
                      - generic [ref=e780]:
                        - text: Canned Fava Beans
                        - generic [ref=e781]: 400 g
                      - text: ⁩
                - button "Add line" [ref=e784] [cursor=pointer]
                - button "+ Add new product" [ref=e785] [cursor=pointer]
            - generic [ref=e786]:
              - heading "Same-supplier lower price" [level=2] [ref=e787]
              - paragraph [ref=e788]: Sour Cherry Juice 1 L · Fresh Valley Foods · Old $1.95 · New $1.80
              - paragraph [ref=e789]: Your answers create a Supervisor alert when you post. Unknown information is allowed with a note.
              - group [ref=e790]:
                - generic [ref=e791]:
                  - generic [ref=e792]: Is the expiry date the same as the goods already in the store?
                  - combobox "Is the expiry date the same as the goods already in the store?" [ref=e793] [cursor=pointer]:
                    - generic [ref=e794]: Choose an answer
          - generic [ref=e798]:
            - button "Save as draft" [ref=e799] [cursor=pointer]
            - button "Post invoice" [ref=e800] [cursor=pointer]
```

# Test source

```ts
  1   | import { readCanonicalBusinessEvidence } from "./business-evidence";
  2   | import { expect, test, type Page } from "@playwright/test";
  3   | import { createHash } from "node:crypto";
  4   | import {
  5   |   signIn,
  6   |   chooseOption,
  7   |   setLanguage,
  8   |   openInvoiceUpload,
  9   | } from "./helpers";
  10  | 
  11  | test.setTimeout(60000);
  12  | 
  13  | const pixel = Buffer.from(
  14  |   "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jUjYAAAAASUVORK5CYII=",
  15  |   "base64",
  16  | );
  17  | async function signInWorker(page: Page) {
  18  |   await signIn(page, "Floor Worker");
  19  |   await page.goto("/#invoices");
  20  |   await expect(
  21  |     page.getByRole("heading", { name: "Invoices", exact: true }),
  22  |   ).toBeVisible();
  23  | }
  24  | async function upload(page: Page) {
  25  |   await (
  26  |     await openInvoiceUpload(page)
  27  |   ).setInputFiles({
  28  |     name: "fictional-supplier-invoice.png",
  29  |     mimeType: "image/png",
  30  |     buffer: pixel,
  31  |   });
  32  |   await expect(
  33  |     page.getByRole("status").filter({ hasText: "Reading invoice…" }),
  34  |   ).toBeVisible();
  35  |   await expect(
  36  |     page.getByRole("heading", { name: "Review invoice lines" }),
  37  |   ).toBeVisible({ timeout: 8000 });
  38  |   await expect(page.locator(".invoice-line")).toHaveCount(6, {
  39  |     timeout: 10000,
  40  |   });
  41  |   await expect
  42  |     .poll(() =>
  43  |       readCanonicalBusinessEvidence(page).then((canonicalState) => {
  44  |         const invoice = JSON.parse(JSON.stringify(canonicalState)!).invoice;
  45  |         return {
  46  |           fileName: invoice.file_name,
  47  |           originalHash: invoice.file_data?.split(":").at(-1),
  48  |           status: invoice.status,
  49  |         };
  50  |       }),
  51  |     )
  52  |     .toEqual({
  53  |       fileName: "fictional-supplier-invoice.png",
  54  |       originalHash: createHash("sha256").update(pixel).digest("hex"),
  55  |       status: "review",
  56  |     });
  57  | }
  58  | async function stored(page: Page) {
  59  |   return readCanonicalBusinessEvidence(page).then((canonicalState) =>
  60  |     JSON.parse(JSON.stringify(canonicalState)!),
  61  |   );
  62  | }
  63  | 
  64  | test("simulated upload, review, lower-price answer and two partial chip deliveries conserve stock and cents", async ({
  65  |   page,
  66  | }) => {
  67  |   await page.addInitScript(() => {
  68  |     Object.defineProperty(globalThis.crypto, "randomUUID", {
  69  |       value: undefined,
  70  |       configurable: true,
  71  |     });
  72  |   });
  73  |   const browserErrors: string[] = [];
  74  |   page.on("pageerror", (error) => browserErrors.push(error.message));
  75  |   await signInWorker(page);
  76  |   // The unread retained original now opens from its real Drafts row.
  77  |   await page.getByRole("button", { name: "Continue", exact: true }).click();
  78  |   await expect(
  79  |     page
  80  |       .getByRole("complementary", { name: "Original invoice", exact: true })
  81  |       .getByText("AI invoice reading is simulated", { exact: true }),
  82  |   ).toBeVisible();
  83  |   // This workflow tests a new uploaded invoice, separately from the retained
  84  |   // original whose Continue action was checked above.
  85  |   await page.getByRole("button", { name: "New invoice", exact: true }).click();
  86  |   const before = await stored(page);
  87  |   const beforeStock = before.stock["Branch 1:0009"];
  88  |   await upload(page);
  89  |   expect(await page.evaluate(() => typeof globalThis.crypto.randomUUID)).toBe(
  90  |     "undefined",
  91  |   );
  92  |   const sumac = page.locator(".invoice-line").nth(1);
  93  |   await sumac.getByLabel("Unit cost before tax", { exact: true }).fill("1.60");
  94  |   await expect(sumac.locator(".price-display")).toHaveText("$2.99");
  95  |   await sumac.getByLabel("Unit cost before tax", { exact: true }).fill("1.30");
  96  |   await expect(sumac.locator(".price-display")).toHaveText("$1.99");
  97  |   const chips = page.locator(".invoice-line").nth(5);
  98  |   await chips
  99  |     .getByRole("checkbox", { name: "Mark as short", exact: true })
> 100 |     .check();
      |      ^ Error: locator.check: Clicking the checkbox did not change its state
  101 |   await expect(chips.getByText(/Deduction:/)).toContainText("$7.23");
  102 |   await expect(
  103 |     page.getByRole("button", { name: "Post invoice", exact: true }),
  104 |   ).toBeEnabled();
  105 |   await page.getByRole("button", { name: "Post invoice", exact: true }).click();
  106 |   await expect(
  107 |     page.getByRole("alert", { name: "What's missing", exact: true }),
  108 |   ).toBeVisible();
  109 |   await chooseOption(
  110 |     page,
  111 |     page.getByLabel(
  112 |       "Is the expiry date the same as the goods already in the store?",
  113 |       {
  114 |         exact: true,
  115 |       },
  116 |     ),
  117 |     "unknown",
  118 |     "Unknown — add a note",
  119 |   );
  120 |   await page
  121 |     .getByLabel("What information is unknown? (required)", { exact: true })
  122 |     .fill("Demo only: old stock label cannot be read.");
  123 |   for (const line of await page.locator(".invoice-line").all()) {
  124 |     await line.getByRole("button", { name: "No", exact: true }).click();
  125 |     await line
  126 |       .getByRole("checkbox", { name: "Confirm this invoice line", exact: true })
  127 |       .click();
  128 |   }
  129 |   await page
  130 |     .getByRole("button", { name: "Save as draft", exact: true })
  131 |     .click();
  132 |   await page.reload();
  133 |   await expect(
  134 |     page.getByLabel("What information is unknown? (required)", { exact: true }),
  135 |   ).toHaveValue("Demo only: old stock label cannot be read.");
  136 |   await expect(
  137 |     page.getByRole("button", { name: "Post invoice", exact: true }),
  138 |   ).toBeEnabled();
  139 |   const beforePost = await stored(page);
  140 |   await page.getByRole("button", { name: "Post invoice", exact: true }).click();
  141 |   const confirmation = page.getByRole("dialog", {
  142 |     name: "Post invoice",
  143 |     exact: true,
  144 |   });
  145 |   await expect(confirmation).toBeVisible();
  146 |   expect((await stored(page)).invoice).toEqual(beforePost.invoice);
  147 |   expect((await stored(page)).ledger).toEqual(beforePost.ledger);
  148 |   await confirmation
  149 |     .getByRole("button", { name: "Cancel", exact: true })
  150 |     .click();
  151 |   expect((await stored(page)).invoice).toEqual(beforePost.invoice);
  152 |   await page.getByRole("button", { name: "Post invoice", exact: true }).click();
  153 |   await page
  154 |     .getByRole("dialog", { name: "Post invoice", exact: true })
  155 |     .getByRole("button", { name: "Post invoice", exact: true })
  156 |     .click();
  157 |   await expect(page.getByRole("status")).toContainText("Posted.");
  158 |   await expect(
  159 |     page.getByRole("button", { name: "Post invoice", exact: true }),
  160 |   ).toHaveCount(0);
  161 |   let state = await stored(page);
  162 |   expect(state.stock["Branch 1:0009"]).toBe(beforeStock + 8);
  163 |   expect(state.invoice.payable_after_open_shorts).toBe("169.79");
  164 |   expect(
  165 |     state.alerts.filter(
  166 |       (alert: { type: string }) => alert.type === "lower_price",
  167 |     ),
  168 |   ).toHaveLength(1);
  169 |   const deliveryReference = page.getByLabel("Delivery document reference", {
  170 |     exact: true,
  171 |   });
  172 |   const deliveryQuantity = page.getByLabel("Actual units received now", {
  173 |     exact: true,
  174 |   });
  175 |   await deliveryReference.fill("");
  176 |   await deliveryQuantity.fill("0");
  177 |   await page
  178 |     .getByRole("button", { name: "Receive short delivery", exact: true })
  179 |     .click();
  180 |   await expect(deliveryReference).toHaveAttribute("aria-invalid", "true");
  181 |   await expect(deliveryQuantity).toHaveAttribute("aria-invalid", "true");
  182 |   await deliveryReference.fill("FICTITIOUS-CHIPS-1");
  183 |   await expect(deliveryReference).toHaveAttribute("aria-invalid", "false");
  184 |   await expect(deliveryQuantity).toHaveAttribute("aria-invalid", "true");
  185 |   await deliveryQuantity.fill("2");
  186 |   await expect(deliveryQuantity).toHaveAttribute("aria-invalid", "false");
  187 |   await page
  188 |     .getByLabel("Delivery document reference", { exact: true })
  189 |     .fill("FICTITIOUS-CHIPS-1");
  190 |   await page
  191 |     .getByRole("button", { name: "Receive short delivery", exact: true })
  192 |     .click();
  193 |   await expect(page.getByRole("status")).toContainText("$3.62");
  194 |   state = await stored(page);
  195 |   expect(state.stock["Branch 1:0009"]).toBe(beforeStock + 10);
  196 |   await page
  197 |     .getByLabel("Delivery document reference", { exact: true })
  198 |     .fill("FICTITIOUS-CHIPS-2");
  199 |   await page
  200 |     .getByRole("button", { name: "Receive short delivery", exact: true })
```