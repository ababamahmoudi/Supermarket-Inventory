# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: c5-button-audit.spec.ts >> C5 button contract covers Suppliers, every supplier tab and item dialogs
- Location: tests/c5-button-audit.spec.ts:54:1

# Error details

```
Error: Suppliers overview: en-light

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 7

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

```
Error: Suppliers overview: en-dark

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 7

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

```
Error: Suppliers overview: fa-light

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 7

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

```
Error: Add supplier dialog: en-light

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 7

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

```
Error: Supplier: Received: en-light

expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 10

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

```
Error: Supplier: Received: en-dark

expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 10

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

```
Error: Supplier: Received: fa-light

expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 10

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

```
Error: Suppliers overview: en-light

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 7

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

```
Error: Suppliers overview: en-dark

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 7

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

```
Error: Suppliers overview: fa-light

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 7

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

```
Error: Supplier: Received: en-light

expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 10

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

```
Error: Supplier: Received: en-dark

expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 10

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

```
Error: Supplier: Received: fa-light

expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 10

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=e5]:
    - banner [ref=e6]:
      - button "Open menu" [ref=e7] [cursor=pointer]
      - combobox "Location" [ref=e11] [cursor=pointer]:
        - generic [ref=e16]: North York
      - button "Notifications, 0 unread" [ref=e19] [cursor=pointer]
      - button "User menu" [ref=e24] [cursor=pointer]:
        - generic [aria-hidden] [ref=e26]: DN
      - button "More" [active] [ref=e27] [cursor=pointer]
    - main [ref=e33]:
      - button "Back to Suppliers" [ref=e34] [cursor=pointer]
      - generic [ref=e38]:
        - heading "Fresh Valley Foods" [level=1] [ref=e39]
        - paragraph [ref=e40]: Supplier details
      - generic [ref=e41]:
        - generic [ref=e42]:
          - generic [ref=e43]: Fresh Valley Foods
          - generic [ref=e44]: Confirmed
        - generic [ref=e45]:
          - generic [ref=e46]:
            - term [ref=e47]: Phone
            - definition [ref=e48]: 555-0101
          - generic [ref=e49]:
            - term [ref=e50]: Email
            - definition [ref=e51]: orders@freshvalley.example
          - generic [ref=e52]:
            - term [ref=e53]: Sales representative
            - definition [ref=e54]: Demo Rep A
          - generic [ref=e55]:
            - term [ref=e56]: Sales rep phone
            - definition [ref=e57]: 555-0111
          - generic [ref=e58]:
            - term [ref=e59]: Payment terms
            - definition [ref=e60]: Net 14
      - generic [ref=e61]:
        - button "Last delivery 2026-10-14" [ref=e62] [cursor=pointer]:
          - generic [ref=e63]: Last delivery
          - generic [ref=e64]: 2026-10-14
        - button "Deliveries this month 1" [ref=e69] [cursor=pointer]:
          - generic [ref=e70]: Deliveries this month
          - generic [ref=e71]: "1"
        - button "Open returns 1" [ref=e76] [cursor=pointer]:
          - generic [ref=e77]: Open returns
          - generic [ref=e78]: "1"
        - generic [ref=e83]:
          - generic [ref=e84]: Open shorts
          - generic [ref=e85]: "0"
      - tablist "Supplier sections" [ref=e87]:
        - tab "Overview" [ref=e88] [cursor=pointer]
        - tab "Invoices" [ref=e90] [cursor=pointer]
        - tab "Supplier items" [ref=e92] [cursor=pointer]
        - tab "Received" [ref=e94] [cursor=pointer]
        - tab "Returns and credits" [ref=e96] [cursor=pointer]
        - tab "Shorts" [ref=e98] [cursor=pointer]
        - tab "Price alerts" [ref=e100] [cursor=pointer]
        - tab "Notes" [selected] [ref=e102] [cursor=pointer]
      - generic [ref=e104]:
        - heading "Notes" [level=2] [ref=e105]
        - article [ref=e107]:
          - paragraph [ref=e108]: 2 Lavash Bread taken for staff lunch
          - generic [ref=e109]: Demo Floor Worker · North York · 2026-10-15
```

# Test source

```ts
  1   | import { writeFile } from "node:fs/promises";
  2   | import { expect, test, type Page, type TestInfo } from "@playwright/test";
  3   | import { chooseOption, setBranch, signIn, uploadInvoice } from "./helpers";
  4   | import {
  5   |   appearance,
  6   |   inspect,
  7   |   type C5Inspection,
  8   | } from "../scripts/c5-browser-proof.mjs";
  9   | 
  10  | test.setTimeout(180000);
  11  | test.use({ actionTimeout: 10000 });
  12  | 
  13  | /** Source census covers conditional calls; this checks real rendered states. */
  14  | function audit(page: Page, info: TestInfo) {
  15  |   const inspections: C5Inspection[] = [];
  16  |   return {
  17  |     async check(screen: string, role = "supervisor") {
  18  |       const modal = await page.locator("dialog[open]").count();
  19  |       const variants = modal
  20  |         ? (["en-light"] as const)
  21  |         : (["en-light", "en-dark", "fa-light"] as const);
  22  |       for (const variant of variants) {
  23  |         // A real modal makes the top bar inert. Extra dialogs are measured in
  24  |         // English light; the required C5 dialogs have all-theme coverage in
  25  |         // c5-presentation.spec.ts and the screenshot capture.
  26  |         if (!modal) await appearance(page, variant);
  27  |         const report = await inspect(
  28  |           page,
  29  |           screen,
  30  |           `${info.project.name}-${variant}`,
  31  |           role,
  32  |         );
  33  |         inspections.push(report);
> 34  |         expect.soft(report.failures, `${screen}: ${variant}`).toEqual([]);
      |                                                               ^ Error: Supplier: Received: fa-light
  35  |       }
  36  |       if (!modal) await appearance(page, "en-light");
  37  |     },
  38  |     async save() {
  39  |       const output = info.outputPath("button-audit.json");
  40  |       await writeFile(output, JSON.stringify(inspections, null, 2));
  41  |       await info.attach("Rendered button audit", {
  42  |         path: output,
  43  |         contentType: "application/json",
  44  |       });
  45  |     },
  46  |   };
  47  | }
  48  | 
  49  | async function closeDialog(page: Page) {
  50  |   await page.keyboard.press("Escape");
  51  |   await expect(page.locator("dialog[open]")).toHaveCount(0);
  52  | }
  53  | 
  54  | test("C5 button contract covers Suppliers, every supplier tab and item dialogs", async ({
  55  |   page,
  56  | }, info) => {
  57  |   const proof = audit(page, info);
  58  |   try {
  59  |     await signIn(page, "Supervisor");
  60  |     await setBranch(page, "Branch 1");
  61  |     await page.goto("/#suppliers");
  62  |     await proof.check("Suppliers overview");
  63  |     await page
  64  |       .getByRole("button", { name: "Add supplier", exact: true })
  65  |       .click();
  66  |     await proof.check("Add supplier dialog");
  67  |     await closeDialog(page);
  68  |     await page.goto("/#suppliers?name=Fresh%20Valley%20Foods");
  69  |     for (const tab of [
  70  |       "Overview",
  71  |       "Invoices",
  72  |       "Supplier items",
  73  |       "Received",
  74  |       "Returns and credits",
  75  |       "Shorts",
  76  |       "Price alerts",
  77  |       "Payments",
  78  |       "Notes",
  79  |     ]) {
  80  |       await page.getByRole("tab", { name: tab, exact: true }).click();
  81  |       await proof.check(`Supplier: ${tab}`);
  82  |     }
  83  |     await page.getByRole("button", { name: "Edit", exact: true }).click();
  84  |     await proof.check("Edit supplier dialog");
  85  |     await closeDialog(page);
  86  |     await page
  87  |       .getByRole("tab", { name: "Supplier items", exact: true })
  88  |       .click();
  89  |     await page.getByRole("button", { name: "Add item", exact: true }).click();
  90  |     await proof.check("Add supplier item dialog");
  91  |     await closeDialog(page);
  92  |     const item = page
  93  |       .locator(".supplier-items-table tbody tr.supplier-item-history-row")
  94  |       .first();
  95  |     await expect(item).toBeVisible();
  96  |     await expect(item.locator(".row-chevron")).toBeVisible();
  97  |     await item.focus();
  98  |     await page.keyboard.press("Enter");
  99  |     await expect(
  100 |       page.getByRole("dialog", { name: "Price history", exact: true }),
  101 |     ).toBeVisible();
  102 |     await proof.check("Supplier item price history dialog");
  103 |     await closeDialog(page);
  104 |     await item.getByRole("button", { name: "Edit", exact: true }).click();
  105 |     await expect(
  106 |       page.getByRole("dialog", { name: "Edit item", exact: true }),
  107 |     ).toBeVisible();
  108 |     await proof.check("Edit supplier item dialog");
  109 |     await closeDialog(page);
  110 |     await signIn(page, "Floor Worker");
  111 |     await page.goto("/#suppliers");
  112 |     await proof.check("Suppliers overview", "floor_worker");
  113 |     await page.goto("/#suppliers?name=Fresh%20Valley%20Foods");
  114 |     for (const tab of [
  115 |       "Overview",
  116 |       "Invoices",
  117 |       "Supplier items",
  118 |       "Received",
  119 |       "Returns and credits",
  120 |       "Shorts",
  121 |       "Price alerts",
  122 |       "Notes",
  123 |     ]) {
  124 |       await page.getByRole("tab", { name: tab, exact: true }).click();
  125 |       await proof.check(`Supplier: ${tab}`, "floor_worker");
  126 |       await expect(page.locator(".supplier-tab-card .money")).toHaveCount(0);
  127 |     }
  128 |   } finally {
  129 |     await proof.save();
  130 |   }
  131 | });
  132 | 
  133 | test("C5 button contract covers working Settings groups and their dialogs", async ({
  134 |   page,
```