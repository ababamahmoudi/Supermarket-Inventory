# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: invoice-orders-c2.spec.ts >> order comparison requires explicit extra and changed-cost decisions, then preserves one alert and accepted receipts
- Location: tests/invoice-orders-c2.spec.ts:129:1

# Error details

```
Test timeout of 60000ms exceeded.
```

```
Error: locator.click: Test timeout of 60000ms exceeded.
Call log:
  - waiting for locator('.invoice-order-card').getByRole('button', { name: 'Refused / sent back with the driver', exact: true })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=e5]:
    - banner [ref=e6]:
      - button "Open menu" [ref=e7] [cursor=pointer]
      - combobox "Location" [ref=e11] [cursor=pointer]:
        - generic [ref=e16]: North York
      - button "Notifications, 5 unread" [ref=e19] [cursor=pointer]:
        - generic [ref=e20]: "5"
      - button "User menu" [ref=e25] [cursor=pointer]:
        - generic [aria-hidden] [ref=e27]: DM
      - button "More" [ref=e28] [cursor=pointer]
    - main [ref=e34]:
      - generic [ref=e35]:
        - link "Back to Invoices" [ref=e36] [cursor=pointer]:
          - /url: "#invoices"
        - generic [ref=e39]:
          - generic [ref=e40]:
            - heading "Invoices" [level=1] [ref=e41]
            - paragraph [ref=e42]: Deliveries and supplier invoices
          - button "New invoice" [ref=e44] [cursor=pointer]
        - tablist "Invoice views" [ref=e45]:
          - tab "Drafts" [ref=e46] [cursor=pointer]
          - tab "Processing" [ref=e48] [cursor=pointer]
          - tab "Needs review" [selected] [ref=e50] [cursor=pointer]
          - tab "Ready to post" [ref=e52] [cursor=pointer]
          - tab "Posted" [ref=e54] [cursor=pointer]
          - tab "Cancelled" [ref=e56] [cursor=pointer]
        - generic [ref=e58]:
          - complementary "Original invoice" [ref=e59]:
            - generic [ref=e60]:
              - heading "Original invoice" [level=2] [ref=e61]
              - paragraph [ref=e62]: AI invoice reading is simulated
              - generic [ref=e64]:
                - generic [ref=e65]: Upload a PDF or photo
                - generic [ref=e66]:
                  - button "Upload a PDF or photo" [ref=e67]
                  - button "Take photo" [ref=e68]
                  - generic [ref=e69]:
                    - generic [ref=e73]:
                      - strong [ref=e74]: fictional-supplier-invoice.png
                      - generic [ref=e75]: 1 KB
                    - button "Remove file" [ref=e76] [cursor=pointer]
                  - generic [ref=e80]:
                    - button "Browse" [ref=e81] [cursor=pointer]
                    - button "Take photo" [ref=e82] [cursor=pointer]
              - group "Original invoice" [ref=e86]:
                - generic [ref=e87]:
                  - button "Zoom out" [ref=e88] [cursor=pointer]
                  - generic [ref=e90]: 100%
                  - button "Zoom in" [ref=e91] [cursor=pointer]
                - button "Fit width" [ref=e93] [cursor=pointer]
                - button "Fit page" [ref=e94] [cursor=pointer]
                - button "Download" [ref=e95] [cursor=pointer]
              - img "Original invoice image" [ref=e100]
          - generic [ref=e101]:
            - alert "What's missing" [ref=e103]:
              - heading "What's missing" [level=3] [ref=e104]
              - list [ref=e105]:
                - listitem [ref=e106]:
                  - link "Choose a decision for every order difference before posting." [ref=e107] [cursor=pointer]:
                    - /url: "#invoice-order-review"
                - listitem [ref=e108]:
                  - 'link "Line 1: Review and confirm every invoice line." [ref=e109] [cursor=pointer]':
                    - /url: "#invoice-line-0-confirm"
                - listitem [ref=e110]:
                  - 'link "Line 1: Choose Yes or No for date tracking on every line; add a date when tracking is on." [ref=e111] [cursor=pointer]':
                    - /url: "#invoice-line-0-date"
            - generic [ref=e112]:
              - generic "Delivery summary" [ref=e113]:
                - generic [ref=e114]:
                  - generic [ref=e115]: Subtotal
                  - strong [ref=e116]: $1.10
                - generic [ref=e117]:
                  - generic [ref=e118]: Tax
                  - strong [ref=e119]: $0.00
                - generic [ref=e120]:
                  - generic [ref=e121]: Shorts and refused deduction
                  - strong [ref=e122]: $0.00
                - generic [ref=e123]:
                  - generic [ref=e124]: Payable
                  - strong [ref=e125]: $1.10
              - paragraph [ref=e126]: This is the amount of this invoice, not a supplier balance. Received records only physically delivered units.
            - generic [ref=e127]:
              - heading [level=2] [ref=e128]:
                - button "Invoice details" [expanded] [ref=e129] [cursor=pointer]
              - paragraph [ref=e132]:
                - generic [ref=e133]: Fresh Valley Foods
                - text: ·
                - generic [ref=e134]: —
                - text: · North York ·
                - generic [ref=e135]: 2026-10-15
              - paragraph [ref=e136]:
                - generic [ref=e137]: Needs review
                - text: Changes save automatically in this browser.
              - group [ref=e138]:
                - generic [ref=e139]:
                  - generic [ref=e140]: Supplier
                  - combobox "Supplier" [ref=e141] [cursor=pointer]:
                    - generic [ref=e142]: ⁦Fresh Valley Foods⁩
                - generic [ref=e145]:
                  - generic [ref=e146]: Supplier invoice number (optional)
                  - textbox "Supplier invoice number (optional)" [ref=e147]:
                    - /placeholder: Assigned on posting if blank
                - generic [ref=e148]:
                  - generic [ref=e149]: Invoice date
                  - button "Invoice date" [ref=e150] [cursor=pointer]:
                    - generic [ref=e151]: 2026-10-15
                - generic [ref=e154]:
                  - generic [ref=e155]:
                    - generic [ref=e156]: Received date
                    - button "Received date" [ref=e157] [cursor=pointer]:
                      - generic [ref=e158]: 2026-10-15
                  - generic [ref=e161]:
                    - generic [ref=e162]: Received time
                    - textbox "Received time" [ref=e163]:
                      - /placeholder: HH:mm
                      - text: 14:20
                    - paragraph [ref=e164]: Store local time, 24-hour HH:mm
                - generic [ref=e165]:
                  - generic [ref=e166]: Receiving employee
                  - combobox "Receiving employee" [ref=e167] [cursor=pointer]:
                    - generic [ref=e168]: Demo Manager
                - generic [ref=e171]:
                  - generic [ref=e172]: Location
                  - combobox "Location" [ref=e173] [cursor=pointer]:
                    - generic [ref=e174]: North York
                - generic [ref=e177]:
                  - generic [ref=e178]: Ship to (optional)
                  - textbox "Ship to (optional)" [ref=e179]
                - generic [ref=e180]:
                  - generic [ref=e181]: Subtotal
                  - textbox "Subtotal" [ref=e182]: "1.10"
                - generic [ref=e183]:
                  - generic [ref=e184]: Tax
                  - textbox "Tax" [ref=e185]: "0.00"
                - generic [ref=e186]:
                  - generic [ref=e187]: Final total
                  - textbox "Final total" [ref=e188]: "1.10"
                - generic [ref=e189]:
                  - generic [ref=e190]: Due date (optional)
                  - button "Due date (optional)" [ref=e191] [cursor=pointer]:
                    - generic [ref=e192]: 2026-10-29
                - generic [ref=e196]:
                  - generic [ref=e197]: Payment terms (optional)
                  - combobox "Payment terms (optional)" [ref=e198] [cursor=pointer]:
                    - generic [ref=e199]: Every 2 weeks (14 days)
            - generic [ref=e203]:
              - heading "Compare with order" [level=2] [ref=e204]
              - generic [ref=e205]:
                - generic [ref=e206]: Order (optional)
                - combobox "Order (optional)" [ref=e207] [cursor=pointer]:
                  - generic [ref=e208]: ORD-0001 · 2026-10-15
                - paragraph [ref=e211]: Choose an open order for this supplier and receiving location.
              - paragraph [ref=e212]: ORD-0001 · Fresh Valley Foods
              - table [ref=e214]:
                - rowgroup [ref=e215]:
                  - row [ref=e216]:
                    - cell "Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی" [ref=e217]:
                      - generic [ref=e218]:
                        - strong [ref=e219]:
                          - generic [ref=e220]:
                            - text: Canned Fava Beans
                            - generic [ref=e221]: 400 g
                        - generic [ref=e223]:
                          - text: باقالا کنسرو شده
                          - generic [ref=e224]: ۴۰۰ گرمی
                    - cell "Ordered units remaining 12" [ref=e225]:
                      - text: Ordered units remaining
                      - generic [ref=e226]: "12"
                    - cell "Delivered units 1" [ref=e227]:
                      - text: Delivered units
                      - generic [ref=e228]: "1"
                    - cell [ref=e229]:
                      - text: Details
                      - button "Hide details" [expanded] [active] [ref=e230] [cursor=pointer]
                  - row [ref=e233]:
                    - 'cell "Decision Unit cost changed Unit cost before tax: $0.98 → $1.10 Case cost before tax: $11.76 → $13.20 Changed cost decision" [ref=e234]':
                      - generic [ref=e236]:
                        - term [ref=e237]: Decision
                        - definition [ref=e238]:
                          - generic [ref=e239]:
                            - generic [ref=e240]: Unit cost changed
                            - paragraph [ref=e241]: "Unit cost before tax: $0.98 → $1.10"
                            - paragraph [ref=e242]: "Case cost before tax: $11.76 → $13.20"
                            - group "Changed cost decision" [ref=e243]:
                              - button "Accept new cost" [ref=e244] [cursor=pointer]
                  - row [ref=e246]:
                    - cell "Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی" [ref=e247]:
                      - generic [ref=e248]:
                        - strong [ref=e249]:
                          - generic [ref=e250]:
                            - text: Canned Fava Beans
                            - generic [ref=e251]: 400 g
                        - generic [ref=e253]:
                          - text: باقالا کنسرو شده
                          - generic [ref=e254]: ۴۰۰ گرمی
                    - cell "Ordered units remaining 11" [ref=e255]:
                      - text: Ordered units remaining
                      - generic [ref=e256]: "11"
                    - cell "Delivered units 0" [ref=e257]:
                      - text: Delivered units
                      - generic [ref=e258]: "0"
                    - cell [ref=e259]:
                      - text: Details
                      - button "Show details" [ref=e260] [cursor=pointer]
            - generic [ref=e263]:
              - heading "Review invoice lines" [level=2] [ref=e264]
              - paragraph [ref=e265]: Choose Cases or Units and confirm the product, pack, quantities, cost, and date decision on each line.
              - table [ref=e267]:
                - 'rowgroup "Line 1: Canned Fava Beans 400 g" [ref=e268]':
                  - row [ref=e269] [cursor=pointer]:
                    - cell "1. Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی 0002 · 400 g Matched" [ref=e270]:
                      - generic [ref=e271]:
                        - heading [level=3] [ref=e272]:
                          - button "1. Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی" [expanded] [ref=e273]:
                            - generic [ref=e274]: "1."
                            - generic [ref=e275]:
                              - strong [ref=e276]:
                                - generic [ref=e277]:
                                  - text: Canned Fava Beans
                                  - generic [ref=e278]: 400 g
                              - generic [ref=e280]:
                                - text: باقالا کنسرو شده
                                - generic [ref=e281]: ۴۰۰ گرمی
                        - paragraph [ref=e284]:
                          - text: 0002 ·
                          - generic [ref=e285]: 400 g
                        - generic [ref=e288]: Matched
                    - cell [ref=e290]:
                      - generic [ref=e291]:
                        - generic [ref=e292]: Invoiced
                        - textbox "Invoiced" [ref=e293]: "1"
                      - generic [ref=e294]:
                        - generic [ref=e295]: Delivered
                        - textbox "Delivered" [ref=e296]: "1"
                    - cell [ref=e297]:
                      - generic [ref=e298]:
                        - generic [ref=e299]: Unit cost before tax
                        - textbox "Unit cost before tax" [ref=e300]: "1.1000"
                    - cell "Line total $1.10" [ref=e301]:
                      - generic [ref=e302]: Line total
                      - text: $1.10
                    - 'cell "Selling price $1.49 Approved: $1.49" [ref=e303]':
                      - generic [ref=e304]:
                        - generic [ref=e305]: Selling price
                        - strong [ref=e306]: $1.49
                        - paragraph [ref=e307]: "Approved: $1.49"
                  - row [ref=e308]:
                    - cell [ref=e309]:
                      - generic [ref=e310]:
                        - group [ref=e311]:
                          - generic [ref=e312]:
                            - generic [ref=e313]: Quantity unit
                            - combobox "Quantity unit" [ref=e314] [cursor=pointer]:
                              - generic [ref=e315]: Units
                          - generic [ref=e318]:
                            - generic [ref=e319]: Units per case
                            - textbox "Units per case" [ref=e320]: "12"
                          - generic [ref=e321]:
                            - generic [ref=e322]: Supplier item code (optional)
                            - textbox "Supplier item code (optional)" [ref=e323]
                          - paragraph [ref=e324]: 1 unit
                          - generic [ref=e325]:
                            - generic [ref=e326]: Matched product
                            - combobox "Matched product" [ref=e327] [cursor=pointer]:
                              - generic [ref=e329]:
                                - text: ⁦0002⁩ · ⁦
                                - generic [ref=e330]:
                                  - text: Canned Fava Beans
                                  - generic [ref=e331]: 400 g
                                - text: ⁩
                          - generic [ref=e334]:
                            - generic [ref=e335]: Pricing category
                            - combobox "Pricing category" [ref=e336] [cursor=pointer]:
                              - generic [ref=e337]: Grocery
                        - button "Remove line" [ref=e340] [cursor=pointer]
                        - checkbox "Mark as short" [ref=e341] [cursor=pointer]
                        - group [ref=e344]:
                          - generic [ref=e345]:
                            - generic [ref=e346]: Track date
                            - group "Track date" [ref=e347]:
                              - button "Yes" [pressed] [ref=e348] [cursor=pointer]
                              - button "No" [ref=e350] [cursor=pointer]
                          - generic [ref=e352]:
                            - generic [ref=e353]:
                              - generic [ref=e354]: Date tracking
                              - combobox "Date tracking" [ref=e355] [cursor=pointer]:
                                - generic [ref=e356]: Expiry
                            - generic [ref=e359]:
                              - generic [ref=e360]: Date
                              - button "Date" [ref=e361] [cursor=pointer]:
                                - generic [ref=e362]: Choose date
                              - alert [ref=e365]: "Line 1: Choose Yes or No for date tracking on every line; add a date when tracking is on."
                            - generic [ref=e366]:
                              - generic [ref=e367]: Lot number (optional)
                              - textbox "Lot number (optional)" [ref=e368]
                        - checkbox "Confirm this invoice line" [ref=e369] [cursor=pointer]
                        - alert [ref=e372]: "Line 1: Review and confirm every invoice line."
              - generic [ref=e373]:
                - generic [ref=e374]:
                  - generic [ref=e375]: Add a product to the invoice
                  - combobox "Add a product to the invoice" [ref=e376] [cursor=pointer]:
                    - generic [ref=e378]:
                      - text: ⁦0002⁩ · ⁦
                      - generic [ref=e379]:
                        - text: Canned Fava Beans
                        - generic [ref=e380]: 400 g
                      - text: ⁩
                - button "Add line" [ref=e383] [cursor=pointer]
                - button "+ Add new product" [ref=e384] [cursor=pointer]
          - generic [ref=e386]:
            - button "Save as draft" [ref=e387] [cursor=pointer]
            - button "Post invoice" [ref=e388] [cursor=pointer]
```

# Test source

```ts
  92  |     line.getByLabel("Unit cost before tax", { exact: true }),
  93  |   ).toHaveValue("1.6658");
  94  |   await expect(line.locator(".invoice-pack-equation")).toContainText(
  95  |     "500 × 12 = 6000",
  96  |   );
  97  |   await confirmNoDate(page);
  98  |   await post(page);
  99  |   const after = await stored(page);
  100 |   expect(after.invoice).toMatchObject({
  101 |     subtotal: "9995.00",
  102 |     final_total: "9995.00",
  103 |     payable_after_open_shorts: "9995.00",
  104 |   });
  105 |   expect(after.invoice.lines[0]).toMatchObject({
  106 |     units_per_case: 12,
  107 |     quantity_unit: "cases",
  108 |     quantity_entered: "500",
  109 |     qty_invoiced: 6000,
  110 |     unit_cost_before_tax: "1.6658",
  111 |     case_cost_before_tax: "19.99",
  112 |   });
  113 |   expect(
  114 |     Decimal.sum(
  115 |       ...after.ledger
  116 |         .filter((entry) => entry.invoice_id === after.invoice.id)
  117 |         .map((entry) => entry.amount),
  118 |     ).toFixed(2),
  119 |   ).toBe("9995.00");
  120 |   await page.goto("/#received");
  121 |   await page
  122 |     .getByRole("textbox", { name: "Search Received", exact: true })
  123 |     .fill(after.invoice.supplier_invoice_number);
  124 |   await expect(page.locator(".received-table")).toContainText("500 cases");
  125 |   await page.reload();
  126 |   expect((await stored(page)).invoice.lines[0].units_per_case).toBe(12);
  127 | });
  128 | 
  129 | test("order comparison requires explicit extra and changed-cost decisions, then preserves one alert and accepted receipts", async ({
  130 |   page,
  131 | }) => {
  132 |   await signIn(page, "Supervisor");
  133 |   await rememberedPack(page);
  134 |   await page.goto("/#orders");
  135 |   await page.getByRole("button", { name: "New order", exact: true }).click();
  136 |   const form = page.getByRole("form", { name: "New order", exact: true });
  137 |   await chooseOption(
  138 |     page,
  139 |     form.getByLabel("Supplier", { exact: true }),
  140 |     "Fresh Valley Foods",
  141 |   );
  142 |   await form
  143 |     .getByRole("textbox", { name: /^Cases — Canned Fava Beans/ })
  144 |     .fill("1");
  145 |   const expectedCost = form.getByRole("textbox", {
  146 |     name: /^Expected unit cost — Canned Fava Beans/,
  147 |   });
  148 |   if (!(await expectedCost.count()))
  149 |     await form
  150 |       .locator("tbody tr")
  151 |       .filter({ hasText: "Canned Fava Beans" })
  152 |       .getByRole("button", { name: "Show details", exact: true })
  153 |       .click();
  154 |   await form
  155 |     .getByRole("textbox", { name: /^Expected unit cost — Canned Fava Beans/ })
  156 |     .fill("0.9800");
  157 |   await form.getByRole("button", { name: "Place order", exact: true }).click();
  158 |   const before = await stored(page);
  159 |   const order = before.orders!.at(-1)!;
  160 |   expect(order.status).toBe("ordered");
  161 |   const line = await manual(page);
  162 |   await line.getByLabel("Invoiced", { exact: true }).fill("18");
  163 |   await line.getByLabel("Unit cost before tax", { exact: true }).fill("1.1000");
  164 |   const comparison = page.locator(".invoice-order-card");
  165 |   await chooseOption(
  166 |     page,
  167 |     comparison.getByLabel("Order (optional)", { exact: true }),
  168 |     order.id,
  169 |     `${order.reference} · ${order.date}`,
  170 |   );
  171 |   await page.getByRole("button", { name: "Post invoice", exact: true }).click();
  172 |   await expect(
  173 |     page.getByRole("link", {
  174 |       name: "Choose a decision for every order difference before posting.",
  175 |       exact: true,
  176 |     }),
  177 |   ).toBeVisible();
  178 |   const row = comparison.locator('tr[data-invoice-line="0"]');
  179 |   const refusal = comparison.getByRole("button", {
  180 |     name: "Refused / sent back with the driver",
  181 |     exact: true,
  182 |   });
  183 |   if (!(await refusal.count()))
  184 |     await row
  185 |       .getByRole("button", { name: "Show details", exact: true })
  186 |       .click();
  187 |   await comparison
  188 |     .getByRole("button", {
  189 |       name: "Refused / sent back with the driver",
  190 |       exact: true,
  191 |     })
> 192 |     .click();
      |      ^ Error: locator.click: Test timeout of 60000ms exceeded.
  193 |   await comparison
  194 |     .getByRole("button", { name: "Accept new cost", exact: true })
  195 |     .click();
  196 |   await confirmNoDate(page);
  197 |   await post(page);
  198 |   const after = await stored(page);
  199 |   const currentOrder = after.orders!.find((item) => item.id === order.id)!;
  200 |   expect(currentOrder.status).toBe("received");
  201 |   expect(currentOrder.lines[0].received_units).toBe(12);
  202 |   expect(after.invoice.lines[0]).toMatchObject({
  203 |     qty_received_at_posting: 18,
  204 |     refused_units: 6,
  205 |     extra_delivery_decision: "refuse",
  206 |     order_price_decision: "accept",
  207 |   });
  208 |   expect(after.invoice.payable_after_open_shorts).toBe("13.20");
  209 |   expect(
  210 |     after.alerts.filter((alert) => alert.invoice_id === after.invoice.id),
  211 |   ).toHaveLength(1);
  212 |   expect(
  213 |     after.alerts.find((alert) => alert.invoice_id === after.invoice.id)
  214 |       ?.order_differences,
  215 |   ).toEqual(
  216 |     expect.arrayContaining([
  217 |       expect.objectContaining({ kind: "extra", units: 6, decision: "refuse" }),
  218 |       expect.objectContaining({ kind: "price_change", decision: "accept" }),
  219 |     ]),
  220 |   );
  221 |   await page.reload();
  222 |   const postedLine = page
  223 |     .locator(".posted-invoice-document tbody tr")
  224 |     .filter({ hasText: "Canned Fava Beans 400 g" });
  225 |   await expect(postedLine).toContainText("Delivered quantity: 12");
  226 |   await expect(postedLine).toContainText(
  227 |     "Refused / sent back with the driver · 6 · $6.60",
  228 |   );
  229 |   await expect(postedLine).toContainText("Accept new cost");
  230 |   await expect(postedLine.getByRole("cell").nth(2)).toHaveText("$1.10");
  231 |   await expect(
  232 |     page.locator(
  233 |       ".posted-invoice-document input, .posted-invoice-document select",
  234 |     ),
  235 |   ).toHaveCount(0);
  236 |   await page.goto("/#alerts");
  237 |   await expect(
  238 |     page.getByRole("heading", {
  239 |       name: "Invoice and order differences",
  240 |       exact: true,
  241 |     }),
  242 |   ).toBeVisible();
  243 |   await page.goto("/#received");
  244 |   await page
  245 |     .getByRole("textbox", { name: "Search Received", exact: true })
  246 |     .fill(after.invoice.supplier_invoice_number);
  247 |   await expect(page.locator(".received-table")).toContainText("12 units");
  248 | });
  249 | 
  250 | test("short-dated expiry discount requires a real date and preserves an existing manual selling price", async ({
  251 |   page,
  252 | }) => {
  253 |   await signIn(page, "Supervisor");
  254 |   const editor = await openC8PriceDialog(page, "0002");
  255 |   await editor.getByRole("radio", { name: /^New regular price/ }).check();
  256 |   await editor.getByLabel("Price", { exact: true }).fill("2.49");
  257 |   await editor
  258 |     .getByRole("checkbox", {
  259 |       name: "Add regular labels to the label waitlist",
  260 |       exact: true,
  261 |     })
  262 |     .uncheck();
  263 |   await editor
  264 |     .getByRole("button", { name: "Save new price", exact: true })
  265 |     .click();
  266 |   await expect(editor).not.toBeVisible();
  267 |   await expect
  268 |     .poll(
  269 |       async () =>
  270 |         (await stored(page)).products.find((entry) => entry.code === "0002")
  271 |           ?.manual_prices?.all.price,
  272 |     )
  273 |     .toBe("2.49");
  274 |   const before = await stored(page);
  275 |   const prior = before.products.find((item) => item.code === "0002")!;
  276 |   const line = await manual(page);
  277 |   await line.getByLabel("Unit cost before tax", { exact: true }).fill("0.8000");
  278 |   await line
  279 |     .getByRole("button", { name: "Short-dated (expiry discount)", exact: true })
  280 |     .click();
  281 |   await expect(
  282 |     line.getByRole("button", { name: "No", exact: true }),
  283 |   ).toBeDisabled();
  284 |   await expect(
  285 |     page.getByRole("button", { name: "Post invoice", exact: true }),
  286 |   ).toBeEnabled();
  287 |   await page.getByRole("button", { name: "Post invoice", exact: true }).click();
  288 |   await expect(
  289 |     page.getByRole("alert", { name: "What's missing", exact: true }),
  290 |   ).toBeVisible();
  291 |   await expect(
  292 |     line.getByRole("button", { name: "Keep $2.49", exact: true }),
```