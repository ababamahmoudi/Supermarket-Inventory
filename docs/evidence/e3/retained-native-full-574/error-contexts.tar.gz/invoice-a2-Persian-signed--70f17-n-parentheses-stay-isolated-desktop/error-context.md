# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: invoice-a2.spec.ts >> Persian signed money, line numbers and deduction parentheses stay isolated
- Location: tests/invoice-a2.spec.ts:118:1

# Error details

```
Error: locator.check: Clicking the checkbox did not change its state
Call log:
  - waiting for locator('.invoice-line').nth(5).getByRole('checkbox', { name: 'Mark as short', exact: true })
    - locator resolved to <button type="button" role="checkbox" aria-checked="false" class="ui-checked-control">…</button>
  - attempting click action
    - waiting for element to be visible, enabled and stable
    - element is visible, enabled and stable
    - scrolling into view if needed
    - done scrolling
    - performing click action
    - click action done
    - waiting for scheduled navigations to finish
    - navigations have finished

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - complementary "Main menu" [ref=e5]:
    - generic [ref=e6]:
      - img "Super Arzon" [ref=e9]
      - generic [ref=e10]: Super Arzon
    - navigation "Pages" [ref=e11]:
      - generic [ref=e12]:
        - button "Daily" [expanded] [ref=e13] [cursor=pointer]
        - generic [ref=e17]:
          - link "Lookup" [ref=e18] [cursor=pointer]:
            - /url: "#lookup"
          - link "Invoices" [ref=e23] [cursor=pointer]:
            - /url: "#invoices"
          - link "Received" [ref=e28] [cursor=pointer]:
            - /url: "#received"
          - link "Returns" [ref=e35] [cursor=pointer]:
            - /url: "#returns"
          - link "Price updates" [ref=e40] [cursor=pointer]:
            - /url: "#price-updates"
          - link "Labels" [ref=e46] [cursor=pointer]:
            - /url: "#labels"
          - link "Date tracking" [ref=e51] [cursor=pointer]:
            - /url: "#expiry"
          - link "Notes" [ref=e56] [cursor=pointer]:
            - /url: "#notes"
          - link "Branch requests" [ref=e60] [cursor=pointer]:
            - /url: "#requests"
      - button "Catalog" [ref=e66] [cursor=pointer]
      - button "Manager" [ref=e71] [cursor=pointer]
      - button "Admin" [ref=e76] [cursor=pointer]
    - button "User menu" [ref=e81] [cursor=pointer]:
      - generic [ref=e82]:
        - generic [aria-hidden] [ref=e83]: DN
        - generic [ref=e84]:
          - strong [ref=e85]: Demo North York Floor Worker
          - generic [ref=e86]: Floor Worker
  - generic [ref=e87]:
    - banner [ref=e88]:
      - button "Collapse sidebar" [expanded] [ref=e89] [cursor=pointer]
      - navigation "Breadcrumbs" [ref=e93]:
        - link "North York" [ref=e94] [cursor=pointer]:
          - /url: "#invoices"
        - link "Invoices" [ref=e97] [cursor=pointer]:
          - /url: "#invoices"
        - link "FV-20417" [ref=e100] [cursor=pointer]:
          - /url: "#invoices?id=invoice-a1827198-0de2-493f-9ea7-ef0576d65ac9"
      - search [ref=e101]:
        - textbox "Search all products" [ref=e105]:
          - /placeholder: Search products
        - generic [aria-hidden] [ref=e106]: /
      - combobox "Location" [ref=e107] [cursor=pointer]:
        - generic [ref=e112]: North York
      - button "Switch to Persian" [ref=e115] [cursor=pointer]: فا
      - button "Switch to dark theme" [ref=e116] [cursor=pointer]
      - button "Comfortable text size" [ref=e119] [cursor=pointer]:
        - generic [aria-hidden] [ref=e120]: Aa
      - button "Notifications, 0 unread" [ref=e121] [cursor=pointer]
      - button "Demo" [ref=e126] [cursor=pointer]
    - main [ref=e129]:
      - generic [ref=e130]:
        - link "Back to Invoices" [ref=e131] [cursor=pointer]:
          - /url: "#invoices"
        - generic [ref=e134]:
          - generic [ref=e135]:
            - heading "Invoices" [level=1] [ref=e136]
            - paragraph [ref=e137]: Deliveries and supplier invoices
          - button "New invoice" [ref=e139] [cursor=pointer]
        - tablist "Invoice views" [ref=e140]:
          - tab "Drafts" [ref=e141] [cursor=pointer]
          - tab "Processing" [ref=e143] [cursor=pointer]
          - tab "Needs review" [selected] [ref=e145] [cursor=pointer]
          - tab "Ready to post" [ref=e147] [cursor=pointer]
          - tab "Posted" [ref=e149] [cursor=pointer]
          - tab "Cancelled" [ref=e151] [cursor=pointer]
        - generic [ref=e153]:
          - complementary "Original invoice" [ref=e154]:
            - generic [ref=e155]:
              - heading "Original invoice" [level=2] [ref=e156]
              - paragraph [ref=e157]: AI invoice reading is simulated
              - generic [ref=e159]:
                - generic [ref=e160]: Upload a PDF or photo
                - generic [ref=e161]:
                  - button "Upload a PDF or photo" [ref=e162]
                  - button "Take photo" [ref=e163]
                  - generic [ref=e164]:
                    - generic [ref=e168]:
                      - strong [ref=e169]: fictional-a2-invoice.png
                      - generic [ref=e170]: 1 KB
                    - button "Remove file" [ref=e171] [cursor=pointer]
                  - button "Browse" [ref=e176] [cursor=pointer]
              - group "Original invoice" [ref=e177]:
                - generic [ref=e178]:
                  - button "Zoom out" [ref=e179] [cursor=pointer]
                  - generic [ref=e181]: 100%
                  - button "Zoom in" [ref=e182] [cursor=pointer]
                - button "Fit width" [ref=e184] [cursor=pointer]
                - button "Fit page" [ref=e185] [cursor=pointer]
                - button "Download" [ref=e186] [cursor=pointer]
              - img "Original invoice image" [ref=e191]
          - generic [ref=e192]:
            - generic [ref=e193]:
              - generic "Delivery summary" [ref=e194]:
                - generic [ref=e195]:
                  - generic [ref=e196]: Subtotal
                  - strong [ref=e197]: $174.52
                - generic [ref=e198]:
                  - generic [ref=e199]: Tax
                  - strong [ref=e200]: $2.50
                - generic [ref=e201]:
                  - generic [ref=e202]: Shorts and refused deduction
                  - strong [ref=e203]: $0.00
                - generic [ref=e204]:
                  - generic [ref=e205]: Payable
                  - strong [ref=e206]: $177.02
              - paragraph [ref=e207]: This is the amount of this invoice, not a supplier balance. Received records only physically delivered units.
            - generic [ref=e208]:
              - heading [level=2] [ref=e209]:
                - button "Invoice details" [ref=e210] [cursor=pointer]
              - paragraph [ref=e213]:
                - generic [ref=e214]: Fresh Valley Foods
                - text: ·
                - generic [ref=e215]: FV-20417
                - text: · North York ·
                - generic [ref=e216]: 2026-10-15
              - paragraph [ref=e217]:
                - generic [ref=e218]: Needs review
                - text: Changes save automatically in this browser.
            - generic [ref=e220]:
              - heading "Compare with order" [level=2] [ref=e221]
              - generic [ref=e222]:
                - generic [ref=e223]: Order (optional)
                - combobox "Order (optional)" [ref=e224] [cursor=pointer]:
                  - generic [ref=e225]: No linked order
                - paragraph [ref=e228]: Choose an open order for this supplier and receiving location.
            - generic [ref=e229]:
              - heading "Review invoice lines" [level=2] [ref=e230]
              - paragraph [ref=e231]: Choose Cases or Units and confirm the product, pack, quantities, cost, and date decision on each line.
              - table [ref=e233]:
                - 'rowgroup "Line 1: Canned Fava Beans 400 g" [ref=e234]':
                  - row [ref=e235] [cursor=pointer]:
                    - cell "1. Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی 0002 · 400 g Matched" [ref=e236]:
                      - generic [ref=e237]:
                        - heading [level=3] [ref=e238]:
                          - button "1. Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی" [expanded] [ref=e239]:
                            - generic [ref=e240]: "1."
                            - generic [ref=e241]:
                              - strong [ref=e242]:
                                - generic [ref=e243]:
                                  - text: Canned Fava Beans
                                  - generic [ref=e244]: 400 g
                              - generic [ref=e246]:
                                - text: باقالا کنسرو شده
                                - generic [ref=e247]: ۴۰۰ گرمی
                        - paragraph [ref=e250]:
                          - text: 0002 ·
                          - generic [ref=e251]: 400 g
                        - generic [ref=e254]: Matched
                    - cell [ref=e257]:
                      - generic [ref=e258]:
                        - generic [ref=e259]: Invoiced
                        - textbox "Invoiced" [ref=e260]: "2"
                      - generic [ref=e261]:
                        - generic [ref=e262]: Delivered
                        - textbox "Delivered" [ref=e263]: "24"
                    - cell [ref=e264]:
                      - generic [ref=e265]:
                        - generic [ref=e266]: Unit cost before tax
                        - textbox "Unit cost before tax" [ref=e267]: "0.98"
                    - cell "Line total $23.52" [ref=e268]:
                      - generic [ref=e269]: Line total
                      - text: $23.52
                    - 'cell "Selling price $1.49 Approved: $1.49" [ref=e270]':
                      - generic [ref=e271]:
                        - generic [ref=e272]: Selling price
                        - strong [ref=e273]: $1.49
                        - paragraph [ref=e274]: "Approved: $1.49"
                  - row [ref=e275]:
                    - cell [ref=e276]:
                      - generic [ref=e277]:
                        - group [ref=e278]:
                          - generic [ref=e279]:
                            - generic [ref=e280]: Quantity unit
                            - combobox "Quantity unit" [ref=e281] [cursor=pointer]:
                              - generic [ref=e282]: Cases
                          - generic [ref=e285]:
                            - generic [ref=e286]: Units per case
                            - textbox "Units per case" [ref=e287]: "12"
                          - generic [ref=e288]:
                            - generic [ref=e289]: Supplier item code (optional)
                            - textbox "Supplier item code (optional)" [ref=e290]
                          - generic [ref=e291]:
                            - generic [ref=e292]: Case cost before tax
                            - textbox "Case cost before tax" [ref=e293]: "11.7600"
                          - paragraph [ref=e294]: 2 × 12 = 24 units
                          - generic [ref=e295]:
                            - generic [ref=e296]: Matched product
                            - combobox "Matched product" [ref=e297] [cursor=pointer]:
                              - generic [ref=e299]:
                                - text: ⁦0002⁩ · ⁦
                                - generic [ref=e300]:
                                  - text: Canned Fava Beans
                                  - generic [ref=e301]: 400 g
                                - text: ⁩
                          - generic [ref=e304]:
                            - generic [ref=e305]: Pricing category
                            - combobox "Pricing category" [ref=e306] [cursor=pointer]:
                              - generic [ref=e307]: Grocery
                        - button "Remove line" [ref=e310] [cursor=pointer]
                        - checkbox "Mark as short" [ref=e311] [cursor=pointer]
                        - group [ref=e314]:
                          - generic [ref=e315]:
                            - generic [ref=e316]: Track date
                            - group "Track date" [ref=e317]:
                              - button "Yes" [pressed] [ref=e318] [cursor=pointer]
                              - button "No" [ref=e320] [cursor=pointer]
                          - generic [ref=e322]:
                            - generic [ref=e323]:
                              - generic [ref=e324]: Date tracking
                              - combobox "Date tracking" [ref=e325] [cursor=pointer]:
                                - generic [ref=e326]: Expiry
                            - generic [ref=e329]:
                              - generic [ref=e330]: Date
                              - button "Date" [ref=e331] [cursor=pointer]:
                                - generic [ref=e332]: Choose date
                            - generic [ref=e335]:
                              - generic [ref=e336]: Lot number (optional)
                              - textbox "Lot number (optional)" [ref=e337]
                        - checkbox "Confirm this invoice line" [ref=e338] [cursor=pointer]
                - 'rowgroup "Line 2: Ground Sumac 100 g" [ref=e341]':
                  - row [ref=e342] [cursor=pointer]:
                    - cell "2. Ground Sumac 100 g سماق ۱۰۰ گرمی 0005 · 100 g Matched" [ref=e343]:
                      - generic [ref=e344]:
                        - heading [level=3] [ref=e345]:
                          - button "2. Ground Sumac 100 g سماق ۱۰۰ گرمی" [expanded] [ref=e346]:
                            - generic [ref=e347]: "2."
                            - generic [ref=e348]:
                              - strong [ref=e349]:
                                - generic [ref=e350]:
                                  - text: Ground Sumac
                                  - generic [ref=e351]: 100 g
                              - generic [ref=e353]:
                                - text: سماق
                                - generic [ref=e354]: ۱۰۰ گرمی
                        - paragraph [ref=e357]:
                          - text: 0005 ·
                          - generic [ref=e358]: 100 g
                        - generic [ref=e361]: Matched
                    - cell [ref=e364]:
                      - generic [ref=e365]:
                        - generic [ref=e366]: Invoiced
                        - textbox "Invoiced" [ref=e367]: "1"
                      - generic [ref=e368]:
                        - generic [ref=e369]: Delivered
                        - textbox "Delivered" [ref=e370]: "12"
                    - cell [ref=e371]:
                      - generic [ref=e372]:
                        - generic [ref=e373]: Unit cost before tax
                        - textbox "Unit cost before tax" [ref=e374]: "1.30"
                    - cell "Line total $15.60" [ref=e375]:
                      - generic [ref=e376]: Line total
                      - text: $15.60
                    - 'cell "Selling price $1.99 Approved: $1.99" [ref=e377]':
                      - generic [ref=e378]:
                        - generic [ref=e379]: Selling price
                        - strong [ref=e380]: $1.99
                        - paragraph [ref=e381]: "Approved: $1.99"
                  - row [ref=e382]:
                    - cell [ref=e383]:
                      - generic [ref=e384]:
                        - group [ref=e385]:
                          - generic [ref=e386]:
                            - generic [ref=e387]: Quantity unit
                            - combobox "Quantity unit" [ref=e388] [cursor=pointer]:
                              - generic [ref=e389]: Cases
                          - generic [ref=e392]:
                            - generic [ref=e393]: Units per case
                            - textbox "Units per case" [ref=e394]: "12"
                          - generic [ref=e395]:
                            - generic [ref=e396]: Supplier item code (optional)
                            - textbox "Supplier item code (optional)" [ref=e397]
                          - generic [ref=e398]:
                            - generic [ref=e399]: Case cost before tax
                            - textbox "Case cost before tax" [ref=e400]: "15.6000"
                          - paragraph [ref=e401]: 1 × 12 = 12 units
                          - generic [ref=e402]:
                            - generic [ref=e403]: Matched product
                            - combobox "Matched product" [ref=e404] [cursor=pointer]:
                              - generic [ref=e406]:
                                - text: ⁦0005⁩ · ⁦
                                - generic [ref=e407]:
                                  - text: Ground Sumac
                                  - generic [ref=e408]: 100 g
                                - text: ⁩
                          - generic [ref=e411]:
                            - generic [ref=e412]: Pricing category
                            - combobox "Pricing category" [ref=e413] [cursor=pointer]:
                              - generic [ref=e414]: Grocery
                        - button "Remove line" [ref=e417] [cursor=pointer]
                        - checkbox "Mark as short" [ref=e418] [cursor=pointer]
                        - group [ref=e421]:
                          - generic [ref=e422]:
                            - generic [ref=e423]: Track date
                            - group "Track date" [ref=e424]:
                              - button "Yes" [pressed] [ref=e425] [cursor=pointer]
                              - button "No" [ref=e427] [cursor=pointer]
                          - generic [ref=e429]:
                            - generic [ref=e430]:
                              - generic [ref=e431]: Date tracking
                              - combobox "Date tracking" [ref=e432] [cursor=pointer]:
                                - generic [ref=e433]: Expiry
                            - generic [ref=e436]:
                              - generic [ref=e437]: Date
                              - button "Date" [ref=e438] [cursor=pointer]:
                                - generic [ref=e439]: Choose date
                            - generic [ref=e442]:
                              - generic [ref=e443]: Lot number (optional)
                              - textbox "Lot number (optional)" [ref=e444]
                        - checkbox "Confirm this invoice line" [ref=e445] [cursor=pointer]
                - 'rowgroup "Line 3: Lavash Bread 500 g" [ref=e448]':
                  - row [ref=e449] [cursor=pointer]:
                    - cell "3. Lavash Bread 500 g نان لواش ۵۰۰ گرمی 0006 · 500 g Matched" [ref=e450]:
                      - generic [ref=e451]:
                        - heading [level=3] [ref=e452]:
                          - button "3. Lavash Bread 500 g نان لواش ۵۰۰ گرمی" [expanded] [ref=e453]:
                            - generic [ref=e454]: "3."
                            - generic [ref=e455]:
                              - strong [ref=e456]:
                                - generic [ref=e457]:
                                  - text: Lavash Bread
                                  - generic [ref=e458]: 500 g
                              - generic [ref=e460]:
                                - text: نان لواش
                                - generic [ref=e461]: ۵۰۰ گرمی
                        - paragraph [ref=e464]:
                          - text: 0006 ·
                          - generic [ref=e465]: 500 g
                        - generic [ref=e468]: Matched
                    - cell [ref=e471]:
                      - generic [ref=e472]:
                        - generic [ref=e473]: Invoiced
                        - textbox "Invoiced" [ref=e474]: "2"
                      - generic [ref=e475]:
                        - generic [ref=e476]: Delivered
                        - textbox "Delivered" [ref=e477]: "20"
                    - cell [ref=e478]:
                      - generic [ref=e479]:
                        - generic [ref=e480]: Unit cost before tax
                        - textbox "Unit cost before tax" [ref=e481]: "1.55"
                    - cell "Line total $31.00" [ref=e482]:
                      - generic [ref=e483]: Line total
                      - text: $31.00
                    - 'cell "Selling price $2.99 Pending Goes to approval when posted Approved: $1.99" [ref=e484]':
                      - generic [ref=e485]:
                        - generic [ref=e486]: Selling price
                        - strong [ref=e487]: $2.99
                        - generic [ref=e488]: Pending
                        - generic [ref=e490]: Goes to approval when posted
                        - paragraph [ref=e491]: "Approved: $1.99"
                  - row [ref=e492]:
                    - cell [ref=e493]:
                      - generic [ref=e494]:
                        - group [ref=e495]:
                          - generic [ref=e496]:
                            - generic [ref=e497]: Quantity unit
                            - combobox "Quantity unit" [ref=e498] [cursor=pointer]:
                              - generic [ref=e499]: Cases
                          - generic [ref=e502]:
                            - generic [ref=e503]: Units per case
                            - textbox "Units per case" [ref=e504]: "10"
                          - generic [ref=e505]:
                            - generic [ref=e506]: Supplier item code (optional)
                            - textbox "Supplier item code (optional)" [ref=e507]
                          - generic [ref=e508]:
                            - generic [ref=e509]: Case cost before tax
                            - textbox "Case cost before tax" [ref=e510]: "15.5000"
                          - paragraph [ref=e511]: 2 × 10 = 20 units
                          - generic [ref=e512]:
                            - generic [ref=e513]: Matched product
                            - combobox "Matched product" [ref=e514] [cursor=pointer]:
                              - generic [ref=e516]:
                                - text: ⁦0006⁩ · ⁦
                                - generic [ref=e517]:
                                  - text: Lavash Bread
                                  - generic [ref=e518]: 500 g
                                - text: ⁩
                          - generic [ref=e521]:
                            - generic [ref=e522]: Pricing category
                            - combobox "Pricing category" [ref=e523] [cursor=pointer]:
                              - generic [ref=e524]: Grocery
                        - button "Remove line" [ref=e527] [cursor=pointer]
                        - checkbox "Mark as short" [ref=e528] [cursor=pointer]
                        - group [ref=e531]:
                          - generic [ref=e532]:
                            - generic [ref=e533]: Track date
                            - group "Track date" [ref=e534]:
                              - button "Yes" [pressed] [ref=e535] [cursor=pointer]
                              - button "No" [ref=e537] [cursor=pointer]
                          - generic [ref=e539]:
                            - generic [ref=e540]:
                              - generic [ref=e541]: Date tracking
                              - combobox "Date tracking" [ref=e542] [cursor=pointer]:
                                - generic [ref=e543]: Expiry
                            - generic [ref=e546]:
                              - generic [ref=e547]: Date
                              - button "Date" [ref=e548] [cursor=pointer]:
                                - generic [ref=e549]: Choose date
                            - generic [ref=e552]:
                              - generic [ref=e553]: Lot number (optional)
                              - textbox "Lot number (optional)" [ref=e554]
                        - checkbox "Confirm this invoice line" [ref=e555] [cursor=pointer]
                - 'rowgroup "Line 4: Sour Cherry Juice 1 L" [ref=e558]':
                  - row [ref=e559] [cursor=pointer]:
                    - cell "4. Sour Cherry Juice 1 L آب آلبالو ۱ لیتری 0003 · 1 L Matched" [ref=e560]:
                      - generic [ref=e561]:
                        - heading [level=3] [ref=e562]:
                          - button "4. Sour Cherry Juice 1 L آب آلبالو ۱ لیتری" [expanded] [ref=e563]:
                            - generic [ref=e564]: "4."
                            - generic [ref=e565]:
                              - strong [ref=e566]:
                                - generic [ref=e567]:
                                  - text: Sour Cherry Juice
                                  - generic [ref=e568]: 1 L
                              - generic [ref=e570]:
                                - text: آب آلبالو
                                - generic [ref=e571]: ۱ لیتری
                        - paragraph [ref=e574]:
                          - text: 0003 ·
                          - generic [ref=e575]: 1 L
                        - generic [ref=e578]: Matched
                    - cell [ref=e581]:
                      - generic [ref=e582]:
                        - generic [ref=e583]: Invoiced
                        - textbox "Invoiced" [ref=e584]: "3"
                      - generic [ref=e585]:
                        - generic [ref=e586]: Delivered
                        - textbox "Delivered" [ref=e587]: "36"
                    - cell [ref=e588]:
                      - generic [ref=e589]:
                        - generic [ref=e590]: Unit cost before tax
                        - textbox "Unit cost before tax" [ref=e591]: "1.80"
                    - cell "Line total $64.80" [ref=e592]:
                      - generic [ref=e593]: Line total
                      - text: $64.80
                    - 'cell "Selling price $2.99 Approved: $2.99" [ref=e594]':
                      - generic [ref=e595]:
                        - generic [ref=e596]: Selling price
                        - strong [ref=e597]: $2.99
                        - paragraph [ref=e598]: "Approved: $2.99"
                  - row [ref=e599]:
                    - cell "Remove line Mark as short Lower-cost receipt Lower-cost receipt Confirm this invoice line" [ref=e600]:
                      - generic [ref=e601]:
                        - group [ref=e602]:
                          - generic [ref=e603]:
                            - generic [ref=e604]: Quantity unit
                            - combobox "Quantity unit" [ref=e605] [cursor=pointer]:
                              - generic [ref=e606]: Cases
                          - generic [ref=e609]:
                            - generic [ref=e610]: Units per case
                            - textbox "Units per case" [ref=e611]: "12"
                          - generic [ref=e612]:
                            - generic [ref=e613]: Supplier item code (optional)
                            - textbox "Supplier item code (optional)" [ref=e614]
                          - generic [ref=e615]:
                            - generic [ref=e616]: Case cost before tax
                            - textbox "Case cost before tax" [ref=e617]: "21.6000"
                          - paragraph [ref=e618]: 3 × 12 = 36 units
                          - generic [ref=e619]:
                            - generic [ref=e620]: Matched product
                            - combobox "Matched product" [ref=e621] [cursor=pointer]:
                              - generic [ref=e623]:
                                - text: ⁦0003⁩ · ⁦
                                - generic [ref=e624]:
                                  - text: Sour Cherry Juice
                                  - generic [ref=e625]: 1 L
                                - text: ⁩
                          - generic [ref=e628]:
                            - generic [ref=e629]: Pricing category
                            - combobox "Pricing category" [ref=e630] [cursor=pointer]:
                              - generic [ref=e631]: Grocery
                        - button "Remove line" [ref=e634] [cursor=pointer]
                        - checkbox "Mark as short" [ref=e635] [cursor=pointer]
                        - generic [ref=e638]:
                          - generic [ref=e639]: Lower-cost receipt
                          - group "Lower-cost receipt" [ref=e640]:
                            - button "Regular receipt" [pressed] [ref=e641] [cursor=pointer]
                            - button "Short-dated (expiry discount)" [ref=e643] [cursor=pointer]
                        - group [ref=e645]:
                          - generic [ref=e646]:
                            - generic [ref=e647]: Track date
                            - group "Track date" [ref=e648]:
                              - button "Yes" [pressed] [ref=e649] [cursor=pointer]
                              - button "No" [ref=e651] [cursor=pointer]
                          - generic [ref=e653]:
                            - generic [ref=e654]:
                              - generic [ref=e655]: Date tracking
                              - combobox "Date tracking" [ref=e656] [cursor=pointer]:
                                - generic [ref=e657]: Expiry
                            - generic [ref=e660]:
                              - generic [ref=e661]: Date
                              - button "Date" [ref=e662] [cursor=pointer]:
                                - generic [ref=e663]: Choose date
                            - generic [ref=e666]:
                              - generic [ref=e667]: Lot number (optional)
                              - textbox "Lot number (optional)" [ref=e668]
                        - checkbox "Confirm this invoice line" [ref=e669] [cursor=pointer]
                - 'rowgroup "Line 5: Dried Barberries 100 g" [ref=e672]':
                  - row [ref=e673] [cursor=pointer]:
                    - cell [ref=e674]:
                      - generic [ref=e675]:
                        - heading [level=3] [ref=e676]:
                          - button "5. Dried Barberries 100 g زرشک خشک ۱۰۰ گرمی" [expanded] [ref=e677]:
                            - generic [ref=e678]: "5."
                            - generic [ref=e679]:
                              - strong [ref=e680]:
                                - generic [ref=e681]:
                                  - text: Dried Barberries
                                  - generic [ref=e682]: 100 g
                              - generic [ref=e684]:
                                - text: زرشک خشک
                                - generic [ref=e685]: ۱۰۰ گرمی
                        - paragraph [ref=e688]: No Product Code yet
                        - generic [ref=e689]: Pending new product
                    - cell [ref=e692]:
                      - generic [ref=e693]:
                        - generic [ref=e694]: Invoiced
                        - textbox "Invoiced" [ref=e695]: "1"
                      - generic [ref=e696]:
                        - generic [ref=e697]: Delivered
                        - textbox "Delivered" [ref=e698]: "6"
                    - cell [ref=e699]:
                      - generic [ref=e700]:
                        - generic [ref=e701]: Unit cost before tax
                        - textbox "Unit cost before tax" [ref=e702]: "3.40"
                    - cell "Line total $20.40" [ref=e703]:
                      - generic [ref=e704]: Line total
                      - text: $20.40
                    - cell "Selling price $5.49 Pending Goes to approval when posted No approved price yet" [ref=e705]:
                      - generic [ref=e706]:
                        - generic [ref=e707]: Selling price
                        - strong [ref=e708]: $5.49
                        - generic [ref=e709]: Pending
                        - generic [ref=e711]: Goes to approval when posted
                        - paragraph [ref=e712]: No approved price yet
                  - row [ref=e713]:
                    - cell [ref=e714]:
                      - generic [ref=e715]:
                        - group [ref=e716]:
                          - generic [ref=e717]:
                            - generic [ref=e718]: Quantity unit
                            - combobox "Quantity unit" [ref=e719] [cursor=pointer]:
                              - generic [ref=e720]: Cases
                          - generic [ref=e723]:
                            - generic [ref=e724]: Units per case
                            - textbox "Units per case" [ref=e725]: "6"
                          - generic [ref=e726]:
                            - generic [ref=e727]: Supplier item code (optional)
                            - textbox "Supplier item code (optional)" [ref=e728]
                          - generic [ref=e729]:
                            - generic [ref=e730]: Case cost before tax
                            - textbox "Case cost before tax" [ref=e731]: "20.4000"
                          - paragraph [ref=e732]: 1 × 6 = 6 units
                          - generic [ref=e733]:
                            - generic [ref=e734]: Matched product
                            - combobox "Matched product" [ref=e735] [cursor=pointer]:
                              - generic [ref=e736]: Create pending new product
                          - generic [ref=e739]:
                            - generic [ref=e740]: Pricing category
                            - combobox "Pricing category" [ref=e741] [cursor=pointer]:
                              - generic [ref=e742]: Grocery
                          - generic [ref=e745]:
                            - generic [ref=e746]: New product name (English)
                            - textbox "New product name (English)" [ref=e747]: Dried Barberries 100 g
                          - generic [ref=e748]:
                            - generic [ref=e749]: New product name (Persian) (optional)
                            - textbox "New product name (Persian) (optional)" [ref=e750]: زرشک خشک ۱۰۰ گرمی
                        - button "Remove line" [ref=e751] [cursor=pointer]
                        - checkbox "Mark as short" [ref=e752] [cursor=pointer]
                        - group [ref=e755]:
                          - generic [ref=e756]:
                            - generic [ref=e757]: Track date
                            - group "Track date" [ref=e758]:
                              - button "Yes" [ref=e759] [cursor=pointer]
                              - button "No" [ref=e761] [cursor=pointer]
                        - checkbox "Confirm this invoice line" [ref=e763] [cursor=pointer]
                - 'rowgroup "Line 6: Potato Chips 150 g" [ref=e766]':
                  - row [ref=e767] [cursor=pointer]:
                    - cell "6. Potato Chips 150 g چیپس سیب‌زمینی ۱۵۰ گرمی 0009 · 150 g Matched Taxable" [ref=e768]:
                      - generic [ref=e769]:
                        - heading [level=3] [ref=e770]:
                          - button "6. Potato Chips 150 g چیپس سیب‌زمینی ۱۵۰ گرمی" [expanded] [ref=e771]:
                            - generic [ref=e772]: "6."
                            - generic [ref=e773]:
                              - strong [ref=e774]:
                                - generic [ref=e775]:
                                  - text: Potato Chips
                                  - generic [ref=e776]: 150 g
                              - generic [ref=e778]:
                                - text: چیپس سیب‌زمینی
                                - generic [ref=e779]: ۱۵۰ گرمی
                        - paragraph [ref=e782]:
                          - text: 0009 ·
                          - generic [ref=e783]: 150 g
                        - generic [ref=e786]:
                          - generic [ref=e787]: Matched
                          - generic [ref=e789]: Taxable
                    - cell [ref=e791]:
                      - generic [ref=e792]:
                        - generic [ref=e793]: Invoiced
                        - textbox "Invoiced" [ref=e794]: "1"
                      - generic [ref=e795]:
                        - generic [ref=e796]: Delivered
                        - textbox "Delivered" [ref=e797]: "12"
                    - cell [ref=e798]:
                      - generic [ref=e799]:
                        - generic [ref=e800]: Unit cost before tax
                        - textbox "Unit cost before tax" [ref=e801]: "1.60"
                    - cell "Line total $19.20" [ref=e802]:
                      - generic [ref=e803]: Line total
                      - text: $19.20
                    - 'cell "Selling price $2.99 Approved: $2.99" [ref=e804]':
                      - generic [ref=e805]:
                        - generic [ref=e806]: Selling price
                        - strong [ref=e807]: $2.99
                        - paragraph [ref=e808]: "Approved: $2.99"
                  - row [ref=e809]:
                    - cell [ref=e810]:
                      - generic [ref=e811]:
                        - group [ref=e812]:
                          - generic [ref=e813]:
                            - generic [ref=e814]: Quantity unit
                            - combobox "Quantity unit" [ref=e815] [cursor=pointer]:
                              - generic [ref=e816]: Cases
                          - generic [ref=e819]:
                            - generic [ref=e820]: Units per case
                            - textbox "Units per case" [ref=e821]: "12"
                          - generic [ref=e822]:
                            - generic [ref=e823]: Supplier item code (optional)
                            - textbox "Supplier item code (optional)" [ref=e824]
                          - generic [ref=e825]:
                            - generic [ref=e826]: Case cost before tax
                            - textbox "Case cost before tax" [ref=e827]: "19.2000"
                          - paragraph [ref=e828]: 1 × 12 = 12 units
                          - generic [ref=e829]:
                            - generic [ref=e830]: Matched product
                            - combobox "Matched product" [ref=e831] [cursor=pointer]:
                              - generic [ref=e833]:
                                - text: ⁦0009⁩ · ⁦
                                - generic [ref=e834]:
                                  - text: Potato Chips
                                  - generic [ref=e835]: 150 g
                                - text: ⁩
                          - generic [ref=e838]:
                            - generic [ref=e839]: Pricing category
                            - combobox "Pricing category" [ref=e840] [cursor=pointer]:
                              - generic [ref=e841]: Grocery (Taxable)
                        - button "Remove line" [ref=e844] [cursor=pointer]
                        - checkbox "Mark as short" [active] [ref=e845] [cursor=pointer]
                        - group [ref=e848]:
                          - generic [ref=e849]:
                            - generic [ref=e850]: Track date
                            - group "Track date" [ref=e851]:
                              - button "Yes" [pressed] [ref=e852] [cursor=pointer]
                              - button "No" [ref=e854] [cursor=pointer]
                          - generic [ref=e856]:
                            - generic [ref=e857]:
                              - generic [ref=e858]: Date tracking
                              - combobox "Date tracking" [ref=e859] [cursor=pointer]:
                                - generic [ref=e860]: Expiry
                            - generic [ref=e863]:
                              - generic [ref=e864]: Date
                              - button "Date" [ref=e865] [cursor=pointer]:
                                - generic [ref=e866]: Choose date
                            - generic [ref=e869]:
                              - generic [ref=e870]: Lot number (optional)
                              - textbox "Lot number (optional)" [ref=e871]
                        - checkbox "Confirm this invoice line" [ref=e872] [cursor=pointer]
              - generic [ref=e875]:
                - generic [ref=e876]:
                  - generic [ref=e877]: Add a product to the invoice
                  - combobox "Add a product to the invoice" [ref=e878] [cursor=pointer]:
                    - generic [ref=e880]:
                      - text: ⁦0002⁩ · ⁦
                      - generic [ref=e881]:
                        - text: Canned Fava Beans
                        - generic [ref=e882]: 400 g
                      - text: ⁩
                - button "Add line" [ref=e885] [cursor=pointer]
                - button "+ Add new product" [ref=e886] [cursor=pointer]
            - generic [ref=e887]:
              - heading "Same-supplier lower price" [level=2] [ref=e888]
              - paragraph [ref=e889]: Sour Cherry Juice 1 L · Fresh Valley Foods · Old $1.95 · New $1.80
              - paragraph [ref=e890]: Your answers create a Supervisor alert when you post. Unknown information is allowed with a note.
              - group [ref=e891]:
                - generic [ref=e892]:
                  - generic [ref=e893]: Is the expiry date the same as the goods already in the store?
                  - combobox "Is the expiry date the same as the goods already in the store?" [ref=e894] [cursor=pointer]:
                    - generic [ref=e895]: Choose an answer
          - generic [ref=e899]:
            - button "Save as draft" [ref=e900] [cursor=pointer]
            - button "Post invoice" [ref=e901] [cursor=pointer]
```

# Test source

```ts
  26  |     mimeType: "image/png",
  27  |     buffer: pixel,
  28  |   });
  29  |   await expect(page.locator(".invoice-line")).toHaveCount(6, {
  30  |     timeout: 10000,
  31  |   });
  32  |   // Existing seed lines can render before the uploaded original and its
  33  |   // simulated reading transition finish. Geometry and edits must use the
  34  |   // committed upload rather than the previous workspace during that change.
  35  |   await expect
  36  |     .poll(() =>
  37  |       readCanonicalBusinessEvidence(page).then((canonicalState) => {
  38  |         const invoice = JSON.parse(JSON.stringify(canonicalState)!).invoice;
  39  |         return {
  40  |           fileName: invoice.file_name,
  41  |           originalHash: invoice.file_data?.split(":").at(-1),
  42  |           status: invoice.status,
  43  |         };
  44  |       }),
  45  |     )
  46  |     .toEqual({
  47  |       fileName: "fictional-a2-invoice.png",
  48  |       originalHash: createHash("sha256").update(pixel).digest("hex"),
  49  |       status: "review",
  50  |     });
  51  |   await page.evaluate(async () => {
  52  |     await document.fonts.ready;
  53  |     await new Promise((resolve) =>
  54  |       requestAnimationFrame(() => requestAnimationFrame(resolve)),
  55  |     );
  56  |   });
  57  | }
  58  | test("each invoice line requires one date answer, collapses when confirmed and opens from the row", async ({
  59  |   page,
  60  | }) => {
  61  |   await review(page);
  62  |   const lines = page.locator(".invoice-line");
  63  |   await expect(
  64  |     page.getByRole("checkbox", {
  65  |       name: "Confirm date tracking decision",
  66  |       exact: true,
  67  |     }),
  68  |   ).toHaveCount(0);
  69  |   await expect(
  70  |     page.getByRole("checkbox", {
  71  |       name: "Track a date for this line",
  72  |       exact: true,
  73  |     }),
  74  |   ).toHaveCount(0);
  75  |   await expect(
  76  |     page.getByRole("button", { name: "Post invoice", exact: true }),
  77  |   ).toBeEnabled();
  78  |   await page.getByRole("button", { name: "Post invoice", exact: true }).click();
  79  |   await expect(
  80  |     page.getByRole("alert", { name: "What's missing", exact: true }),
  81  |   ).toBeVisible();
  82  |   const first = lines.first();
  83  |   await first
  84  |     .getByRole("checkbox", { name: "Confirm this invoice line", exact: true })
  85  |     .click();
  86  |   await expect(first).toHaveAttribute("data-expanded", "true");
  87  |   await first.getByRole("button", { name: "No", exact: true }).click();
  88  |   await first
  89  |     .getByRole("checkbox", { name: "Confirm this invoice line", exact: true })
  90  |     .click();
  91  |   await expect(first).toHaveAttribute("data-expanded", "false");
  92  |   await expect(first.locator(".invoice-line-detail")).toHaveCount(0);
  93  |   await first.locator(".invoice-line-toggle").click();
  94  |   await expect(first).toHaveAttribute("data-expanded", "true");
  95  |   await first.locator(".invoice-line-summary td").nth(3).click();
  96  |   await expect(first).toHaveAttribute("data-expanded", "false");
  97  |   await expect(
  98  |     lines.nth(4).getByText("No Product Code yet", { exact: true }),
  99  |   ).toBeVisible();
  100 |   await expect(
  101 |     lines.nth(2).getByText("Pending", { exact: true }),
  102 |   ).toBeVisible();
  103 |   await expect(
  104 |     lines.nth(2).getByText("Goes to approval when posted", { exact: true }),
  105 |   ).toBeVisible();
  106 |   const section = page.locator(".invoice-summary-section");
  107 |   expect(
  108 |     await section
  109 |       .locator(".invoice-summary-note")
  110 |       .evaluate((note) =>
  111 |         Math.round(
  112 |           note.getBoundingClientRect().top -
  113 |             note.previousElementSibling!.getBoundingClientRect().bottom,
  114 |         ),
  115 |       ),
  116 |   ).toBe(16);
  117 | });
  118 | test("Persian signed money, line numbers and deduction parentheses stay isolated", async ({
  119 |   page,
  120 | }) => {
  121 |   await review(page);
  122 |   await page
  123 |     .locator(".invoice-line")
  124 |     .nth(5)
  125 |     .getByRole("checkbox", { name: "Mark as short", exact: true })
> 126 |     .check();
      |      ^ Error: locator.check: Clicking the checkbox did not change its state
  127 |   await setLanguage(page, "fa");
  128 |   const deduction = page
  129 |     .locator(".invoice-summary-grid .ui-summary-tile")
  130 |     .nth(2);
  131 |   await expect(deduction).toContainText("-$7.23");
  132 |   await expect(deduction.locator('bdi[dir="ltr"]')).toContainText("-$7.23");
  133 |   await expect(page.locator(".invoice-line-toggle > bdi").first()).toHaveText(
  134 |     "1.",
  135 |   );
  136 |   const parentheses = page
  137 |     .locator(".invoice-line")
  138 |     .nth(5)
  139 |     .locator(".banner > bdi")
  140 |     .last();
  141 |   await expect(parentheses).toHaveAttribute("dir", "ltr");
  142 |   await expect(parentheses).toContainText("($6.40 + $0.83 )");
  143 | });
  144 | test("the document sticks beside the review and the action bar has a full surface", async ({
  145 |   page,
  146 | }, testInfo) => {
  147 |   test.skip(
  148 |     testInfo.project.name === "phone",
  149 |     "Phone review uses one stacked column.",
  150 |   );
  151 |   await page.setViewportSize({ width: 1920, height: 1080 });
  152 |   await review(page);
  153 |   await page.evaluate(() => window.scrollTo(0, 450));
  154 |   const pane = await page.locator(".invoice-document-pane").boundingBox();
  155 |   const topbar = await page.locator(".topbar").boundingBox();
  156 |   expect(pane!.y).toBeGreaterThanOrEqual(topbar!.y + topbar!.height + 22);
  157 |   expect(pane!.y).toBeLessThanOrEqual(topbar!.y + topbar!.height + 26);
  158 |   const reviewPane = await page.locator(".invoice-review-pane").boundingBox();
  159 |   const footer = await page.locator(".invoice-action-footer").boundingBox();
  160 |   // The C7 bar reserves its own row below the review pane instead of stretching across the original.
  161 |   expect(Math.abs(reviewPane!.width - footer!.width)).toBeLessThanOrEqual(2);
  162 |   expect(Math.abs(reviewPane!.x - footer!.x)).toBeLessThanOrEqual(2);
  163 |   expect(footer!.y).toBeGreaterThanOrEqual(reviewPane!.y + reviewPane!.height);
  164 |   await expect(page.locator(".invoice-action-footer")).toHaveCSS(
  165 |     "position",
  166 |     "static",
  167 |   );
  168 |   expect(
  169 |     await page
  170 |       .locator(".invoice-action-footer")
  171 |       .evaluate((node) => getComputedStyle(node).backgroundColor),
  172 |   ).not.toBe("rgba(0, 0, 0, 0)");
  173 |   expect(
  174 |     await page.evaluate(
  175 |       () => document.documentElement.scrollWidth <= window.innerWidth,
  176 |     ),
  177 |   ).toBe(true);
  178 | });
  179 | 
  180 | test("manual invoice drafts work when randomUUID is unavailable", async ({
  181 |   page,
  182 | }) => {
  183 |   const errors: string[] = [];
  184 |   page.on("pageerror", (error) => errors.push(error.message));
  185 |   await page.addInitScript(() => {
  186 |     Object.defineProperty(globalThis.crypto, "randomUUID", {
  187 |       value: undefined,
  188 |       configurable: true,
  189 |     });
  190 |   });
  191 |   await signIn(page, "Supervisor");
  192 |   await page.goto("/#invoices");
  193 |   await page.getByRole("button", { name: "New invoice", exact: true }).click();
  194 |   await page.getByRole("button", { name: "Manual entry", exact: true }).click();
  195 |   await page.getByRole("button", { name: "Add line", exact: true }).click();
  196 |   expect(
  197 |     await page.evaluate(
  198 |       () => document.documentElement.scrollWidth <= window.innerWidth,
  199 |     ),
  200 |   ).toBe(true);
  201 |   expect(
  202 |     await page.evaluate(
  203 |       () => window.innerWidth === document.documentElement.clientWidth,
  204 |     ),
  205 |   ).toBe(true);
  206 |   await page
  207 |     .getByRole("button", { name: "Save as draft", exact: true })
  208 |     .click();
  209 |   await page.reload();
  210 |   await expect(page.locator(".invoice-line")).toHaveCount(1);
  211 |   const invoice = await readCanonicalBusinessEvidence(page).then(
  212 |     (canonicalState) => JSON.parse(JSON.stringify(canonicalState)!).invoice,
  213 |   );
  214 |   expect(invoice.status).toBe("draft");
  215 |   expect(typeof invoice.id).toBe("string");
  216 |   expect(invoice.id.length).toBeGreaterThan(0);
  217 |   expect(await page.evaluate(() => typeof globalThis.crypto.randomUUID)).toBe(
  218 |     "undefined",
  219 |   );
  220 |   expect(errors).toEqual([]);
  221 | });
  222 | 
  223 | test("fictional invoice answers are available only inside Demo and retain Persian copy", async ({
  224 |   page,
  225 | }) => {
  226 |   await review(page);
```