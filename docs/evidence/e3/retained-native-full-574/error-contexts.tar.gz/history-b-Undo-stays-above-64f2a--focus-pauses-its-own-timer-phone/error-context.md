# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: history-b.spec.ts >> Undo stays above a native modal and keyboard focus pauses its own timer
- Location: tests/history-b.spec.ts:200:1

# Error details

```
Error: expect(received).toMatchObject(expected)

- Expected  - 2
+ Received  + 1

  Object {
-   "action": "Undone",
+   "action": "Cancel price update",
    "actor_username": "manager",
    "by": "Demo Manager",
-   "reversal_kind": "undo",
  }
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=e5]:
    - banner [ref=e6]:
      - button "Open menu" [ref=e7] [cursor=pointer]
      - combobox "Location" [ref=e11] [cursor=pointer]:
        - generic [ref=e16]: North York
      - button "Notifications, 8 unread" [ref=e19] [cursor=pointer]:
        - generic [ref=e20]: "8"
      - button "User menu" [ref=e25] [cursor=pointer]:
        - generic [aria-hidden] [ref=e27]: DM
      - button "More" [ref=e28] [cursor=pointer]
    - main [ref=e34]:
      - generic [ref=e35]:
        - generic [ref=e37]:
          - heading "Cashier lookup" [level=1] [ref=e38]
          - paragraph [ref=e39]: Find the approved price to charge now. Search in English or Persian, or scan a barcode.
        - generic [ref=e40]:
          - generic [ref=e41]: Search products
          - generic [ref=e42]:
            - combobox "Search products" [expanded] [ref=e46]: "0003"
            - button "Scan barcode" [ref=e47] [cursor=pointer]
          - generic [ref=e53]:
            - group "AI category" [ref=e54]:
              - button "All" [pressed] [ref=e55] [cursor=pointer]
              - button "Beans & legumes" [ref=e56] [cursor=pointer]
              - button "Bread & bakery" [ref=e57] [cursor=pointer]
              - button "Cleaning" [ref=e58] [cursor=pointer]
              - button "More categories" [ref=e59] [cursor=pointer]: More
            - generic [ref=e62]: 1 product
            - paragraph [ref=e63]: Use ↑ ↓ and Enter to select a product.
            - button "Clear filters" [ref=e64] [cursor=pointer]
        - generic [ref=e65]:
          - generic [ref=e66]:
            - generic [ref=e67]:
              - heading "Sour Cherry Juice 1 L" [level=2] [ref=e68]:
                - generic [ref=e70]:
                  - text: Sour Cherry Juice
                  - generic [ref=e71]: 1 L
              - paragraph [ref=e72]:
                - generic [ref=e74]:
                  - text: آب آلبالو
                  - generic [ref=e75]: ۱ لیتری
              - paragraph [ref=e76]:
                - generic [ref=e77]: Product Code 0003
                - generic [ref=e78]: 1 L
            - generic [ref=e81]:
              - button "Change price" [ref=e82] [cursor=pointer]
              - button "Edit Sour Cherry Juice 1 L" [active] [ref=e83] [cursor=pointer]: Edit
              - button "Product actions" [ref=e84] [cursor=pointer]
          - paragraph [ref=e89]: "Calculated from invoice FV-20390: $2.99"
          - generic [ref=e91]:
            - strong [ref=e92]: $2.99
            - generic [ref=e93]:
              - paragraph [ref=e94]: Selling price
              - generic [ref=e95]: 2 for $5.00
              - paragraph [ref=e97]: Before tax
          - region "Dates" [ref=e98]:
            - list [ref=e99]:
              - listitem [ref=e100]:
                - generic [ref=e106]: Expires 2026-11-09 · North York
                - generic [ref=e107]: Expiring soon
            - generic [ref=e108]:
              - generic [ref=e115]: Last received 2026-10-14
              - generic [ref=e116]: Fresh Valley Foods · FV-20390
        - generic [ref=e117]:
          - heading "Search results" [level=2] [ref=e118]
          - listbox "Product results" [ref=e119]:
            - option "Sour Cherry Juice 1 L آب آلبالو ۱ لیتری $2.99 2 for $5.00" [selected] [ref=e120] [cursor=pointer]:
              - generic [ref=e121]:
                - strong [ref=e122]:
                  - generic [ref=e124]:
                    - text: Sour Cherry Juice
                    - generic [ref=e125]: 1 L
                - generic [ref=e128]:
                  - text: آب آلبالو
                  - generic [ref=e129]: ۱ لیتری
              - generic [ref=e130]:
                - generic [ref=e131]: $2.99
                - generic [ref=e132]: 2 for $5.00
```

# Test source

```ts
  141 |     .getByRole("button", { name: "Revert", exact: true })
  142 |     .click();
  143 |   await page
  144 |     .getByRole("dialog", { name: "Revert change", exact: true })
  145 |     .getByRole("button", { name: "Revert change", exact: true })
  146 |     .click();
  147 |   await page.goto("/#lookup");
  148 |   await page.getByLabel("Search products", { exact: true }).fill("0006");
  149 |   await expect(page.locator(".lookup-detail-header")).toContainText(
  150 |     "Lavash Bread 500 g",
  151 |   );
  152 |   await expect(page.locator(".lookup-detail-header")).not.toContainText(
  153 |     "corrected",
  154 |   );
  155 |   await page.goto("/#history");
  156 |   await expect(
  157 |     page.getByRole("heading", { name: "History", exact: true }),
  158 |   ).toBeVisible();
  159 |   const range = page.getByRole("button", { name: "Date range", exact: true });
  160 |   await expect(range).toHaveCount(1);
  161 |   await range.click();
  162 |   const rangeDialog = page.getByRole("dialog", {
  163 |     name: "Date range",
  164 |     exact: true,
  165 |   });
  166 |   for (const label of ["Today", "This week", "This month"])
  167 |     await expect(
  168 |       rangeDialog.getByRole("button", { name: label, exact: true }),
  169 |     ).toBeVisible();
  170 |   for (const label of ["From", "To"])
  171 |     await expect(
  172 |       rangeDialog.getByRole("button", { name: label, exact: true }),
  173 |     ).toBeVisible();
  174 |   await rangeDialog
  175 |     .getByRole("button", { name: "Cancel", exact: true })
  176 |     .click();
  177 |   expect(
  178 |     await page.evaluate(
  179 |       () => document.documentElement.scrollWidth > window.innerWidth,
  180 |     ),
  181 |   ).toBe(false);
  182 |   await historyRow(page, "Reverted Save product");
  183 |   await historyRow(page, "Save product", "corrected");
  184 |   await expect(page.locator(".history-table")).toContainText("Reverted");
  185 |   await expect(page.locator(".history-table")).toContainText("Save product");
  186 |   const saved = await readCanonicalBusinessEvidence(page).then(
  187 |     (canonicalState) => JSON.parse(JSON.stringify(canonicalState)!).activity,
  188 |   );
  189 |   expect(saved.at(-1)).toMatchObject({
  190 |     action: "Reverted Save product",
  191 |     by: configuredPersonExpectation("manager").name_en,
  192 |     actor_username: configuredPersonExpectation("manager").username,
  193 |     reversal_kind: "revert",
  194 |   });
  195 |   expect(
  196 |     saved.some((item: { action: string }) => item.action === "Save product"),
  197 |   ).toBe(true);
  198 | });
  199 | 
  200 | test("Undo stays above a native modal and keyboard focus pauses its own timer", async ({
  201 |   page,
  202 | }) => {
  203 |   await signIn(page, "Supervisor");
  204 |   await freezeClock(page);
  205 |   await stopOffer(page, "0003");
  206 |   await page.goto("/#lookup");
  207 |   await page.getByLabel("Search products", { exact: true }).fill("0003");
  208 |   await page.mouse.move(0, 0);
  209 |   await page.clock.runFor(1000);
  210 |   await page.getByRole("button", { name: /^Edit Sour Cherry Juice/ }).click();
  211 |   const dialog = page.getByRole("dialog", {
  212 |     name: "Edit product",
  213 |     exact: true,
  214 |   });
  215 |   const undo = dialog.getByRole("button", { name: "Undo", exact: true });
  216 |   await expect(undo).toBeVisible();
  217 |   await undo.focus();
  218 |   await expect(undo).toBeFocused();
  219 |   await page.clock.runFor(15000);
  220 |   await expect(undo).toBeVisible();
  221 |   expect(
  222 |     await undo.evaluate((node) => {
  223 |       const rect = node.getBoundingClientRect();
  224 |       return (
  225 |         document.elementFromPoint(
  226 |           rect.x + rect.width / 2,
  227 |           rect.y + rect.height / 2,
  228 |         ) === node
  229 |       );
  230 |     }),
  231 |   ).toBe(true);
  232 |   await undo.click();
  233 |   await expect(page.locator(".undo-toast-stack")).not.toBeVisible();
  234 |   await page.keyboard.press("Escape");
  235 |   await expect(
  236 |     page.locator(".lookup-approved-price .offer-pill"),
  237 |   ).toContainText("2 for $5");
  238 |   const saved = await readCanonicalBusinessEvidence(page).then(
  239 |     (canonicalState) => JSON.parse(JSON.stringify(canonicalState)!).activity,
  240 |   );
> 241 |   expect(saved.at(-1)).toMatchObject({
      |                        ^ Error: expect(received).toMatchObject(expected)
  242 |     action: "Undone",
  243 |     by: configuredPersonExpectation("manager").name_en,
  244 |     actor_username: configuredPersonExpectation("manager").username,
  245 |     reversal_kind: "undo",
  246 |   });
  247 |   expect(
  248 |     saved.some((item: { action: string }) => item.action === "Stop offer"),
  249 |   ).toBe(true);
  250 | });
  251 | 
  252 | test("History Revert previews the actor, branch, values and requires confirmation", async ({
  253 |   page,
  254 | }) => {
  255 |   await signIn(page, "Supervisor");
  256 |   await freezeClock(page);
  257 |   await saveName(page, "Lavash Bread 500 g approved edit");
  258 |   await page.clock.runFor(10001);
  259 |   await expect(page.locator(".undo-toast-stack")).not.toBeVisible();
  260 |   await page.goto("/#history");
  261 |   const row = await historyRow(page, "Save product");
  262 |   await row.getByRole("button", { name: "Revert", exact: true }).click();
  263 |   const dialog = page.getByRole("dialog", {
  264 |     name: "Revert change",
  265 |     exact: true,
  266 |   });
  267 |   await expect(dialog).toContainText(
  268 |     configuredPersonExpectation("manager").name_en,
  269 |   );
  270 |   await expect(dialog).toContainText("All branches");
  271 |   await expect(dialog).toContainText("Lavash Bread 500 g approved edit");
  272 |   await expect(dialog).toContainText("Lavash Bread 500 g");
  273 |   let stored = await readCanonicalBusinessEvidence(page).then(
  274 |     (canonicalState) =>
  275 |       JSON.parse(JSON.stringify(canonicalState)!).products.find(
  276 |         (item: { code: string }) => item.code === "0006",
  277 |       ).name_en,
  278 |   );
  279 |   expect(stored).toContain("approved edit");
  280 |   await dialog
  281 |     .getByRole("button", { name: "Revert change", exact: true })
  282 |     .click();
  283 |   await expect(dialog).not.toBeVisible();
  284 |   await expect(page.getByRole("status")).toContainText("Change reverted");
  285 |   stored = await readCanonicalBusinessEvidence(page).then(
  286 |     (canonicalState) =>
  287 |       JSON.parse(JSON.stringify(canonicalState)!).products.find(
  288 |         (item: { code: string }) => item.code === "0006",
  289 |       ).name_en,
  290 |   );
  291 |   expect(stored).toBe("Lavash Bread 500 g");
  292 |   await historyRow(page, "Reverted Save product");
  293 |   await expect(page.locator(".history-table")).toContainText(
  294 |     "Reverted Save product",
  295 |   );
  296 | });
  297 | 
  298 | test("an intervening edit displays a conflict and cannot be silently overwritten", async ({
  299 |   page,
  300 | }) => {
  301 |   await signIn(page, "Supervisor");
  302 |   await freezeClock(page);
  303 |   await saveName(page, "Lavash Bread 500 g first change");
  304 |   await saveName(page, "Lavash Bread 500 g latest change");
  305 |   await page.goto("/#history");
  306 |   const older = await historyRow(
  307 |     page,
  308 |     "Save product",
  309 |     "first change",
  310 |     "latest change",
  311 |   );
  312 |   await older.getByRole("button", { name: "Revert", exact: true }).click();
  313 |   const dialog = page.getByRole("dialog", {
  314 |     name: "Revert change",
  315 |     exact: true,
  316 |   });
  317 |   await expect(
  318 |     dialog.getByRole("alert").filter({ hasText: "changed again" }),
  319 |   ).toContainText("changed again");
  320 |   await expect(
  321 |     dialog.getByRole("button", { name: "Revert change", exact: true }),
  322 |   ).toBeDisabled();
  323 |   await page.keyboard.press("Escape");
  324 |   await page.goto("/#lookup");
  325 |   await page.getByLabel("Search products", { exact: true }).fill("0006");
  326 |   await expect(page.locator(".lookup-detail-header")).toContainText(
  327 |     "latest change",
  328 |   );
  329 | });
  330 | 
  331 | test("each eligible action replaces the single toast and its last message expires after eight seconds", async ({
  332 |   page,
  333 | }) => {
  334 |   await signIn(page, "Supervisor");
  335 |   await page.goto("/#offers");
  336 |   const codes = await page
  337 |     .locator(".current-offers-table tr[data-product-code]")
  338 |     .evaluateAll((rows) =>
  339 |       rows.map((row) => row.getAttribute("data-product-code")!),
  340 |     );
  341 |   // C8 adds two sale records beside the original five multi-buy offers.
```