# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: c8-layout-display.spec.ts >> C8 list navigation and disclosure stay at the row end (en)
- Location: tests/c8-layout-display.spec.ts:220:3

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('.received-table tbody > tr[data-row-href]').first().locator('td[data-column-key="actions"] .table-row-link')
Expected: 1
Received: 0
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" locator('.received-table tbody > tr[data-row-href]').first().locator('td[data-column-key="actions"] .table-row-link') with timeout 5000ms
  - waiting for locator('.received-table tbody > tr[data-row-href]').first().locator('td[data-column-key="actions"] .table-row-link')
    14 × locator resolved to 0 elements
       - unexpected value "0"

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=e5]:
    - banner [ref=e6]:
      - button "Open menu" [ref=e7] [cursor=pointer]
      - combobox "Location" [ref=e11] [cursor=pointer]:
        - generic [ref=e16]: North York
      - button "Notifications, 5 unread" [ref=e19] [cursor=pointer]:
        - generic [ref=e20]: "5"
      - button "User menu" [ref=e25] [cursor=pointer]:
        - generic [aria-hidden] [ref=e27]: DM
      - button "More" [ref=e28] [cursor=pointer]
    - main [ref=e34]:
      - generic [ref=e36]:
        - heading "Received" [level=1] [ref=e37]
        - paragraph [ref=e38]: What came in, where and when.
      - generic [ref=e39]:
        - generic "Received filters" [ref=e40]:
          - textbox "Search Received" [ref=e45]:
            - /placeholder: Search products, invoices or suppliers
          - button "Date range" [ref=e46] [cursor=pointer]
          - combobox "Supplier" [ref=e49] [cursor=pointer]:
            - generic [ref=e50]: All suppliers
          - combobox "Product" [ref=e53] [cursor=pointer]:
            - generic [ref=e54]: All products
          - button "Clear filters" [ref=e57] [cursor=pointer]
          - generic [ref=e59]:
            - generic [ref=e60]: 20 deliveries
            - button "Columns" [ref=e61] [cursor=pointer]
        - table [ref=e65]:
          - rowgroup [ref=e66]:
            - row [ref=e67]:
              - cell "Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی" [ref=e68]:
                - generic [ref=e70]:
                  - strong [ref=e71]:
                    - generic [ref=e72]:
                      - text: Canned Fava Beans
                      - generic [ref=e73]: 400 g
                  - generic [ref=e75]:
                    - text: باقالا کنسرو شده
                    - generic [ref=e76]: ۴۰۰ گرمی
              - cell "2 cases (24 units)" [ref=e77]:
                - text: 2 cases
                - generic [ref=e78]: (24 units)
              - cell [ref=e79]:
                - link "Invoice FV-20390" [ref=e80] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3AFV-20390"
              - cell "North York Fresh Valley Foods 2026-10-14" [ref=e83]:
                - generic [ref=e84]: North York
                - generic [ref=e85]: Fresh Valley Foods
                - generic [ref=e87]: 2026-10-14
            - row [ref=e89]:
              - cell "Ground Sumac 100 g سماق ۱۰۰ گرمی" [ref=e90]:
                - generic [ref=e92]:
                  - strong [ref=e93]:
                    - generic [ref=e94]:
                      - text: Ground Sumac
                      - generic [ref=e95]: 100 g
                  - generic [ref=e97]:
                    - text: سماق
                    - generic [ref=e98]: ۱۰۰ گرمی
              - cell "1 case (12 units)" [ref=e99]:
                - text: 1 case
                - generic [ref=e100]: (12 units)
              - cell [ref=e101]:
                - link "Invoice FV-20390" [ref=e102] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3AFV-20390"
              - cell "North York Fresh Valley Foods 2026-10-14" [ref=e105]:
                - generic [ref=e106]: North York
                - generic [ref=e107]: Fresh Valley Foods
                - generic [ref=e109]: 2026-10-14
            - row [ref=e111]:
              - cell "Lavash Bread 500 g نان لواش ۵۰۰ گرمی" [ref=e112]:
                - generic [ref=e114]:
                  - strong [ref=e115]:
                    - generic [ref=e116]:
                      - text: Lavash Bread
                      - generic [ref=e117]: 500 g
                  - generic [ref=e119]:
                    - text: نان لواش
                    - generic [ref=e120]: ۵۰۰ گرمی
              - cell "2 cases (20 units)" [ref=e121]:
                - text: 2 cases
                - generic [ref=e122]: (20 units)
              - cell [ref=e123]:
                - link "Invoice FV-20390" [ref=e124] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3AFV-20390"
              - cell "North York Fresh Valley Foods 2026-10-14" [ref=e127]:
                - generic [ref=e128]: North York
                - generic [ref=e129]: Fresh Valley Foods
                - generic [ref=e131]: 2026-10-14
            - row [ref=e133]:
              - cell "Sour Cherry Juice 1 L آب آلبالو ۱ لیتری" [ref=e134]:
                - generic [ref=e136]:
                  - strong [ref=e137]:
                    - generic [ref=e138]:
                      - text: Sour Cherry Juice
                      - generic [ref=e139]: 1 L
                  - generic [ref=e141]:
                    - text: آب آلبالو
                    - generic [ref=e142]: ۱ لیتری
              - cell "3 cases (36 units)" [ref=e143]:
                - text: 3 cases
                - generic [ref=e144]: (36 units)
              - cell [ref=e145]:
                - link "Invoice FV-20390" [ref=e146] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3AFV-20390"
              - cell "North York Fresh Valley Foods 2026-10-14" [ref=e149]:
                - generic [ref=e150]: North York
                - generic [ref=e151]: Fresh Valley Foods
                - generic [ref=e153]: 2026-10-14
            - row [ref=e155]:
              - cell "Dried Barberries 100 g زرشک خشک ۱۰۰ گرمی" [ref=e156]:
                - generic [ref=e158]:
                  - strong [ref=e159]:
                    - generic [ref=e160]:
                      - text: Dried Barberries
                      - generic [ref=e161]: 100 g
                  - generic [ref=e163]:
                    - text: زرشک خشک
                    - generic [ref=e164]: ۱۰۰ گرمی
              - cell "1 case (6 units)" [ref=e165]:
                - text: 1 case
                - generic [ref=e166]: (6 units)
              - cell [ref=e167]:
                - link "Invoice FV-20390" [ref=e168] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3AFV-20390"
              - cell "North York Fresh Valley Foods 2026-10-14" [ref=e171]:
                - generic [ref=e172]: North York
                - generic [ref=e173]: Fresh Valley Foods
                - generic [ref=e175]: 2026-10-14
            - row [ref=e177]:
              - cell "Potato Chips 150 g چیپس سیب‌زمینی ۱۵۰ گرمی" [ref=e178]:
                - generic [ref=e180]:
                  - strong [ref=e181]:
                    - generic [ref=e182]:
                      - text: Potato Chips
                      - generic [ref=e183]: 150 g
                  - generic [ref=e185]:
                    - text: چیپس سیب‌زمینی
                    - generic [ref=e186]: ۱۵۰ گرمی
              - cell "1 case (12 units)" [ref=e187]:
                - text: 1 case
                - generic [ref=e188]: (12 units)
              - cell [ref=e189]:
                - link "Invoice FV-20390" [ref=e190] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3AFV-20390"
              - cell "North York Fresh Valley Foods 2026-10-14" [ref=e193]:
                - generic [ref=e194]: North York
                - generic [ref=e195]: Fresh Valley Foods
                - generic [ref=e197]: 2026-10-14
            - row [ref=e199]:
              - cell "Basmati Rice 4.5 kg برنج باسماتی ۴٫۵ کیلوگرمی" [ref=e200]:
                - generic [ref=e202]:
                  - strong [ref=e203]:
                    - generic [ref=e204]:
                      - text: Basmati Rice
                      - generic [ref=e205]: 4.5 kg
                  - generic [ref=e207]:
                    - text: برنج باسماتی
                    - generic [ref=e208]: ۴٫۵ کیلوگرمی
              - cell "1 unit" [ref=e209]
              - cell [ref=e210]:
                - link "Invoice GG-11842" [ref=e211] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3AGG-11842"
              - cell "North York Golden Grain Distributors 2026-10-12" [ref=e214]:
                - generic [ref=e215]: North York
                - generic [ref=e216]: Golden Grain Distributors
                - generic [ref=e218]: 2026-10-12
            - row [ref=e220]:
              - cell "Basmati Rice 4.5 kg برنج باسماتی ۴٫۵ کیلوگرمی" [ref=e221]:
                - generic [ref=e223]:
                  - strong [ref=e224]:
                    - generic [ref=e225]:
                      - text: Basmati Rice
                      - generic [ref=e226]: 4.5 kg
                  - generic [ref=e228]:
                    - text: برنج باسماتی
                    - generic [ref=e229]: ۴٫۵ کیلوگرمی
              - cell "7 cases + 2 units (30 units)" [ref=e230]:
                - text: 7 cases + 2 units
                - generic [ref=e231]: (30 units)
              - cell [ref=e232]:
                - link "Invoice GG-11879" [ref=e233] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3AGG-11879"
              - cell "North York Golden Grain Distributors 2026-10-10" [ref=e236]:
                - generic [ref=e237]: North York
                - generic [ref=e238]: Golden Grain Distributors
                - generic [ref=e240]: 2026-10-10
            - row [ref=e242]:
              - cell "Dried Red Kidney Beans 900 g لوبیا قرمز ۹۰۰ گرمی" [ref=e243]:
                - generic [ref=e245]:
                  - strong [ref=e246]:
                    - generic [ref=e247]:
                      - text: Dried Red Kidney Beans
                      - generic [ref=e248]: 900 g
                  - generic [ref=e250]:
                    - text: لوبیا قرمز
                    - generic [ref=e251]: ۹۰۰ گرمی
              - cell "3 cases + 4 units (40 units)" [ref=e252]:
                - text: 3 cases + 4 units
                - generic [ref=e253]: (40 units)
              - cell [ref=e254]:
                - link "Invoice GG-11879" [ref=e255] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3AGG-11879"
              - cell "North York Golden Grain Distributors 2026-10-10" [ref=e258]:
                - generic [ref=e259]: North York
                - generic [ref=e260]: Golden Grain Distributors
                - generic [ref=e262]: 2026-10-10
            - row [ref=e264]:
              - cell "Black Tea 450 g چای سیاه ۴۵۰ گرمی" [ref=e265]:
                - generic [ref=e267]:
                  - strong [ref=e268]:
                    - generic [ref=e269]:
                      - text: Black Tea
                      - generic [ref=e270]: 450 g
                  - generic [ref=e272]:
                    - text: چای سیاه
                    - generic [ref=e273]: ۴۵۰ گرمی
              - cell "2 cases + 4 units (16 units)" [ref=e274]:
                - text: 2 cases + 4 units
                - generic [ref=e275]: (16 units)
              - cell [ref=e276]:
                - link "Invoice SB-7862" [ref=e277] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3ASB-7862"
              - cell "North York Sunrise Beverages 2026-10-06" [ref=e280]:
                - generic [ref=e281]: North York
                - generic [ref=e282]: Sunrise Beverages
                - generic [ref=e284]: 2026-10-06
            - row [ref=e286]:
              - cell "Fruit Soda 6-pack نوشابه میوه‌ای بسته ۶ عددی" [ref=e287]:
                - generic [ref=e289]:
                  - strong [ref=e290]: Fruit Soda 6-pack
                  - generic [ref=e291]: نوشابه میوه‌ای بسته ۶ عددی
              - cell "2 cases (12 units)" [ref=e292]:
                - text: 2 cases
                - generic [ref=e293]: (12 units)
              - cell [ref=e294]:
                - link "Invoice SB-7862" [ref=e295] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3ASB-7862"
              - cell "North York Sunrise Beverages 2026-10-06" [ref=e298]:
                - generic [ref=e299]: North York
                - generic [ref=e300]: Sunrise Beverages
                - generic [ref=e302]: 2026-10-06
            - row [ref=e304]:
              - cell "Black Tea 450 g چای سیاه ۴۵۰ گرمی" [ref=e305]:
                - generic [ref=e307]:
                  - strong [ref=e308]:
                    - generic [ref=e309]:
                      - text: Black Tea
                      - generic [ref=e310]: 450 g
                  - generic [ref=e312]:
                    - text: چای سیاه
                    - generic [ref=e313]: ۴۵۰ گرمی
              - cell "1 case (6 units)" [ref=e314]:
                - text: 1 case
                - generic [ref=e315]: (6 units)
              - cell [ref=e316]:
                - link "Invoice SB-7848" [ref=e317] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3ASB-7848"
              - cell "North York Sunrise Beverages 2026-10-05" [ref=e320]:
                - generic [ref=e321]: North York
                - generic [ref=e322]: Sunrise Beverages
                - generic [ref=e324]: 2026-10-05
            - row [ref=e326]:
              - cell "Tea Glass Set (6 pcs) ست استکان چای (۶ عددی)" [ref=e327]:
                - generic [ref=e329]:
                  - strong [ref=e330]: Tea Glass Set (6 pcs)
                  - generic [ref=e331]: ست استکان چای (۶ عددی)
              - cell "10 cases (20 units)" [ref=e332]:
                - text: 10 cases
                - generic [ref=e333]: (20 units)
              - cell [ref=e334]:
                - link "Invoice HW-4936" [ref=e335] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3AHW-4936"
              - cell "North York HomeWare Imports 2026-09-24" [ref=e338]:
                - generic [ref=e339]: North York
                - generic [ref=e340]: HomeWare Imports
                - generic [ref=e342]: 2026-09-24
            - row [ref=e344]:
              - cell "Stainless Steel Pot 24 cm قابلمه استیل ۲۴ سانتی‌متری" [ref=e345]:
                - generic [ref=e347]:
                  - strong [ref=e348]: Stainless Steel Pot 24 cm
                  - generic [ref=e349]: قابلمه استیل ۲۴ سانتی‌متری
              - cell "10 cases (30 units)" [ref=e350]:
                - text: 10 cases
                - generic [ref=e351]: (30 units)
              - cell [ref=e352]:
                - link "Invoice HW-4936" [ref=e353] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3AHW-4936"
              - cell "North York HomeWare Imports 2026-09-24" [ref=e356]:
                - generic [ref=e357]: North York
                - generic [ref=e358]: HomeWare Imports
                - generic [ref=e360]: 2026-09-24
            - row [ref=e362]:
              - cell "Rice Cooker 1.8 L پلوپز ۱٫۸ لیتری" [ref=e363]:
                - generic [ref=e365]:
                  - strong [ref=e366]:
                    - generic [ref=e367]:
                      - text: Rice Cooker
                      - generic [ref=e368]: 1.8 L
                  - generic [ref=e370]:
                    - text: پلوپز
                    - generic [ref=e371]: ۱٫۸ لیتری
              - cell "20 units" [ref=e372]
              - cell [ref=e373]:
                - link "Invoice HW-4936" [ref=e374] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3AHW-4936"
              - cell "North York HomeWare Imports 2026-09-24" [ref=e377]:
                - generic [ref=e378]: North York
                - generic [ref=e379]: HomeWare Imports
                - generic [ref=e381]: 2026-09-24
            - row [ref=e383]:
              - cell "Kitchen Sponge 3-pack اسفنج ظرفشویی بسته ۳ عددی" [ref=e384]:
                - generic [ref=e386]:
                  - strong [ref=e387]: Kitchen Sponge 3-pack
                  - generic [ref=e388]: اسفنج ظرفشویی بسته ۳ عددی
              - cell "5 cases (20 units)" [ref=e389]:
                - text: 5 cases
                - generic [ref=e390]: (20 units)
              - cell [ref=e391]:
                - link "Invoice HW-4936" [ref=e392] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3AHW-4936"
              - cell "North York HomeWare Imports 2026-09-24" [ref=e395]:
                - generic [ref=e396]: North York
                - generic [ref=e397]: HomeWare Imports
                - generic [ref=e399]: 2026-09-24
            - row [ref=e401]:
              - cell "Sour Cherry Juice 1 L آب آلبالو ۱ لیتری" [ref=e402]:
                - generic [ref=e404]:
                  - strong [ref=e405]:
                    - generic [ref=e406]:
                      - text: Sour Cherry Juice
                      - generic [ref=e407]: 1 L
                  - generic [ref=e409]:
                    - text: آب آلبالو
                    - generic [ref=e410]: ۱ لیتری
              - cell "1 case (12 units)" [ref=e411]:
                - text: 1 case
                - generic [ref=e412]: (12 units)
              - cell [ref=e413]:
                - link "Invoice FV-20296" [ref=e414] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3AFV-20296"
              - cell "North York Fresh Valley Foods 2026-09-21" [ref=e417]:
                - generic [ref=e418]: North York
                - generic [ref=e419]: Fresh Valley Foods
                - generic [ref=e421]: 2026-09-21
            - row [ref=e423]:
              - cell "Ground Sumac 100 g سماق ۱۰۰ گرمی" [ref=e424]:
                - generic [ref=e426]:
                  - strong [ref=e427]:
                    - generic [ref=e428]:
                      - text: Ground Sumac
                      - generic [ref=e429]: 100 g
                  - generic [ref=e431]:
                    - text: سماق
                    - generic [ref=e432]: ۱۰۰ گرمی
              - cell "1 case (12 units)" [ref=e433]:
                - text: 1 case
                - generic [ref=e434]: (12 units)
              - cell [ref=e435]:
                - link "Invoice FV-20296" [ref=e436] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3AFV-20296"
              - cell "North York Fresh Valley Foods 2026-09-21" [ref=e439]:
                - generic [ref=e440]: North York
                - generic [ref=e441]: Fresh Valley Foods
                - generic [ref=e443]: 2026-09-21
            - row [ref=e445]:
              - cell "Basmati Rice 4.5 kg برنج باسماتی ۴٫۵ کیلوگرمی" [ref=e446]:
                - generic [ref=e448]:
                  - strong [ref=e449]:
                    - generic [ref=e450]:
                      - text: Basmati Rice
                      - generic [ref=e451]: 4.5 kg
                  - generic [ref=e453]:
                    - text: برنج باسماتی
                    - generic [ref=e454]: ۴٫۵ کیلوگرمی
              - cell "5 cases (20 units)" [ref=e455]:
                - text: 5 cases
                - generic [ref=e456]: (20 units)
              - cell [ref=e457]:
                - link "Invoice GG-11842" [ref=e458] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3AGG-11842"
              - cell "North York Golden Grain Distributors 2026-09-10" [ref=e461]:
                - generic [ref=e462]: North York
                - generic [ref=e463]: Golden Grain Distributors
                - generic [ref=e465]: 2026-09-10
            - row [ref=e467]:
              - cell "Dried Red Kidney Beans 900 g لوبیا قرمز ۹۰۰ گرمی" [ref=e468]:
                - generic [ref=e470]:
                  - strong [ref=e471]:
                    - generic [ref=e472]:
                      - text: Dried Red Kidney Beans
                      - generic [ref=e473]: 900 g
                  - generic [ref=e475]:
                    - text: لوبیا قرمز
                    - generic [ref=e476]: ۹۰۰ گرمی
              - cell "1 case (12 units)" [ref=e477]:
                - text: 1 case
                - generic [ref=e478]: (12 units)
              - cell [ref=e479]:
                - link "Invoice GG-11794" [ref=e480] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3AGG-11794"
              - cell "North York Golden Grain Distributors 2026-08-24" [ref=e483]:
                - generic [ref=e484]: North York
                - generic [ref=e485]: Golden Grain Distributors
                - generic [ref=e487]: 2026-08-24
```

# Test source

```ts
  139 |     expect(originalHash).toBe(
  140 |       createHash("sha256").update(invoiceImage.buffer).digest("hex"),
  141 |     );
  142 |     const line = page.locator(".invoice-line").first();
  143 |     await line
  144 |       .getByLabel("Unit cost before tax", { exact: true })
  145 |       .fill("1.5525");
  146 |     await line.getByRole("button", { name: "No", exact: true }).click();
  147 |     await line
  148 |       .getByRole("checkbox", { name: "Confirm this invoice line", exact: true })
  149 |       .click();
  150 |     await expect(line).toHaveAttribute("data-expanded", "false");
  151 |     await setLanguage(page, language);
  152 |     const displayedCost = line
  153 |       .locator(".invoice-line-summary > td:nth-child(3)")
  154 |       .getByText("$1.5525", { exact: true });
  155 |     await expect(displayedCost).toBeVisible();
  156 |     await expect(displayedCost).toHaveText("$1.5525");
  157 |     await expect
  158 |       .poll(
  159 |         async () => (await saved(page)).invoice.lines[0].unit_cost_before_tax,
  160 |       )
  161 |       .toBe("1.5525");
  162 |     const after = await saved(page);
  163 |     expect(after.ledger).toEqual(before.ledger);
  164 |     expect(after.invoices).toEqual(before.invoices);
  165 |     expect(after.invoice.file_data).toBe(before.invoice.file_data);
  166 |     expect(await retainedOriginalHash(page, after.invoice.file_data!)).toBe(
  167 |       originalHash,
  168 |     );
  169 |     await page.reload();
  170 |     await expect(displayedCost).toBeVisible();
  171 |     await expect(displayedCost).toHaveText("$1.5525");
  172 |     expect((await saved(page)).invoice.file_data).toBe(
  173 |       before.invoice.file_data,
  174 |     );
  175 |     expect(await retainedOriginalHash(page, before.invoice.file_data!)).toBe(
  176 |       originalHash,
  177 |     );
  178 |   });
  179 | 
  180 |   test(`C8 Received uses whole cases and retained loose units (${language})`, async ({
  181 |     page,
  182 |   }) => {
  183 |     await signIn(page, "Supervisor");
  184 |     const before = await saved(page);
  185 |     await page.goto("/#received");
  186 |     await setLanguage(page, language);
  187 |     for (const [number, code, expected] of [
  188 |       [
  189 |         "GG-11879",
  190 |         "0007",
  191 |         copy(language, "3 cases + 4 units", "3 کارتن + 4 واحد"),
  192 |       ],
  193 |       [
  194 |         "SB-7862",
  195 |         "0004",
  196 |         copy(language, "2 cases + 4 units", "2 کارتن + 4 واحد"),
  197 |       ],
  198 |     ]) {
  199 |       const invoice = before.invoices!.find(
  200 |         (item) => item.supplier_invoice_number === number,
  201 |       )!;
  202 |       expect(invoice).toBeDefined();
  203 |       const name = demo.products.find((item) => item.code === code)!.name_en;
  204 |       const row = page
  205 |         .locator(
  206 |           `.received-table tbody > tr[data-row-href="#invoices?id=${encodeURIComponent(invoice.id)}"]`,
  207 |         )
  208 |         .filter({ hasText: name });
  209 |       await expect(row).toHaveCount(1);
  210 |       const evidence = await quantityEvidence(page, row);
  211 |       await expect(evidence).toContainText(expected);
  212 |       await expect(evidence).not.toContainText(/\d+\.\d+\s+(?:cases|کارتن)/);
  213 |     }
  214 |     const after = await saved(page);
  215 |     expect(after.invoices).toEqual(before.invoices);
  216 |     expect(after.stock_movements).toEqual(before.stock_movements);
  217 |     expect(after.ledger).toEqual(before.ledger);
  218 |   });
  219 | 
  220 |   test(`C8 list navigation and disclosure stay at the row end (${language})`, async ({
  221 |     page,
  222 |   }) => {
  223 |     await signIn(page, "Supervisor");
  224 |     await setLanguage(page, language);
  225 |     const tables = [
  226 |       ["received", ".received-table"],
  227 |       ["suppliers", ".suppliers-table"],
  228 |       ["payables", ".payables-overview-table"],
  229 |       ["returns", ".returns-overview-table"],
  230 |       ["dashboard", ".dashboard-invoices .ui-data-table"],
  231 |     ];
  232 |     for (const [route, selector] of tables) {
  233 |       await page.goto(`/#${route}`);
  234 |       const row = page.locator(`${selector} tbody > tr[data-row-href]`).first();
  235 |       await expect(row).toBeVisible();
  236 |       await expect(row.locator(".table-row-link")).toHaveCount(1);
  237 |       await expect(
  238 |         row.locator('td[data-column-key="actions"] .table-row-link'),
> 239 |       ).toHaveCount(1);
      |         ^ Error: expect(locator).toHaveCount(expected) failed
  240 |       const disclosure = row.locator(".table-details-toggle");
  241 |       if (await disclosure.count()) {
  242 |         await expect(
  243 |           row.locator('td[data-column-key="actions"] .table-details-toggle'),
  244 |         ).toHaveCount(1);
  245 |       }
  246 |     }
  247 |     await page.setViewportSize({ width: 1920, height: 1080 });
  248 |     await page.goto("/#suppliers");
  249 |     const suppliersTable = page.locator(".suppliers-table");
  250 |     const supplierRow = suppliersTable
  251 |       .locator("tbody > tr[data-row-href]")
  252 |       .filter({ hasText: "Fresh Valley Foods" });
  253 |     await expect(supplierRow).toHaveCount(1);
  254 |     const visibleValues = await supplierRow
  255 |       .locator("td[data-column-key]")
  256 |       .evaluateAll((cells) =>
  257 |         Object.fromEntries(
  258 |           cells.map((cell) => [
  259 |             cell.getAttribute("data-column-key")!,
  260 |             cell.textContent?.trim() ?? "",
  261 |           ]),
  262 |         ),
  263 |       );
  264 |     const before = await saved(page);
  265 |     const supplier = before.suppliers!.find(
  266 |       (item) => item.name === "Fresh Valley Foods",
  267 |     )!;
  268 |     expect(supplier).toBeDefined();
  269 |     await page
  270 |       .getByRole("button", {
  271 |         name: copy(language, "Columns", "ستون‌ها"),
  272 |         exact: true,
  273 |       })
  274 |       .click();
  275 |     const columns = page.getByRole("dialog", {
  276 |       name: copy(language, "Columns", "ستون‌ها"),
  277 |       exact: true,
  278 |     });
  279 |     for (const [en, fa] of [
  280 |       ["Payment terms", "شرایط پرداخت"],
  281 |       ["Sales rep and phone", "نماینده فروش و تلفن"],
  282 |       ["Next due date", "سررسید بعدی"],
  283 |     ]) {
  284 |       const option = columns.getByRole("checkbox", {
  285 |         name: copy(language, en, fa),
  286 |         exact: true,
  287 |       });
  288 |       await expect(option).not.toBeChecked();
  289 |       await option.click();
  290 |       await expect(option).toBeChecked();
  291 |     }
  292 |     await columns
  293 |       .getByRole("button", {
  294 |         name: copy(language, "Close", "بستن"),
  295 |         exact: true,
  296 |       })
  297 |       .click();
  298 |     for (const [key, en, fa] of [
  299 |       ["name", "Supplier", "تأمین‌کننده"],
  300 |       ["status", "Status", "وضعیت"],
  301 |       ["last_delivery", "Last delivery", "آخرین تحویل"],
  302 |       ["deliveries", "Deliveries", "تحویل‌ها"],
  303 |       ["returns", "Open returns", "مرجوعی‌های باز"],
  304 |       ["shorts", "Open shorts", "کسری‌های باز"],
  305 |       ["terms", "Payment terms", "شرایط پرداخت"],
  306 |       ["contact", "Sales rep and phone", "نماینده فروش و تلفن"],
  307 |       ["balance", "Balance", "مانده"],
  308 |       ["overdue", "Overdue", "سررسید گذشته"],
  309 |       ["due", "Next due date", "سررسید بعدی"],
  310 |       ["actions", "Action", "عملیات"],
  311 |     ]) {
  312 |       const header = suppliersTable.locator(
  313 |         `thead th[data-column-key="${key}"]`,
  314 |       );
  315 |       await expect(header).toBeVisible();
  316 |       await expect(header).toContainText(copy(language, en, fa));
  317 |       await expect(
  318 |         supplierRow.locator(`td[data-column-key="${key}"]`),
  319 |       ).toBeVisible();
  320 |     }
  321 |     for (const [key, value] of Object.entries(visibleValues))
  322 |       await expect(
  323 |         supplierRow.locator(`td[data-column-key="${key}"]`),
  324 |       ).toHaveText(value);
  325 |     await expect(supplierRow.locator('td[data-column-key="terms"]')).toHaveText(
  326 |       supplier.payment_terms ?? "—",
  327 |     );
  328 |     await expect(
  329 |       supplierRow.locator('td[data-column-key="contact"]'),
  330 |     ).toContainText(supplier.sales_rep_name ?? "—");
  331 |     await expect(
  332 |       supplierRow.locator('td[data-column-key="contact"]'),
  333 |     ).toContainText(supplier.sales_rep_phone ?? "—");
  334 |     await expect(supplierRow.locator('td[data-column-key="due"]')).toHaveText(
  335 |       /^(?:\d{4}-\d{2}-\d{2}|—)$/,
  336 |     );
  337 |     await expect(suppliersTable).toHaveAttribute(
  338 |       "data-width-hidden-column-count",
  339 |       "0",
```