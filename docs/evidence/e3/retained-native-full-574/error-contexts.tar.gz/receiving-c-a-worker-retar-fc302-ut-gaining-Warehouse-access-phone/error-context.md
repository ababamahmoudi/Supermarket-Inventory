# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: receiving-c.spec.ts >> a worker retargets their own invoice to Warehouse without gaining Warehouse access
- Location: tests/receiving-c.spec.ts:42:1

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  getByRole('combobox', { name: 'Location', exact: true })
Expected: 0
Received: 1
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" getByRole('combobox', { name: 'Location', exact: true }) with timeout 5000ms
  - waiting for getByRole('combobox', { name: 'Location', exact: true })
    14 × locator resolved to 1 element
       - unexpected value "1"

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=e5]:
    - banner [ref=e6]:
      - button "Open menu" [ref=e7] [cursor=pointer]
      - combobox "Location" [ref=e11] [cursor=pointer]:
        - generic [ref=e16]: North York
      - button "Notifications, 0 unread" [ref=e19] [cursor=pointer]
      - button "User menu" [ref=e24] [cursor=pointer]:
        - generic [aria-hidden] [ref=e26]: DN
      - button "More" [ref=e27] [cursor=pointer]
    - main [ref=e33]:
      - generic [ref=e35]:
        - heading "Received" [level=1] [ref=e36]
        - paragraph [ref=e37]: What came in, where and when.
      - generic [ref=e38]:
        - generic "Received filters" [ref=e39]:
          - textbox "Search Received" [ref=e44]:
            - /placeholder: Search products, invoices or suppliers
          - button "Date range" [ref=e45] [cursor=pointer]
          - combobox "Supplier" [ref=e48] [cursor=pointer]:
            - generic [ref=e49]: All suppliers
          - combobox "Product" [ref=e52] [cursor=pointer]:
            - generic [ref=e53]: All products
          - button "Clear filters" [ref=e56] [cursor=pointer]
          - generic [ref=e58]:
            - generic [ref=e59]: 20 deliveries
            - button "Columns" [ref=e60] [cursor=pointer]
        - table [ref=e64]:
          - rowgroup [ref=e65]:
            - row [ref=e66]:
              - cell "Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی" [ref=e67]:
                - generic [ref=e69]:
                  - strong [ref=e70]:
                    - generic [ref=e71]:
                      - text: Canned Fava Beans
                      - generic [ref=e72]: 400 g
                  - generic [ref=e74]:
                    - text: باقالا کنسرو شده
                    - generic [ref=e75]: ۴۰۰ گرمی
              - cell "2 cases (24 units)" [ref=e76]:
                - text: 2 cases
                - generic [ref=e77]: (24 units)
              - cell [ref=e78]:
                - link "Invoice FV-20390" [ref=e79] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3AFV-20390"
              - cell "North York Fresh Valley Foods 2026-10-14" [ref=e82]:
                - generic [ref=e83]: North York
                - generic [ref=e84]: Fresh Valley Foods
                - generic [ref=e86]: 2026-10-14
            - row [ref=e88]:
              - cell "Ground Sumac 100 g سماق ۱۰۰ گرمی" [ref=e89]:
                - generic [ref=e91]:
                  - strong [ref=e92]:
                    - generic [ref=e93]:
                      - text: Ground Sumac
                      - generic [ref=e94]: 100 g
                  - generic [ref=e96]:
                    - text: سماق
                    - generic [ref=e97]: ۱۰۰ گرمی
              - cell "1 case (12 units)" [ref=e98]:
                - text: 1 case
                - generic [ref=e99]: (12 units)
              - cell [ref=e100]:
                - link "Invoice FV-20390" [ref=e101] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3AFV-20390"
              - cell "North York Fresh Valley Foods 2026-10-14" [ref=e104]:
                - generic [ref=e105]: North York
                - generic [ref=e106]: Fresh Valley Foods
                - generic [ref=e108]: 2026-10-14
            - row [ref=e110]:
              - cell "Lavash Bread 500 g نان لواش ۵۰۰ گرمی" [ref=e111]:
                - generic [ref=e113]:
                  - strong [ref=e114]:
                    - generic [ref=e115]:
                      - text: Lavash Bread
                      - generic [ref=e116]: 500 g
                  - generic [ref=e118]:
                    - text: نان لواش
                    - generic [ref=e119]: ۵۰۰ گرمی
              - cell "2 cases (20 units)" [ref=e120]:
                - text: 2 cases
                - generic [ref=e121]: (20 units)
              - cell [ref=e122]:
                - link "Invoice FV-20390" [ref=e123] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3AFV-20390"
              - cell "North York Fresh Valley Foods 2026-10-14" [ref=e126]:
                - generic [ref=e127]: North York
                - generic [ref=e128]: Fresh Valley Foods
                - generic [ref=e130]: 2026-10-14
            - row [ref=e132]:
              - cell "Sour Cherry Juice 1 L آب آلبالو ۱ لیتری" [ref=e133]:
                - generic [ref=e135]:
                  - strong [ref=e136]:
                    - generic [ref=e137]:
                      - text: Sour Cherry Juice
                      - generic [ref=e138]: 1 L
                  - generic [ref=e140]:
                    - text: آب آلبالو
                    - generic [ref=e141]: ۱ لیتری
              - cell "3 cases (36 units)" [ref=e142]:
                - text: 3 cases
                - generic [ref=e143]: (36 units)
              - cell [ref=e144]:
                - link "Invoice FV-20390" [ref=e145] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3AFV-20390"
              - cell "North York Fresh Valley Foods 2026-10-14" [ref=e148]:
                - generic [ref=e149]: North York
                - generic [ref=e150]: Fresh Valley Foods
                - generic [ref=e152]: 2026-10-14
            - row [ref=e154]:
              - cell "Dried Barberries 100 g زرشک خشک ۱۰۰ گرمی" [ref=e155]:
                - generic [ref=e157]:
                  - strong [ref=e158]:
                    - generic [ref=e159]:
                      - text: Dried Barberries
                      - generic [ref=e160]: 100 g
                  - generic [ref=e162]:
                    - text: زرشک خشک
                    - generic [ref=e163]: ۱۰۰ گرمی
              - cell "1 case (6 units)" [ref=e164]:
                - text: 1 case
                - generic [ref=e165]: (6 units)
              - cell [ref=e166]:
                - link "Invoice FV-20390" [ref=e167] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3AFV-20390"
              - cell "North York Fresh Valley Foods 2026-10-14" [ref=e170]:
                - generic [ref=e171]: North York
                - generic [ref=e172]: Fresh Valley Foods
                - generic [ref=e174]: 2026-10-14
            - row [ref=e176]:
              - cell "Potato Chips 150 g چیپس سیب‌زمینی ۱۵۰ گرمی" [ref=e177]:
                - generic [ref=e179]:
                  - strong [ref=e180]:
                    - generic [ref=e181]:
                      - text: Potato Chips
                      - generic [ref=e182]: 150 g
                  - generic [ref=e184]:
                    - text: چیپس سیب‌زمینی
                    - generic [ref=e185]: ۱۵۰ گرمی
              - cell "1 case (12 units)" [ref=e186]:
                - text: 1 case
                - generic [ref=e187]: (12 units)
              - cell [ref=e188]:
                - link "Invoice FV-20390" [ref=e189] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3AFV-20390"
              - cell "North York Fresh Valley Foods 2026-10-14" [ref=e192]:
                - generic [ref=e193]: North York
                - generic [ref=e194]: Fresh Valley Foods
                - generic [ref=e196]: 2026-10-14
            - row [ref=e198]:
              - cell "Basmati Rice 4.5 kg برنج باسماتی ۴٫۵ کیلوگرمی" [ref=e199]:
                - generic [ref=e201]:
                  - strong [ref=e202]:
                    - generic [ref=e203]:
                      - text: Basmati Rice
                      - generic [ref=e204]: 4.5 kg
                  - generic [ref=e206]:
                    - text: برنج باسماتی
                    - generic [ref=e207]: ۴٫۵ کیلوگرمی
              - cell "1 unit" [ref=e208]
              - cell [ref=e209]:
                - link "Invoice GG-11842" [ref=e210] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3AGG-11842"
              - cell "North York Golden Grain Distributors 2026-10-12" [ref=e213]:
                - generic [ref=e214]: North York
                - generic [ref=e215]: Golden Grain Distributors
                - generic [ref=e217]: 2026-10-12
            - row [ref=e219]:
              - cell "Basmati Rice 4.5 kg برنج باسماتی ۴٫۵ کیلوگرمی" [ref=e220]:
                - generic [ref=e222]:
                  - strong [ref=e223]:
                    - generic [ref=e224]:
                      - text: Basmati Rice
                      - generic [ref=e225]: 4.5 kg
                  - generic [ref=e227]:
                    - text: برنج باسماتی
                    - generic [ref=e228]: ۴٫۵ کیلوگرمی
              - cell "7 cases + 2 units (30 units)" [ref=e229]:
                - text: 7 cases + 2 units
                - generic [ref=e230]: (30 units)
              - cell [ref=e231]:
                - link "Invoice GG-11879" [ref=e232] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3AGG-11879"
              - cell "North York Golden Grain Distributors 2026-10-10" [ref=e235]:
                - generic [ref=e236]: North York
                - generic [ref=e237]: Golden Grain Distributors
                - generic [ref=e239]: 2026-10-10
            - row [ref=e241]:
              - cell "Dried Red Kidney Beans 900 g لوبیا قرمز ۹۰۰ گرمی" [ref=e242]:
                - generic [ref=e244]:
                  - strong [ref=e245]:
                    - generic [ref=e246]:
                      - text: Dried Red Kidney Beans
                      - generic [ref=e247]: 900 g
                  - generic [ref=e249]:
                    - text: لوبیا قرمز
                    - generic [ref=e250]: ۹۰۰ گرمی
              - cell "3 cases + 4 units (40 units)" [ref=e251]:
                - text: 3 cases + 4 units
                - generic [ref=e252]: (40 units)
              - cell [ref=e253]:
                - link "Invoice GG-11879" [ref=e254] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3AGG-11879"
              - cell "North York Golden Grain Distributors 2026-10-10" [ref=e257]:
                - generic [ref=e258]: North York
                - generic [ref=e259]: Golden Grain Distributors
                - generic [ref=e261]: 2026-10-10
            - row [ref=e263]:
              - cell "Black Tea 450 g چای سیاه ۴۵۰ گرمی" [ref=e264]:
                - generic [ref=e266]:
                  - strong [ref=e267]:
                    - generic [ref=e268]:
                      - text: Black Tea
                      - generic [ref=e269]: 450 g
                  - generic [ref=e271]:
                    - text: چای سیاه
                    - generic [ref=e272]: ۴۵۰ گرمی
              - cell "2 cases + 4 units (16 units)" [ref=e273]:
                - text: 2 cases + 4 units
                - generic [ref=e274]: (16 units)
              - cell [ref=e275]:
                - link "Invoice SB-7862" [ref=e276] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3ASB-7862"
              - cell "North York Sunrise Beverages 2026-10-06" [ref=e279]:
                - generic [ref=e280]: North York
                - generic [ref=e281]: Sunrise Beverages
                - generic [ref=e283]: 2026-10-06
            - row [ref=e285]:
              - cell "Fruit Soda 6-pack نوشابه میوه‌ای بسته ۶ عددی" [ref=e286]:
                - generic [ref=e288]:
                  - strong [ref=e289]: Fruit Soda 6-pack
                  - generic [ref=e290]: نوشابه میوه‌ای بسته ۶ عددی
              - cell "2 cases (12 units)" [ref=e291]:
                - text: 2 cases
                - generic [ref=e292]: (12 units)
              - cell [ref=e293]:
                - link "Invoice SB-7862" [ref=e294] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3ASB-7862"
              - cell "North York Sunrise Beverages 2026-10-06" [ref=e297]:
                - generic [ref=e298]: North York
                - generic [ref=e299]: Sunrise Beverages
                - generic [ref=e301]: 2026-10-06
            - row [ref=e303]:
              - cell "Black Tea 450 g چای سیاه ۴۵۰ گرمی" [ref=e304]:
                - generic [ref=e306]:
                  - strong [ref=e307]:
                    - generic [ref=e308]:
                      - text: Black Tea
                      - generic [ref=e309]: 450 g
                  - generic [ref=e311]:
                    - text: چای سیاه
                    - generic [ref=e312]: ۴۵۰ گرمی
              - cell "1 case (6 units)" [ref=e313]:
                - text: 1 case
                - generic [ref=e314]: (6 units)
              - cell [ref=e315]:
                - link "Invoice SB-7848" [ref=e316] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3ASB-7848"
              - cell "North York Sunrise Beverages 2026-10-05" [ref=e319]:
                - generic [ref=e320]: North York
                - generic [ref=e321]: Sunrise Beverages
                - generic [ref=e323]: 2026-10-05
            - row [ref=e325]:
              - cell "Tea Glass Set (6 pcs) ست استکان چای (۶ عددی)" [ref=e326]:
                - generic [ref=e328]:
                  - strong [ref=e329]: Tea Glass Set (6 pcs)
                  - generic [ref=e330]: ست استکان چای (۶ عددی)
              - cell "10 cases (20 units)" [ref=e331]:
                - text: 10 cases
                - generic [ref=e332]: (20 units)
              - cell [ref=e333]:
                - link "Invoice HW-4936" [ref=e334] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3AHW-4936"
              - cell "North York HomeWare Imports 2026-09-24" [ref=e337]:
                - generic [ref=e338]: North York
                - generic [ref=e339]: HomeWare Imports
                - generic [ref=e341]: 2026-09-24
            - row [ref=e343]:
              - cell "Stainless Steel Pot 24 cm قابلمه استیل ۲۴ سانتی‌متری" [ref=e344]:
                - generic [ref=e346]:
                  - strong [ref=e347]: Stainless Steel Pot 24 cm
                  - generic [ref=e348]: قابلمه استیل ۲۴ سانتی‌متری
              - cell "10 cases (30 units)" [ref=e349]:
                - text: 10 cases
                - generic [ref=e350]: (30 units)
              - cell [ref=e351]:
                - link "Invoice HW-4936" [ref=e352] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3AHW-4936"
              - cell "North York HomeWare Imports 2026-09-24" [ref=e355]:
                - generic [ref=e356]: North York
                - generic [ref=e357]: HomeWare Imports
                - generic [ref=e359]: 2026-09-24
            - row [ref=e361]:
              - cell "Rice Cooker 1.8 L پلوپز ۱٫۸ لیتری" [ref=e362]:
                - generic [ref=e364]:
                  - strong [ref=e365]:
                    - generic [ref=e366]:
                      - text: Rice Cooker
                      - generic [ref=e367]: 1.8 L
                  - generic [ref=e369]:
                    - text: پلوپز
                    - generic [ref=e370]: ۱٫۸ لیتری
              - cell "20 units" [ref=e371]
              - cell [ref=e372]:
                - link "Invoice HW-4936" [ref=e373] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3AHW-4936"
              - cell "North York HomeWare Imports 2026-09-24" [ref=e376]:
                - generic [ref=e377]: North York
                - generic [ref=e378]: HomeWare Imports
                - generic [ref=e380]: 2026-09-24
            - row [ref=e382]:
              - cell "Kitchen Sponge 3-pack اسفنج ظرفشویی بسته ۳ عددی" [ref=e383]:
                - generic [ref=e385]:
                  - strong [ref=e386]: Kitchen Sponge 3-pack
                  - generic [ref=e387]: اسفنج ظرفشویی بسته ۳ عددی
              - cell "5 cases (20 units)" [ref=e388]:
                - text: 5 cases
                - generic [ref=e389]: (20 units)
              - cell [ref=e390]:
                - link "Invoice HW-4936" [ref=e391] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3AHW-4936"
              - cell "North York HomeWare Imports 2026-09-24" [ref=e394]:
                - generic [ref=e395]: North York
                - generic [ref=e396]: HomeWare Imports
                - generic [ref=e398]: 2026-09-24
            - row [ref=e400]:
              - cell "Sour Cherry Juice 1 L آب آلبالو ۱ لیتری" [ref=e401]:
                - generic [ref=e403]:
                  - strong [ref=e404]:
                    - generic [ref=e405]:
                      - text: Sour Cherry Juice
                      - generic [ref=e406]: 1 L
                  - generic [ref=e408]:
                    - text: آب آلبالو
                    - generic [ref=e409]: ۱ لیتری
              - cell "1 case (12 units)" [ref=e410]:
                - text: 1 case
                - generic [ref=e411]: (12 units)
              - cell [ref=e412]:
                - link "Invoice FV-20296" [ref=e413] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3AFV-20296"
              - cell "North York Fresh Valley Foods 2026-09-21" [ref=e416]:
                - generic [ref=e417]: North York
                - generic [ref=e418]: Fresh Valley Foods
                - generic [ref=e420]: 2026-09-21
            - row [ref=e422]:
              - cell "Ground Sumac 100 g سماق ۱۰۰ گرمی" [ref=e423]:
                - generic [ref=e425]:
                  - strong [ref=e426]:
                    - generic [ref=e427]:
                      - text: Ground Sumac
                      - generic [ref=e428]: 100 g
                  - generic [ref=e430]:
                    - text: سماق
                    - generic [ref=e431]: ۱۰۰ گرمی
              - cell "1 case (12 units)" [ref=e432]:
                - text: 1 case
                - generic [ref=e433]: (12 units)
              - cell [ref=e434]:
                - link "Invoice FV-20296" [ref=e435] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3AFV-20296"
              - cell "North York Fresh Valley Foods 2026-09-21" [ref=e438]:
                - generic [ref=e439]: North York
                - generic [ref=e440]: Fresh Valley Foods
                - generic [ref=e442]: 2026-09-21
            - row [ref=e444]:
              - cell "Basmati Rice 4.5 kg برنج باسماتی ۴٫۵ کیلوگرمی" [ref=e445]:
                - generic [ref=e447]:
                  - strong [ref=e448]:
                    - generic [ref=e449]:
                      - text: Basmati Rice
                      - generic [ref=e450]: 4.5 kg
                  - generic [ref=e452]:
                    - text: برنج باسماتی
                    - generic [ref=e453]: ۴٫۵ کیلوگرمی
              - cell "5 cases (20 units)" [ref=e454]:
                - text: 5 cases
                - generic [ref=e455]: (20 units)
              - cell [ref=e456]:
                - link "Invoice GG-11842" [ref=e457] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3AGG-11842"
              - cell "North York Golden Grain Distributors 2026-09-10" [ref=e460]:
                - generic [ref=e461]: North York
                - generic [ref=e462]: Golden Grain Distributors
                - generic [ref=e464]: 2026-09-10
            - row [ref=e466]:
              - cell "Dried Red Kidney Beans 900 g لوبیا قرمز ۹۰۰ گرمی" [ref=e467]:
                - generic [ref=e469]:
                  - strong [ref=e470]:
                    - generic [ref=e471]:
                      - text: Dried Red Kidney Beans
                      - generic [ref=e472]: 900 g
                  - generic [ref=e474]:
                    - text: لوبیا قرمز
                    - generic [ref=e475]: ۹۰۰ گرمی
              - cell "1 case (12 units)" [ref=e476]:
                - text: 1 case
                - generic [ref=e477]: (12 units)
              - cell [ref=e478]:
                - link "Invoice GG-11794" [ref=e479] [cursor=pointer]:
                  - /url: "#invoices?id=a2-fixture%3AGG-11794"
              - cell "North York Golden Grain Distributors 2026-08-24" [ref=e482]:
                - generic [ref=e483]: North York
                - generic [ref=e484]: Golden Grain Distributors
                - generic [ref=e486]: 2026-08-24
```

# Test source

```ts
  7   |   setBranch,
  8   |   signIn,
  9   |   uploadInvoice,
  10  | } from "./helpers";
  11  | import receiptFixtures from "../src/fixtures/a2-demo-data.json" with { type: "json" };
  12  | import type { DemoState } from "../src/types";
  13  | import { openC8PriceDialog } from "../scripts/capture-c8-proof.mjs";
  14  | 
  15  | test.setTimeout(60000);
  16  | 
  17  | async function saved(
  18  |   page: import("@playwright/test").Page,
  19  | ): Promise<DemoState> {
  20  |   return readCanonicalBusinessEvidence(page).then((canonicalState) =>
  21  |     JSON.parse(JSON.stringify(canonicalState)!),
  22  |   );
  23  | }
  24  | 
  25  | async function manualInvoice(page: import("@playwright/test").Page) {
  26  |   await page.goto("/#invoices");
  27  |   await page.getByRole("button", { name: "New invoice", exact: true }).click();
  28  |   await page.getByRole("button", { name: "Manual entry", exact: true }).click();
  29  |   const header = page.locator("#invoice-details-fields");
  30  |   await header.getByLabel("Supplier", { exact: true }).click();
  31  |   await page
  32  |     .getByRole("listbox", { name: "Supplier", exact: true })
  33  |     .getByRole("option", { name: /Fresh Valley Foods/ })
  34  |     .click();
  35  |   await page.getByRole("button", { name: "Add line", exact: true }).click();
  36  |   await page
  37  |     .getByLabel("Upload a PDF or photo", { exact: true })
  38  |     .setInputFiles(invoiceImage);
  39  |   await expect(page.locator(".invoice-line")).toHaveCount(1);
  40  | }
  41  | 
  42  | test("a worker retargets their own invoice to Warehouse without gaining Warehouse access", async ({
  43  |   page,
  44  | }) => {
  45  |   await signIn(page, "Floor Worker");
  46  |   await page.goto("/#invoices");
  47  |   await expect(
  48  |     page.getByRole("button", { name: "Manual entry", exact: true }),
  49  |   ).toHaveCount(0);
  50  |   await uploadInvoice(page);
  51  |   await expect(page.locator(".invoice-line")).toHaveCount(6);
  52  |   const header = page.locator("#invoice-details-fields");
  53  |   if (!(await header.isVisible()))
  54  |     await page
  55  |       .getByRole("button", { name: "Invoice details", exact: true })
  56  |       .click();
  57  |   await chooseOption(
  58  |     page,
  59  |     header.getByLabel("Location", { exact: true }),
  60  |     "Warehouse",
  61  |   );
  62  |   await expect(header.getByLabel("Location", { exact: true })).toContainText(
  63  |     "Warehouse",
  64  |   );
  65  |   await expect(page.locator(".topbar .branch-pill")).toContainText(
  66  |     "North York",
  67  |   );
  68  |   await expect(
  69  |     page.getByText(
  70  |       "Choose an invoice in your branch, or start a new invoice.",
  71  |       { exact: true },
  72  |     ),
  73  |   ).toHaveCount(0);
  74  |   const draft = (await saved(page)).invoice;
  75  |   expect(draft).toMatchObject({
  76  |     branch: "Warehouse",
  77  |     handling_branch: "Branch 1",
  78  |   });
  79  |   for (const line of await page.locator(".invoice-line").all()) {
  80  |     await line.getByRole("button", { name: "No", exact: true }).click();
  81  |     await line
  82  |       .getByRole("checkbox", {
  83  |         name: "Confirm this invoice line",
  84  |         exact: true,
  85  |       })
  86  |       .click();
  87  |     await expect(line.getByText("Confirmed", { exact: true })).toBeVisible();
  88  |   }
  89  |   await expect(
  90  |     page.getByRole("button", { name: "Post invoice", exact: true }),
  91  |   ).toBeEnabled();
  92  |   await page.getByRole("button", { name: "Post invoice", exact: true }).click();
  93  |   await page
  94  |     .getByRole("dialog", { name: "Post invoice", exact: true })
  95  |     .getByRole("button", { name: "Post invoice", exact: true })
  96  |     .click();
  97  |   const after = await saved(page);
  98  |   expect(
  99  |     after.invoices?.find((invoice) => invoice.id === draft.id),
  100 |   ).toMatchObject({ status: "posted", branch: "Warehouse" });
  101 |   await page.goto("/#received");
  102 |   await expect(
  103 |     page.getByRole("heading", { name: "Received", exact: true }),
  104 |   ).toBeVisible();
  105 |   await expect(
  106 |     page.getByRole("combobox", { name: "Location", exact: true }),
> 107 |   ).toHaveCount(0);
      |     ^ Error: expect(locator).toHaveCount(expected) failed
  108 |   expect(
  109 |     await page
  110 |       .locator(".received-table")
  111 |       .getByText("Warehouse", { exact: true })
  112 |       .count(),
  113 |   ).toBe(0);
  114 | });
  115 | 
  116 | test("Supervisor moves a posted invoice with a reason and retains its original document and company balance", async ({
  117 |   page,
  118 | }) => {
  119 |   await signIn(page, "Supervisor");
  120 |   await setBranch(page, "all");
  121 |   const source = receiptFixtures.invoices[0];
  122 |   const id = `a2-fixture:${source.number}`;
  123 |   await page.goto(`/#invoices?id=${encodeURIComponent(id)}`);
  124 |   await expect(
  125 |     page.getByRole("button", { name: "Move invoice", exact: true }),
  126 |   ).toBeVisible();
  127 |   const before = await saved(page);
  128 |   const original = before.invoices!.find((invoice) => invoice.id === id)!;
  129 |   await page.getByRole("button", { name: "Move invoice", exact: true }).click();
  130 |   const dialog = page.getByRole("dialog", {
  131 |     name: "Move invoice",
  132 |     exact: true,
  133 |   });
  134 |   await chooseOption(
  135 |     page,
  136 |     dialog.getByLabel("Location", { exact: true }),
  137 |     "Warehouse",
  138 |   );
  139 |   await expect(
  140 |     dialog.getByRole("button", { name: "Move invoice", exact: true }),
  141 |   ).toBeEnabled();
  142 |   await dialog
  143 |     .getByRole("button", { name: "Move invoice", exact: true })
  144 |     .click();
  145 |   await expect(
  146 |     dialog.getByRole("alert", { name: "What's missing", exact: true }),
  147 |   ).toBeVisible();
  148 |   await expect(dialog.getByLabel("Reason", { exact: true })).toHaveAttribute(
  149 |     "aria-invalid",
  150 |     "true",
  151 |   );
  152 |   expect((await saved(page)).ledger).toEqual(before.ledger);
  153 |   await dialog
  154 |     .getByLabel("Reason", { exact: true })
  155 |     .fill("Correct the delivery location");
  156 |   await expect(dialog).toContainText(
  157 |     "Previous payments and credits stay at their recorded location.",
  158 |   );
  159 |   await dialog
  160 |     .getByRole("button", { name: "Move invoice", exact: true })
  161 |     .click();
  162 |   await expect(dialog).not.toBeVisible();
  163 |   await expect(
  164 |     page.getByText("Invoice moved. The correction is recorded in History.", {
  165 |       exact: true,
  166 |     }),
  167 |   ).toBeVisible();
  168 |   const after = await saved(page);
  169 |   expect(after.invoices!.find((invoice) => invoice.id === id)).toEqual(
  170 |     original,
  171 |   );
  172 |   expect(after.ledger.slice(0, before.ledger.length)).toEqual(before.ledger);
  173 |   expect(after.invoice_location_corrections?.at(-1)).toMatchObject({
  174 |     invoice_id: id,
  175 |     to_branch: "Warehouse",
  176 |     reason: "Correct the delivery location",
  177 |   });
  178 |   const appended = after.ledger.slice(before.ledger.length);
  179 |   expect(appended).toHaveLength(2);
  180 |   expect(Decimal.sum(...appended.map((entry) => entry.amount)).toFixed(2)).toBe(
  181 |     "0.00",
  182 |   );
  183 |   await page.goto("/#received");
  184 |   await page
  185 |     .getByRole("textbox", { name: "Search Received", exact: true })
  186 |     .fill(source.number);
  187 |   const warehouseLocation = page
  188 |     .locator(".received-table")
  189 |     .getByText("Warehouse", { exact: true })
  190 |     .first();
  191 |   if (!(await warehouseLocation.isVisible()))
  192 |     await page.locator(".received-table .table-details-toggle").first().click();
  193 |   await expect(warehouseLocation).toBeVisible();
  194 |   await page.reload();
  195 |   expect(
  196 |     (await saved(page)).invoice_location_corrections?.at(-1)?.to_branch,
  197 |   ).toBe("Warehouse");
  198 | });
  199 | 
  200 | test("invoice changed regular cost defaults to calculated and explicit Keep preserves the approved price on posting", async ({
  201 |   page,
  202 | }) => {
  203 |   await signIn(page, "Supervisor");
  204 |   const editor = await openC8PriceDialog(page, "0002");
  205 |   await editor.getByRole("radio", { name: /^New regular price/ }).check();
  206 |   await editor.getByLabel("Price", { exact: true }).fill("2.79");
  207 |   await editor
```