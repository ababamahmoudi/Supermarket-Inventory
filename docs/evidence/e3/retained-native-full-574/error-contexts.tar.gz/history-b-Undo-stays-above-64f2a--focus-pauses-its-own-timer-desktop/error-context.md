# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: history-b.spec.ts >> Undo stays above a native modal and keyboard focus pauses its own timer
- Location: tests/history-b.spec.ts:200:1

# Error details

```
Error: expect(received).toMatchObject(expected)

- Expected  - 2
+ Received  + 1

  Object {
-   "action": "Undone",
+   "action": "Cancel price update",
    "actor_username": "manager",
    "by": "Demo Manager",
-   "reversal_kind": "undo",
  }
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - complementary "Main menu" [ref=e5]:
    - generic [ref=e6]:
      - img "Super Arzon" [ref=e9]
      - generic [ref=e10]: Super Arzon
    - navigation "Pages" [ref=e11]:
      - generic [ref=e12]:
        - button "Daily" [expanded] [ref=e13] [cursor=pointer]
        - generic [ref=e17]:
          - link "Lookup" [ref=e18] [cursor=pointer]:
            - /url: "#lookup"
          - link "Invoices" [ref=e23] [cursor=pointer]:
            - /url: "#invoices"
          - link "Received" [ref=e28] [cursor=pointer]:
            - /url: "#received"
          - link "Returns" [ref=e35] [cursor=pointer]:
            - /url: "#returns"
          - link "Price updates" [ref=e40] [cursor=pointer]:
            - /url: "#price-updates"
          - link "Labels" [ref=e46] [cursor=pointer]:
            - /url: "#labels"
          - link "Date tracking" [ref=e51] [cursor=pointer]:
            - /url: "#expiry"
          - link "Notes" [ref=e56] [cursor=pointer]:
            - /url: "#notes"
            - generic [ref=e60]: "2"
          - link "Branch requests" [ref=e61] [cursor=pointer]:
            - /url: "#requests"
      - button "Catalog" [ref=e67] [cursor=pointer]
      - button "Manager" [ref=e72] [cursor=pointer]
      - button "Admin" [ref=e77] [cursor=pointer]
    - button "User menu" [ref=e82] [cursor=pointer]:
      - generic [ref=e83]:
        - generic [aria-hidden] [ref=e84]: DM
        - generic [ref=e85]:
          - strong [ref=e86]: Demo Manager
          - generic [ref=e87]: Manager
  - generic [ref=e88]:
    - banner [ref=e89]:
      - button "Collapse sidebar" [expanded] [ref=e90] [cursor=pointer]
      - navigation "Breadcrumbs" [ref=e94]:
        - link "North York" [ref=e95] [cursor=pointer]:
          - /url: "#dashboard"
        - link "Lookup" [ref=e98] [cursor=pointer]:
          - /url: "#lookup"
      - search [ref=e99]:
        - textbox "Search all products" [ref=e103]:
          - /placeholder: Search products
        - generic [aria-hidden] [ref=e104]: /
      - combobox "Location" [ref=e105] [cursor=pointer]:
        - generic [ref=e110]: North York
      - button "Switch to Persian" [ref=e113] [cursor=pointer]: فا
      - button "Switch to dark theme" [ref=e114] [cursor=pointer]
      - button "Comfortable text size" [ref=e117] [cursor=pointer]:
        - generic [aria-hidden] [ref=e118]: Aa
      - button "Notifications, 8 unread" [ref=e119] [cursor=pointer]:
        - generic [ref=e120]: "8"
      - button "Demo" [ref=e125] [cursor=pointer]
    - main [ref=e128]:
      - generic [ref=e129]:
        - generic [ref=e131]:
          - heading "Cashier lookup" [level=1] [ref=e132]
          - paragraph [ref=e133]: Find the approved price to charge now. Search in English or Persian, or scan a barcode.
        - generic [ref=e134]:
          - generic [ref=e135]: Search products
          - generic [ref=e136]:
            - combobox "Search products" [expanded] [ref=e140]: "0003"
            - button "Scan barcode" [ref=e141] [cursor=pointer]
          - generic [ref=e147]:
            - group "AI category" [ref=e148]:
              - button "All" [pressed] [ref=e149] [cursor=pointer]
              - button "Beans & legumes" [ref=e150] [cursor=pointer]
              - button "Bread & bakery" [ref=e151] [cursor=pointer]
              - button "Cleaning" [ref=e152] [cursor=pointer]
              - button "More categories" [ref=e153] [cursor=pointer]: More
            - generic [ref=e156]: 1 product
            - paragraph [ref=e157]: Use ↑ ↓ and Enter to select a product.
            - button "Clear filters" [ref=e158] [cursor=pointer]
        - generic [ref=e159]:
          - generic [ref=e160]:
            - generic [ref=e161]:
              - heading "Sour Cherry Juice 1 L" [level=2] [ref=e162]:
                - generic [ref=e164]:
                  - text: Sour Cherry Juice
                  - generic [ref=e165]: 1 L
              - paragraph [ref=e166]:
                - generic [ref=e168]:
                  - text: آب آلبالو
                  - generic [ref=e169]: ۱ لیتری
              - paragraph [ref=e170]:
                - generic [ref=e171]: Product Code 0003
                - generic [ref=e172]: 1 L
            - generic [ref=e175]:
              - button "Change price" [ref=e176] [cursor=pointer]
              - button "Edit Sour Cherry Juice 1 L" [active] [ref=e177] [cursor=pointer]: Edit
              - button "Product actions" [ref=e178] [cursor=pointer]
          - paragraph [ref=e183]: "Calculated from invoice FV-20390: $2.99"
          - generic [ref=e185]:
            - strong [ref=e186]: $2.99
            - generic [ref=e187]:
              - paragraph [ref=e188]: Selling price
              - generic [ref=e189]: 2 for $5.00
              - paragraph [ref=e191]: Before tax
          - region "Dates" [ref=e192]:
            - list [ref=e193]:
              - listitem [ref=e194]:
                - generic [ref=e200]: Expires 2026-11-09 · North York
                - generic [ref=e201]: Expiring soon
            - generic [ref=e202]:
              - generic [ref=e209]: Last received 2026-10-14
              - generic [ref=e210]: Fresh Valley Foods · FV-20390
        - generic [ref=e211]:
          - heading "Search results" [level=2] [ref=e212]
          - listbox "Product results" [ref=e213]:
            - option "Sour Cherry Juice 1 L آب آلبالو ۱ لیتری Product Code 0003 $2.99 2 for $5.00" [selected] [ref=e214] [cursor=pointer]:
              - generic [ref=e215]:
                - strong [ref=e216]:
                  - generic [ref=e218]:
                    - text: Sour Cherry Juice
                    - generic [ref=e219]: 1 L
                - generic [ref=e220]:
                  - generic [ref=e222]:
                    - text: آب آلبالو
                    - generic [ref=e223]: ۱ لیتری
                  - generic [ref=e224]: Product Code 0003
              - generic [ref=e225]:
                - generic [ref=e226]: $2.99
                - generic [ref=e227]: 2 for $5.00
```

# Test source

```ts
  141 |     .getByRole("button", { name: "Revert", exact: true })
  142 |     .click();
  143 |   await page
  144 |     .getByRole("dialog", { name: "Revert change", exact: true })
  145 |     .getByRole("button", { name: "Revert change", exact: true })
  146 |     .click();
  147 |   await page.goto("/#lookup");
  148 |   await page.getByLabel("Search products", { exact: true }).fill("0006");
  149 |   await expect(page.locator(".lookup-detail-header")).toContainText(
  150 |     "Lavash Bread 500 g",
  151 |   );
  152 |   await expect(page.locator(".lookup-detail-header")).not.toContainText(
  153 |     "corrected",
  154 |   );
  155 |   await page.goto("/#history");
  156 |   await expect(
  157 |     page.getByRole("heading", { name: "History", exact: true }),
  158 |   ).toBeVisible();
  159 |   const range = page.getByRole("button", { name: "Date range", exact: true });
  160 |   await expect(range).toHaveCount(1);
  161 |   await range.click();
  162 |   const rangeDialog = page.getByRole("dialog", {
  163 |     name: "Date range",
  164 |     exact: true,
  165 |   });
  166 |   for (const label of ["Today", "This week", "This month"])
  167 |     await expect(
  168 |       rangeDialog.getByRole("button", { name: label, exact: true }),
  169 |     ).toBeVisible();
  170 |   for (const label of ["From", "To"])
  171 |     await expect(
  172 |       rangeDialog.getByRole("button", { name: label, exact: true }),
  173 |     ).toBeVisible();
  174 |   await rangeDialog
  175 |     .getByRole("button", { name: "Cancel", exact: true })
  176 |     .click();
  177 |   expect(
  178 |     await page.evaluate(
  179 |       () => document.documentElement.scrollWidth > window.innerWidth,
  180 |     ),
  181 |   ).toBe(false);
  182 |   await historyRow(page, "Reverted Save product");
  183 |   await historyRow(page, "Save product", "corrected");
  184 |   await expect(page.locator(".history-table")).toContainText("Reverted");
  185 |   await expect(page.locator(".history-table")).toContainText("Save product");
  186 |   const saved = await readCanonicalBusinessEvidence(page).then(
  187 |     (canonicalState) => JSON.parse(JSON.stringify(canonicalState)!).activity,
  188 |   );
  189 |   expect(saved.at(-1)).toMatchObject({
  190 |     action: "Reverted Save product",
  191 |     by: configuredPersonExpectation("manager").name_en,
  192 |     actor_username: configuredPersonExpectation("manager").username,
  193 |     reversal_kind: "revert",
  194 |   });
  195 |   expect(
  196 |     saved.some((item: { action: string }) => item.action === "Save product"),
  197 |   ).toBe(true);
  198 | });
  199 | 
  200 | test("Undo stays above a native modal and keyboard focus pauses its own timer", async ({
  201 |   page,
  202 | }) => {
  203 |   await signIn(page, "Supervisor");
  204 |   await freezeClock(page);
  205 |   await stopOffer(page, "0003");
  206 |   await page.goto("/#lookup");
  207 |   await page.getByLabel("Search products", { exact: true }).fill("0003");
  208 |   await page.mouse.move(0, 0);
  209 |   await page.clock.runFor(1000);
  210 |   await page.getByRole("button", { name: /^Edit Sour Cherry Juice/ }).click();
  211 |   const dialog = page.getByRole("dialog", {
  212 |     name: "Edit product",
  213 |     exact: true,
  214 |   });
  215 |   const undo = dialog.getByRole("button", { name: "Undo", exact: true });
  216 |   await expect(undo).toBeVisible();
  217 |   await undo.focus();
  218 |   await expect(undo).toBeFocused();
  219 |   await page.clock.runFor(15000);
  220 |   await expect(undo).toBeVisible();
  221 |   expect(
  222 |     await undo.evaluate((node) => {
  223 |       const rect = node.getBoundingClientRect();
  224 |       return (
  225 |         document.elementFromPoint(
  226 |           rect.x + rect.width / 2,
  227 |           rect.y + rect.height / 2,
  228 |         ) === node
  229 |       );
  230 |     }),
  231 |   ).toBe(true);
  232 |   await undo.click();
  233 |   await expect(page.locator(".undo-toast-stack")).not.toBeVisible();
  234 |   await page.keyboard.press("Escape");
  235 |   await expect(
  236 |     page.locator(".lookup-approved-price .offer-pill"),
  237 |   ).toContainText("2 for $5");
  238 |   const saved = await readCanonicalBusinessEvidence(page).then(
  239 |     (canonicalState) => JSON.parse(JSON.stringify(canonicalState)!).activity,
  240 |   );
> 241 |   expect(saved.at(-1)).toMatchObject({
      |                        ^ Error: expect(received).toMatchObject(expected)
  242 |     action: "Undone",
  243 |     by: configuredPersonExpectation("manager").name_en,
  244 |     actor_username: configuredPersonExpectation("manager").username,
  245 |     reversal_kind: "undo",
  246 |   });
  247 |   expect(
  248 |     saved.some((item: { action: string }) => item.action === "Stop offer"),
  249 |   ).toBe(true);
  250 | });
  251 | 
  252 | test("History Revert previews the actor, branch, values and requires confirmation", async ({
  253 |   page,
  254 | }) => {
  255 |   await signIn(page, "Supervisor");
  256 |   await freezeClock(page);
  257 |   await saveName(page, "Lavash Bread 500 g approved edit");
  258 |   await page.clock.runFor(10001);
  259 |   await expect(page.locator(".undo-toast-stack")).not.toBeVisible();
  260 |   await page.goto("/#history");
  261 |   const row = await historyRow(page, "Save product");
  262 |   await row.getByRole("button", { name: "Revert", exact: true }).click();
  263 |   const dialog = page.getByRole("dialog", {
  264 |     name: "Revert change",
  265 |     exact: true,
  266 |   });
  267 |   await expect(dialog).toContainText(
  268 |     configuredPersonExpectation("manager").name_en,
  269 |   );
  270 |   await expect(dialog).toContainText("All branches");
  271 |   await expect(dialog).toContainText("Lavash Bread 500 g approved edit");
  272 |   await expect(dialog).toContainText("Lavash Bread 500 g");
  273 |   let stored = await readCanonicalBusinessEvidence(page).then(
  274 |     (canonicalState) =>
  275 |       JSON.parse(JSON.stringify(canonicalState)!).products.find(
  276 |         (item: { code: string }) => item.code === "0006",
  277 |       ).name_en,
  278 |   );
  279 |   expect(stored).toContain("approved edit");
  280 |   await dialog
  281 |     .getByRole("button", { name: "Revert change", exact: true })
  282 |     .click();
  283 |   await expect(dialog).not.toBeVisible();
  284 |   await expect(page.getByRole("status")).toContainText("Change reverted");
  285 |   stored = await readCanonicalBusinessEvidence(page).then(
  286 |     (canonicalState) =>
  287 |       JSON.parse(JSON.stringify(canonicalState)!).products.find(
  288 |         (item: { code: string }) => item.code === "0006",
  289 |       ).name_en,
  290 |   );
  291 |   expect(stored).toBe("Lavash Bread 500 g");
  292 |   await historyRow(page, "Reverted Save product");
  293 |   await expect(page.locator(".history-table")).toContainText(
  294 |     "Reverted Save product",
  295 |   );
  296 | });
  297 | 
  298 | test("an intervening edit displays a conflict and cannot be silently overwritten", async ({
  299 |   page,
  300 | }) => {
  301 |   await signIn(page, "Supervisor");
  302 |   await freezeClock(page);
  303 |   await saveName(page, "Lavash Bread 500 g first change");
  304 |   await saveName(page, "Lavash Bread 500 g latest change");
  305 |   await page.goto("/#history");
  306 |   const older = await historyRow(
  307 |     page,
  308 |     "Save product",
  309 |     "first change",
  310 |     "latest change",
  311 |   );
  312 |   await older.getByRole("button", { name: "Revert", exact: true }).click();
  313 |   const dialog = page.getByRole("dialog", {
  314 |     name: "Revert change",
  315 |     exact: true,
  316 |   });
  317 |   await expect(
  318 |     dialog.getByRole("alert").filter({ hasText: "changed again" }),
  319 |   ).toContainText("changed again");
  320 |   await expect(
  321 |     dialog.getByRole("button", { name: "Revert change", exact: true }),
  322 |   ).toBeDisabled();
  323 |   await page.keyboard.press("Escape");
  324 |   await page.goto("/#lookup");
  325 |   await page.getByLabel("Search products", { exact: true }).fill("0006");
  326 |   await expect(page.locator(".lookup-detail-header")).toContainText(
  327 |     "latest change",
  328 |   );
  329 | });
  330 | 
  331 | test("each eligible action replaces the single toast and its last message expires after eight seconds", async ({
  332 |   page,
  333 | }) => {
  334 |   await signIn(page, "Supervisor");
  335 |   await page.goto("/#offers");
  336 |   const codes = await page
  337 |     .locator(".current-offers-table tr[data-product-code]")
  338 |     .evaluateAll((rows) =>
  339 |       rows.map((row) => row.getAttribute("data-product-code")!),
  340 |     );
  341 |   // C8 adds two sale records beside the original five multi-buy offers.
```