# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: invoice-orders-c2.spec.ts >> order comparison requires explicit extra and changed-cost decisions, then preserves one alert and accepted receipts
- Location: tests/invoice-orders-c2.spec.ts:129:1

# Error details

```
Test timeout of 60000ms exceeded.
```

```
Error: locator.click: Test timeout of 60000ms exceeded.
Call log:
  - waiting for locator('.invoice-order-card').getByRole('button', { name: 'Refused / sent back with the driver', exact: true })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - complementary "Main menu" [ref=e5]:
    - generic [ref=e6]:
      - img "Super Arzon" [ref=e9]
      - generic [ref=e10]: Super Arzon
    - navigation "Pages" [ref=e11]:
      - generic [ref=e12]:
        - button "Daily" [expanded] [ref=e13] [cursor=pointer]
        - generic [ref=e17]:
          - link "Lookup" [ref=e18] [cursor=pointer]:
            - /url: "#lookup"
          - link "Invoices" [ref=e23] [cursor=pointer]:
            - /url: "#invoices"
          - link "Received" [ref=e28] [cursor=pointer]:
            - /url: "#received"
          - link "Returns" [ref=e35] [cursor=pointer]:
            - /url: "#returns"
          - link "Price updates" [ref=e40] [cursor=pointer]:
            - /url: "#price-updates"
          - link "Labels" [ref=e46] [cursor=pointer]:
            - /url: "#labels"
          - link "Date tracking" [ref=e51] [cursor=pointer]:
            - /url: "#expiry"
          - link "Notes" [ref=e56] [cursor=pointer]:
            - /url: "#notes"
            - generic [ref=e60]: "2"
          - link "Branch requests" [ref=e61] [cursor=pointer]:
            - /url: "#requests"
      - button "Catalog" [ref=e67] [cursor=pointer]
      - button "Manager" [ref=e72] [cursor=pointer]
      - button "Admin" [ref=e77] [cursor=pointer]
    - button "User menu" [ref=e82] [cursor=pointer]:
      - generic [ref=e83]:
        - generic [aria-hidden] [ref=e84]: DM
        - generic [ref=e85]:
          - strong [ref=e86]: Demo Manager
          - generic [ref=e87]: Manager
  - generic [ref=e88]:
    - banner [ref=e89]:
      - button "Collapse sidebar" [expanded] [ref=e90] [cursor=pointer]
      - navigation "Breadcrumbs" [ref=e94]:
        - link "North York" [ref=e95] [cursor=pointer]:
          - /url: "#dashboard"
        - link "Invoices" [ref=e98] [cursor=pointer]:
          - /url: "#invoices"
      - search [ref=e99]:
        - textbox "Search all products" [ref=e103]:
          - /placeholder: Search products
        - generic [aria-hidden] [ref=e104]: /
      - combobox "Location" [ref=e105] [cursor=pointer]:
        - generic [ref=e110]: North York
      - button "Switch to Persian" [ref=e113] [cursor=pointer]: فا
      - button "Switch to dark theme" [ref=e114] [cursor=pointer]
      - button "Comfortable text size" [ref=e117] [cursor=pointer]:
        - generic [aria-hidden] [ref=e118]: Aa
      - button "Notifications, 5 unread" [ref=e119] [cursor=pointer]:
        - generic [ref=e120]: "5"
      - button "Demo" [ref=e125] [cursor=pointer]
    - main [ref=e128]:
      - generic [ref=e129]:
        - link "Back to Invoices" [ref=e130] [cursor=pointer]:
          - /url: "#invoices"
        - generic [ref=e133]:
          - generic [ref=e134]:
            - heading "Invoices" [level=1] [ref=e135]
            - paragraph [ref=e136]: Deliveries and supplier invoices
          - button "New invoice" [ref=e138] [cursor=pointer]
        - tablist "Invoice views" [ref=e139]:
          - tab "Drafts" [ref=e140] [cursor=pointer]
          - tab "Processing" [ref=e142] [cursor=pointer]
          - tab "Needs review" [selected] [ref=e144] [cursor=pointer]
          - tab "Ready to post" [ref=e146] [cursor=pointer]
          - tab "Posted" [ref=e148] [cursor=pointer]
          - tab "Cancelled" [ref=e150] [cursor=pointer]
        - generic [ref=e152]:
          - complementary "Original invoice" [ref=e153]:
            - generic [ref=e154]:
              - heading "Original invoice" [level=2] [ref=e155]
              - paragraph [ref=e156]: AI invoice reading is simulated
              - generic [ref=e158]:
                - generic [ref=e159]: Upload a PDF or photo
                - generic [ref=e160]:
                  - button "Upload a PDF or photo" [ref=e161]
                  - button "Take photo" [ref=e162]
                  - generic [ref=e163]:
                    - generic [ref=e167]:
                      - strong [ref=e168]: fictional-supplier-invoice.png
                      - generic [ref=e169]: 1 KB
                    - button "Remove file" [ref=e170] [cursor=pointer]
                  - button "Browse" [ref=e175] [cursor=pointer]
              - group "Original invoice" [ref=e176]:
                - generic [ref=e177]:
                  - button "Zoom out" [ref=e178] [cursor=pointer]
                  - generic [ref=e180]: 100%
                  - button "Zoom in" [ref=e181] [cursor=pointer]
                - button "Fit width" [ref=e183] [cursor=pointer]
                - button "Fit page" [ref=e184] [cursor=pointer]
                - button "Download" [ref=e185] [cursor=pointer]
              - img "Original invoice image" [ref=e190]
          - generic [ref=e191]:
            - alert "What's missing" [ref=e193]:
              - heading "What's missing" [level=3] [ref=e194]
              - list [ref=e195]:
                - listitem [ref=e196]:
                  - link "Choose a decision for every order difference before posting." [ref=e197] [cursor=pointer]:
                    - /url: "#invoice-order-review"
                - listitem [ref=e198]:
                  - 'link "Line 1: Review and confirm every invoice line." [ref=e199] [cursor=pointer]':
                    - /url: "#invoice-line-0-confirm"
                - listitem [ref=e200]:
                  - 'link "Line 1: Choose Yes or No for date tracking on every line; add a date when tracking is on." [ref=e201] [cursor=pointer]':
                    - /url: "#invoice-line-0-date"
            - generic [ref=e202]:
              - generic "Delivery summary" [ref=e203]:
                - generic [ref=e204]:
                  - generic [ref=e205]: Subtotal
                  - strong [ref=e206]: $1.10
                - generic [ref=e207]:
                  - generic [ref=e208]: Tax
                  - strong [ref=e209]: $0.00
                - generic [ref=e210]:
                  - generic [ref=e211]: Shorts and refused deduction
                  - strong [ref=e212]: $0.00
                - generic [ref=e213]:
                  - generic [ref=e214]: Payable
                  - strong [ref=e215]: $1.10
              - paragraph [ref=e216]: This is the amount of this invoice, not a supplier balance. Received records only physically delivered units.
            - generic [ref=e217]:
              - heading [level=2] [ref=e218]:
                - button "Invoice details" [expanded] [ref=e219] [cursor=pointer]
              - paragraph [ref=e222]:
                - generic [ref=e223]: Fresh Valley Foods
                - text: ·
                - generic [ref=e224]: —
                - text: · North York ·
                - generic [ref=e225]: 2026-10-15
              - paragraph [ref=e226]:
                - generic [ref=e227]: Needs review
                - text: Changes save automatically in this browser.
              - group [ref=e228]:
                - generic [ref=e229]:
                  - generic [ref=e230]: Supplier
                  - combobox "Supplier" [ref=e231] [cursor=pointer]:
                    - generic [ref=e232]: ⁦Fresh Valley Foods⁩
                - generic [ref=e235]:
                  - generic [ref=e236]: Supplier invoice number (optional)
                  - textbox "Supplier invoice number (optional)" [ref=e237]:
                    - /placeholder: Assigned on posting if blank
                - generic [ref=e238]:
                  - generic [ref=e239]: Invoice date
                  - button "Invoice date" [ref=e240] [cursor=pointer]:
                    - generic [ref=e241]: 2026-10-15
                - generic [ref=e244]:
                  - generic [ref=e245]:
                    - generic [ref=e246]: Received date
                    - button "Received date" [ref=e247] [cursor=pointer]:
                      - generic [ref=e248]: 2026-10-15
                  - generic [ref=e251]:
                    - generic [ref=e252]: Received time
                    - textbox "Received time" [ref=e253]:
                      - /placeholder: HH:mm
                      - text: 13:52
                    - paragraph [ref=e254]: Store local time, 24-hour HH:mm
                - generic [ref=e255]:
                  - generic [ref=e256]: Receiving employee
                  - combobox "Receiving employee" [ref=e257] [cursor=pointer]:
                    - generic [ref=e258]: Demo Manager
                - generic [ref=e261]:
                  - generic [ref=e262]: Location
                  - combobox "Location" [ref=e263] [cursor=pointer]:
                    - generic [ref=e264]: North York
                - generic [ref=e267]:
                  - generic [ref=e268]: Ship to (optional)
                  - textbox "Ship to (optional)" [ref=e269]
                - generic [ref=e270]:
                  - generic [ref=e271]: Subtotal
                  - textbox "Subtotal" [ref=e272]: "1.10"
                - generic [ref=e273]:
                  - generic [ref=e274]: Tax
                  - textbox "Tax" [ref=e275]: "0.00"
                - generic [ref=e276]:
                  - generic [ref=e277]: Final total
                  - textbox "Final total" [ref=e278]: "1.10"
                - generic [ref=e279]:
                  - generic [ref=e280]: Due date (optional)
                  - button "Due date (optional)" [ref=e281] [cursor=pointer]:
                    - generic [ref=e282]: 2026-10-29
                - generic [ref=e286]:
                  - generic [ref=e287]: Payment terms (optional)
                  - combobox "Payment terms (optional)" [ref=e288] [cursor=pointer]:
                    - generic [ref=e289]: Every 2 weeks (14 days)
            - generic [ref=e293]:
              - heading "Compare with order" [level=2] [ref=e294]
              - generic [ref=e295]:
                - generic [ref=e296]: Order (optional)
                - combobox "Order (optional)" [ref=e297] [cursor=pointer]:
                  - generic [ref=e298]: ORD-0001 · 2026-10-15
                - paragraph [ref=e301]: Choose an open order for this supplier and receiving location.
              - paragraph [ref=e302]: ORD-0001 · Fresh Valley Foods
              - table [ref=e304]:
                - rowgroup [ref=e310]:
                  - row [ref=e311]:
                    - columnheader "Product" [ref=e312]
                    - columnheader "Ordered units remaining" [ref=e313]
                    - columnheader "Delivered units" [ref=e314]
                    - columnheader "Details" [ref=e315]
                - rowgroup [ref=e316]:
                  - row [ref=e317]:
                    - cell "Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی" [ref=e318]:
                      - generic [ref=e319]:
                        - strong [ref=e320]:
                          - generic [ref=e321]:
                            - text: Canned Fava Beans
                            - generic [ref=e322]: 400 g
                        - generic [ref=e324]:
                          - text: باقالا کنسرو شده
                          - generic [ref=e325]: ۴۰۰ گرمی
                    - cell "12" [ref=e326]
                    - cell "1" [ref=e327]
                    - cell [ref=e328]:
                      - button "Hide details" [expanded] [active] [ref=e329] [cursor=pointer]
                  - row [ref=e332]:
                    - cell [ref=e333]:
                      - generic [ref=e335]:
                        - term [ref=e336]: Decision
                        - definition [ref=e337]:
                          - generic [ref=e338]:
                            - generic [ref=e339]: Unit cost changed
                            - paragraph [ref=e341]: "Unit cost before tax: $0.98 → $1.10"
                            - paragraph [ref=e342]: "Case cost before tax: $11.76 → $13.20"
                            - group "Changed cost decision" [ref=e343]:
                              - button "Accept new cost" [ref=e344] [cursor=pointer]
                  - row [ref=e346]:
                    - cell "Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی" [ref=e347]:
                      - generic [ref=e348]:
                        - strong [ref=e349]:
                          - generic [ref=e350]:
                            - text: Canned Fava Beans
                            - generic [ref=e351]: 400 g
                        - generic [ref=e353]:
                          - text: باقالا کنسرو شده
                          - generic [ref=e354]: ۴۰۰ گرمی
                    - cell "11" [ref=e355]
                    - cell "0" [ref=e356]
                    - cell [ref=e357]:
                      - button "Show details" [ref=e358] [cursor=pointer]
            - generic [ref=e361]:
              - heading "Review invoice lines" [level=2] [ref=e362]
              - paragraph [ref=e363]: Choose Cases or Units and confirm the product, pack, quantities, cost, and date decision on each line.
              - table [ref=e365]:
                - 'rowgroup "Line 1: Canned Fava Beans 400 g" [ref=e366]':
                  - row [ref=e367] [cursor=pointer]:
                    - cell "1. Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی 0002 · 400 g Matched" [ref=e368]:
                      - generic [ref=e369]:
                        - heading [level=3] [ref=e370]:
                          - button "1. Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی" [expanded] [ref=e371]:
                            - generic [ref=e372]: "1."
                            - generic [ref=e373]:
                              - strong [ref=e374]:
                                - generic [ref=e375]:
                                  - text: Canned Fava Beans
                                  - generic [ref=e376]: 400 g
                              - generic [ref=e378]:
                                - text: باقالا کنسرو شده
                                - generic [ref=e379]: ۴۰۰ گرمی
                        - paragraph [ref=e382]:
                          - text: 0002 ·
                          - generic [ref=e383]: 400 g
                        - generic [ref=e386]: Matched
                    - cell [ref=e389]:
                      - generic [ref=e390]:
                        - generic [ref=e391]: Invoiced
                        - textbox "Invoiced" [ref=e392]: "1"
                      - generic [ref=e393]:
                        - generic [ref=e394]: Delivered
                        - textbox "Delivered" [ref=e395]: "1"
                    - cell [ref=e396]:
                      - generic [ref=e397]:
                        - generic [ref=e398]: Unit cost before tax
                        - textbox "Unit cost before tax" [ref=e399]: "1.1000"
                    - cell "Line total $1.10" [ref=e400]:
                      - generic [ref=e401]: Line total
                      - text: $1.10
                    - 'cell "Selling price $1.49 Approved: $1.49" [ref=e402]':
                      - generic [ref=e403]:
                        - generic [ref=e404]: Selling price
                        - strong [ref=e405]: $1.49
                        - paragraph [ref=e406]: "Approved: $1.49"
                  - row [ref=e407]:
                    - cell [ref=e408]:
                      - generic [ref=e409]:
                        - group [ref=e410]:
                          - generic [ref=e411]:
                            - generic [ref=e412]: Quantity unit
                            - combobox "Quantity unit" [ref=e413] [cursor=pointer]:
                              - generic [ref=e414]: Units
                          - generic [ref=e417]:
                            - generic [ref=e418]: Units per case
                            - textbox "Units per case" [ref=e419]: "12"
                          - generic [ref=e420]:
                            - generic [ref=e421]: Supplier item code (optional)
                            - textbox "Supplier item code (optional)" [ref=e422]
                          - paragraph [ref=e423]: 1 unit
                          - generic [ref=e424]:
                            - generic [ref=e425]: Matched product
                            - combobox "Matched product" [ref=e426] [cursor=pointer]:
                              - generic [ref=e428]:
                                - text: ⁦0002⁩ · ⁦
                                - generic [ref=e429]:
                                  - text: Canned Fava Beans
                                  - generic [ref=e430]: 400 g
                                - text: ⁩
                          - generic [ref=e433]:
                            - generic [ref=e434]: Pricing category
                            - combobox "Pricing category" [ref=e435] [cursor=pointer]:
                              - generic [ref=e436]: Grocery
                        - button "Remove line" [ref=e439] [cursor=pointer]
                        - checkbox "Mark as short" [ref=e440] [cursor=pointer]
                        - group [ref=e443]:
                          - generic [ref=e444]:
                            - generic [ref=e445]: Track date
                            - group "Track date" [ref=e446]:
                              - button "Yes" [pressed] [ref=e447] [cursor=pointer]
                              - button "No" [ref=e449] [cursor=pointer]
                          - generic [ref=e451]:
                            - generic [ref=e452]:
                              - generic [ref=e453]: Date tracking
                              - combobox "Date tracking" [ref=e454] [cursor=pointer]:
                                - generic [ref=e455]: Expiry
                            - generic [ref=e458]:
                              - generic [ref=e459]: Date
                              - button "Date" [ref=e460] [cursor=pointer]:
                                - generic [ref=e461]: Choose date
                              - alert [ref=e464]: "Line 1: Choose Yes or No for date tracking on every line; add a date when tracking is on."
                            - generic [ref=e465]:
                              - generic [ref=e466]: Lot number (optional)
                              - textbox "Lot number (optional)" [ref=e467]
                        - checkbox "Confirm this invoice line" [ref=e468] [cursor=pointer]
                        - alert [ref=e471]: "Line 1: Review and confirm every invoice line."
              - generic [ref=e472]:
                - generic [ref=e473]:
                  - generic [ref=e474]: Add a product to the invoice
                  - combobox "Add a product to the invoice" [ref=e475] [cursor=pointer]:
                    - generic [ref=e477]:
                      - text: ⁦0002⁩ · ⁦
                      - generic [ref=e478]:
                        - text: Canned Fava Beans
                        - generic [ref=e479]: 400 g
                      - text: ⁩
                - button "Add line" [ref=e482] [cursor=pointer]
                - button "+ Add new product" [ref=e483] [cursor=pointer]
          - generic [ref=e485]:
            - button "Save as draft" [ref=e486] [cursor=pointer]
            - button "Post invoice" [ref=e487] [cursor=pointer]
```

# Test source

```ts
  92  |     line.getByLabel("Unit cost before tax", { exact: true }),
  93  |   ).toHaveValue("1.6658");
  94  |   await expect(line.locator(".invoice-pack-equation")).toContainText(
  95  |     "500 × 12 = 6000",
  96  |   );
  97  |   await confirmNoDate(page);
  98  |   await post(page);
  99  |   const after = await stored(page);
  100 |   expect(after.invoice).toMatchObject({
  101 |     subtotal: "9995.00",
  102 |     final_total: "9995.00",
  103 |     payable_after_open_shorts: "9995.00",
  104 |   });
  105 |   expect(after.invoice.lines[0]).toMatchObject({
  106 |     units_per_case: 12,
  107 |     quantity_unit: "cases",
  108 |     quantity_entered: "500",
  109 |     qty_invoiced: 6000,
  110 |     unit_cost_before_tax: "1.6658",
  111 |     case_cost_before_tax: "19.99",
  112 |   });
  113 |   expect(
  114 |     Decimal.sum(
  115 |       ...after.ledger
  116 |         .filter((entry) => entry.invoice_id === after.invoice.id)
  117 |         .map((entry) => entry.amount),
  118 |     ).toFixed(2),
  119 |   ).toBe("9995.00");
  120 |   await page.goto("/#received");
  121 |   await page
  122 |     .getByRole("textbox", { name: "Search Received", exact: true })
  123 |     .fill(after.invoice.supplier_invoice_number);
  124 |   await expect(page.locator(".received-table")).toContainText("500 cases");
  125 |   await page.reload();
  126 |   expect((await stored(page)).invoice.lines[0].units_per_case).toBe(12);
  127 | });
  128 | 
  129 | test("order comparison requires explicit extra and changed-cost decisions, then preserves one alert and accepted receipts", async ({
  130 |   page,
  131 | }) => {
  132 |   await signIn(page, "Supervisor");
  133 |   await rememberedPack(page);
  134 |   await page.goto("/#orders");
  135 |   await page.getByRole("button", { name: "New order", exact: true }).click();
  136 |   const form = page.getByRole("form", { name: "New order", exact: true });
  137 |   await chooseOption(
  138 |     page,
  139 |     form.getByLabel("Supplier", { exact: true }),
  140 |     "Fresh Valley Foods",
  141 |   );
  142 |   await form
  143 |     .getByRole("textbox", { name: /^Cases — Canned Fava Beans/ })
  144 |     .fill("1");
  145 |   const expectedCost = form.getByRole("textbox", {
  146 |     name: /^Expected unit cost — Canned Fava Beans/,
  147 |   });
  148 |   if (!(await expectedCost.count()))
  149 |     await form
  150 |       .locator("tbody tr")
  151 |       .filter({ hasText: "Canned Fava Beans" })
  152 |       .getByRole("button", { name: "Show details", exact: true })
  153 |       .click();
  154 |   await form
  155 |     .getByRole("textbox", { name: /^Expected unit cost — Canned Fava Beans/ })
  156 |     .fill("0.9800");
  157 |   await form.getByRole("button", { name: "Place order", exact: true }).click();
  158 |   const before = await stored(page);
  159 |   const order = before.orders!.at(-1)!;
  160 |   expect(order.status).toBe("ordered");
  161 |   const line = await manual(page);
  162 |   await line.getByLabel("Invoiced", { exact: true }).fill("18");
  163 |   await line.getByLabel("Unit cost before tax", { exact: true }).fill("1.1000");
  164 |   const comparison = page.locator(".invoice-order-card");
  165 |   await chooseOption(
  166 |     page,
  167 |     comparison.getByLabel("Order (optional)", { exact: true }),
  168 |     order.id,
  169 |     `${order.reference} · ${order.date}`,
  170 |   );
  171 |   await page.getByRole("button", { name: "Post invoice", exact: true }).click();
  172 |   await expect(
  173 |     page.getByRole("link", {
  174 |       name: "Choose a decision for every order difference before posting.",
  175 |       exact: true,
  176 |     }),
  177 |   ).toBeVisible();
  178 |   const row = comparison.locator('tr[data-invoice-line="0"]');
  179 |   const refusal = comparison.getByRole("button", {
  180 |     name: "Refused / sent back with the driver",
  181 |     exact: true,
  182 |   });
  183 |   if (!(await refusal.count()))
  184 |     await row
  185 |       .getByRole("button", { name: "Show details", exact: true })
  186 |       .click();
  187 |   await comparison
  188 |     .getByRole("button", {
  189 |       name: "Refused / sent back with the driver",
  190 |       exact: true,
  191 |     })
> 192 |     .click();
      |      ^ Error: locator.click: Test timeout of 60000ms exceeded.
  193 |   await comparison
  194 |     .getByRole("button", { name: "Accept new cost", exact: true })
  195 |     .click();
  196 |   await confirmNoDate(page);
  197 |   await post(page);
  198 |   const after = await stored(page);
  199 |   const currentOrder = after.orders!.find((item) => item.id === order.id)!;
  200 |   expect(currentOrder.status).toBe("received");
  201 |   expect(currentOrder.lines[0].received_units).toBe(12);
  202 |   expect(after.invoice.lines[0]).toMatchObject({
  203 |     qty_received_at_posting: 18,
  204 |     refused_units: 6,
  205 |     extra_delivery_decision: "refuse",
  206 |     order_price_decision: "accept",
  207 |   });
  208 |   expect(after.invoice.payable_after_open_shorts).toBe("13.20");
  209 |   expect(
  210 |     after.alerts.filter((alert) => alert.invoice_id === after.invoice.id),
  211 |   ).toHaveLength(1);
  212 |   expect(
  213 |     after.alerts.find((alert) => alert.invoice_id === after.invoice.id)
  214 |       ?.order_differences,
  215 |   ).toEqual(
  216 |     expect.arrayContaining([
  217 |       expect.objectContaining({ kind: "extra", units: 6, decision: "refuse" }),
  218 |       expect.objectContaining({ kind: "price_change", decision: "accept" }),
  219 |     ]),
  220 |   );
  221 |   await page.reload();
  222 |   const postedLine = page
  223 |     .locator(".posted-invoice-document tbody tr")
  224 |     .filter({ hasText: "Canned Fava Beans 400 g" });
  225 |   await expect(postedLine).toContainText("Delivered quantity: 12");
  226 |   await expect(postedLine).toContainText(
  227 |     "Refused / sent back with the driver · 6 · $6.60",
  228 |   );
  229 |   await expect(postedLine).toContainText("Accept new cost");
  230 |   await expect(postedLine.getByRole("cell").nth(2)).toHaveText("$1.10");
  231 |   await expect(
  232 |     page.locator(
  233 |       ".posted-invoice-document input, .posted-invoice-document select",
  234 |     ),
  235 |   ).toHaveCount(0);
  236 |   await page.goto("/#alerts");
  237 |   await expect(
  238 |     page.getByRole("heading", {
  239 |       name: "Invoice and order differences",
  240 |       exact: true,
  241 |     }),
  242 |   ).toBeVisible();
  243 |   await page.goto("/#received");
  244 |   await page
  245 |     .getByRole("textbox", { name: "Search Received", exact: true })
  246 |     .fill(after.invoice.supplier_invoice_number);
  247 |   await expect(page.locator(".received-table")).toContainText("12 units");
  248 | });
  249 | 
  250 | test("short-dated expiry discount requires a real date and preserves an existing manual selling price", async ({
  251 |   page,
  252 | }) => {
  253 |   await signIn(page, "Supervisor");
  254 |   const editor = await openC8PriceDialog(page, "0002");
  255 |   await editor.getByRole("radio", { name: /^New regular price/ }).check();
  256 |   await editor.getByLabel("Price", { exact: true }).fill("2.49");
  257 |   await editor
  258 |     .getByRole("checkbox", {
  259 |       name: "Add regular labels to the label waitlist",
  260 |       exact: true,
  261 |     })
  262 |     .uncheck();
  263 |   await editor
  264 |     .getByRole("button", { name: "Save new price", exact: true })
  265 |     .click();
  266 |   await expect(editor).not.toBeVisible();
  267 |   await expect
  268 |     .poll(
  269 |       async () =>
  270 |         (await stored(page)).products.find((entry) => entry.code === "0002")
  271 |           ?.manual_prices?.all.price,
  272 |     )
  273 |     .toBe("2.49");
  274 |   const before = await stored(page);
  275 |   const prior = before.products.find((item) => item.code === "0002")!;
  276 |   const line = await manual(page);
  277 |   await line.getByLabel("Unit cost before tax", { exact: true }).fill("0.8000");
  278 |   await line
  279 |     .getByRole("button", { name: "Short-dated (expiry discount)", exact: true })
  280 |     .click();
  281 |   await expect(
  282 |     line.getByRole("button", { name: "No", exact: true }),
  283 |   ).toBeDisabled();
  284 |   await expect(
  285 |     page.getByRole("button", { name: "Post invoice", exact: true }),
  286 |   ).toBeEnabled();
  287 |   await page.getByRole("button", { name: "Post invoice", exact: true }).click();
  288 |   await expect(
  289 |     page.getByRole("alert", { name: "What's missing", exact: true }),
  290 |   ).toBeVisible();
  291 |   await expect(
  292 |     line.getByRole("button", { name: "Keep $2.49", exact: true }),
```