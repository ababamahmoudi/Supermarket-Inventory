# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: c8-layout-display.spec.ts >> C8 Received uses whole cases and retained loose units (en)
- Location: tests/c8-layout-display.spec.ts:180:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('.received-table tbody > tr[data-row-href="#invoices?id=a2-fixture%3AGG-11879"]').filter({ hasText: 'Dried Red Kidney Beans 900 g' }).locator('.table-details-toggle')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('.received-table tbody > tr[data-row-href="#invoices?id=a2-fixture%3AGG-11879"]').filter({ hasText: 'Dried Red Kidney Beans 900 g' }).locator('.table-details-toggle') with timeout 5000ms
  - waiting for locator('.received-table tbody > tr[data-row-href="#invoices?id=a2-fixture%3AGG-11879"]').filter({ hasText: 'Dried Red Kidney Beans 900 g' }).locator('.table-details-toggle')

```

```yaml
- link "Skip to content":
  - /url: "#main-content"
- banner:
  - button "Open menu"
  - combobox "Location": North York
  - button "Notifications, 5 unread": "5"
  - button "User menu"
  - button "More"
- main:
  - heading "Received" [level=1]
  - paragraph: What came in, where and when.
  - textbox "Search Received":
    - /placeholder: Search products, invoices or suppliers
  - button "Date range"
  - combobox "Supplier": All suppliers
  - combobox "Product": All products
  - button "Clear filters"
  - text: 20 deliveries
  - button "Columns"
  - table:
    - rowgroup:
      - row "Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی 2 cases (24 units) Invoice FV-20390 North York Fresh Valley Foods 2026-10-14":
        - cell "Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی":
          - strong: Canned Fava Beans 400 g
          - text: باقالا کنسرو شده ۴۰۰ گرمی
        - cell "2 cases (24 units)"
        - cell "Invoice FV-20390":
          - link "Invoice FV-20390":
            - /url: "#invoices?id=a2-fixture%3AFV-20390"
        - cell "North York Fresh Valley Foods 2026-10-14"
      - row "Ground Sumac 100 g سماق ۱۰۰ گرمی 1 case (12 units) Invoice FV-20390 North York Fresh Valley Foods 2026-10-14":
        - cell "Ground Sumac 100 g سماق ۱۰۰ گرمی":
          - strong: Ground Sumac 100 g
          - text: سماق ۱۰۰ گرمی
        - cell "1 case (12 units)"
        - cell "Invoice FV-20390":
          - link "Invoice FV-20390":
            - /url: "#invoices?id=a2-fixture%3AFV-20390"
        - cell "North York Fresh Valley Foods 2026-10-14"
      - row "Lavash Bread 500 g نان لواش ۵۰۰ گرمی 2 cases (20 units) Invoice FV-20390 North York Fresh Valley Foods 2026-10-14":
        - cell "Lavash Bread 500 g نان لواش ۵۰۰ گرمی":
          - strong: Lavash Bread 500 g
          - text: نان لواش ۵۰۰ گرمی
        - cell "2 cases (20 units)"
        - cell "Invoice FV-20390":
          - link "Invoice FV-20390":
            - /url: "#invoices?id=a2-fixture%3AFV-20390"
        - cell "North York Fresh Valley Foods 2026-10-14"
      - row "Sour Cherry Juice 1 L آب آلبالو ۱ لیتری 3 cases (36 units) Invoice FV-20390 North York Fresh Valley Foods 2026-10-14":
        - cell "Sour Cherry Juice 1 L آب آلبالو ۱ لیتری":
          - strong: Sour Cherry Juice 1 L
          - text: آب آلبالو ۱ لیتری
        - cell "3 cases (36 units)"
        - cell "Invoice FV-20390":
          - link "Invoice FV-20390":
            - /url: "#invoices?id=a2-fixture%3AFV-20390"
        - cell "North York Fresh Valley Foods 2026-10-14"
      - row "Dried Barberries 100 g زرشک خشک ۱۰۰ گرمی 1 case (6 units) Invoice FV-20390 North York Fresh Valley Foods 2026-10-14":
        - cell "Dried Barberries 100 g زرشک خشک ۱۰۰ گرمی":
          - strong: Dried Barberries 100 g
          - text: زرشک خشک ۱۰۰ گرمی
        - cell "1 case (6 units)"
        - cell "Invoice FV-20390":
          - link "Invoice FV-20390":
            - /url: "#invoices?id=a2-fixture%3AFV-20390"
        - cell "North York Fresh Valley Foods 2026-10-14"
      - row "Potato Chips 150 g چیپس سیب‌زمینی ۱۵۰ گرمی 1 case (12 units) Invoice FV-20390 North York Fresh Valley Foods 2026-10-14":
        - cell "Potato Chips 150 g چیپس سیب‌زمینی ۱۵۰ گرمی":
          - strong: Potato Chips 150 g
          - text: چیپس سیب‌زمینی ۱۵۰ گرمی
        - cell "1 case (12 units)"
        - cell "Invoice FV-20390":
          - link "Invoice FV-20390":
            - /url: "#invoices?id=a2-fixture%3AFV-20390"
        - cell "North York Fresh Valley Foods 2026-10-14"
      - row "Basmati Rice 4.5 kg برنج باسماتی ۴٫۵ کیلوگرمی 1 unit Invoice GG-11842 North York Golden Grain Distributors 2026-10-12":
        - cell "Basmati Rice 4.5 kg برنج باسماتی ۴٫۵ کیلوگرمی":
          - strong: Basmati Rice 4.5 kg
          - text: برنج باسماتی ۴٫۵ کیلوگرمی
        - cell "1 unit"
        - cell "Invoice GG-11842":
          - link "Invoice GG-11842":
            - /url: "#invoices?id=a2-fixture%3AGG-11842"
        - cell "North York Golden Grain Distributors 2026-10-12"
      - row "Basmati Rice 4.5 kg برنج باسماتی ۴٫۵ کیلوگرمی 7 cases + 2 units (30 units) Invoice GG-11879 North York Golden Grain Distributors 2026-10-10":
        - cell "Basmati Rice 4.5 kg برنج باسماتی ۴٫۵ کیلوگرمی":
          - strong: Basmati Rice 4.5 kg
          - text: برنج باسماتی ۴٫۵ کیلوگرمی
        - cell "7 cases + 2 units (30 units)"
        - cell "Invoice GG-11879":
          - link "Invoice GG-11879":
            - /url: "#invoices?id=a2-fixture%3AGG-11879"
        - cell "North York Golden Grain Distributors 2026-10-10"
      - row "Dried Red Kidney Beans 900 g لوبیا قرمز ۹۰۰ گرمی 3 cases + 4 units (40 units) Invoice GG-11879 North York Golden Grain Distributors 2026-10-10":
        - cell "Dried Red Kidney Beans 900 g لوبیا قرمز ۹۰۰ گرمی":
          - strong: Dried Red Kidney Beans 900 g
          - text: لوبیا قرمز ۹۰۰ گرمی
        - cell "3 cases + 4 units (40 units)"
        - cell "Invoice GG-11879":
          - link "Invoice GG-11879":
            - /url: "#invoices?id=a2-fixture%3AGG-11879"
        - cell "North York Golden Grain Distributors 2026-10-10"
      - row "Black Tea 450 g چای سیاه ۴۵۰ گرمی 2 cases + 4 units (16 units) Invoice SB-7862 North York Sunrise Beverages 2026-10-06":
        - cell "Black Tea 450 g چای سیاه ۴۵۰ گرمی":
          - strong: Black Tea 450 g
          - text: چای سیاه ۴۵۰ گرمی
        - cell "2 cases + 4 units (16 units)"
        - cell "Invoice SB-7862":
          - link "Invoice SB-7862":
            - /url: "#invoices?id=a2-fixture%3ASB-7862"
        - cell "North York Sunrise Beverages 2026-10-06"
      - row "Fruit Soda 6-pack نوشابه میوه‌ای بسته ۶ عددی 2 cases (12 units) Invoice SB-7862 North York Sunrise Beverages 2026-10-06":
        - cell "Fruit Soda 6-pack نوشابه میوه‌ای بسته ۶ عددی":
          - strong: Fruit Soda 6-pack
          - text: نوشابه میوه‌ای بسته ۶ عددی
        - cell "2 cases (12 units)"
        - cell "Invoice SB-7862":
          - link "Invoice SB-7862":
            - /url: "#invoices?id=a2-fixture%3ASB-7862"
        - cell "North York Sunrise Beverages 2026-10-06"
      - row "Black Tea 450 g چای سیاه ۴۵۰ گرمی 1 case (6 units) Invoice SB-7848 North York Sunrise Beverages 2026-10-05":
        - cell "Black Tea 450 g چای سیاه ۴۵۰ گرمی":
          - strong: Black Tea 450 g
          - text: چای سیاه ۴۵۰ گرمی
        - cell "1 case (6 units)"
        - cell "Invoice SB-7848":
          - link "Invoice SB-7848":
            - /url: "#invoices?id=a2-fixture%3ASB-7848"
        - cell "North York Sunrise Beverages 2026-10-05"
      - row "Tea Glass Set (6 pcs) ست استکان چای (۶ عددی) 10 cases (20 units) Invoice HW-4936 North York HomeWare Imports 2026-09-24":
        - cell "Tea Glass Set (6 pcs) ست استکان چای (۶ عددی)":
          - strong: Tea Glass Set (6 pcs)
          - text: ست استکان چای (۶ عددی)
        - cell "10 cases (20 units)"
        - cell "Invoice HW-4936":
          - link "Invoice HW-4936":
            - /url: "#invoices?id=a2-fixture%3AHW-4936"
        - cell "North York HomeWare Imports 2026-09-24"
      - row "Stainless Steel Pot 24 cm قابلمه استیل ۲۴ سانتی‌متری 10 cases (30 units) Invoice HW-4936 North York HomeWare Imports 2026-09-24":
        - cell "Stainless Steel Pot 24 cm قابلمه استیل ۲۴ سانتی‌متری":
          - strong: Stainless Steel Pot 24 cm
          - text: قابلمه استیل ۲۴ سانتی‌متری
        - cell "10 cases (30 units)"
        - cell "Invoice HW-4936":
          - link "Invoice HW-4936":
            - /url: "#invoices?id=a2-fixture%3AHW-4936"
        - cell "North York HomeWare Imports 2026-09-24"
      - row "Rice Cooker 1.8 L پلوپز ۱٫۸ لیتری 20 units Invoice HW-4936 North York HomeWare Imports 2026-09-24":
        - cell "Rice Cooker 1.8 L پلوپز ۱٫۸ لیتری":
          - strong: Rice Cooker 1.8 L
          - text: پلوپز ۱٫۸ لیتری
        - cell "20 units"
        - cell "Invoice HW-4936":
          - link "Invoice HW-4936":
            - /url: "#invoices?id=a2-fixture%3AHW-4936"
        - cell "North York HomeWare Imports 2026-09-24"
      - row "Kitchen Sponge 3-pack اسفنج ظرفشویی بسته ۳ عددی 5 cases (20 units) Invoice HW-4936 North York HomeWare Imports 2026-09-24":
        - cell "Kitchen Sponge 3-pack اسفنج ظرفشویی بسته ۳ عددی":
          - strong: Kitchen Sponge 3-pack
          - text: اسفنج ظرفشویی بسته ۳ عددی
        - cell "5 cases (20 units)"
        - cell "Invoice HW-4936":
          - link "Invoice HW-4936":
            - /url: "#invoices?id=a2-fixture%3AHW-4936"
        - cell "North York HomeWare Imports 2026-09-24"
      - row "Sour Cherry Juice 1 L آب آلبالو ۱ لیتری 1 case (12 units) Invoice FV-20296 North York Fresh Valley Foods 2026-09-21":
        - cell "Sour Cherry Juice 1 L آب آلبالو ۱ لیتری":
          - strong: Sour Cherry Juice 1 L
          - text: آب آلبالو ۱ لیتری
        - cell "1 case (12 units)"
        - cell "Invoice FV-20296":
          - link "Invoice FV-20296":
            - /url: "#invoices?id=a2-fixture%3AFV-20296"
        - cell "North York Fresh Valley Foods 2026-09-21"
      - row "Ground Sumac 100 g سماق ۱۰۰ گرمی 1 case (12 units) Invoice FV-20296 North York Fresh Valley Foods 2026-09-21":
        - cell "Ground Sumac 100 g سماق ۱۰۰ گرمی":
          - strong: Ground Sumac 100 g
          - text: سماق ۱۰۰ گرمی
        - cell "1 case (12 units)"
        - cell "Invoice FV-20296":
          - link "Invoice FV-20296":
            - /url: "#invoices?id=a2-fixture%3AFV-20296"
        - cell "North York Fresh Valley Foods 2026-09-21"
      - row "Basmati Rice 4.5 kg برنج باسماتی ۴٫۵ کیلوگرمی 5 cases (20 units) Invoice GG-11842 North York Golden Grain Distributors 2026-09-10":
        - cell "Basmati Rice 4.5 kg برنج باسماتی ۴٫۵ کیلوگرمی":
          - strong: Basmati Rice 4.5 kg
          - text: برنج باسماتی ۴٫۵ کیلوگرمی
        - cell "5 cases (20 units)"
        - cell "Invoice GG-11842":
          - link "Invoice GG-11842":
            - /url: "#invoices?id=a2-fixture%3AGG-11842"
        - cell "North York Golden Grain Distributors 2026-09-10"
      - row "Dried Red Kidney Beans 900 g لوبیا قرمز ۹۰۰ گرمی 1 case (12 units) Invoice GG-11794 North York Golden Grain Distributors 2026-08-24":
        - cell "Dried Red Kidney Beans 900 g لوبیا قرمز ۹۰۰ گرمی":
          - strong: Dried Red Kidney Beans 900 g
          - text: لوبیا قرمز ۹۰۰ گرمی
        - cell "1 case (12 units)"
        - cell "Invoice GG-11794":
          - link "Invoice GG-11794":
            - /url: "#invoices?id=a2-fixture%3AGG-11794"
        - cell "North York Golden Grain Distributors 2026-08-24"
```

# Test source

```ts
  1   | import { readCanonicalBusinessEvidence } from "./business-evidence";
  2   | import { createHash } from "node:crypto";
  3   | import { fileURLToPath } from "node:url";
  4   | import { expect, test, type Locator, type Page } from "@playwright/test";
  5   | import demo from "../../seed/demo-data.json" with { type: "json" };
  6   | import type { DemoState } from "../src/types";
  7   | import {
  8   |   invoiceImage,
  9   |   openInvoiceUpload,
  10  |   setLanguage,
  11  |   signIn,
  12  |   uploadInvoice,
  13  | } from "./helpers";
  14  | 
  15  | const copy = (lang: "en" | "fa", en: string, fa: string) =>
  16  |   lang === "fa" ? fa : en;
  17  | const saved = (page: Page): Promise<DemoState> =>
  18  |   readCanonicalBusinessEvidence(page).then((canonicalState) =>
  19  |     JSON.parse(JSON.stringify(canonicalState)!),
  20  |   );
  21  | 
  22  | async function retainedOriginalHash(page: Page, reference: string) {
  23  |   const bytes = await page.evaluate(async (id) => {
  24  |     const db = await new Promise<IDBDatabase>((resolve, reject) => {
  25  |       const request = indexedDB.open("supermarket-prototype-files-v1", 1);
  26  |       request.onsuccess = () => resolve(request.result);
  27  |       request.onerror = () => reject(request.error);
  28  |     });
  29  |     try {
  30  |       const record = await new Promise<{ source: Blob }>((resolve, reject) => {
  31  |         const request = db
  32  |           .transaction("files", "readonly")
  33  |           .objectStore("files")
  34  |           .get(id);
  35  |         request.onsuccess = () => resolve(request.result);
  36  |         request.onerror = () => reject(request.error);
  37  |       });
  38  |       if (!(record?.source instanceof Blob))
  39  |         throw new Error("Original evidence is missing");
  40  |       return Array.from(new Uint8Array(await record.source.arrayBuffer()));
  41  |     } finally {
  42  |       db.close();
  43  |     }
  44  |   }, reference);
  45  |   return createHash("sha256").update(Buffer.from(bytes)).digest("hex");
  46  | }
  47  | 
  48  | async function quantityEvidence(page: Page, row: Locator) {
  49  |   const direct = row.locator('td[data-column-key="quantity"]');
  50  |   if (await direct.isVisible()) return direct;
  51  |   const disclosure = row.locator(".table-details-toggle");
> 52  |   await expect(disclosure).toBeVisible();
      |                            ^ Error: expect(locator).toBeVisible() failed
  53  |   const id = await disclosure.getAttribute("aria-controls");
  54  |   await disclosure.click();
  55  |   const details = page.locator(`[id=${JSON.stringify(id)}]`);
  56  |   await expect(details).toBeVisible();
  57  |   return details;
  58  | }
  59  | 
  60  | for (const language of ["en", "fa"] as const) {
  61  |   test(`C8 unread original has Continue and exact durable evidence (${language})`, async ({
  62  |     page,
  63  |   }) => {
  64  |     await signIn(page, "Supervisor");
  65  |     await page.goto("/#invoices");
  66  |     await setLanguage(page, language);
  67  |     const before = (await saved(page)).invoice;
  68  |     expect(before.status).toBe("empty");
  69  |     expect(before.file_data).toMatch(/^idb-file:v1:/);
  70  |     const originalHash = await retainedOriginalHash(page, before.file_data!);
  71  |     const drafts = page.locator(".invoice-saved-drafts");
  72  |     await expect(drafts).toContainText(
  73  |       copy(language, "Not read yet", "هنوز خوانده نشده"),
  74  |     );
  75  |     await expect(
  76  |       page
  77  |         .getByText(before.file_name!, { exact: true })
  78  |         .filter({ visible: true }),
  79  |     ).toHaveCount(1);
  80  |     await expect(
  81  |       page.getByText(
  82  |         copy(
  83  |           language,
  84  |           "No drafts. Start a new invoice.",
  85  |           "پیش‌نویسی نیست. فاکتور جدید شروع کنید.",
  86  |         ),
  87  |         { exact: true },
  88  |       ),
  89  |     ).toHaveCount(0);
  90  |     await drafts
  91  |       .getByRole("button", {
  92  |         name: copy(language, "Continue", "ادامه"),
  93  |         exact: true,
  94  |       })
  95  |       .click();
  96  |     await expect(page.locator(".invoice-reading-state")).toBeVisible();
  97  |     await expect(
  98  |       page.getByRole("heading", {
  99  |         name: copy(language, "Review invoice lines", "بررسی ردیف‌های فاکتور"),
  100 |         exact: true,
  101 |       }),
  102 |     ).toBeVisible({ timeout: 10000 });
  103 |     await expect
  104 |       .poll(async () => (await saved(page)).invoice.status)
  105 |       .toBe("review");
  106 |     const after = (await saved(page)).invoice;
  107 |     expect(after.id).toBe(before.id);
  108 |     expect(after.file_data).toBe(before.file_data);
  109 |     expect(after.lines).toEqual(before.lines);
  110 |     expect(await retainedOriginalHash(page, after.file_data!)).toBe(
  111 |       originalHash,
  112 |     );
  113 |     await expect(
  114 |       page
  115 |         .getByText(before.file_name!, { exact: true })
  116 |         .filter({ visible: true }),
  117 |     ).toHaveCount(1);
  118 |     await page.reload();
  119 |     await expect(page.locator(".invoice-original-media img")).toBeVisible();
  120 |     expect(await retainedOriginalHash(page, after.file_data!)).toBe(
  121 |       originalHash,
  122 |     );
  123 |   });
  124 | 
  125 |   test(`C8 invoice read-only costs preserve four decimals without posting money (${language})`, async ({
  126 |     page,
  127 |   }) => {
  128 |     await signIn(page, "Supervisor");
  129 |     await page.goto("/#invoices");
  130 |     await uploadInvoice(page);
  131 |     await expect
  132 |       .poll(async () => (await saved(page)).invoice.file_data)
  133 |       .toMatch(/^idb-file:v1:/);
  134 |     const before = await saved(page);
  135 |     const originalHash = await retainedOriginalHash(
  136 |       page,
  137 |       before.invoice.file_data!,
  138 |     );
  139 |     expect(originalHash).toBe(
  140 |       createHash("sha256").update(invoiceImage.buffer).digest("hex"),
  141 |     );
  142 |     const line = page.locator(".invoice-line").first();
  143 |     await line
  144 |       .getByLabel("Unit cost before tax", { exact: true })
  145 |       .fill("1.5525");
  146 |     await line.getByRole("button", { name: "No", exact: true }).click();
  147 |     await line
  148 |       .getByRole("checkbox", { name: "Confirm this invoice line", exact: true })
  149 |       .click();
  150 |     await expect(line).toHaveAttribute("data-expanded", "false");
  151 |     await setLanguage(page, language);
  152 |     const displayedCost = line
```