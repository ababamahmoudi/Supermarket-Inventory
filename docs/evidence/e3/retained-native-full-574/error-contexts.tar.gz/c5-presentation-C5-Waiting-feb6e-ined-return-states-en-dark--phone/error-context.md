# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: c5-presentation.spec.ts >> C5 Waiting for credit is amber for different retained return states (en-dark)
- Location: tests/c5-presentation.spec.ts:141:3

# Error details

```
Error: Waiting for credit across return states

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 4

- Array []
+ Array [
+   "Row navigation/disclosure is not at the row end",
+   "Row navigation/disclosure is not at the row end",
+ ]
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=e5]:
    - banner [ref=e6]:
      - button "Open menu" [ref=e7] [cursor=pointer]
      - combobox "Location" [ref=e11] [cursor=pointer]:
        - generic [ref=e16]: North York
      - button "Notifications, 6 unread" [ref=e19] [cursor=pointer]:
        - generic [ref=e20]: "6"
      - button "User menu" [ref=e25] [cursor=pointer]:
        - generic [aria-hidden] [ref=e27]: DM
      - button "More" [active] [ref=e28] [cursor=pointer]
    - main [ref=e34]:
      - generic [ref=e36]:
        - heading "Returns" [level=1] [ref=e37]
        - paragraph [ref=e38]: Supplier returns and credits
      - generic [ref=e39]:
        - tablist "Returns view" [ref=e40]:
          - tab "Open" [selected] [ref=e41] [cursor=pointer]
          - tab "History" [ref=e43] [cursor=pointer]
        - generic "Filter returns" [ref=e45]:
          - textbox "Search returns" [ref=e50]
          - combobox "Supplier" [ref=e51] [cursor=pointer]:
            - generic [ref=e52]: All suppliers
          - combobox "Status" [ref=e55] [cursor=pointer]:
            - generic [ref=e56]: All statuses
          - combobox "Return branch" [ref=e59] [cursor=pointer]:
            - generic [ref=e60]: All branches
          - button "Clear filters" [ref=e63] [cursor=pointer]
          - generic [ref=e65]:
            - generic [ref=e66]: 2 results
            - button "Columns" [ref=e67] [cursor=pointer]
        - table [ref=e71]:
          - rowgroup [ref=e72]:
            - 'row "Return #1 · Fresh Valley Foods" [ref=e73] [cursor=pointer]':
              - cell "Fresh Valley Foods" [ref=e74]
              - cell "Waiting for credit" [ref=e75]
              - cell [ref=e77]:
                - 'link "View Return #1" [ref=e78]':
                  - /url: "#return?id=demo-return-1"
              - cell "#1 North York 2026-10-14" [ref=e81]:
                - link "#1" [ref=e83]:
                  - /url: "#return?id=demo-return-1"
                - generic [ref=e85]: North York
                - generic [ref=e86]: 2026-10-14
            - 'row "Return #2 · Golden Grain Distributors" [ref=e88] [cursor=pointer]':
              - cell "Golden Grain Distributors" [ref=e89]
              - cell "Waiting for credit" [ref=e90]
              - cell [ref=e92]:
                - 'link "View Return #2" [ref=e93]':
                  - /url: "#return?id=demo-return-2"
              - cell "#2 North York 2026-10-11" [ref=e96]:
                - link "#2" [ref=e98]:
                  - /url: "#return?id=demo-return-2"
                - generic [ref=e100]: North York
                - generic [ref=e101]: 2026-10-11
```

# Test source

```ts
  36  | ) {
  37  |   const proof = await inspect(
  38  |     page,
  39  |     scene,
  40  |     `${test.info().project.name}-${variant}`,
  41  |     role,
  42  |   );
  43  |   const reports = measurements.get(page) ?? [];
  44  |   reports.push(proof);
  45  |   measurements.set(page, reports);
  46  |   expect(
  47  |     proof.buttons.length,
  48  |     `${scene}: real controls measured`,
  49  |   ).toBeGreaterThan(2);
  50  |   if (proof.viewport.width < 760) {
  51  |     expect(
  52  |       proof.topbar.length,
  53  |       `${scene}: all five priority-bar controls measured`,
  54  |     ).toBe(5);
  55  |     expect(
  56  |       await page
  57  |         .locator(".topbar")
  58  |         .evaluate((element) => element.getBoundingClientRect().height),
  59  |       `${scene}: the phone priority bar stays on one 60px row`,
  60  |     ).toBeCloseTo(60, 0);
  61  |     for (const selector of [
  62  |       "#menu-toggle",
  63  |       ".branch-pill",
  64  |       ".notifications-menu",
  65  |       ".mobile-account-menu",
  66  |       ".mobile-more-menu",
  67  |     ])
  68  |       await expect(page.locator(`.topbar ${selector}`)).toBeVisible();
  69  |     expect(
  70  |       await page
  71  |         .locator(
  72  |           'button[aria-label="User menu"], button[aria-label="منوی کاربر"]',
  73  |         )
  74  |         .evaluateAll(
  75  |           (controls) =>
  76  |             controls.filter((control) => {
  77  |               const rect = control.getBoundingClientRect();
  78  |               return (
  79  |                 rect.width > 0 &&
  80  |                 rect.height > 0 &&
  81  |                 getComputedStyle(control).visibility !== "hidden"
  82  |               );
  83  |             }).length,
  84  |         ),
  85  |       `${scene}: exactly one account is visible, including behind a modal`,
  86  |     ).toBe(1);
  87  |     // The top bar is deliberately inert while a modal is open. Exercise the
  88  |     // collapsed controls in every ordinary screen instead of counting hidden
  89  |     // desktop buttons as phone controls.
  90  |     if (!(await page.locator("dialog[open]").count())) {
  91  |       const persian =
  92  |         (await page.locator("html").getAttribute("lang")) === "fa";
  93  |       const dark =
  94  |         (await page.locator("html").getAttribute("data-theme")) === "dark";
  95  |       const more = page.locator(".mobile-more-menu");
  96  |       if ((await more.getAttribute("aria-expanded")) !== "true")
  97  |         await more.click();
  98  |       for (const name of [
  99  |         persian ? "جست‌وجوی همهٔ محصولات" : "Search all products",
  100 |         persian ? "تغییر به انگلیسی" : "Switch to Persian",
  101 |         persian
  102 |           ? dark
  103 |             ? "تغییر به تم روشن"
  104 |             : "تغییر به تم تیره"
  105 |           : dark
  106 |             ? "Switch to light theme"
  107 |             : "Switch to dark theme",
  108 |         persian ? "اندازهٔ متن راحت" : "Comfortable text size",
  109 |         persian ? "دمو" : "Demo",
  110 |       ])
  111 |         await expect(
  112 |           page.getByRole("menuitem", { name, exact: true }),
  113 |         ).toBeVisible();
  114 |       const demo = page.getByRole("menuitem", {
  115 |         name: persian ? "دمو" : "Demo",
  116 |         exact: true,
  117 |       });
  118 |       await demo.click();
  119 |       await expect(
  120 |         page.getByRole("menuitem", {
  121 |           name: persian ? "بازنشانی دمو" : "Reset demo",
  122 |           exact: true,
  123 |         }),
  124 |       ).toBeVisible();
  125 |       await page.keyboard.press("Escape");
  126 |       await expect(demo).toBeFocused();
  127 |       await page.keyboard.press("Escape");
  128 |       await expect(more).toBeFocused();
  129 |     }
  130 |   } else {
  131 |     expect(
  132 |       proof.topbar.length,
  133 |       `${scene}: all desktop topbar controls measured`,
  134 |     ).toBeGreaterThanOrEqual(7);
  135 |   }
> 136 |   expect(proof.failures, scene).toEqual([]);
      |                                 ^ Error: Waiting for credit across return states
  137 |   return proof;
  138 | }
  139 | 
  140 | for (const variant of ["en-light", "en-dark", "fa-light"] as const) {
  141 |   test(`C5 Waiting for credit is amber for different retained return states (${variant})`, async ({
  142 |     page,
  143 |   }) => {
  144 |     await signIn(page, "Supervisor");
  145 |     await setBranch(page, "Branch 1");
  146 |     await page.goto("/#return?id=demo-return-1");
  147 |     await button(page.locator(".return-header-card"), "Record pickup").click();
  148 |     const pickup = page.locator(".return-action-card");
  149 |     await assertContract(page, "Record return pickup form", "en-light");
  150 |     await pickup
  151 |       .getByLabel("Actual pickup quantity", { exact: true })
  152 |       .fill("3");
  153 |     await field(pickup, "Supplier representative name").fill("Demo Driver");
  154 |     await field(pickup, "Signed paper pickup slip reference").fill(
  155 |       "SIGNED-C5-COLOR-001",
  156 |     );
  157 |     await button(pickup, "Record pickup").click();
  158 |     // This existing status is published only after the actual command completes.
  159 |     await expect(page.getByRole("status")).toHaveText(
  160 |       "Recorded pickup and retained Return memo.",
  161 |     );
  162 |     await page.goto("/#returns");
  163 |     await expect(page.locator(".returns-overview-table")).toBeVisible();
  164 |     await appearance(page, variant);
  165 |     const proof = await assertContract(
  166 |       page,
  167 |       "Waiting for credit across return states",
  168 |       variant,
  169 |     );
  170 |     const credit = proof.statuses.filter(
  171 |       (status) => status.returnStatus === "waiting_for_credit",
  172 |     );
  173 |     expect(credit.length).toBeGreaterThanOrEqual(2);
  174 |     expect(
  175 |       credit.every((status) => status.classes.split(" ").includes("pending")),
  176 |     ).toBe(true);
  177 |     expect(
  178 |       new Set(credit.map((status) => `${status.color}/${status.background}`))
  179 |         .size,
  180 |     ).toBe(1);
  181 |   });
  182 | 
  183 |   test(`C5 Klead text actions, intrinsic table actions and uniform topbar (${variant})`, async ({
  184 |     page,
  185 |   }, info) => {
  186 |     await signIn(page, "Supervisor");
  187 |     await setBranch(page, "Branch 1");
  188 |     await appearance(page, variant);
  189 |     const proofs: C5Inspection[] = [];
  190 |     for (const route of [
  191 |       "invoices",
  192 |       "products",
  193 |       "alerts",
  194 |       "returns",
  195 |       "expiry",
  196 |       "offers",
  197 |       "approvals",
  198 |     ]) {
  199 |       await page.goto(`/#${route}`);
  200 |       proofs.push(await assertContract(page, route, variant));
  201 |       if (route === "products") {
  202 |         await field(
  203 |           page.getByRole("main"),
  204 |           "Search products",
  205 |           "جست‌وجوی محصولات",
  206 |         ).fill("0016");
  207 |         const cost = page.locator(".catalog-products-table .weight-cost");
  208 |         if ((await cost.count()) === 0)
  209 |           await button(
  210 |             page.locator(".catalog-products-table tbody tr").first(),
  211 |             "Show details",
  212 |             "نمایش جزئیات",
  213 |           ).click();
  214 |         await expect(cost).toHaveText("$4.9895/lb");
  215 |         await expect(cost).toHaveAttribute("dir", "ltr");
  216 |         const price = page.locator(".catalog-products-table .weight-price");
  217 |         await expect(price.locator(".weight-price-main")).toHaveText(
  218 |           "$7.49/lb",
  219 |         );
  220 |         await expect(price.locator(".weight-price-secondary")).toHaveText(
  221 |           "$16.51/kg",
  222 |         );
  223 |         proofs.push(
  224 |           await assertContract(page, "Products weighed item", variant),
  225 |         );
  226 |       }
  227 |       if (route === "expiry") {
  228 |         const product = field(
  229 |           page.locator(".date-quick-card"),
  230 |           "Product",
  231 |           "محصول",
  232 |         );
  233 |         await product.fill("0001");
  234 |         const iconClearance = await product.evaluate((element) => {
  235 |           const style = getComputedStyle(element);
  236 |           const bounds = element.getBoundingClientRect();
```