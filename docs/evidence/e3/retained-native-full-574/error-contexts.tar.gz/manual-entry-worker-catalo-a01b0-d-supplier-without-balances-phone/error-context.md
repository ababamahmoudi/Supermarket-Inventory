# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: manual-entry.spec.ts >> worker catalog actions stay hidden while invoice quick-add creates a Proposed supplier without balances
- Location: tests/manual-entry.spec.ts:202:1

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator: locator('#invoice-details-fields').getByLabel('Supplier', { exact: true })
Expected: "combobox"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toHaveAttribute" locator('#invoice-details-fields').getByLabel('Supplier', { exact: true }) with timeout 5000ms
  - waiting for locator('#invoice-details-fields').getByLabel('Supplier', { exact: true })

```

```yaml
- link "Skip to content":
  - /url: "#main-content"
- banner:
  - button "Open menu"
  - combobox "Location": North York
  - button "Notifications, 0 unread"
  - button "User menu"
  - button "More"
- main:
  - link "Back to Invoices":
    - /url: "#invoices"
  - heading "Invoices" [level=1]
  - paragraph: Deliveries and supplier invoices
  - button "New invoice"
  - tablist "Invoice views":
    - tab "Drafts" [selected]
    - tab "Processing"
    - tab "Needs review"
    - tab "Ready to post"
    - tab "Posted"
    - tab "Cancelled"
  - complementary "Original invoice":
    - heading "Original invoice" [level=2]
    - paragraph: AI invoice reading is simulated
    - button "Upload"
    - text: Upload a PDF or photo
    - button "Upload a PDF or photo"
    - button "Take photo"
    - paragraph: Drop a PDF or photo here, or browse
    - button "Browse"
    - button "Take photo"
    - paragraph: No original attached
  - heading "Drafts" [level=2]
  - table:
    - rowgroup:
      - row "FV-20417 Supplier Fresh Valley Foods Date 2026-10-15 Status Draft Details Show details":
        - cell "FV-20417"
        - cell "Supplier Fresh Valley Foods"
        - cell "Date 2026-10-15"
        - cell "Status Draft"
        - cell "Details Show details":
          - text: Details
          - button "Show details"
  - text: Subtotal
  - strong: $174.52
  - text: Tax
  - strong: $2.50
  - text: Shorts and refused deduction
  - strong: $0.00
  - text: Payable
  - strong: $177.02
  - paragraph: This is the amount of this invoice, not a supplier balance. Received records only physically delivered units.
  - heading "Invoice details" [level=2]:
    - button "Invoice details"
  - paragraph: Fresh Valley Foods · FV-20417 · North York · 2026-10-15
  - paragraph: Needs review Changes save automatically in this browser.
  - heading "Compare with order" [level=2]
  - text: Order (optional)
  - combobox "Order (optional)": No linked order
  - paragraph: Choose an open order for this supplier and receiving location.
  - heading "Review invoice lines" [level=2]
  - paragraph: Choose Cases or Units and confirm the product, pack, quantities, cost, and date decision on each line.
  - table:
    - 'rowgroup "Line 1: Canned Fava Beans 400 g"':
      - 'row "1. Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی 0002 · 400 g Matched Invoiced 2 Delivered 24 Unit cost before tax 0.98 Line total $23.52 Selling price $1.49 Approved: $1.49"':
        - cell "1. Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی 0002 · 400 g Matched":
          - heading "1. Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی" [level=3]:
            - button "1. Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی" [expanded]:
              - text: "1."
              - strong: Canned Fava Beans 400 g
              - text: باقالا کنسرو شده ۴۰۰ گرمی
          - paragraph: 0002 · 400 g
          - text: Matched
        - cell "Invoiced 2 Delivered 24":
          - text: Invoiced
          - textbox "Invoiced": "2"
          - text: Delivered
          - textbox "Delivered": "24"
        - cell "Unit cost before tax 0.98":
          - text: Unit cost before tax
          - textbox "Unit cost before tax": "0.98"
        - cell "Line total $23.52"
        - 'cell "Selling price $1.49 Approved: $1.49"':
          - text: Selling price
          - strong: $1.49
          - paragraph: "Approved: $1.49"
      - row "Remove line Mark as short Confirm this invoice line":
        - cell "Remove line Mark as short Confirm this invoice line":
          - group:
            - text: Quantity unit
            - combobox "Quantity unit": Cases
            - text: Units per case
            - textbox "Units per case": "12"
            - text: Supplier item code (optional)
            - textbox "Supplier item code (optional)"
            - text: Case cost before tax
            - textbox "Case cost before tax": "11.7600"
            - paragraph: 2 × 12 = 24 units
            - text: Matched product
            - combobox "Matched product": ⁦0002⁩ · ⁦Canned Fava Beans 400 g ⁩
            - text: Pricing category
            - combobox "Pricing category": Grocery
          - button "Remove line"
          - checkbox "Mark as short"
          - group:
            - text: Track date
            - group "Track date":
              - button "Yes" [pressed]
              - button "No"
            - text: Date tracking
            - combobox "Date tracking": Expiry
            - text: Date
            - button "Date": Choose date
            - text: Lot number (optional)
            - textbox "Lot number (optional)"
          - checkbox "Confirm this invoice line"
    - 'rowgroup "Line 2: Ground Sumac 100 g"':
      - 'row "2. Ground Sumac 100 g سماق ۱۰۰ گرمی 0005 · 100 g Matched Invoiced 1 Delivered 12 Unit cost before tax 1.30 Line total $15.60 Selling price $1.99 Approved: $1.99"':
        - cell "2. Ground Sumac 100 g سماق ۱۰۰ گرمی 0005 · 100 g Matched":
          - heading "2. Ground Sumac 100 g سماق ۱۰۰ گرمی" [level=3]:
            - button "2. Ground Sumac 100 g سماق ۱۰۰ گرمی" [expanded]:
              - text: "2."
              - strong: Ground Sumac 100 g
              - text: سماق ۱۰۰ گرمی
          - paragraph: 0005 · 100 g
          - text: Matched
        - cell "Invoiced 1 Delivered 12":
          - text: Invoiced
          - textbox "Invoiced": "1"
          - text: Delivered
          - textbox "Delivered": "12"
        - cell "Unit cost before tax 1.30":
          - text: Unit cost before tax
          - textbox "Unit cost before tax": "1.30"
        - cell "Line total $15.60"
        - 'cell "Selling price $1.99 Approved: $1.99"':
          - text: Selling price
          - strong: $1.99
          - paragraph: "Approved: $1.99"
      - row "Remove line Mark as short Confirm this invoice line":
        - cell "Remove line Mark as short Confirm this invoice line":
          - group:
            - text: Quantity unit
            - combobox "Quantity unit": Cases
            - text: Units per case
            - textbox "Units per case": "12"
            - text: Supplier item code (optional)
            - textbox "Supplier item code (optional)"
            - text: Case cost before tax
            - textbox "Case cost before tax": "15.6000"
            - paragraph: 1 × 12 = 12 units
            - text: Matched product
            - combobox "Matched product": ⁦0005⁩ · ⁦Ground Sumac 100 g ⁩
            - text: Pricing category
            - combobox "Pricing category": Grocery
          - button "Remove line"
          - checkbox "Mark as short"
          - group:
            - text: Track date
            - group "Track date":
              - button "Yes" [pressed]
              - button "No"
            - text: Date tracking
            - combobox "Date tracking": Expiry
            - text: Date
            - button "Date": Choose date
            - text: Lot number (optional)
            - textbox "Lot number (optional)"
          - checkbox "Confirm this invoice line"
    - 'rowgroup "Line 3: Lavash Bread 500 g"':
      - 'row "3. Lavash Bread 500 g نان لواش ۵۰۰ گرمی 0006 · 500 g Matched Invoiced 2 Delivered 20 Unit cost before tax 1.55 Line total $31.00 Selling price $2.99 Pending Goes to approval when posted Approved: $1.99"':
        - cell "3. Lavash Bread 500 g نان لواش ۵۰۰ گرمی 0006 · 500 g Matched":
          - heading "3. Lavash Bread 500 g نان لواش ۵۰۰ گرمی" [level=3]:
            - button "3. Lavash Bread 500 g نان لواش ۵۰۰ گرمی" [expanded]:
              - text: "3."
              - strong: Lavash Bread 500 g
              - text: نان لواش ۵۰۰ گرمی
          - paragraph: 0006 · 500 g
          - text: Matched
        - cell "Invoiced 2 Delivered 20":
          - text: Invoiced
          - textbox "Invoiced": "2"
          - text: Delivered
          - textbox "Delivered": "20"
        - cell "Unit cost before tax 1.55":
          - text: Unit cost before tax
          - textbox "Unit cost before tax": "1.55"
        - cell "Line total $31.00"
        - 'cell "Selling price $2.99 Pending Goes to approval when posted Approved: $1.99"':
          - text: Selling price
          - strong: $2.99
          - text: Pending Goes to approval when posted
          - paragraph: "Approved: $1.99"
      - row "Remove line Mark as short Confirm this invoice line":
        - cell "Remove line Mark as short Confirm this invoice line":
          - group:
            - text: Quantity unit
            - combobox "Quantity unit": Cases
            - text: Units per case
            - textbox "Units per case": "10"
            - text: Supplier item code (optional)
            - textbox "Supplier item code (optional)"
            - text: Case cost before tax
            - textbox "Case cost before tax": "15.5000"
            - paragraph: 2 × 10 = 20 units
            - text: Matched product
            - combobox "Matched product": ⁦0006⁩ · ⁦Lavash Bread 500 g ⁩
            - text: Pricing category
            - combobox "Pricing category": Grocery
          - button "Remove line"
          - checkbox "Mark as short"
          - group:
            - text: Track date
            - group "Track date":
              - button "Yes" [pressed]
              - button "No"
            - text: Date tracking
            - combobox "Date tracking": Expiry
            - text: Date
            - button "Date": Choose date
            - text: Lot number (optional)
            - textbox "Lot number (optional)"
          - checkbox "Confirm this invoice line"
    - 'rowgroup "Line 4: Sour Cherry Juice 1 L"':
      - 'row "4. Sour Cherry Juice 1 L آب آلبالو ۱ لیتری 0003 · 1 L Matched Invoiced 3 Delivered 36 Unit cost before tax 1.80 Line total $64.80 Selling price $2.99 Approved: $2.99"':
        - cell "4. Sour Cherry Juice 1 L آب آلبالو ۱ لیتری 0003 · 1 L Matched":
          - heading "4. Sour Cherry Juice 1 L آب آلبالو ۱ لیتری" [level=3]:
            - button "4. Sour Cherry Juice 1 L آب آلبالو ۱ لیتری" [expanded]:
              - text: "4."
              - strong: Sour Cherry Juice 1 L
              - text: آب آلبالو ۱ لیتری
          - paragraph: 0003 · 1 L
          - text: Matched
        - cell "Invoiced 3 Delivered 36":
          - text: Invoiced
          - textbox "Invoiced": "3"
          - text: Delivered
          - textbox "Delivered": "36"
        - cell "Unit cost before tax 1.80":
          - text: Unit cost before tax
          - textbox "Unit cost before tax": "1.80"
        - cell "Line total $64.80"
        - 'cell "Selling price $2.99 Approved: $2.99"':
          - text: Selling price
          - strong: $2.99
          - paragraph: "Approved: $2.99"
      - row "Remove line Mark as short Lower-cost receipt Lower-cost receipt Confirm this invoice line":
        - cell "Remove line Mark as short Lower-cost receipt Lower-cost receipt Confirm this invoice line":
          - group:
            - text: Quantity unit
            - combobox "Quantity unit": Cases
            - text: Units per case
            - textbox "Units per case": "12"
            - text: Supplier item code (optional)
            - textbox "Supplier item code (optional)"
            - text: Case cost before tax
            - textbox "Case cost before tax": "21.6000"
            - paragraph: 3 × 12 = 36 units
            - text: Matched product
            - combobox "Matched product": ⁦0003⁩ · ⁦Sour Cherry Juice 1 L ⁩
            - text: Pricing category
            - combobox "Pricing category": Grocery
          - button "Remove line"
          - checkbox "Mark as short"
          - text: Lower-cost receipt
          - group "Lower-cost receipt":
            - button "Regular receipt" [pressed]
            - button "Short-dated (expiry discount)"
          - group:
            - text: Track date
            - group "Track date":
              - button "Yes" [pressed]
              - button "No"
            - text: Date tracking
            - combobox "Date tracking": Expiry
            - text: Date
            - button "Date": Choose date
            - text: Lot number (optional)
            - textbox "Lot number (optional)"
          - checkbox "Confirm this invoice line"
    - 'rowgroup "Line 5: Dried Barberries 100 g"':
      - row "5. Dried Barberries 100 g زرشک خشک ۱۰۰ گرمی No Product Code yet Pending new product Invoiced 1 Delivered 6 Unit cost before tax 3.40 Line total $20.40 Selling price $5.49 Pending Goes to approval when posted No approved price yet":
        - cell "5. Dried Barberries 100 g زرشک خشک ۱۰۰ گرمی No Product Code yet Pending new product":
          - heading "5. Dried Barberries 100 g زرشک خشک ۱۰۰ گرمی" [level=3]:
            - button "5. Dried Barberries 100 g زرشک خشک ۱۰۰ گرمی" [expanded]:
              - text: "5."
              - strong: Dried Barberries 100 g
              - text: زرشک خشک ۱۰۰ گرمی
          - paragraph: No Product Code yet
          - text: Pending new product
        - cell "Invoiced 1 Delivered 6":
          - text: Invoiced
          - textbox "Invoiced": "1"
          - text: Delivered
          - textbox "Delivered": "6"
        - cell "Unit cost before tax 3.40":
          - text: Unit cost before tax
          - textbox "Unit cost before tax": "3.40"
        - cell "Line total $20.40"
        - cell "Selling price $5.49 Pending Goes to approval when posted No approved price yet":
          - text: Selling price
          - strong: $5.49
          - text: Pending Goes to approval when posted
          - paragraph: No approved price yet
      - row "Remove line Mark as short Confirm this invoice line":
        - cell "Remove line Mark as short Confirm this invoice line":
          - group:
            - text: Quantity unit
            - combobox "Quantity unit": Cases
            - text: Units per case
            - textbox "Units per case": "6"
            - text: Supplier item code (optional)
            - textbox "Supplier item code (optional)"
            - text: Case cost before tax
            - textbox "Case cost before tax": "20.4000"
            - paragraph: 1 × 6 = 6 units
            - text: Matched product
            - combobox "Matched product": Create pending new product
            - text: Pricing category
            - combobox "Pricing category": Grocery
            - text: New product name (English)
            - textbox "New product name (English)": Dried Barberries 100 g
            - text: New product name (Persian) (optional)
            - textbox "New product name (Persian) (optional)": زرشک خشک ۱۰۰ گرمی
          - button "Remove line"
          - checkbox "Mark as short"
          - group:
            - text: Track date
            - group "Track date":
              - button "Yes"
              - button "No"
          - checkbox "Confirm this invoice line"
    - 'rowgroup "Line 6: Potato Chips 150 g"':
      - 'row "6. Potato Chips 150 g چیپس سیب‌زمینی ۱۵۰ گرمی 0009 · 150 g Matched Taxable Invoiced 1 Delivered 12 Unit cost before tax 1.60 Line total $19.20 Selling price $2.99 Approved: $2.99"':
        - cell "6. Potato Chips 150 g چیپس سیب‌زمینی ۱۵۰ گرمی 0009 · 150 g Matched Taxable":
          - heading "6. Potato Chips 150 g چیپس سیب‌زمینی ۱۵۰ گرمی" [level=3]:
            - button "6. Potato Chips 150 g چیپس سیب‌زمینی ۱۵۰ گرمی" [expanded]:
              - text: "6."
              - strong: Potato Chips 150 g
              - text: چیپس سیب‌زمینی ۱۵۰ گرمی
          - paragraph: 0009 · 150 g
          - text: Matched Taxable
        - cell "Invoiced 1 Delivered 12":
          - text: Invoiced
          - textbox "Invoiced": "1"
          - text: Delivered
          - textbox "Delivered": "12"
        - cell "Unit cost before tax 1.60":
          - text: Unit cost before tax
          - textbox "Unit cost before tax": "1.60"
        - cell "Line total $19.20"
        - 'cell "Selling price $2.99 Approved: $2.99"':
          - text: Selling price
          - strong: $2.99
          - paragraph: "Approved: $2.99"
      - row "Remove line Mark as short Confirm this invoice line":
        - cell "Remove line Mark as short Confirm this invoice line":
          - group:
            - text: Quantity unit
            - combobox "Quantity unit": Cases
            - text: Units per case
            - textbox "Units per case": "12"
            - text: Supplier item code (optional)
            - textbox "Supplier item code (optional)"
            - text: Case cost before tax
            - textbox "Case cost before tax": "19.2000"
            - paragraph: 1 × 12 = 12 units
            - text: Matched product
            - combobox "Matched product": ⁦0009⁩ · ⁦Potato Chips 150 g ⁩
            - text: Pricing category
            - combobox "Pricing category": Grocery (Taxable)
          - button "Remove line"
          - checkbox "Mark as short"
          - group:
            - text: Track date
            - group "Track date":
              - button "Yes" [pressed]
              - button "No"
            - text: Date tracking
            - combobox "Date tracking": Expiry
            - text: Date
            - button "Date": Choose date
            - text: Lot number (optional)
            - textbox "Lot number (optional)"
          - checkbox "Confirm this invoice line"
  - text: Add a product to the invoice
  - combobox "Add a product to the invoice": ⁦0002⁩ · ⁦Canned Fava Beans 400 g ⁩
  - button "Add line"
  - button "+ Add new product"
  - heading "Same-supplier lower price" [level=2]
  - paragraph: Sour Cherry Juice 1 L · Fresh Valley Foods · Old $1.95 · New $1.80
  - paragraph: Your answers create a Supervisor alert when you post. Unknown information is allowed with a note.
  - group:
    - text: Is the expiry date the same as the goods already in the store?
    - combobox "Is the expiry date the same as the goods already in the store?": Choose an answer
  - button "Save as draft"
  - button "Post invoice"
```

# Test source

```ts
  27  |   const item = page.getByRole("menuitem", { name, exact: true });
  28  |   if (!(await item.isVisible()))
  29  |     await page.locator(".mobile-more-menu").click();
  30  |   await expect(item).toBeVisible();
  31  |   return item;
  32  | }
  33  | 
  34  | export async function signIn(page: Page, role: DemoRole) {
  35  |   // Retained Supervisor cases exercise the same configured Manager person;
  36  |   // the legacy name is not an authority role or a fabricated seventh account.
  37  |   const username = {
  38  |     Cashier: "cashier",
  39  |     "Floor Worker": "ny-floor",
  40  |     Supervisor: "manager",
  41  |     cashier: "cashier",
  42  |     floor_worker: "ny-floor",
  43  |     supervisor: "manager",
  44  |     Owner: "owner",
  45  |     Manager: "manager",
  46  |     "Branch Supervisor": "rh-supervisor",
  47  |     owner: "owner",
  48  |     manager: "manager",
  49  |     branch_supervisor: "rh-supervisor",
  50  |     "ny-floor": "ny-floor",
  51  |     "wh-floor": "wh-floor",
  52  |   }[role];
  53  |   const account = demoSeed.demo_users.find(
  54  |     (user) => user.username === username,
  55  |   );
  56  |   if (!account)
  57  |     throw new Error(`Configured Demo person is missing: ${username}`);
  58  |   if (await page.locator(".topbar").isVisible()) {
  59  |     const fa = (await page.locator("html").getAttribute("lang")) === "fa";
  60  |     await (await openShellAction(page, fa ? "دمو" : "Demo")).click();
  61  |     await page
  62  |       .getByRole("menuitem", {
  63  |         name: fa
  64  |           ? `تغییر به ${account.name_fa}`
  65  |           : `Switch to ${account.name_en}`,
  66  |         exact: true,
  67  |       })
  68  |       .click();
  69  |   } else {
  70  |     await page.goto("/");
  71  |     const heading = page.getByRole("heading", { name: /^(Sign in|ورود)$/ });
  72  |     await expect(heading).toBeVisible();
  73  |     const fa = (await heading.innerText()) === "ورود";
  74  |     await page
  75  |       .getByLabel(fa ? "نام کاربری" : "Username", { exact: true })
  76  |       .fill(account.username);
  77  |     await page
  78  |       .getByLabel(fa ? "گذرواژه" : "Password", { exact: true })
  79  |       .fill(account.password ?? "demo1234");
  80  |     await page
  81  |       .getByRole("button", { name: fa ? "ورود" : "Sign in", exact: true })
  82  |       .click();
  83  |     if (["owner", "manager", "branch_supervisor"].includes(account.role)) {
  84  |       // The normal privileged flow includes the real simulated challenge;
  85  |       // only the explicitly invoked Demo menu uses its configured shortcut.
  86  |       if (account.setup.second_step_method === "authenticator") {
  87  |         await page
  88  |           .getByLabel(fa ? "کد برنامهٔ احراز هویت" : "Authenticator app code", {
  89  |             exact: true,
  90  |           })
  91  |           .fill(configuration.session.simulated_authenticator_code);
  92  |         await page
  93  |           .getByRole("button", { name: fa ? "ادامه" : "Continue", exact: true })
  94  |           .click();
  95  |       } else {
  96  |         await page
  97  |           .getByRole("button", {
  98  |             name: fa
  99  |               ? "استفاده از کلید ورود شبیه‌سازی‌شده"
  100 |               : "Use simulated passkey",
  101 |             exact: true,
  102 |           })
  103 |           .click();
  104 |       }
  105 |     }
  106 |   }
  107 |   await expect(page.locator(".topbar")).toBeVisible();
  108 |   const fa = (await page.locator("html").getAttribute("lang")) === "fa";
  109 |   await expect(page.locator(".user-chip-copy strong")).toHaveText(
  110 |     fa ? account.name_fa : account.name_en,
  111 |   );
  112 |   // These controls only mount after actual session completion and the current
  113 |   // protected projection. E1 canonical business persistence is IndexedDB.
  114 |   await expect(
  115 |     page
  116 |       .locator(".topbar")
  117 |       .getByRole("combobox", { name: fa ? "مکان" : "Location", exact: true }),
  118 |   ).toBeEnabled();
  119 | }
  120 | 
  121 | export async function chooseOption(
  122 |   page: Page,
  123 |   control: Locator,
  124 |   value: string,
  125 |   label = value,
  126 | ) {
> 127 |   await expect(control).toHaveAttribute("role", "combobox");
      |                         ^ Error: expect(locator).toHaveAttribute(expected) failed
  128 |   await control.click();
  129 |   await page.getByRole("option", { name: label, exact: true }).click();
  130 | }
  131 | 
  132 | export async function setBranch(page: Page, branch: string) {
  133 |   const fa = (await page.locator("html").getAttribute("lang")) === "fa";
  134 |   const control = page
  135 |     .locator(".topbar")
  136 |     .getByRole("combobox", { name: fa ? "مکان" : "Location", exact: true });
  137 |   if (branch === "all") {
  138 |     await control.click();
  139 |     await page
  140 |       .getByRole("option", {
  141 |         name: fa
  142 |           ? /^(همه مکان‌ها|همه مکان‌های من)$/
  143 |           : /^All (locations|my locations)$/,
  144 |       })
  145 |       .click();
  146 |     await expect(control).toBeEnabled();
  147 |     return;
  148 |   }
  149 |   const location = configuration.branches.find((row) => row.id === branch);
  150 |   await chooseOption(
  151 |     page,
  152 |     control,
  153 |     branch,
  154 |     (fa ? location?.name_fa : location?.name) ?? branch,
  155 |   );
  156 |   await expect(control).toBeEnabled();
  157 | }
  158 | 
  159 | export async function setLanguage(page: Page, language: "en" | "fa") {
  160 |   if ((await page.locator("html").getAttribute("lang")) === language) return;
  161 |   await (
  162 |     await openShellAction(
  163 |       page,
  164 |       language === "fa" ? "Switch to Persian" : "تغییر به انگلیسی",
  165 |     )
  166 |   ).click();
  167 | }
  168 | 
  169 | export async function resetDemo(page: Page) {
  170 |   const fa = (await page.locator("html").getAttribute("lang")) === "fa";
  171 |   const locationName = fa ? "مکان" : "Location";
  172 |   const beforeLocation = (
  173 |     await page
  174 |       .locator(".topbar")
  175 |       .getByRole("combobox", { name: locationName, exact: true })
  176 |       .locator("bdi")
  177 |       .innerText()
  178 |   ).trim();
  179 |   const beforeSession = await page.evaluate((key) => {
  180 |     const raw = sessionStorage.getItem(key);
  181 |     return raw ? JSON.parse(raw).session_id : null;
  182 |   }, AUTH_IDENTITY_KEY);
  183 |   await (await openShellAction(page, fa ? "دمو" : "Demo")).click();
  184 |   const resetName = fa ? "بازنشانی دمو" : "Reset demo";
  185 |   await page.getByRole("menuitem", { name: resetName, exact: true }).click();
  186 |   await page
  187 |     .getByRole("dialog", { name: resetName, exact: true })
  188 |     .getByRole("button", { name: resetName, exact: true })
  189 |     .click();
  190 |   // Observe the real reset's new SID without publishing or writing identities.
  191 |   // The dialog closes before its asynchronous transaction finishes.
  192 |   await expect
  193 |     .poll(() =>
  194 |       page.evaluate(
  195 |         ({ key, previous }) => {
  196 |           const raw = sessionStorage.getItem(key);
  197 |           const current = raw ? JSON.parse(raw).session_id : null;
  198 |           return typeof current === "string" && current !== previous;
  199 |         },
  200 |         { key: AUTH_IDENTITY_KEY, previous: beforeSession },
  201 |       ),
  202 |     )
  203 |     .toBe(true);
  204 |   await expect(page.locator(".topbar")).toBeVisible();
  205 |   const current = page
  206 |     .locator(".topbar")
  207 |     .getByRole("combobox", { name: locationName, exact: true });
  208 |   await expect(current).toBeEnabled();
  209 |   if ((await current.locator("bdi").innerText()).trim() !== beforeLocation) {
  210 |     // Restore the caller's selection only when the fresh six-person directory
  211 |     // still permits it. Never switch personas or substitute a first store.
  212 |     await current.click();
  213 |     const permitted = page.getByRole("option", {
  214 |       name: beforeLocation,
  215 |       exact: true,
  216 |     });
  217 |     if (await permitted.count()) {
  218 |       await permitted.click();
  219 |       await expect(current).toBeEnabled();
  220 |     } else {
  221 |       await page.keyboard.press("Escape");
  222 |     }
  223 |   }
  224 | }
  225 | 
  226 | export async function visitPage(page: Page, label: string) {
  227 |   // Wait for the real route projection before choosing a compact sidebar group.
```