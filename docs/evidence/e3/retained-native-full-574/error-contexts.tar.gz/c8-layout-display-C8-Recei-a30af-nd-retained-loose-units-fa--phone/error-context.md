# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: c8-layout-display.spec.ts >> C8 Received uses whole cases and retained loose units (fa)
- Location: tests/c8-layout-display.spec.ts:180:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('.received-table tbody > tr[data-row-href="#invoices?id=a2-fixture%3AGG-11879"]').filter({ hasText: 'Dried Red Kidney Beans 900 g' }).locator('.table-details-toggle')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('.received-table tbody > tr[data-row-href="#invoices?id=a2-fixture%3AGG-11879"]').filter({ hasText: 'Dried Red Kidney Beans 900 g' }).locator('.table-details-toggle') with timeout 5000ms
  - waiting for locator('.received-table tbody > tr[data-row-href="#invoices?id=a2-fixture%3AGG-11879"]').filter({ hasText: 'Dried Red Kidney Beans 900 g' }).locator('.table-details-toggle')

```

```yaml
- link "رفتن به محتوا":
  - /url: "#main-content"
- banner:
  - button "باز کردن منو"
  - combobox "مکان": نورث یورک
  - button "اعلان‌ها، 5 خوانده‌نشده": "5"
  - button "منوی کاربر"
  - button "بیشتر"
- main:
  - heading "دریافت‌شده‌ها" [level=1]
  - paragraph: چه کالایی، کجا و چه زمانی دریافت شد.
  - textbox "جستجوی دریافت‌شده‌ها":
    - /placeholder: جستجوی کالا، فاکتور یا تأمین‌کننده
  - button "بازه تاریخ"
  - combobox "تأمین‌کننده": همه تأمین‌کنندگان
  - combobox "کالا": همه کالاها
  - button "پاک کردن فیلترها"
  - text: 20 تحویل
  - button "ستون‌ها"
  - table:
    - rowgroup:
      - row "باقالا کنسرو شده ۴۰۰ گرمی Canned Fava Beans 400 g 2 کارتن (24 واحد) فاکتور FV-20390 نورث یورک Fresh Valley Foods 2026-10-14":
        - cell "باقالا کنسرو شده ۴۰۰ گرمی Canned Fava Beans 400 g":
          - strong: باقالا کنسرو شده ۴۰۰ گرمی
          - text: Canned Fava Beans 400 g
        - cell "2 کارتن (24 واحد)"
        - cell "فاکتور FV-20390":
          - link "فاکتور FV-20390":
            - /url: "#invoices?id=a2-fixture%3AFV-20390"
        - cell "نورث یورک Fresh Valley Foods 2026-10-14"
      - row "سماق ۱۰۰ گرمی Ground Sumac 100 g 1 کارتن (12 واحد) فاکتور FV-20390 نورث یورک Fresh Valley Foods 2026-10-14":
        - cell "سماق ۱۰۰ گرمی Ground Sumac 100 g":
          - strong: سماق ۱۰۰ گرمی
          - text: Ground Sumac 100 g
        - cell "1 کارتن (12 واحد)"
        - cell "فاکتور FV-20390":
          - link "فاکتور FV-20390":
            - /url: "#invoices?id=a2-fixture%3AFV-20390"
        - cell "نورث یورک Fresh Valley Foods 2026-10-14"
      - row "نان لواش ۵۰۰ گرمی Lavash Bread 500 g 2 کارتن (20 واحد) فاکتور FV-20390 نورث یورک Fresh Valley Foods 2026-10-14":
        - cell "نان لواش ۵۰۰ گرمی Lavash Bread 500 g":
          - strong: نان لواش ۵۰۰ گرمی
          - text: Lavash Bread 500 g
        - cell "2 کارتن (20 واحد)"
        - cell "فاکتور FV-20390":
          - link "فاکتور FV-20390":
            - /url: "#invoices?id=a2-fixture%3AFV-20390"
        - cell "نورث یورک Fresh Valley Foods 2026-10-14"
      - row "آب آلبالو ۱ لیتری Sour Cherry Juice 1 L 3 کارتن (36 واحد) فاکتور FV-20390 نورث یورک Fresh Valley Foods 2026-10-14":
        - cell "آب آلبالو ۱ لیتری Sour Cherry Juice 1 L":
          - strong: آب آلبالو ۱ لیتری
          - text: Sour Cherry Juice 1 L
        - cell "3 کارتن (36 واحد)"
        - cell "فاکتور FV-20390":
          - link "فاکتور FV-20390":
            - /url: "#invoices?id=a2-fixture%3AFV-20390"
        - cell "نورث یورک Fresh Valley Foods 2026-10-14"
      - row "زرشک خشک ۱۰۰ گرمی Dried Barberries 100 g 1 کارتن (6 واحد) فاکتور FV-20390 نورث یورک Fresh Valley Foods 2026-10-14":
        - cell "زرشک خشک ۱۰۰ گرمی Dried Barberries 100 g":
          - strong: زرشک خشک ۱۰۰ گرمی
          - text: Dried Barberries 100 g
        - cell "1 کارتن (6 واحد)"
        - cell "فاکتور FV-20390":
          - link "فاکتور FV-20390":
            - /url: "#invoices?id=a2-fixture%3AFV-20390"
        - cell "نورث یورک Fresh Valley Foods 2026-10-14"
      - row "چیپس سیب‌زمینی ۱۵۰ گرمی Potato Chips 150 g 1 کارتن (12 واحد) فاکتور FV-20390 نورث یورک Fresh Valley Foods 2026-10-14":
        - cell "چیپس سیب‌زمینی ۱۵۰ گرمی Potato Chips 150 g":
          - strong: چیپس سیب‌زمینی ۱۵۰ گرمی
          - text: Potato Chips 150 g
        - cell "1 کارتن (12 واحد)"
        - cell "فاکتور FV-20390":
          - link "فاکتور FV-20390":
            - /url: "#invoices?id=a2-fixture%3AFV-20390"
        - cell "نورث یورک Fresh Valley Foods 2026-10-14"
      - row "برنج باسماتی ۴٫۵ کیلوگرمی Basmati Rice 4.5 kg 1 واحد فاکتور GG-11842 نورث یورک Golden Grain Distributors 2026-10-12":
        - cell "برنج باسماتی ۴٫۵ کیلوگرمی Basmati Rice 4.5 kg":
          - strong: برنج باسماتی ۴٫۵ کیلوگرمی
          - text: Basmati Rice 4.5 kg
        - cell "1 واحد"
        - cell "فاکتور GG-11842":
          - link "فاکتور GG-11842":
            - /url: "#invoices?id=a2-fixture%3AGG-11842"
        - cell "نورث یورک Golden Grain Distributors 2026-10-12"
      - row "برنج باسماتی ۴٫۵ کیلوگرمی Basmati Rice 4.5 kg 7 کارتن + 2 واحد (30 واحد) فاکتور GG-11879 نورث یورک Golden Grain Distributors 2026-10-10":
        - cell "برنج باسماتی ۴٫۵ کیلوگرمی Basmati Rice 4.5 kg":
          - strong: برنج باسماتی ۴٫۵ کیلوگرمی
          - text: Basmati Rice 4.5 kg
        - cell "7 کارتن + 2 واحد (30 واحد)"
        - cell "فاکتور GG-11879":
          - link "فاکتور GG-11879":
            - /url: "#invoices?id=a2-fixture%3AGG-11879"
        - cell "نورث یورک Golden Grain Distributors 2026-10-10"
      - row "لوبیا قرمز ۹۰۰ گرمی Dried Red Kidney Beans 900 g 3 کارتن + 4 واحد (40 واحد) فاکتور GG-11879 نورث یورک Golden Grain Distributors 2026-10-10":
        - cell "لوبیا قرمز ۹۰۰ گرمی Dried Red Kidney Beans 900 g":
          - strong: لوبیا قرمز ۹۰۰ گرمی
          - text: Dried Red Kidney Beans 900 g
        - cell "3 کارتن + 4 واحد (40 واحد)"
        - cell "فاکتور GG-11879":
          - link "فاکتور GG-11879":
            - /url: "#invoices?id=a2-fixture%3AGG-11879"
        - cell "نورث یورک Golden Grain Distributors 2026-10-10"
      - row "چای سیاه ۴۵۰ گرمی Black Tea 450 g 2 کارتن + 4 واحد (16 واحد) فاکتور SB-7862 نورث یورک Sunrise Beverages 2026-10-06":
        - cell "چای سیاه ۴۵۰ گرمی Black Tea 450 g":
          - strong: چای سیاه ۴۵۰ گرمی
          - text: Black Tea 450 g
        - cell "2 کارتن + 4 واحد (16 واحد)"
        - cell "فاکتور SB-7862":
          - link "فاکتور SB-7862":
            - /url: "#invoices?id=a2-fixture%3ASB-7862"
        - cell "نورث یورک Sunrise Beverages 2026-10-06"
      - row "نوشابه میوه‌ای بسته ۶ عددی Fruit Soda 6-pack 2 کارتن (12 واحد) فاکتور SB-7862 نورث یورک Sunrise Beverages 2026-10-06":
        - cell "نوشابه میوه‌ای بسته ۶ عددی Fruit Soda 6-pack":
          - strong: نوشابه میوه‌ای بسته ۶ عددی
          - text: Fruit Soda 6-pack
        - cell "2 کارتن (12 واحد)"
        - cell "فاکتور SB-7862":
          - link "فاکتور SB-7862":
            - /url: "#invoices?id=a2-fixture%3ASB-7862"
        - cell "نورث یورک Sunrise Beverages 2026-10-06"
      - row "چای سیاه ۴۵۰ گرمی Black Tea 450 g 1 کارتن (6 واحد) فاکتور SB-7848 نورث یورک Sunrise Beverages 2026-10-05":
        - cell "چای سیاه ۴۵۰ گرمی Black Tea 450 g":
          - strong: چای سیاه ۴۵۰ گرمی
          - text: Black Tea 450 g
        - cell "1 کارتن (6 واحد)"
        - cell "فاکتور SB-7848":
          - link "فاکتور SB-7848":
            - /url: "#invoices?id=a2-fixture%3ASB-7848"
        - cell "نورث یورک Sunrise Beverages 2026-10-05"
      - row "ست استکان چای (۶ عددی) Tea Glass Set (6 pcs) 10 کارتن (20 واحد) فاکتور HW-4936 نورث یورک HomeWare Imports 2026-09-24":
        - cell "ست استکان چای (۶ عددی) Tea Glass Set (6 pcs)":
          - strong: ست استکان چای (۶ عددی)
          - text: Tea Glass Set (6 pcs)
        - cell "10 کارتن (20 واحد)"
        - cell "فاکتور HW-4936":
          - link "فاکتور HW-4936":
            - /url: "#invoices?id=a2-fixture%3AHW-4936"
        - cell "نورث یورک HomeWare Imports 2026-09-24"
      - row "قابلمه استیل ۲۴ سانتی‌متری Stainless Steel Pot 24 cm 10 کارتن (30 واحد) فاکتور HW-4936 نورث یورک HomeWare Imports 2026-09-24":
        - cell "قابلمه استیل ۲۴ سانتی‌متری Stainless Steel Pot 24 cm":
          - strong: قابلمه استیل ۲۴ سانتی‌متری
          - text: Stainless Steel Pot 24 cm
        - cell "10 کارتن (30 واحد)"
        - cell "فاکتور HW-4936":
          - link "فاکتور HW-4936":
            - /url: "#invoices?id=a2-fixture%3AHW-4936"
        - cell "نورث یورک HomeWare Imports 2026-09-24"
      - row "پلوپز ۱٫۸ لیتری Rice Cooker 1.8 L 20 واحد فاکتور HW-4936 نورث یورک HomeWare Imports 2026-09-24":
        - cell "پلوپز ۱٫۸ لیتری Rice Cooker 1.8 L":
          - strong: پلوپز ۱٫۸ لیتری
          - text: Rice Cooker 1.8 L
        - cell "20 واحد"
        - cell "فاکتور HW-4936":
          - link "فاکتور HW-4936":
            - /url: "#invoices?id=a2-fixture%3AHW-4936"
        - cell "نورث یورک HomeWare Imports 2026-09-24"
      - row "اسفنج ظرفشویی بسته ۳ عددی Kitchen Sponge 3-pack 5 کارتن (20 واحد) فاکتور HW-4936 نورث یورک HomeWare Imports 2026-09-24":
        - cell "اسفنج ظرفشویی بسته ۳ عددی Kitchen Sponge 3-pack":
          - strong: اسفنج ظرفشویی بسته ۳ عددی
          - text: Kitchen Sponge 3-pack
        - cell "5 کارتن (20 واحد)"
        - cell "فاکتور HW-4936":
          - link "فاکتور HW-4936":
            - /url: "#invoices?id=a2-fixture%3AHW-4936"
        - cell "نورث یورک HomeWare Imports 2026-09-24"
      - row "آب آلبالو ۱ لیتری Sour Cherry Juice 1 L 1 کارتن (12 واحد) فاکتور FV-20296 نورث یورک Fresh Valley Foods 2026-09-21":
        - cell "آب آلبالو ۱ لیتری Sour Cherry Juice 1 L":
          - strong: آب آلبالو ۱ لیتری
          - text: Sour Cherry Juice 1 L
        - cell "1 کارتن (12 واحد)"
        - cell "فاکتور FV-20296":
          - link "فاکتور FV-20296":
            - /url: "#invoices?id=a2-fixture%3AFV-20296"
        - cell "نورث یورک Fresh Valley Foods 2026-09-21"
      - row "سماق ۱۰۰ گرمی Ground Sumac 100 g 1 کارتن (12 واحد) فاکتور FV-20296 نورث یورک Fresh Valley Foods 2026-09-21":
        - cell "سماق ۱۰۰ گرمی Ground Sumac 100 g":
          - strong: سماق ۱۰۰ گرمی
          - text: Ground Sumac 100 g
        - cell "1 کارتن (12 واحد)"
        - cell "فاکتور FV-20296":
          - link "فاکتور FV-20296":
            - /url: "#invoices?id=a2-fixture%3AFV-20296"
        - cell "نورث یورک Fresh Valley Foods 2026-09-21"
      - row "برنج باسماتی ۴٫۵ کیلوگرمی Basmati Rice 4.5 kg 5 کارتن (20 واحد) فاکتور GG-11842 نورث یورک Golden Grain Distributors 2026-09-10":
        - cell "برنج باسماتی ۴٫۵ کیلوگرمی Basmati Rice 4.5 kg":
          - strong: برنج باسماتی ۴٫۵ کیلوگرمی
          - text: Basmati Rice 4.5 kg
        - cell "5 کارتن (20 واحد)"
        - cell "فاکتور GG-11842":
          - link "فاکتور GG-11842":
            - /url: "#invoices?id=a2-fixture%3AGG-11842"
        - cell "نورث یورک Golden Grain Distributors 2026-09-10"
      - row "لوبیا قرمز ۹۰۰ گرمی Dried Red Kidney Beans 900 g 1 کارتن (12 واحد) فاکتور GG-11794 نورث یورک Golden Grain Distributors 2026-08-24":
        - cell "لوبیا قرمز ۹۰۰ گرمی Dried Red Kidney Beans 900 g":
          - strong: لوبیا قرمز ۹۰۰ گرمی
          - text: Dried Red Kidney Beans 900 g
        - cell "1 کارتن (12 واحد)"
        - cell "فاکتور GG-11794":
          - link "فاکتور GG-11794":
            - /url: "#invoices?id=a2-fixture%3AGG-11794"
        - cell "نورث یورک Golden Grain Distributors 2026-08-24"
```

# Test source

```ts
  1   | import { readCanonicalBusinessEvidence } from "./business-evidence";
  2   | import { createHash } from "node:crypto";
  3   | import { fileURLToPath } from "node:url";
  4   | import { expect, test, type Locator, type Page } from "@playwright/test";
  5   | import demo from "../../seed/demo-data.json" with { type: "json" };
  6   | import type { DemoState } from "../src/types";
  7   | import {
  8   |   invoiceImage,
  9   |   openInvoiceUpload,
  10  |   setLanguage,
  11  |   signIn,
  12  |   uploadInvoice,
  13  | } from "./helpers";
  14  | 
  15  | const copy = (lang: "en" | "fa", en: string, fa: string) =>
  16  |   lang === "fa" ? fa : en;
  17  | const saved = (page: Page): Promise<DemoState> =>
  18  |   readCanonicalBusinessEvidence(page).then((canonicalState) =>
  19  |     JSON.parse(JSON.stringify(canonicalState)!),
  20  |   );
  21  | 
  22  | async function retainedOriginalHash(page: Page, reference: string) {
  23  |   const bytes = await page.evaluate(async (id) => {
  24  |     const db = await new Promise<IDBDatabase>((resolve, reject) => {
  25  |       const request = indexedDB.open("supermarket-prototype-files-v1", 1);
  26  |       request.onsuccess = () => resolve(request.result);
  27  |       request.onerror = () => reject(request.error);
  28  |     });
  29  |     try {
  30  |       const record = await new Promise<{ source: Blob }>((resolve, reject) => {
  31  |         const request = db
  32  |           .transaction("files", "readonly")
  33  |           .objectStore("files")
  34  |           .get(id);
  35  |         request.onsuccess = () => resolve(request.result);
  36  |         request.onerror = () => reject(request.error);
  37  |       });
  38  |       if (!(record?.source instanceof Blob))
  39  |         throw new Error("Original evidence is missing");
  40  |       return Array.from(new Uint8Array(await record.source.arrayBuffer()));
  41  |     } finally {
  42  |       db.close();
  43  |     }
  44  |   }, reference);
  45  |   return createHash("sha256").update(Buffer.from(bytes)).digest("hex");
  46  | }
  47  | 
  48  | async function quantityEvidence(page: Page, row: Locator) {
  49  |   const direct = row.locator('td[data-column-key="quantity"]');
  50  |   if (await direct.isVisible()) return direct;
  51  |   const disclosure = row.locator(".table-details-toggle");
> 52  |   await expect(disclosure).toBeVisible();
      |                            ^ Error: expect(locator).toBeVisible() failed
  53  |   const id = await disclosure.getAttribute("aria-controls");
  54  |   await disclosure.click();
  55  |   const details = page.locator(`[id=${JSON.stringify(id)}]`);
  56  |   await expect(details).toBeVisible();
  57  |   return details;
  58  | }
  59  | 
  60  | for (const language of ["en", "fa"] as const) {
  61  |   test(`C8 unread original has Continue and exact durable evidence (${language})`, async ({
  62  |     page,
  63  |   }) => {
  64  |     await signIn(page, "Supervisor");
  65  |     await page.goto("/#invoices");
  66  |     await setLanguage(page, language);
  67  |     const before = (await saved(page)).invoice;
  68  |     expect(before.status).toBe("empty");
  69  |     expect(before.file_data).toMatch(/^idb-file:v1:/);
  70  |     const originalHash = await retainedOriginalHash(page, before.file_data!);
  71  |     const drafts = page.locator(".invoice-saved-drafts");
  72  |     await expect(drafts).toContainText(
  73  |       copy(language, "Not read yet", "هنوز خوانده نشده"),
  74  |     );
  75  |     await expect(
  76  |       page
  77  |         .getByText(before.file_name!, { exact: true })
  78  |         .filter({ visible: true }),
  79  |     ).toHaveCount(1);
  80  |     await expect(
  81  |       page.getByText(
  82  |         copy(
  83  |           language,
  84  |           "No drafts. Start a new invoice.",
  85  |           "پیش‌نویسی نیست. فاکتور جدید شروع کنید.",
  86  |         ),
  87  |         { exact: true },
  88  |       ),
  89  |     ).toHaveCount(0);
  90  |     await drafts
  91  |       .getByRole("button", {
  92  |         name: copy(language, "Continue", "ادامه"),
  93  |         exact: true,
  94  |       })
  95  |       .click();
  96  |     await expect(page.locator(".invoice-reading-state")).toBeVisible();
  97  |     await expect(
  98  |       page.getByRole("heading", {
  99  |         name: copy(language, "Review invoice lines", "بررسی ردیف‌های فاکتور"),
  100 |         exact: true,
  101 |       }),
  102 |     ).toBeVisible({ timeout: 10000 });
  103 |     await expect
  104 |       .poll(async () => (await saved(page)).invoice.status)
  105 |       .toBe("review");
  106 |     const after = (await saved(page)).invoice;
  107 |     expect(after.id).toBe(before.id);
  108 |     expect(after.file_data).toBe(before.file_data);
  109 |     expect(after.lines).toEqual(before.lines);
  110 |     expect(await retainedOriginalHash(page, after.file_data!)).toBe(
  111 |       originalHash,
  112 |     );
  113 |     await expect(
  114 |       page
  115 |         .getByText(before.file_name!, { exact: true })
  116 |         .filter({ visible: true }),
  117 |     ).toHaveCount(1);
  118 |     await page.reload();
  119 |     await expect(page.locator(".invoice-original-media img")).toBeVisible();
  120 |     expect(await retainedOriginalHash(page, after.file_data!)).toBe(
  121 |       originalHash,
  122 |     );
  123 |   });
  124 | 
  125 |   test(`C8 invoice read-only costs preserve four decimals without posting money (${language})`, async ({
  126 |     page,
  127 |   }) => {
  128 |     await signIn(page, "Supervisor");
  129 |     await page.goto("/#invoices");
  130 |     await uploadInvoice(page);
  131 |     await expect
  132 |       .poll(async () => (await saved(page)).invoice.file_data)
  133 |       .toMatch(/^idb-file:v1:/);
  134 |     const before = await saved(page);
  135 |     const originalHash = await retainedOriginalHash(
  136 |       page,
  137 |       before.invoice.file_data!,
  138 |     );
  139 |     expect(originalHash).toBe(
  140 |       createHash("sha256").update(invoiceImage.buffer).digest("hex"),
  141 |     );
  142 |     const line = page.locator(".invoice-line").first();
  143 |     await line
  144 |       .getByLabel("Unit cost before tax", { exact: true })
  145 |       .fill("1.5525");
  146 |     await line.getByRole("button", { name: "No", exact: true }).click();
  147 |     await line
  148 |       .getByRole("checkbox", { name: "Confirm this invoice line", exact: true })
  149 |       .click();
  150 |     await expect(line).toHaveAttribute("data-expanded", "false");
  151 |     await setLanguage(page, language);
  152 |     const displayedCost = line
```