# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: receiving-c.spec.ts >> a worker retargets their own invoice to Warehouse without gaining Warehouse access
- Location: tests/receiving-c.spec.ts:42:1

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  getByRole('combobox', { name: 'Location', exact: true })
Expected: 0
Received: 1
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" getByRole('combobox', { name: 'Location', exact: true }) with timeout 5000ms
  - waiting for getByRole('combobox', { name: 'Location', exact: true })
    14 × locator resolved to 1 element
       - unexpected value "1"

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - complementary "Main menu" [ref=e5]:
    - generic [ref=e6]:
      - img "Super Arzon" [ref=e9]
      - generic [ref=e10]: Super Arzon
    - navigation "Pages" [ref=e11]:
      - generic [ref=e12]:
        - button "Daily" [expanded] [ref=e13] [cursor=pointer]
        - generic [ref=e17]:
          - link "Lookup" [ref=e18] [cursor=pointer]:
            - /url: "#lookup"
          - link "Invoices" [ref=e23] [cursor=pointer]:
            - /url: "#invoices"
          - link "Received" [ref=e28] [cursor=pointer]:
            - /url: "#received"
          - link "Returns" [ref=e35] [cursor=pointer]:
            - /url: "#returns"
          - link "Price updates" [ref=e40] [cursor=pointer]:
            - /url: "#price-updates"
          - link "Labels" [ref=e46] [cursor=pointer]:
            - /url: "#labels"
          - link "Date tracking" [ref=e51] [cursor=pointer]:
            - /url: "#expiry"
          - link "Notes" [ref=e56] [cursor=pointer]:
            - /url: "#notes"
          - link "Branch requests" [ref=e60] [cursor=pointer]:
            - /url: "#requests"
      - button "Catalog" [ref=e66] [cursor=pointer]
      - button "Manager" [ref=e71] [cursor=pointer]
      - button "Admin" [ref=e76] [cursor=pointer]
    - button "User menu" [ref=e81] [cursor=pointer]:
      - generic [ref=e82]:
        - generic [aria-hidden] [ref=e83]: DN
        - generic [ref=e84]:
          - strong [ref=e85]: Demo North York Floor Worker
          - generic [ref=e86]: Floor Worker
  - generic [ref=e87]:
    - banner [ref=e88]:
      - button "Collapse sidebar" [expanded] [ref=e89] [cursor=pointer]
      - navigation "Breadcrumbs" [ref=e93]:
        - link "North York" [ref=e94] [cursor=pointer]:
          - /url: "#invoices"
        - link "Received" [ref=e97] [cursor=pointer]:
          - /url: "#received"
      - search [ref=e98]:
        - textbox "Search all products" [ref=e102]:
          - /placeholder: Search products
        - generic [aria-hidden] [ref=e103]: /
      - combobox "Location" [ref=e104] [cursor=pointer]:
        - generic [ref=e109]: North York
      - button "Switch to Persian" [ref=e112] [cursor=pointer]: فا
      - button "Switch to dark theme" [ref=e113] [cursor=pointer]
      - button "Comfortable text size" [ref=e116] [cursor=pointer]:
        - generic [aria-hidden] [ref=e117]: Aa
      - button "Notifications, 0 unread" [ref=e118] [cursor=pointer]
      - button "Demo" [ref=e123] [cursor=pointer]
    - main [ref=e126]:
      - generic [ref=e128]:
        - heading "Received" [level=1] [ref=e129]
        - paragraph [ref=e130]: What came in, where and when.
      - generic [ref=e131]:
        - generic "Received filters" [ref=e132]:
          - textbox "Search Received" [ref=e137]:
            - /placeholder: Search products, invoices or suppliers
          - button "Date range" [ref=e138] [cursor=pointer]
          - combobox "Supplier" [ref=e141] [cursor=pointer]:
            - generic [ref=e142]: All suppliers
          - combobox "Product" [ref=e145] [cursor=pointer]:
            - generic [ref=e146]: All products
          - button "Clear filters" [ref=e149] [cursor=pointer]
          - generic [ref=e151]:
            - generic [ref=e152]: 20 deliveries
            - button "Columns" [ref=e153] [cursor=pointer]
        - table [ref=e157]:
          - rowgroup [ref=e164]:
            - row [ref=e165]:
              - columnheader "Product" [ref=e166]
              - columnheader "Cases and units" [ref=e167]
              - columnheader "Invoice number" [ref=e168]
              - columnheader "Date" [ref=e169]
              - columnheader "Action" [ref=e170]
          - rowgroup [ref=e171]:
            - row [ref=e172] [cursor=pointer]:
              - cell "Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی" [ref=e173]:
                - generic [ref=e175]:
                  - strong [ref=e176]:
                    - generic [ref=e177]:
                      - text: Canned Fava Beans
                      - generic [ref=e178]: 400 g
                  - generic [ref=e180]:
                    - text: باقالا کنسرو شده
                    - generic [ref=e181]: ۴۰۰ گرمی
              - cell "2 cases (24 units)" [ref=e182]:
                - text: 2 cases
                - generic [ref=e183]: (24 units)
              - cell [ref=e184]:
                - link "FV-20390" [ref=e185]:
                  - /url: "#invoices?id=a2-fixture%3AFV-20390"
              - cell "2026-10-14" [ref=e187]
              - cell [ref=e188]:
                - generic [ref=e189]:
                  - link "Invoice FV-20390" [ref=e190]:
                    - /url: "#invoices?id=a2-fixture%3AFV-20390"
                  - button "Show details" [ref=e193]
            - row [ref=e196] [cursor=pointer]:
              - cell "Ground Sumac 100 g سماق ۱۰۰ گرمی" [ref=e197]:
                - generic [ref=e199]:
                  - strong [ref=e200]:
                    - generic [ref=e201]:
                      - text: Ground Sumac
                      - generic [ref=e202]: 100 g
                  - generic [ref=e204]:
                    - text: سماق
                    - generic [ref=e205]: ۱۰۰ گرمی
              - cell "1 case (12 units)" [ref=e206]:
                - text: 1 case
                - generic [ref=e207]: (12 units)
              - cell [ref=e208]:
                - link "FV-20390" [ref=e209]:
                  - /url: "#invoices?id=a2-fixture%3AFV-20390"
              - cell "2026-10-14" [ref=e211]
              - cell [ref=e212]:
                - generic [ref=e213]:
                  - link "Invoice FV-20390" [ref=e214]:
                    - /url: "#invoices?id=a2-fixture%3AFV-20390"
                  - button "Show details" [ref=e217]
            - row [ref=e220] [cursor=pointer]:
              - cell "Lavash Bread 500 g نان لواش ۵۰۰ گرمی" [ref=e221]:
                - generic [ref=e223]:
                  - strong [ref=e224]:
                    - generic [ref=e225]:
                      - text: Lavash Bread
                      - generic [ref=e226]: 500 g
                  - generic [ref=e228]:
                    - text: نان لواش
                    - generic [ref=e229]: ۵۰۰ گرمی
              - cell "2 cases (20 units)" [ref=e230]:
                - text: 2 cases
                - generic [ref=e231]: (20 units)
              - cell [ref=e232]:
                - link "FV-20390" [ref=e233]:
                  - /url: "#invoices?id=a2-fixture%3AFV-20390"
              - cell "2026-10-14" [ref=e235]
              - cell [ref=e236]:
                - generic [ref=e237]:
                  - link "Invoice FV-20390" [ref=e238]:
                    - /url: "#invoices?id=a2-fixture%3AFV-20390"
                  - button "Show details" [ref=e241]
            - row [ref=e244] [cursor=pointer]:
              - cell "Sour Cherry Juice 1 L آب آلبالو ۱ لیتری" [ref=e245]:
                - generic [ref=e247]:
                  - strong [ref=e248]:
                    - generic [ref=e249]:
                      - text: Sour Cherry Juice
                      - generic [ref=e250]: 1 L
                  - generic [ref=e252]:
                    - text: آب آلبالو
                    - generic [ref=e253]: ۱ لیتری
              - cell "3 cases (36 units)" [ref=e254]:
                - text: 3 cases
                - generic [ref=e255]: (36 units)
              - cell [ref=e256]:
                - link "FV-20390" [ref=e257]:
                  - /url: "#invoices?id=a2-fixture%3AFV-20390"
              - cell "2026-10-14" [ref=e259]
              - cell [ref=e260]:
                - generic [ref=e261]:
                  - link "Invoice FV-20390" [ref=e262]:
                    - /url: "#invoices?id=a2-fixture%3AFV-20390"
                  - button "Show details" [ref=e265]
            - row [ref=e268] [cursor=pointer]:
              - cell "Dried Barberries 100 g زرشک خشک ۱۰۰ گرمی" [ref=e269]:
                - generic [ref=e271]:
                  - strong [ref=e272]:
                    - generic [ref=e273]:
                      - text: Dried Barberries
                      - generic [ref=e274]: 100 g
                  - generic [ref=e276]:
                    - text: زرشک خشک
                    - generic [ref=e277]: ۱۰۰ گرمی
              - cell "1 case (6 units)" [ref=e278]:
                - text: 1 case
                - generic [ref=e279]: (6 units)
              - cell [ref=e280]:
                - link "FV-20390" [ref=e281]:
                  - /url: "#invoices?id=a2-fixture%3AFV-20390"
              - cell "2026-10-14" [ref=e283]
              - cell [ref=e284]:
                - generic [ref=e285]:
                  - link "Invoice FV-20390" [ref=e286]:
                    - /url: "#invoices?id=a2-fixture%3AFV-20390"
                  - button "Show details" [ref=e289]
            - row [ref=e292] [cursor=pointer]:
              - cell "Potato Chips 150 g چیپس سیب‌زمینی ۱۵۰ گرمی" [ref=e293]:
                - generic [ref=e295]:
                  - strong [ref=e296]:
                    - generic [ref=e297]:
                      - text: Potato Chips
                      - generic [ref=e298]: 150 g
                  - generic [ref=e300]:
                    - text: چیپس سیب‌زمینی
                    - generic [ref=e301]: ۱۵۰ گرمی
              - cell "1 case (12 units)" [ref=e302]:
                - text: 1 case
                - generic [ref=e303]: (12 units)
              - cell [ref=e304]:
                - link "FV-20390" [ref=e305]:
                  - /url: "#invoices?id=a2-fixture%3AFV-20390"
              - cell "2026-10-14" [ref=e307]
              - cell [ref=e308]:
                - generic [ref=e309]:
                  - link "Invoice FV-20390" [ref=e310]:
                    - /url: "#invoices?id=a2-fixture%3AFV-20390"
                  - button "Show details" [ref=e313]
            - row [ref=e316] [cursor=pointer]:
              - cell "Basmati Rice 4.5 kg برنج باسماتی ۴٫۵ کیلوگرمی" [ref=e317]:
                - generic [ref=e319]:
                  - strong [ref=e320]:
                    - generic [ref=e321]:
                      - text: Basmati Rice
                      - generic [ref=e322]: 4.5 kg
                  - generic [ref=e324]:
                    - text: برنج باسماتی
                    - generic [ref=e325]: ۴٫۵ کیلوگرمی
              - cell "1 unit" [ref=e326]
              - cell [ref=e327]:
                - link "GG-11842" [ref=e328]:
                  - /url: "#invoices?id=a2-fixture%3AGG-11842"
              - cell "2026-10-12" [ref=e330]
              - cell [ref=e331]:
                - generic [ref=e332]:
                  - link "Invoice GG-11842" [ref=e333]:
                    - /url: "#invoices?id=a2-fixture%3AGG-11842"
                  - button "Show details" [ref=e336]
            - row [ref=e339] [cursor=pointer]:
              - cell "Basmati Rice 4.5 kg برنج باسماتی ۴٫۵ کیلوگرمی" [ref=e340]:
                - generic [ref=e342]:
                  - strong [ref=e343]:
                    - generic [ref=e344]:
                      - text: Basmati Rice
                      - generic [ref=e345]: 4.5 kg
                  - generic [ref=e347]:
                    - text: برنج باسماتی
                    - generic [ref=e348]: ۴٫۵ کیلوگرمی
              - cell "7 cases + 2 units (30 units)" [ref=e349]:
                - text: 7 cases + 2 units
                - generic [ref=e350]: (30 units)
              - cell [ref=e351]:
                - link "GG-11879" [ref=e352]:
                  - /url: "#invoices?id=a2-fixture%3AGG-11879"
              - cell "2026-10-10" [ref=e354]
              - cell [ref=e355]:
                - generic [ref=e356]:
                  - link "Invoice GG-11879" [ref=e357]:
                    - /url: "#invoices?id=a2-fixture%3AGG-11879"
                  - button "Show details" [ref=e360]
            - row [ref=e363] [cursor=pointer]:
              - cell "Dried Red Kidney Beans 900 g لوبیا قرمز ۹۰۰ گرمی" [ref=e364]:
                - generic [ref=e366]:
                  - strong [ref=e367]:
                    - generic [ref=e368]:
                      - text: Dried Red Kidney Beans
                      - generic [ref=e369]: 900 g
                  - generic [ref=e371]:
                    - text: لوبیا قرمز
                    - generic [ref=e372]: ۹۰۰ گرمی
              - cell "3 cases + 4 units (40 units)" [ref=e373]:
                - text: 3 cases + 4 units
                - generic [ref=e374]: (40 units)
              - cell [ref=e375]:
                - link "GG-11879" [ref=e376]:
                  - /url: "#invoices?id=a2-fixture%3AGG-11879"
              - cell "2026-10-10" [ref=e378]
              - cell [ref=e379]:
                - generic [ref=e380]:
                  - link "Invoice GG-11879" [ref=e381]:
                    - /url: "#invoices?id=a2-fixture%3AGG-11879"
                  - button "Show details" [ref=e384]
            - row [ref=e387] [cursor=pointer]:
              - cell "Black Tea 450 g چای سیاه ۴۵۰ گرمی" [ref=e388]:
                - generic [ref=e390]:
                  - strong [ref=e391]:
                    - generic [ref=e392]:
                      - text: Black Tea
                      - generic [ref=e393]: 450 g
                  - generic [ref=e395]:
                    - text: چای سیاه
                    - generic [ref=e396]: ۴۵۰ گرمی
              - cell "2 cases + 4 units (16 units)" [ref=e397]:
                - text: 2 cases + 4 units
                - generic [ref=e398]: (16 units)
              - cell [ref=e399]:
                - link "SB-7862" [ref=e400]:
                  - /url: "#invoices?id=a2-fixture%3ASB-7862"
              - cell "2026-10-06" [ref=e402]
              - cell [ref=e403]:
                - generic [ref=e404]:
                  - link "Invoice SB-7862" [ref=e405]:
                    - /url: "#invoices?id=a2-fixture%3ASB-7862"
                  - button "Show details" [ref=e408]
            - row [ref=e411] [cursor=pointer]:
              - cell "Fruit Soda 6-pack نوشابه میوه‌ای بسته ۶ عددی" [ref=e412]:
                - generic [ref=e414]:
                  - strong [ref=e415]: Fruit Soda 6-pack
                  - generic [ref=e416]: نوشابه میوه‌ای بسته ۶ عددی
              - cell "2 cases (12 units)" [ref=e417]:
                - text: 2 cases
                - generic [ref=e418]: (12 units)
              - cell [ref=e419]:
                - link "SB-7862" [ref=e420]:
                  - /url: "#invoices?id=a2-fixture%3ASB-7862"
              - cell "2026-10-06" [ref=e422]
              - cell [ref=e423]:
                - generic [ref=e424]:
                  - link "Invoice SB-7862" [ref=e425]:
                    - /url: "#invoices?id=a2-fixture%3ASB-7862"
                  - button "Show details" [ref=e428]
            - row [ref=e431] [cursor=pointer]:
              - cell "Black Tea 450 g چای سیاه ۴۵۰ گرمی" [ref=e432]:
                - generic [ref=e434]:
                  - strong [ref=e435]:
                    - generic [ref=e436]:
                      - text: Black Tea
                      - generic [ref=e437]: 450 g
                  - generic [ref=e439]:
                    - text: چای سیاه
                    - generic [ref=e440]: ۴۵۰ گرمی
              - cell "1 case (6 units)" [ref=e441]:
                - text: 1 case
                - generic [ref=e442]: (6 units)
              - cell [ref=e443]:
                - link "SB-7848" [ref=e444]:
                  - /url: "#invoices?id=a2-fixture%3ASB-7848"
              - cell "2026-10-05" [ref=e446]
              - cell [ref=e447]:
                - generic [ref=e448]:
                  - link "Invoice SB-7848" [ref=e449]:
                    - /url: "#invoices?id=a2-fixture%3ASB-7848"
                  - button "Show details" [ref=e452]
            - row [ref=e455] [cursor=pointer]:
              - cell "Tea Glass Set (6 pcs) ست استکان چای (۶ عددی)" [ref=e456]:
                - generic [ref=e458]:
                  - strong [ref=e459]: Tea Glass Set (6 pcs)
                  - generic [ref=e460]: ست استکان چای (۶ عددی)
              - cell "10 cases (20 units)" [ref=e461]:
                - text: 10 cases
                - generic [ref=e462]: (20 units)
              - cell [ref=e463]:
                - link "HW-4936" [ref=e464]:
                  - /url: "#invoices?id=a2-fixture%3AHW-4936"
              - cell "2026-09-24" [ref=e466]
              - cell [ref=e467]:
                - generic [ref=e468]:
                  - link "Invoice HW-4936" [ref=e469]:
                    - /url: "#invoices?id=a2-fixture%3AHW-4936"
                  - button "Show details" [ref=e472]
            - row [ref=e475] [cursor=pointer]:
              - cell "Stainless Steel Pot 24 cm قابلمه استیل ۲۴ سانتی‌متری" [ref=e476]:
                - generic [ref=e478]:
                  - strong [ref=e479]: Stainless Steel Pot 24 cm
                  - generic [ref=e480]: قابلمه استیل ۲۴ سانتی‌متری
              - cell "10 cases (30 units)" [ref=e481]:
                - text: 10 cases
                - generic [ref=e482]: (30 units)
              - cell [ref=e483]:
                - link "HW-4936" [ref=e484]:
                  - /url: "#invoices?id=a2-fixture%3AHW-4936"
              - cell "2026-09-24" [ref=e486]
              - cell [ref=e487]:
                - generic [ref=e488]:
                  - link "Invoice HW-4936" [ref=e489]:
                    - /url: "#invoices?id=a2-fixture%3AHW-4936"
                  - button "Show details" [ref=e492]
            - row [ref=e495] [cursor=pointer]:
              - cell "Rice Cooker 1.8 L پلوپز ۱٫۸ لیتری" [ref=e496]:
                - generic [ref=e498]:
                  - strong [ref=e499]:
                    - generic [ref=e500]:
                      - text: Rice Cooker
                      - generic [ref=e501]: 1.8 L
                  - generic [ref=e503]:
                    - text: پلوپز
                    - generic [ref=e504]: ۱٫۸ لیتری
              - cell "20 units" [ref=e505]
              - cell [ref=e506]:
                - link "HW-4936" [ref=e507]:
                  - /url: "#invoices?id=a2-fixture%3AHW-4936"
              - cell "2026-09-24" [ref=e509]
              - cell [ref=e510]:
                - generic [ref=e511]:
                  - link "Invoice HW-4936" [ref=e512]:
                    - /url: "#invoices?id=a2-fixture%3AHW-4936"
                  - button "Show details" [ref=e515]
            - row [ref=e518] [cursor=pointer]:
              - cell "Kitchen Sponge 3-pack اسفنج ظرفشویی بسته ۳ عددی" [ref=e519]:
                - generic [ref=e521]:
                  - strong [ref=e522]: Kitchen Sponge 3-pack
                  - generic [ref=e523]: اسفنج ظرفشویی بسته ۳ عددی
              - cell "5 cases (20 units)" [ref=e524]:
                - text: 5 cases
                - generic [ref=e525]: (20 units)
              - cell [ref=e526]:
                - link "HW-4936" [ref=e527]:
                  - /url: "#invoices?id=a2-fixture%3AHW-4936"
              - cell "2026-09-24" [ref=e529]
              - cell [ref=e530]:
                - generic [ref=e531]:
                  - link "Invoice HW-4936" [ref=e532]:
                    - /url: "#invoices?id=a2-fixture%3AHW-4936"
                  - button "Show details" [ref=e535]
            - row [ref=e538] [cursor=pointer]:
              - cell "Sour Cherry Juice 1 L آب آلبالو ۱ لیتری" [ref=e539]:
                - generic [ref=e541]:
                  - strong [ref=e542]:
                    - generic [ref=e543]:
                      - text: Sour Cherry Juice
                      - generic [ref=e544]: 1 L
                  - generic [ref=e546]:
                    - text: آب آلبالو
                    - generic [ref=e547]: ۱ لیتری
              - cell "1 case (12 units)" [ref=e548]:
                - text: 1 case
                - generic [ref=e549]: (12 units)
              - cell [ref=e550]:
                - link "FV-20296" [ref=e551]:
                  - /url: "#invoices?id=a2-fixture%3AFV-20296"
              - cell "2026-09-21" [ref=e553]
              - cell [ref=e554]:
                - generic [ref=e555]:
                  - link "Invoice FV-20296" [ref=e556]:
                    - /url: "#invoices?id=a2-fixture%3AFV-20296"
                  - button "Show details" [ref=e559]
            - row [ref=e562] [cursor=pointer]:
              - cell "Ground Sumac 100 g سماق ۱۰۰ گرمی" [ref=e563]:
                - generic [ref=e565]:
                  - strong [ref=e566]:
                    - generic [ref=e567]:
                      - text: Ground Sumac
                      - generic [ref=e568]: 100 g
                  - generic [ref=e570]:
                    - text: سماق
                    - generic [ref=e571]: ۱۰۰ گرمی
              - cell "1 case (12 units)" [ref=e572]:
                - text: 1 case
                - generic [ref=e573]: (12 units)
              - cell [ref=e574]:
                - link "FV-20296" [ref=e575]:
                  - /url: "#invoices?id=a2-fixture%3AFV-20296"
              - cell "2026-09-21" [ref=e577]
              - cell [ref=e578]:
                - generic [ref=e579]:
                  - link "Invoice FV-20296" [ref=e580]:
                    - /url: "#invoices?id=a2-fixture%3AFV-20296"
                  - button "Show details" [ref=e583]
            - row [ref=e586] [cursor=pointer]:
              - cell "Basmati Rice 4.5 kg برنج باسماتی ۴٫۵ کیلوگرمی" [ref=e587]:
                - generic [ref=e589]:
                  - strong [ref=e590]:
                    - generic [ref=e591]:
                      - text: Basmati Rice
                      - generic [ref=e592]: 4.5 kg
                  - generic [ref=e594]:
                    - text: برنج باسماتی
                    - generic [ref=e595]: ۴٫۵ کیلوگرمی
              - cell "5 cases (20 units)" [ref=e596]:
                - text: 5 cases
                - generic [ref=e597]: (20 units)
              - cell [ref=e598]:
                - link "GG-11842" [ref=e599]:
                  - /url: "#invoices?id=a2-fixture%3AGG-11842"
              - cell "2026-09-10" [ref=e601]
              - cell [ref=e602]:
                - generic [ref=e603]:
                  - link "Invoice GG-11842" [ref=e604]:
                    - /url: "#invoices?id=a2-fixture%3AGG-11842"
                  - button "Show details" [ref=e607]
            - row [ref=e610] [cursor=pointer]:
              - cell "Dried Red Kidney Beans 900 g لوبیا قرمز ۹۰۰ گرمی" [ref=e611]:
                - generic [ref=e613]:
                  - strong [ref=e614]:
                    - generic [ref=e615]:
                      - text: Dried Red Kidney Beans
                      - generic [ref=e616]: 900 g
                  - generic [ref=e618]:
                    - text: لوبیا قرمز
                    - generic [ref=e619]: ۹۰۰ گرمی
              - cell "1 case (12 units)" [ref=e620]:
                - text: 1 case
                - generic [ref=e621]: (12 units)
              - cell [ref=e622]:
                - link "GG-11794" [ref=e623]:
                  - /url: "#invoices?id=a2-fixture%3AGG-11794"
              - cell "2026-08-24" [ref=e625]
              - cell [ref=e626]:
                - generic [ref=e627]:
                  - link "Invoice GG-11794" [ref=e628]:
                    - /url: "#invoices?id=a2-fixture%3AGG-11794"
                  - button "Show details" [ref=e631]
```

# Test source

```ts
  7   |   setBranch,
  8   |   signIn,
  9   |   uploadInvoice,
  10  | } from "./helpers";
  11  | import receiptFixtures from "../src/fixtures/a2-demo-data.json" with { type: "json" };
  12  | import type { DemoState } from "../src/types";
  13  | import { openC8PriceDialog } from "../scripts/capture-c8-proof.mjs";
  14  | 
  15  | test.setTimeout(60000);
  16  | 
  17  | async function saved(
  18  |   page: import("@playwright/test").Page,
  19  | ): Promise<DemoState> {
  20  |   return readCanonicalBusinessEvidence(page).then((canonicalState) =>
  21  |     JSON.parse(JSON.stringify(canonicalState)!),
  22  |   );
  23  | }
  24  | 
  25  | async function manualInvoice(page: import("@playwright/test").Page) {
  26  |   await page.goto("/#invoices");
  27  |   await page.getByRole("button", { name: "New invoice", exact: true }).click();
  28  |   await page.getByRole("button", { name: "Manual entry", exact: true }).click();
  29  |   const header = page.locator("#invoice-details-fields");
  30  |   await header.getByLabel("Supplier", { exact: true }).click();
  31  |   await page
  32  |     .getByRole("listbox", { name: "Supplier", exact: true })
  33  |     .getByRole("option", { name: /Fresh Valley Foods/ })
  34  |     .click();
  35  |   await page.getByRole("button", { name: "Add line", exact: true }).click();
  36  |   await page
  37  |     .getByLabel("Upload a PDF or photo", { exact: true })
  38  |     .setInputFiles(invoiceImage);
  39  |   await expect(page.locator(".invoice-line")).toHaveCount(1);
  40  | }
  41  | 
  42  | test("a worker retargets their own invoice to Warehouse without gaining Warehouse access", async ({
  43  |   page,
  44  | }) => {
  45  |   await signIn(page, "Floor Worker");
  46  |   await page.goto("/#invoices");
  47  |   await expect(
  48  |     page.getByRole("button", { name: "Manual entry", exact: true }),
  49  |   ).toHaveCount(0);
  50  |   await uploadInvoice(page);
  51  |   await expect(page.locator(".invoice-line")).toHaveCount(6);
  52  |   const header = page.locator("#invoice-details-fields");
  53  |   if (!(await header.isVisible()))
  54  |     await page
  55  |       .getByRole("button", { name: "Invoice details", exact: true })
  56  |       .click();
  57  |   await chooseOption(
  58  |     page,
  59  |     header.getByLabel("Location", { exact: true }),
  60  |     "Warehouse",
  61  |   );
  62  |   await expect(header.getByLabel("Location", { exact: true })).toContainText(
  63  |     "Warehouse",
  64  |   );
  65  |   await expect(page.locator(".topbar .branch-pill")).toContainText(
  66  |     "North York",
  67  |   );
  68  |   await expect(
  69  |     page.getByText(
  70  |       "Choose an invoice in your branch, or start a new invoice.",
  71  |       { exact: true },
  72  |     ),
  73  |   ).toHaveCount(0);
  74  |   const draft = (await saved(page)).invoice;
  75  |   expect(draft).toMatchObject({
  76  |     branch: "Warehouse",
  77  |     handling_branch: "Branch 1",
  78  |   });
  79  |   for (const line of await page.locator(".invoice-line").all()) {
  80  |     await line.getByRole("button", { name: "No", exact: true }).click();
  81  |     await line
  82  |       .getByRole("checkbox", {
  83  |         name: "Confirm this invoice line",
  84  |         exact: true,
  85  |       })
  86  |       .click();
  87  |     await expect(line.getByText("Confirmed", { exact: true })).toBeVisible();
  88  |   }
  89  |   await expect(
  90  |     page.getByRole("button", { name: "Post invoice", exact: true }),
  91  |   ).toBeEnabled();
  92  |   await page.getByRole("button", { name: "Post invoice", exact: true }).click();
  93  |   await page
  94  |     .getByRole("dialog", { name: "Post invoice", exact: true })
  95  |     .getByRole("button", { name: "Post invoice", exact: true })
  96  |     .click();
  97  |   const after = await saved(page);
  98  |   expect(
  99  |     after.invoices?.find((invoice) => invoice.id === draft.id),
  100 |   ).toMatchObject({ status: "posted", branch: "Warehouse" });
  101 |   await page.goto("/#received");
  102 |   await expect(
  103 |     page.getByRole("heading", { name: "Received", exact: true }),
  104 |   ).toBeVisible();
  105 |   await expect(
  106 |     page.getByRole("combobox", { name: "Location", exact: true }),
> 107 |   ).toHaveCount(0);
      |     ^ Error: expect(locator).toHaveCount(expected) failed
  108 |   expect(
  109 |     await page
  110 |       .locator(".received-table")
  111 |       .getByText("Warehouse", { exact: true })
  112 |       .count(),
  113 |   ).toBe(0);
  114 | });
  115 | 
  116 | test("Supervisor moves a posted invoice with a reason and retains its original document and company balance", async ({
  117 |   page,
  118 | }) => {
  119 |   await signIn(page, "Supervisor");
  120 |   await setBranch(page, "all");
  121 |   const source = receiptFixtures.invoices[0];
  122 |   const id = `a2-fixture:${source.number}`;
  123 |   await page.goto(`/#invoices?id=${encodeURIComponent(id)}`);
  124 |   await expect(
  125 |     page.getByRole("button", { name: "Move invoice", exact: true }),
  126 |   ).toBeVisible();
  127 |   const before = await saved(page);
  128 |   const original = before.invoices!.find((invoice) => invoice.id === id)!;
  129 |   await page.getByRole("button", { name: "Move invoice", exact: true }).click();
  130 |   const dialog = page.getByRole("dialog", {
  131 |     name: "Move invoice",
  132 |     exact: true,
  133 |   });
  134 |   await chooseOption(
  135 |     page,
  136 |     dialog.getByLabel("Location", { exact: true }),
  137 |     "Warehouse",
  138 |   );
  139 |   await expect(
  140 |     dialog.getByRole("button", { name: "Move invoice", exact: true }),
  141 |   ).toBeEnabled();
  142 |   await dialog
  143 |     .getByRole("button", { name: "Move invoice", exact: true })
  144 |     .click();
  145 |   await expect(
  146 |     dialog.getByRole("alert", { name: "What's missing", exact: true }),
  147 |   ).toBeVisible();
  148 |   await expect(dialog.getByLabel("Reason", { exact: true })).toHaveAttribute(
  149 |     "aria-invalid",
  150 |     "true",
  151 |   );
  152 |   expect((await saved(page)).ledger).toEqual(before.ledger);
  153 |   await dialog
  154 |     .getByLabel("Reason", { exact: true })
  155 |     .fill("Correct the delivery location");
  156 |   await expect(dialog).toContainText(
  157 |     "Previous payments and credits stay at their recorded location.",
  158 |   );
  159 |   await dialog
  160 |     .getByRole("button", { name: "Move invoice", exact: true })
  161 |     .click();
  162 |   await expect(dialog).not.toBeVisible();
  163 |   await expect(
  164 |     page.getByText("Invoice moved. The correction is recorded in History.", {
  165 |       exact: true,
  166 |     }),
  167 |   ).toBeVisible();
  168 |   const after = await saved(page);
  169 |   expect(after.invoices!.find((invoice) => invoice.id === id)).toEqual(
  170 |     original,
  171 |   );
  172 |   expect(after.ledger.slice(0, before.ledger.length)).toEqual(before.ledger);
  173 |   expect(after.invoice_location_corrections?.at(-1)).toMatchObject({
  174 |     invoice_id: id,
  175 |     to_branch: "Warehouse",
  176 |     reason: "Correct the delivery location",
  177 |   });
  178 |   const appended = after.ledger.slice(before.ledger.length);
  179 |   expect(appended).toHaveLength(2);
  180 |   expect(Decimal.sum(...appended.map((entry) => entry.amount)).toFixed(2)).toBe(
  181 |     "0.00",
  182 |   );
  183 |   await page.goto("/#received");
  184 |   await page
  185 |     .getByRole("textbox", { name: "Search Received", exact: true })
  186 |     .fill(source.number);
  187 |   const warehouseLocation = page
  188 |     .locator(".received-table")
  189 |     .getByText("Warehouse", { exact: true })
  190 |     .first();
  191 |   if (!(await warehouseLocation.isVisible()))
  192 |     await page.locator(".received-table .table-details-toggle").first().click();
  193 |   await expect(warehouseLocation).toBeVisible();
  194 |   await page.reload();
  195 |   expect(
  196 |     (await saved(page)).invoice_location_corrections?.at(-1)?.to_branch,
  197 |   ).toBe("Warehouse");
  198 | });
  199 | 
  200 | test("invoice changed regular cost defaults to calculated and explicit Keep preserves the approved price on posting", async ({
  201 |   page,
  202 | }) => {
  203 |   await signIn(page, "Supervisor");
  204 |   const editor = await openC8PriceDialog(page, "0002");
  205 |   await editor.getByRole("radio", { name: /^New regular price/ }).check();
  206 |   await editor.getByLabel("Price", { exact: true }).fill("2.79");
  207 |   await editor
```