# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: operations.spec.ts >> supplier pickup and partial substitute receipt preserve Payables; settled cancellation restores zero supplier-held originals
- Location: tests/operations.spec.ts:30:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText(/Supervisor review required/)
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByText(/Supervisor review required/) with timeout 5000ms
  - waiting for getByText(/Supervisor review required/)

```

```yaml
- link "Skip to content":
  - /url: "#main-content"
- banner:
  - button "Open menu"
  - combobox "Location": North York
  - button "Notifications, 0 unread"
  - button "User menu"
  - button "More"
- main:
  - link "Back to Returns":
    - /url: "#returns"
  - status: Recorded cancellation disposition. Existing compensation remains unchanged.
  - 'heading "Return #2" [level=1]'
  - text: Waiting for credit
  - paragraph: created 2026-10-11 by Demo Floor Worker · Golden Grain Distributors · North York
  - button "Return policy"
  - heading "Items" [level=2]
  - table:
    - rowgroup:
      - row "Basmati Rice 4.5 kg برنج باسماتی ۴٫۵ کیلوگرمی Quantity 2 Picked up 2 Details Show details":
        - cell "Basmati Rice 4.5 kg برنج باسماتی ۴٫۵ کیلوگرمی":
          - strong: Basmati Rice 4.5 kg
          - text: برنج باسماتی ۴٫۵ کیلوگرمی
        - cell "Quantity 2"
        - cell "Picked up 2"
        - cell "Details Show details":
          - text: Details
          - button "Show details"
  - text: "Replacement received: Basmati Rice 4.5 kg × 1. No amount was added to Payables."
  - paragraph: Two originals remain with the supplier; one replacement was received. Cancellation restores zero supplier-held units and needs Owner / Manager review.
  - paragraph: "Signed pickup slip: DEMO-PICKUP-002 (fictional paper reference) · Demo Supplier Representative"
  - text: Owner / Manager review required. Supplier-held originals are not recorded as recovered. Existing settlement has not been reversed.
  - heading "Evidence and history" [level=2]
  - strong: Cancellation review
  - paragraph: 2026-10-15 14:28 · Demo North York Floor Worker ·
  - paragraph: Fictional supplier retains originals; keep received replacement
```

# Test source

```ts
  15  |   await visitPage(page, label);
  16  | }
  17  | async function stored(page: Page) {
  18  |   return readCanonicalBusinessEvidence(page).then((canonicalState) =>
  19  |     JSON.parse(JSON.stringify(canonicalState)!),
  20  |   );
  21  | }
  22  | async function openReturn(page: Page, number: number) {
  23  |   await visit(page, "Returns");
  24  |   await page.getByRole("link", { name: `#${number}`, exact: true }).click();
  25  |   await expect(page).toHaveURL(
  26  |     new RegExp(`#return\\?id=demo-return-${number}$`),
  27  |   );
  28  | }
  29  | 
  30  | test("supplier pickup and partial substitute receipt preserve Payables; settled cancellation restores zero supplier-held originals", async ({
  31  |   page,
  32  | }) => {
  33  |   const errors: string[] = [];
  34  |   page.on("pageerror", (error) => errors.push(error.message));
  35  |   await signIn(page, "Floor Worker");
  36  |   await openReturn(page, 1);
  37  |   await expect(
  38  |     page.getByText("Sour Cherry Juice 1 L", { exact: true }),
  39  |   ).toBeVisible();
  40  |   await page
  41  |     .getByRole("button", { name: "Record pickup", exact: true })
  42  |     .click();
  43  |   await page.getByLabel("Actual pickup quantity", { exact: true }).fill("3");
  44  |   await page
  45  |     .getByLabel("Supplier representative name", { exact: true })
  46  |     .fill("Fictional Representative");
  47  |   await page
  48  |     .getByLabel("Signed paper pickup slip reference", { exact: true })
  49  |     .fill("DEMO-SIGNED-001");
  50  |   await page
  51  |     .getByRole("button", { name: "Record pickup", exact: true })
  52  |     .last()
  53  |     .click();
  54  |   await expect(page.getByRole("status")).toContainText("Recorded pickup");
  55  |   const before = await stored(page);
  56  |   await page
  57  |     .getByRole("button", { name: "Record resolution", exact: true })
  58  |     .click();
  59  |   await chooseOption(
  60  |     page,
  61  |     page.getByRole("combobox", { name: "Outcome", exact: true }),
  62  |     "replaced",
  63  |     "Replaced",
  64  |   );
  65  |   await page.getByLabel("Original quantity covered", { exact: true }).fill("1");
  66  |   await page.getByLabel("Remaining expected date", { exact: true }).click();
  67  |   await page.getByRole("button", { name: "Today", exact: true }).click();
  68  |   await page
  69  |     .getByLabel("Actual replacement quantity", { exact: true })
  70  |     .fill("2");
  71  |   await chooseOption(
  72  |     page,
  73  |     page.getByLabel("Replacement product actually received", { exact: true }),
  74  |     "0002",
  75  |     demoSeed.products.find((product) => product.code === "0002")!.name_en,
  76  |   );
  77  |   await page
  78  |     .getByLabel("Supplier representative name", { exact: true })
  79  |     .fill("Fictional Representative");
  80  |   await page
  81  |     .getByLabel("Replacement receipt reference", { exact: true })
  82  |     .fill("DEMO-REPLACE-001");
  83  |   await page
  84  |     .locator(".return-action-card")
  85  |     .getByRole("button", { name: "Record resolution", exact: true })
  86  |     .click();
  87  |   await expect(page.getByRole("status")).toContainText(
  88  |     "Recorded item resolutions",
  89  |   );
  90  |   const after = await stored(page);
  91  |   expect(after.ledger).toEqual(before.ledger);
  92  |   expect(after.stock["Branch 1:0002"]).toBe(before.stock["Branch 1:0002"] + 2);
  93  |   await openReturn(page, 2);
  94  |   await expect(
  95  |     page.getByRole("table").getByText("Basmati Rice 4.5 kg", { exact: true }),
  96  |   ).toBeVisible();
  97  |   await page
  98  |     .getByRole("button", { name: "Request cancellation", exact: true })
  99  |     .click();
  100 |   await chooseOption(
  101 |     page,
  102 |     page.getByLabel("Actual disposition", { exact: true }),
  103 |     "supplier_held",
  104 |     "Supplier still holds originals — restore zero",
  105 |   );
  106 |   await page
  107 |     .getByLabel("Cancellation reason (required)", { exact: true })
  108 |     .fill("Fictional supplier retains originals; keep received replacement");
  109 |   await page
  110 |     .getByRole("button", {
  111 |       name: "Record cancellation disposition",
  112 |       exact: true,
  113 |     })
  114 |     .click();
> 115 |   await expect(page.getByText(/Supervisor review required/)).toBeVisible();
      |                                                              ^ Error: expect(locator).toBeVisible() failed
  116 |   const cancelled = await stored(page);
  117 |   expect(cancelled.stock["Branch 1:0001"]).toBe(before.stock["Branch 1:0001"]);
  118 |   expect(cancelled.returns[1].status).toBe("cancellation_review");
  119 |   await signIn(page, "Supervisor");
  120 |   await openReturn(page, 2);
  121 |   await page
  122 |     .getByLabel("Settlement review and reason", { exact: true })
  123 |     .fill(
  124 |       "Checked fictional receipt; original goods remain supplier-held and replacement is retained",
  125 |     );
  126 |   await page.getByRole("checkbox", { name: /I reviewed the history/ }).check();
  127 |   await page
  128 |     .getByRole("button", { name: "Approve cancellation", exact: true })
  129 |     .click();
  130 |   await expect(
  131 |     page.locator(".return-header-card").getByText("Cancelled", { exact: true }),
  132 |   ).toBeVisible();
  133 |   expect((await stored(page)).stock["Branch 1:0001"]).toBe(
  134 |     before.stock["Branch 1:0001"],
  135 |   );
  136 |   expect(errors).toEqual([]);
  137 | });
  138 | 
  139 | test("date removal, notes store-use, and unread Supervisor actions survive refresh", async ({
  140 |   page,
  141 | }) => {
  142 |   await signIn(page, "Floor Worker");
  143 |   await visit(page, "Date tracking");
  144 |   const beforeDateRemoval = await stored(page);
  145 |   await expect(
  146 |     page.getByRole("button", { name: "Remove", exact: true }),
  147 |   ).toHaveCount(2);
  148 |   await page
  149 |     .getByRole("button", { name: "Remove", exact: true })
  150 |     .first()
  151 |     .click();
  152 |   const removal = page.getByRole("dialog", {
  153 |     name: "Remove date",
  154 |     exact: true,
  155 |   });
  156 |   await chooseOption(
  157 |     page,
  158 |     removal.getByLabel("Reason", { exact: true }),
  159 |     "sold_out",
  160 |     "Sold out",
  161 |   );
  162 |   await removal.getByRole("button", { name: "Remove", exact: true }).click();
  163 |   await expect(
  164 |     page.getByRole("button", { name: "Remove", exact: true }),
  165 |   ).toHaveCount(1);
  166 |   const removed = await stored(page);
  167 |   expect(removed.expiry).toHaveLength(beforeDateRemoval.expiry.length);
  168 |   expect(
  169 |     removed.expiry.find(
  170 |       (entry: { branch: string; product_code: string }) =>
  171 |         entry.branch === "Branch 1" && entry.product_code === "0006",
  172 |     ),
  173 |   ).toMatchObject({ status: "removed", removed_reason: "sold_out" });
  174 |   expect(removed.stock).toEqual(beforeDateRemoval.stock);
  175 |   expect(removed.ledger).toEqual(beforeDateRemoval.ledger);
  176 |   await page.reload();
  177 |   await expect(
  178 |     page.getByRole("button", { name: "Remove", exact: true }),
  179 |   ).toHaveCount(1);
  180 |   await visit(page, "Notes");
  181 |   await page.getByRole("tab", { name: "Store use", exact: true }).click();
  182 |   await page.getByRole("button", { name: "Add note", exact: true }).click();
  183 |   const beforeStoreUse = await stored(page);
  184 |   await page.getByLabel("Note", { exact: true }).fill("Demo staff lunch");
  185 |   await chooseOption(
  186 |     page,
  187 |     page.getByLabel("Product (required)", { exact: true }),
  188 |     "0006",
  189 |     "Lavash Bread 500 g",
  190 |   );
  191 |   await page
  192 |     .getByLabel("Actual quantity used (required)", { exact: true })
  193 |     .fill("2");
  194 |   await page.getByRole("button", { name: "Save note", exact: true }).click();
  195 |   expect((await stored(page)).stock["Branch 1:0006"]).toBe(
  196 |     beforeStoreUse.stock["Branch 1:0006"] - 2,
  197 |   );
  198 |   await page.getByRole("tab", { name: "For Supervisor", exact: true }).click();
  199 |   await page.getByRole("button", { name: "Add note", exact: true }).click();
  200 |   await page
  201 |     .getByLabel("Note", { exact: true })
  202 |     .fill("Fictional supervisor check requested");
  203 |   await page.getByRole("button", { name: "Save note", exact: true }).click();
  204 |   await expect(
  205 |     page.getByRole("button", { name: "More actions", exact: true }),
  206 |   ).toHaveCount(0);
  207 |   await signIn(page, "Supervisor");
  208 |   await visit(page, "Notes");
  209 |   await page.getByRole("tab", { name: /For Supervisor/ }).click();
  210 |   await expect(
  211 |     page.getByRole("button", { name: "More actions", exact: true }),
  212 |   ).toHaveCount(2);
  213 |   await page
  214 |     .getByRole("button", { name: "More actions", exact: true })
  215 |     .first()
```