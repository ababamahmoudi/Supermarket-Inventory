# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: returns-a2.spec.ts >> Return detail pickup does not deduct stock twice and replacement increases actual stock without posting to the supplier ledger
- Location: tests/returns-a2.spec.ts:394:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('status')
Expected substring: "Recorded item resolutions. Credit claims require Supervisor verification."
Received string:    "Recorded item resolutions. Credit claims require Owner / Manager verification."
Timeout: 5000ms

Call log:
  - Expect "toContainText" getByRole('status') with timeout 5000ms
  - waiting for getByRole('status')
    12 × locator resolved to <div role="status" class="banner approved">Recorded item resolutions. Credit claims require …</div>
       - unexpected value "Recorded item resolutions. Credit claims require Owner / Manager verification."

```

```yaml
- status: Recorded item resolutions. Credit claims require Owner / Manager verification.
```

# Test source

```ts
  354 |     },
  355 |     undefined,
  356 |   );
  357 |   await page.reload();
  358 |   await setBranch(page, "all");
  359 |   await page.goto("/#returns");
  360 |   await expect(page.locator(".returns-overview-table")).toContainText(
  361 |     "Branch Two Private Return",
  362 |   );
  363 |   await expect(page.locator(".returns-overview-table")).not.toContainText(
  364 |     "Another Company Private Supplier",
  365 |   );
  366 |   await expect(page.locator(".returns-overview-table")).not.toContainText(
  367 |     "Cancelled Return Supplier",
  368 |   );
  369 |   await page.getByRole("tab", { name: "History", exact: true }).click();
  370 |   await expect(page.locator(".returns-overview-table")).toContainText(
  371 |     "Cancelled Return Supplier",
  372 |   );
  373 |   await signIn(page, "Floor Worker");
  374 |   await visitPage(page, "Returns");
  375 |   await expect(page.locator(".returns-overview-table")).not.toContainText(
  376 |     "Branch Two Private Return",
  377 |   );
  378 |   await page.goto("/#return?id=scope-other-branch");
  379 |   await expect(
  380 |     page.getByText("This return is not available in your branch.", {
  381 |       exact: true,
  382 |     }),
  383 |   ).toBeVisible();
  384 |   await expect(page.locator(".return-detail")).toHaveCount(0);
  385 |   await page.goto("/#return?id=scope-other-company");
  386 |   await expect(
  387 |     page.getByText("This return is not available in your branch.", {
  388 |       exact: true,
  389 |     }),
  390 |   ).toBeVisible();
  391 |   await expect(page.locator(".return-detail")).toHaveCount(0);
  392 | });
  393 | 
  394 | test("Return detail pickup does not deduct stock twice and replacement increases actual stock without posting to the supplier ledger", async ({
  395 |   page,
  396 | }) => {
  397 |   await signIn(page, "Floor Worker");
  398 |   await page.goto("/#return?id=demo-return-1");
  399 |   const before = await snapshot(page);
  400 |   await page
  401 |     .locator(".return-header-card")
  402 |     .getByRole("button", { name: "Record pickup", exact: true })
  403 |     .click();
  404 |   await page.getByLabel("Actual pickup quantity", { exact: true }).fill("3");
  405 |   await page
  406 |     .getByLabel("Supplier representative name", { exact: true })
  407 |     .fill("Fictional Representative");
  408 |   await page
  409 |     .getByLabel("Signed paper pickup slip reference", { exact: true })
  410 |     .fill("A2-SIGNED-001");
  411 |   await page
  412 |     .locator(".return-action-card")
  413 |     .getByRole("button", { name: "Record pickup", exact: true })
  414 |     .click();
  415 |   await expect(page.getByRole("status")).toContainText("Recorded pickup");
  416 |   const pickup = await snapshot(page);
  417 |   expect(pickup.stock).toEqual(before.stock);
  418 |   expect(pickup.ledger).toEqual(before.ledger);
  419 |   await page
  420 |     .locator(".return-header-card")
  421 |     .getByRole("button", { name: "Record resolution", exact: true })
  422 |     .click();
  423 |   await chooseOption(
  424 |     page,
  425 |     page.getByRole("combobox", { name: "Outcome", exact: true }),
  426 |     "replaced",
  427 |     "Replaced",
  428 |   );
  429 |   await page.getByLabel("Original quantity covered", { exact: true }).fill("1");
  430 |   await page.getByLabel("Remaining expected date", { exact: true }).click();
  431 |   await page.getByRole("button", { name: "Today", exact: true }).click();
  432 |   await page
  433 |     .getByLabel("Actual replacement quantity", { exact: true })
  434 |     .fill("2");
  435 |   const replacement = pickup.products.find(
  436 |     (product: { code: string }) => product.code === "0002",
  437 |   );
  438 |   await chooseOption(
  439 |     page,
  440 |     page.getByLabel("Replacement product actually received", { exact: true }),
  441 |     "0002",
  442 |     replacement.name_en,
  443 |   );
  444 |   await page
  445 |     .getByLabel("Supplier representative name", { exact: true })
  446 |     .fill("Fictional Representative");
  447 |   await page
  448 |     .getByLabel("Replacement receipt reference", { exact: true })
  449 |     .fill("A2-REPLACEMENT-001");
  450 |   await page
  451 |     .locator(".return-action-card")
  452 |     .getByRole("button", { name: "Record resolution", exact: true })
  453 |     .click();
> 454 |   await expect(page.getByRole("status")).toContainText(
      |                                          ^ Error: expect(locator).toContainText(expected) failed
  455 |     "Recorded item resolutions. Credit claims require Supervisor verification.",
  456 |   );
  457 |   const received = await snapshot(page);
  458 |   expect(received.ledger).toEqual(before.ledger);
  459 |   expect(received.stock["Branch 1:0002"]).toBe(
  460 |     before.stock["Branch 1:0002"] + 2,
  461 |   );
  462 |   await expect(page.locator(".return-evidence-card")).toContainText(
  463 |     "A2-SIGNED-001",
  464 |   );
  465 |   await expect(page.locator(".return-evidence-card")).toContainText(
  466 |     "A2-REPLACEMENT-001",
  467 |   );
  468 | });
  469 | 
  470 | test("Supplier-held cancellation keeps stock and compensation unchanged and requires Supervisor review", async ({
  471 |   page,
  472 | }) => {
  473 |   await signIn(page, "Floor Worker");
  474 |   await page.goto("/#return?id=demo-return-2");
  475 |   const before = await snapshot(page);
  476 |   await page
  477 |     .getByRole("button", { name: "Request cancellation", exact: true })
  478 |     .click();
  479 |   await chooseOption(
  480 |     page,
  481 |     page.getByLabel("Actual disposition", { exact: true }),
  482 |     "supplier_held",
  483 |     "Supplier still holds originals — restore zero",
  484 |   );
  485 |   await page
  486 |     .getByLabel("Cancellation reason (required)", { exact: true })
  487 |     .fill("Supplier holds originals; keep the recorded replacement.");
  488 |   await page
  489 |     .getByRole("button", {
  490 |       name: "Record cancellation disposition",
  491 |       exact: true,
  492 |     })
  493 |     .click();
  494 |   await expect(page.locator(".return-review-card")).toContainText(
  495 |     "Supervisor review required.",
  496 |   );
  497 |   await expect(
  498 |     page.getByRole("button", { name: "Approve cancellation", exact: true }),
  499 |   ).toHaveCount(0);
  500 |   const waiting = await snapshot(page);
  501 |   expect(waiting.stock).toEqual(before.stock);
  502 |   expect(waiting.ledger).toEqual(before.ledger);
  503 |   expect(
  504 |     waiting.returns.find(
  505 |       (record: { id: string }) => record.id === "demo-return-2",
  506 |     ).status,
  507 |   ).toBe("cancellation_review");
  508 |   await signIn(page, "Supervisor");
  509 |   await page.goto("/#return?id=demo-return-2");
  510 |   await page
  511 |     .getByLabel("Settlement review and reason", { exact: true })
  512 |     .fill(
  513 |       "Reviewed the replacement receipt; retain compensation and restore no supplier-held originals.",
  514 |     );
  515 |   await page
  516 |     .getByRole("checkbox", {
  517 |       name: "I reviewed the history. Existing replacement or compensation is retained; no reversal is needed.",
  518 |       exact: true,
  519 |     })
  520 |     .click();
  521 |   await page
  522 |     .getByRole("button", { name: "Approve cancellation", exact: true })
  523 |     .click();
  524 |   await expect(page.getByRole("status")).toContainText("Approved cancellation");
  525 |   const cancelled = await snapshot(page);
  526 |   expect(cancelled.stock).toEqual(before.stock);
  527 |   expect(cancelled.ledger).toEqual(before.ledger);
  528 |   expect(
  529 |     cancelled.returns.find(
  530 |       (record: { id: string }) => record.id === "demo-return-2",
  531 |     ).replacement_received,
  532 |   ).toEqual(
  533 |     before.returns.find(
  534 |       (record: { id: string }) => record.id === "demo-return-2",
  535 |     ).replacement_received,
  536 |   );
  537 | });
  538 | 
```