# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: manual-prices-c1.spec.ts >> manual price stays visible to staff while catalog cost, margin and cost history stay Supervisor-only
- Location: tests/manual-prices-c1.spec.ts:15:1

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator: locator('.manual-price-comparison')
Expected: "Rule price $2.99 · Manual price $3.29"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toHaveText" locator('.manual-price-comparison') with timeout 5000ms
  - waiting for locator('.manual-price-comparison')

```

```yaml
- link "Skip to content":
  - /url: "#main-content"
- complementary "Main menu":
  - img "Super Arzon"
  - text: Super Arzon
  - navigation "Pages":
    - button "Daily"
    - button "Catalog" [expanded]
    - link "Products":
      - /url: "#products"
    - link "Offers":
      - /url: "#offers"
    - link "Suppliers":
      - /url: "#suppliers"
    - button "Manager"
    - button "Admin"
  - button "User menu":
    - strong: Demo Manager
    - text: Manager
- banner:
  - button "Collapse sidebar" [expanded]
  - navigation "Breadcrumbs":
    - link "All locations":
      - /url: "#dashboard"
    - link "Products":
      - /url: "#products"
    - link "Potato Chips 150 g":
      - /url: "#product?code=0009"
  - search:
    - textbox "Search all products":
      - /placeholder: Search products
  - combobox "Location": All locations
  - button "Switch to Persian": فا
  - button "Switch to dark theme"
  - button "Comfortable text size"
  - button "Notifications, 8 unread": "8"
  - button "Demo"
- main:
  - link "Back to Products":
    - /url: "#products"
  - heading "Potato Chips 150 g" [level=1]
  - paragraph: چیپس سیب‌زمینی ۱۵۰ گرمی
  - text: Product Code 0009 150 g HST 13% Approved
  - button "Change price"
  - button "Edit Potato Chips 150 g": Edit
  - button "Product actions"
  - heading "Price at All branches" [level=2]
  - text: Location
  - combobox "Location": Choose location
  - text: Last received No deliveries yet
  - heading "Dates at All branches" [level=2]
  - region "Dates":
    - paragraph: No open dates in this location.
  - heading "Details" [level=2]
  - term: Barcode
  - definition: DEMO-6000063352
  - term: AI category
  - definition: Snacks
  - term: Pricing category
  - definition: Grocery (Taxable)
  - term: Tax
  - definition: HST 13%
  - term: Supplier
  - definition: Fresh Valley Foods
  - term: Sold by
  - definition: Each
  - term: Unit size
  - definition: 150 g
  - term: First added at
  - definition: —
  - heading "Prices by store" [level=2]
  - table:
    - rowgroup:
      - row "Location Selling price Price scope":
        - columnheader "Location"
        - columnheader "Selling price"
        - columnheader "Price scope"
    - rowgroup:
      - row "North York $3.29 Manual price Company default":
        - cell "North York"
        - cell "$3.29 Manual price"
        - cell "Company default"
      - row "Richmond Hill $3.29 Manual price Company default":
        - cell "Richmond Hill"
        - cell "$3.29 Manual price"
        - cell "Company default"
      - row "Newmarket $3.29 Manual price Company default":
        - cell "Newmarket"
        - cell "$3.29 Manual price"
        - cell "Company default"
  - heading "Deliveries" [level=2]
  - table:
    - rowgroup:
      - row "Date Location Cases and units Supplier Invoice number Details":
        - columnheader "Date"
        - columnheader "Location"
        - columnheader "Cases and units"
        - columnheader "Supplier"
        - columnheader "Invoice number"
        - columnheader "Details"
    - rowgroup:
      - row "2026-10-14 North York 1 case Fresh Valley Foods FV-20390 Open FV-20390":
        - cell "2026-10-14"
        - cell "North York"
        - cell "1 case"
        - cell "Fresh Valley Foods"
        - cell "FV-20390"
        - cell "Open FV-20390":
          - link "Open FV-20390":
            - /url: "#invoices?id=a2-fixture%3AFV-20390"
  - heading "Lots" [level=2]
  - paragraph: No dated receipts recorded.
  - heading "Cost history" [level=2]
  - table:
    - rowgroup:
      - row "Supplier Location Date Invoice number Unit cost before tax Details":
        - columnheader "Supplier"
        - columnheader "Location"
        - columnheader "Date"
        - columnheader "Invoice number"
        - columnheader "Unit cost before tax"
        - columnheader "Details"
    - rowgroup:
      - row "Fresh Valley Foods North York 2026-10-14 FV-20390 $1.60 Show details":
        - cell "Fresh Valley Foods"
        - cell "North York"
        - cell "2026-10-14"
        - cell "FV-20390":
          - link "FV-20390":
            - /url: "#invoices?id=a2-fixture%3AFV-20390"
        - cell "$1.60"
        - cell "Show details":
          - button "Show details"
  - heading "History" [level=2]
  - list:
    - listitem: Recorded activity Demo Manager · 2026-10-15
    - listitem: Recorded activity Demo Manager · 2026-10-15
    - listitem: Recorded activity Demo Manager · 2026-10-15
    - listitem: Recorded activity Demo Manager · 2026-10-15
```

# Test source

```ts
  1   | import { expect, test, type Page } from "@playwright/test";
  2   | import { resetDemo, setBranch, setLanguage, signIn } from "./helpers";
  3   | 
  4   | async function showManualPrice(page: Page) {
  5   |   const table = page.locator(".catalog-products-table");
  6   |   const badge = table.locator(".manual-price-pill");
  7   |   if (!(await badge.isVisible()))
  8   |     await table
  9   |       .getByRole("button", { name: "Show details", exact: true })
  10  |       .first()
  11  |       .click();
  12  |   await expect(badge).toHaveText("Manual price");
  13  | }
  14  | 
  15  | test("manual price stays visible to staff while catalog cost, margin and cost history stay Supervisor-only", async ({
  16  |   page,
  17  | }) => {
  18  |   await signIn(page, "Supervisor");
  19  |   await setBranch(page, "all");
  20  |   await page.goto("/#products");
  21  |   await page.getByLabel("Search products", { exact: true }).fill("0009");
  22  |   const table = page.locator(".catalog-products-table");
  23  |   const productRow = table
  24  |     .locator("tbody tr")
  25  |     .filter({ hasText: "0009" })
  26  |     .first();
  27  |   for (const label of ["Store cost", "Margin %"]) {
  28  |     const heading = table.getByRole("columnheader", {
  29  |       name: label,
  30  |       exact: true,
  31  |     });
  32  |     const cell = productRow.locator(`td[data-column-label="${label}"]`);
  33  |     if (await heading.count()) await expect(heading).toBeVisible();
  34  |     else if (await cell.isVisible()) {
  35  |       await expect(cell).toHaveAttribute("data-column-label", label);
  36  |       await expect(cell).not.toBeEmpty();
  37  |     } else {
  38  |       await productRow
  39  |         .getByRole("button", { name: "Show details", exact: true })
  40  |         .click();
  41  |       await expect(
  42  |         table.locator(".table-expanded-row").getByText(label, { exact: true }),
  43  |       ).toBeVisible();
  44  |       await productRow
  45  |         .getByRole("button", { name: "Hide details", exact: true })
  46  |         .click();
  47  |     }
  48  |   }
  49  |   await page
  50  |     .getByRole("link", { name: "Potato Chips 150 g", exact: true })
  51  |     .click();
  52  |   await page
  53  |     .locator(".product-header-actions")
  54  |     .getByRole("button", { name: "Change price", exact: true })
  55  |     .click();
  56  |   const editor = page.getByRole("dialog", {
  57  |     name: "Change price",
  58  |     exact: true,
  59  |   });
  60  |   await editor.getByRole("radio", { name: /^New regular price/ }).click();
  61  |   await editor.getByLabel("Price", { exact: true }).fill("3.29");
  62  |   await editor
  63  |     .getByRole("button", { name: "Save new price", exact: true })
  64  |     .click();
  65  |   await expect(editor).not.toBeVisible();
  66  |   await page
  67  |     .getByRole("link", { name: "Back to Products", exact: true })
  68  |     .click();
  69  |   await page.getByLabel("Manual prices", { exact: true }).check();
  70  |   await expect(page.locator(".catalog-products-table tbody tr")).toHaveCount(1);
  71  |   await showManualPrice(page);
  72  |   await page
  73  |     .getByRole("link", { name: "Potato Chips 150 g", exact: true })
  74  |     .click();
  75  |   await expect(
  76  |     page.getByRole("heading", { name: "Cost history", exact: true }),
  77  |   ).toBeVisible();
  78  |   await expect(
  79  |     page.getByRole("heading", { name: "Deliveries", exact: true }),
  80  |   ).toBeVisible();
  81  |   await expect(page.locator(".product-last-received-summary")).toContainText(
  82  |     "Last received",
  83  |   );
  84  |   await expect(
  85  |     page.getByRole("heading", { name: "Stock estimate", exact: true }),
  86  |   ).toHaveCount(0);
> 87  |   await expect(page.locator(".manual-price-comparison")).toHaveText(
      |                                                          ^ Error: expect(locator).toHaveText(expected) failed
  88  |     "Rule price $2.99 · Manual price $3.29",
  89  |   );
  90  |   await expect(page.locator(".manual-price-margin")).toBeVisible();
  91  | 
  92  |   await signIn(page, "Floor Worker");
  93  |   await page.goto("/#products");
  94  |   await page.getByLabel("Search products", { exact: true }).fill("0009");
  95  |   await expect(
  96  |     page.getByRole("columnheader", { name: "Store cost", exact: true }),
  97  |   ).toHaveCount(0);
  98  |   await expect(
  99  |     page.getByRole("columnheader", { name: "Margin %", exact: true }),
  100 |   ).toHaveCount(0);
  101 |   await expect(
  102 |     page.locator(
  103 |       '.catalog-products-table td[data-column-label="Store cost"], .catalog-products-table td[data-column-label="Margin %"]',
  104 |     ),
  105 |   ).toHaveCount(0);
  106 |   await showManualPrice(page);
  107 |   await page
  108 |     .getByRole("link", { name: "Potato Chips 150 g", exact: true })
  109 |     .click();
  110 |   await expect(
  111 |     page.getByRole("heading", { name: "Cost history", exact: true }),
  112 |   ).toHaveCount(0);
  113 |   await expect(page.locator(".manual-price-margin")).toHaveCount(0);
  114 | 
  115 |   await signIn(page, "Cashier");
  116 |   await page.goto("/#lookup");
  117 |   await page.getByLabel("Search products", { exact: true }).fill("0009");
  118 |   await expect(page.locator(".lookup-detail .manual-price-pill")).toHaveText(
  119 |     "Manual price",
  120 |   );
  121 |   await expect(
  122 |     page.locator(".lookup-detail .manual-price-comparison"),
  123 |   ).toHaveText("Rule price $2.99 · Manual price $3.29");
  124 |   await expect(page.locator(".manual-price-margin")).toHaveCount(0);
  125 |   await page.reload();
  126 |   await page.getByLabel("Search products", { exact: true }).fill("0009");
  127 |   await expect(page.locator(".lookup-detail .price")).toHaveText("$3.29");
  128 |   await setLanguage(page, "fa");
  129 |   await expect(page.locator(".lookup-detail .manual-price-pill")).toHaveText(
  130 |     "قیمت دستی",
  131 |   );
  132 |   await expect(
  133 |     page.locator(".lookup-detail .manual-price-comparison bdi"),
  134 |   ).toHaveText(["$2.99", "$3.29"]);
  135 |   await setLanguage(page, "en");
  136 |   await resetDemo(page);
  137 |   await page.goto("/#lookup");
  138 |   await page.getByLabel("Search products", { exact: true }).fill("0009");
  139 |   await expect(page.locator(".lookup-detail .manual-price-pill")).toHaveCount(
  140 |     0,
  141 |   );
  142 |   await expect(page.locator(".lookup-detail .price")).toHaveText("$2.99");
  143 | });
  144 | 
  145 | test("branch-only manual prices do not flag the other location", async ({
  146 |   page,
  147 | }) => {
  148 |   await signIn(page, "Supervisor");
  149 |   await setBranch(page, "Branch 1");
  150 |   await page.goto("/#lookup");
  151 |   await page.getByLabel("Search products", { exact: true }).fill("0009");
  152 |   await page
  153 |     .locator(".product-header-actions")
  154 |     .getByRole("button", { name: "Change price", exact: true })
  155 |     .click();
  156 |   const editor = page.getByRole("dialog", {
  157 |     name: "Change price",
  158 |     exact: true,
  159 |   });
  160 |   await editor.getByRole("radio", { name: /^New regular price/ }).click();
  161 |   await editor.getByLabel("Price", { exact: true }).fill("3.29");
  162 |   await editor
  163 |     .getByRole("button", { name: "Only North York", exact: true })
  164 |     .click();
  165 |   await editor
  166 |     .getByRole("button", { name: "Save new price", exact: true })
  167 |     .click();
  168 |   await expect(page.locator(".lookup-detail .manual-price-pill")).toHaveText(
  169 |     "Manual price",
  170 |   );
  171 |   await setBranch(page, "Branch 2");
  172 |   await expect(page.locator(".lookup-detail .manual-price-pill")).toHaveCount(
  173 |     0,
  174 |   );
  175 |   await expect(page.locator(".lookup-detail .price")).toHaveText("$2.99");
  176 | });
  177 | 
```