# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: receiving-c.spec.ts >> invoice changed regular cost defaults to calculated and explicit Keep preserves the approved price on posting
- Location: tests/receiving-c.spec.ts:200:1

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator: locator('.invoice-line').first().getByRole('button', { name: 'Use the new calculated price $1.99', exact: true })
Expected: "true"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toHaveAttribute" locator('.invoice-line').first().getByRole('button', { name: 'Use the new calculated price $1.99', exact: true }) with timeout 5000ms
  - waiting for locator('.invoice-line').first().getByRole('button', { name: 'Use the new calculated price $1.99', exact: true })

```

```yaml
- link "Skip to content":
  - /url: "#main-content"
- complementary "Main menu":
  - img "Super Arzon"
  - text: Super Arzon
  - navigation "Pages":
    - button "Daily" [expanded]
    - link "Lookup":
      - /url: "#lookup"
    - link "Invoices":
      - /url: "#invoices"
    - link "Received":
      - /url: "#received"
    - link "Returns":
      - /url: "#returns"
    - link "Price updates":
      - /url: "#price-updates"
      - text: Price updates 1
    - link "Labels":
      - /url: "#labels"
    - link "Date tracking":
      - /url: "#expiry"
    - link "Notes":
      - /url: "#notes"
      - text: Notes 2
    - link "Branch requests":
      - /url: "#requests"
    - button "Catalog"
    - button "Manager"
    - button "Admin"
  - button "User menu":
    - strong: Demo Manager
    - text: Manager
- banner:
  - button "Collapse sidebar" [expanded]
  - navigation "Breadcrumbs":
    - link "North York":
      - /url: "#dashboard"
    - link "Invoices":
      - /url: "#invoices"
  - search:
    - textbox "Search all products":
      - /placeholder: Search products
  - combobox "Location": North York
  - button "Switch to Persian": فا
  - button "Switch to dark theme"
  - button "Comfortable text size"
  - button "Notifications, 8 unread": "8"
  - button "Demo"
- main:
  - link "Back to Invoices":
    - /url: "#invoices"
  - heading "Invoices" [level=1]
  - paragraph: Deliveries and supplier invoices
  - button "New invoice"
  - tablist "Invoice views":
    - tab "Drafts"
    - tab "Processing"
    - tab "Needs review" [selected]
    - tab "Ready to post"
    - tab "Posted"
    - tab "Cancelled"
  - complementary "Original invoice":
    - heading "Original invoice" [level=2]
    - paragraph: AI invoice reading is simulated
    - text: Upload a PDF or photo
    - button "Upload a PDF or photo"
    - button "Take photo"
    - strong: fictional-supplier-invoice.png
    - text: 1 KB
    - button "Remove file"
    - button "Browse"
    - group "Original invoice":
      - button "Zoom out"
      - text: 100%
      - button "Zoom in"
      - button "Fit width"
      - button "Fit page"
      - button "Download"
    - img "Original invoice image"
  - text: Subtotal
  - strong: $0.98
  - text: Tax
  - strong: $0.00
  - text: Shorts and refused deduction
  - strong: $0.00
  - text: Payable
  - strong: $0.98
  - paragraph: This is the amount of this invoice, not a supplier balance. Received records only physically delivered units.
  - heading "Invoice details" [level=2]:
    - button "Invoice details"
  - paragraph: Fresh Valley Foods · — · North York · 2026-10-15
  - paragraph: Needs review Changes save automatically in this browser.
  - heading "Compare with order" [level=2]
  - text: Order (optional)
  - combobox "Order (optional)": No linked order
  - paragraph: Choose an open order for this supplier and receiving location.
  - heading "Review invoice lines" [level=2]
  - paragraph: Choose Cases or Units and confirm the product, pack, quantities, cost, and date decision on each line.
  - table:
    - 'rowgroup "Line 1: Canned Fava Beans 400 g"':
      - 'row "1. Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی 0002 · 400 g Matched Invoiced 1 Delivered 1 Unit cost before tax 0.9800 Line total $0.98 Selling price $2.79 Manual price Rule price $1.49 · Manual price $2.79 Margin %: 64.87% Approved: $2.79"':
        - cell "1. Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی 0002 · 400 g Matched":
          - heading "1. Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی" [level=3]:
            - button "1. Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی" [expanded]:
              - text: "1."
              - strong: Canned Fava Beans 400 g
              - text: باقالا کنسرو شده ۴۰۰ گرمی
          - paragraph: 0002 · 400 g
          - text: Matched
        - cell "Invoiced 1 Delivered 1":
          - text: Invoiced
          - textbox "Invoiced": "1"
          - text: Delivered
          - textbox "Delivered": "1"
        - cell "Unit cost before tax 0.9800":
          - text: Unit cost before tax
          - textbox "Unit cost before tax": "0.9800"
        - cell "Line total $0.98"
        - 'cell "Selling price $2.79 Manual price Rule price $1.49 · Manual price $2.79 Margin %: 64.87% Approved: $2.79"':
          - text: Selling price
          - strong: $2.79
          - text: Manual price
          - paragraph: Rule price $1.49 · Manual price $2.79
          - paragraph: "Margin %: 64.87%"
          - paragraph: "Approved: $2.79"
      - row "Remove line Mark as short Confirm this invoice line":
        - cell "Remove line Mark as short Confirm this invoice line":
          - group:
            - text: Quantity unit
            - combobox "Quantity unit": Units
            - text: Units per case
            - textbox "Units per case": "12"
            - text: Supplier item code (optional)
            - textbox "Supplier item code (optional)"
            - paragraph: 1 unit
            - text: Matched product
            - combobox "Matched product": ⁦0002⁩ · ⁦Canned Fava Beans 400 g ⁩
            - text: Pricing category
            - combobox "Pricing category": Grocery
          - button "Remove line"
          - checkbox "Mark as short"
          - group:
            - text: Track date
            - group "Track date":
              - button "Yes" [pressed]
              - button "No"
            - text: Date tracking
            - combobox "Date tracking": Expiry
            - text: Date
            - button "Date": Choose date
            - text: Lot number (optional)
            - textbox "Lot number (optional)"
          - checkbox "Confirm this invoice line"
  - text: Add a product to the invoice
  - combobox "Add a product to the invoice": ⁦0002⁩ · ⁦Canned Fava Beans 400 g ⁩
  - button "Add line"
  - button "+ Add new product"
  - button "Save as draft"
  - button "Post invoice"
```

# Test source

```ts
  141 |   ).toBeEnabled();
  142 |   await dialog
  143 |     .getByRole("button", { name: "Move invoice", exact: true })
  144 |     .click();
  145 |   await expect(
  146 |     dialog.getByRole("alert", { name: "What's missing", exact: true }),
  147 |   ).toBeVisible();
  148 |   await expect(dialog.getByLabel("Reason", { exact: true })).toHaveAttribute(
  149 |     "aria-invalid",
  150 |     "true",
  151 |   );
  152 |   expect((await saved(page)).ledger).toEqual(before.ledger);
  153 |   await dialog
  154 |     .getByLabel("Reason", { exact: true })
  155 |     .fill("Correct the delivery location");
  156 |   await expect(dialog).toContainText(
  157 |     "Previous payments and credits stay at their recorded location.",
  158 |   );
  159 |   await dialog
  160 |     .getByRole("button", { name: "Move invoice", exact: true })
  161 |     .click();
  162 |   await expect(dialog).not.toBeVisible();
  163 |   await expect(
  164 |     page.getByText("Invoice moved. The correction is recorded in History.", {
  165 |       exact: true,
  166 |     }),
  167 |   ).toBeVisible();
  168 |   const after = await saved(page);
  169 |   expect(after.invoices!.find((invoice) => invoice.id === id)).toEqual(
  170 |     original,
  171 |   );
  172 |   expect(after.ledger.slice(0, before.ledger.length)).toEqual(before.ledger);
  173 |   expect(after.invoice_location_corrections?.at(-1)).toMatchObject({
  174 |     invoice_id: id,
  175 |     to_branch: "Warehouse",
  176 |     reason: "Correct the delivery location",
  177 |   });
  178 |   const appended = after.ledger.slice(before.ledger.length);
  179 |   expect(appended).toHaveLength(2);
  180 |   expect(Decimal.sum(...appended.map((entry) => entry.amount)).toFixed(2)).toBe(
  181 |     "0.00",
  182 |   );
  183 |   await page.goto("/#received");
  184 |   await page
  185 |     .getByRole("textbox", { name: "Search Received", exact: true })
  186 |     .fill(source.number);
  187 |   const warehouseLocation = page
  188 |     .locator(".received-table")
  189 |     .getByText("Warehouse", { exact: true })
  190 |     .first();
  191 |   if (!(await warehouseLocation.isVisible()))
  192 |     await page.locator(".received-table .table-details-toggle").first().click();
  193 |   await expect(warehouseLocation).toBeVisible();
  194 |   await page.reload();
  195 |   expect(
  196 |     (await saved(page)).invoice_location_corrections?.at(-1)?.to_branch,
  197 |   ).toBe("Warehouse");
  198 | });
  199 | 
  200 | test("invoice changed regular cost defaults to calculated and explicit Keep preserves the approved price on posting", async ({
  201 |   page,
  202 | }) => {
  203 |   await signIn(page, "Supervisor");
  204 |   const editor = await openC8PriceDialog(page, "0002");
  205 |   await editor.getByRole("radio", { name: /^New regular price/ }).check();
  206 |   await editor.getByLabel("Price", { exact: true }).fill("2.79");
  207 |   await editor
  208 |     .getByRole("checkbox", {
  209 |       name: "Add regular labels to the label waitlist",
  210 |       exact: true,
  211 |     })
  212 |     .uncheck();
  213 |   await editor
  214 |     .getByRole("button", { name: "Save new price", exact: true })
  215 |     .click();
  216 |   await expect(editor).not.toBeVisible();
  217 |   await expect
  218 |     .poll(
  219 |       async () =>
  220 |         (await saved(page)).products.find((entry) => entry.code === "0002")
  221 |           ?.manual_prices?.all.price,
  222 |     )
  223 |     .toBe("2.79");
  224 |   await manualInvoice(page);
  225 |   const line = page.locator(".invoice-line").first();
  226 |   await line.getByLabel("Unit cost before tax", { exact: true }).fill("1.4000");
  227 |   await expect(
  228 |     line.getByText("Manual price", { exact: true }).first(),
  229 |   ).toBeVisible();
  230 |   await expect(
  231 |     line.getByRole("checkbox", {
  232 |       name: "Confirm this invoice line",
  233 |       exact: true,
  234 |     }),
  235 |   ).toBeEnabled();
  236 |   await expect(
  237 |     line.getByRole("button", {
  238 |       name: "Use the new calculated price $1.99",
  239 |       exact: true,
  240 |     }),
> 241 |   ).toHaveAttribute("aria-pressed", "true");
      |     ^ Error: expect(locator).toHaveAttribute(expected) failed
  242 |   await line.getByRole("button", { name: "Keep $2.79", exact: true }).click();
  243 |   await line.getByRole("button", { name: "No", exact: true }).click();
  244 |   await line
  245 |     .getByRole("checkbox", { name: "Confirm this invoice line", exact: true })
  246 |     .click();
  247 |   await expect(line.getByText("Confirmed", { exact: true })).toBeVisible();
  248 |   await expect(
  249 |     page.getByRole("button", { name: "Post invoice", exact: true }),
  250 |   ).toBeEnabled();
  251 |   await page.getByRole("button", { name: "Post invoice", exact: true }).click();
  252 |   await page
  253 |     .getByRole("dialog", { name: "Post invoice", exact: true })
  254 |     .getByRole("button", { name: "Post invoice", exact: true })
  255 |     .click();
  256 |   await expect
  257 |     .poll(async () => (await saved(page)).invoice.status)
  258 |     .toBe("posted");
  259 |   const after = await saved(page);
  260 |   const product = after.products.find((product) => product.code === "0002")!;
  261 |   expect(product.selling_price).toBe("2.79");
  262 |   expect(product.manual_prices?.all.price).toBe("2.79");
  263 |   expect(after.invoice.lines[0]).toMatchObject({
  264 |     manual_price_decision: "keep",
  265 |     calculated_selling_price: "1.99",
  266 |     current_selling_price: "2.79",
  267 |   });
  268 |   expect(
  269 |     after.approvals.filter(
  270 |       (approval) => approval.source_invoice_id === after.invoice.id,
  271 |     ),
  272 |   ).toEqual([
  273 |     expect.objectContaining({
  274 |       type: "price_change",
  275 |       product_code: "0002",
  276 |       status: "pending",
  277 |       current_price: "2.79",
  278 |       proposed_price: "1.99",
  279 |       unit_cost: "1.4000",
  280 |       manual_price_review: expect.objectContaining({
  281 |         kept_price: "2.79",
  282 |         calculated_price: "1.99",
  283 |         receiver_recommendation: "keep",
  284 |       }),
  285 |     }),
  286 |   ]);
  287 | });
  288 | 
```