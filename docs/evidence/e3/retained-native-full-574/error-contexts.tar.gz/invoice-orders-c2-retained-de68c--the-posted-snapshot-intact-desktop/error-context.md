# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: invoice-orders-c2.spec.ts >> retained case quote bills exactly, remembers the pack and leaves the posted snapshot intact
- Location: tests/invoice-orders-c2.spec.ts:74:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('.invoice-line').first().locator('.invoice-pack-equation')
Expected substring: "500 × 12 = 6000"
Received string:    "0.083333333333333333333500 × 12 = 1 unit"
Timeout: 5000ms

Call log:
  - Expect "toContainText" locator('.invoice-line').first().locator('.invoice-pack-equation') with timeout 5000ms
  - waiting for locator('.invoice-line').first().locator('.invoice-pack-equation')
    14 × locator resolved to <p class="invoice-pack-equation muted">…</p>
       - unexpected value "0.083333333333333333333500 × 12 = 1 unit"

```

```yaml
- paragraph: 0.083333333333333333333500 × 12 = 1 unit
```

# Test source

```ts
  1   | import { readCanonicalBusinessEvidence } from "./business-evidence";
  2   | import { expect, test, type Page } from "@playwright/test";
  3   | import Decimal from "decimal.js";
  4   | import { chooseOption, invoiceImage, signIn } from "./helpers";
  5   | import type { DemoState } from "../src/types";
  6   | import { openC8PriceDialog } from "../scripts/capture-c8-proof.mjs";
  7   | 
  8   | test.setTimeout(60000);
  9   | const stored = (page: Page): Promise<DemoState> =>
  10  |   readCanonicalBusinessEvidence(page).then((canonicalState) =>
  11  |     JSON.parse(JSON.stringify(canonicalState)!),
  12  |   );
  13  | 
  14  | async function rememberedPack(page: Page) {
  15  |   await page.goto(
  16  |     `/#suppliers?name=${encodeURIComponent("Fresh Valley Foods")}`,
  17  |   );
  18  |   await page.getByRole("tab", { name: "Supplier items", exact: true }).click();
  19  |   const row = page
  20  |     .locator(".supplier-items-table tbody tr")
  21  |     .filter({ hasText: "Canned Fava Beans" })
  22  |     .first();
  23  |   await row.getByRole("button", { name: "Edit", exact: true }).click();
  24  |   const dialog = page.getByRole("dialog", { name: "Edit item", exact: true });
  25  |   await dialog.getByLabel("Units per case", { exact: true }).fill("12");
  26  |   await dialog.getByRole("button", { name: "Save item", exact: true }).click();
  27  |   await expect(dialog).not.toBeVisible();
  28  | }
  29  | 
  30  | async function manual(page: Page) {
  31  |   await page.goto("/#invoices");
  32  |   await page.getByRole("button", { name: "New invoice", exact: true }).click();
  33  |   await page.getByRole("button", { name: "Manual entry", exact: true }).click();
  34  |   await page
  35  |     .locator("#invoice-details-fields")
  36  |     .getByLabel("Supplier", { exact: true })
  37  |     .click();
  38  |   await page
  39  |     .getByRole("listbox", { name: "Supplier", exact: true })
  40  |     .getByRole("option", { name: /Fresh Valley Foods/ })
  41  |     .click();
  42  |   await page.getByRole("button", { name: "Add line", exact: true }).click();
  43  |   await page
  44  |     .getByLabel("Upload a PDF or photo", { exact: true })
  45  |     .setInputFiles(invoiceImage);
  46  |   await expect(page.locator(".invoice-line")).toHaveCount(1);
  47  |   return page.locator(".invoice-line").first();
  48  | }
  49  | 
  50  | async function confirmNoDate(page: Page) {
  51  |   const line = page.locator(".invoice-line").first();
  52  |   await line.getByRole("button", { name: "No", exact: true }).click();
  53  |   await line
  54  |     .getByRole("checkbox", { name: "Confirm this invoice line", exact: true })
  55  |     .click();
  56  |   await expect(line.getByText("Confirmed", { exact: true })).toBeVisible();
  57  | }
  58  | 
  59  | async function post(page: Page) {
  60  |   const button = page.getByRole("button", {
  61  |     name: "Post invoice",
  62  |     exact: true,
  63  |   });
  64  |   await expect(button).toBeEnabled();
  65  |   await button.click();
  66  |   await page
  67  |     .getByRole("dialog", { name: "Post invoice", exact: true })
  68  |     .getByRole("button", { name: "Post invoice", exact: true })
  69  |     .click();
  70  |   await expect(button).toHaveCount(0);
  71  |   expect((await stored(page)).invoice.status).toBe("posted");
  72  | }
  73  | 
  74  | test("retained case quote bills exactly, remembers the pack and leaves the posted snapshot intact", async ({
  75  |   page,
  76  | }) => {
  77  |   await signIn(page, "Supervisor");
  78  |   await rememberedPack(page);
  79  |   const line = await manual(page);
  80  |   await expect(line.getByLabel("Units per case", { exact: true })).toHaveValue(
  81  |     "12",
  82  |   );
  83  |   await chooseOption(
  84  |     page,
  85  |     line.getByLabel("Quantity unit", { exact: true }),
  86  |     "cases",
  87  |     "Cases",
  88  |   );
  89  |   await line.getByLabel("Invoiced", { exact: true }).fill("500");
  90  |   await line.getByLabel("Case cost before tax", { exact: true }).fill("19.99");
  91  |   await expect(
  92  |     line.getByLabel("Unit cost before tax", { exact: true }),
  93  |   ).toHaveValue("1.6658");
> 94  |   await expect(line.locator(".invoice-pack-equation")).toContainText(
      |                                                        ^ Error: expect(locator).toContainText(expected) failed
  95  |     "500 × 12 = 6000",
  96  |   );
  97  |   await confirmNoDate(page);
  98  |   await post(page);
  99  |   const after = await stored(page);
  100 |   expect(after.invoice).toMatchObject({
  101 |     subtotal: "9995.00",
  102 |     final_total: "9995.00",
  103 |     payable_after_open_shorts: "9995.00",
  104 |   });
  105 |   expect(after.invoice.lines[0]).toMatchObject({
  106 |     units_per_case: 12,
  107 |     quantity_unit: "cases",
  108 |     quantity_entered: "500",
  109 |     qty_invoiced: 6000,
  110 |     unit_cost_before_tax: "1.6658",
  111 |     case_cost_before_tax: "19.99",
  112 |   });
  113 |   expect(
  114 |     Decimal.sum(
  115 |       ...after.ledger
  116 |         .filter((entry) => entry.invoice_id === after.invoice.id)
  117 |         .map((entry) => entry.amount),
  118 |     ).toFixed(2),
  119 |   ).toBe("9995.00");
  120 |   await page.goto("/#received");
  121 |   await page
  122 |     .getByRole("textbox", { name: "Search Received", exact: true })
  123 |     .fill(after.invoice.supplier_invoice_number);
  124 |   await expect(page.locator(".received-table")).toContainText("500 cases");
  125 |   await page.reload();
  126 |   expect((await stored(page)).invoice.lines[0].units_per_case).toBe(12);
  127 | });
  128 | 
  129 | test("order comparison requires explicit extra and changed-cost decisions, then preserves one alert and accepted receipts", async ({
  130 |   page,
  131 | }) => {
  132 |   await signIn(page, "Supervisor");
  133 |   await rememberedPack(page);
  134 |   await page.goto("/#orders");
  135 |   await page.getByRole("button", { name: "New order", exact: true }).click();
  136 |   const form = page.getByRole("form", { name: "New order", exact: true });
  137 |   await chooseOption(
  138 |     page,
  139 |     form.getByLabel("Supplier", { exact: true }),
  140 |     "Fresh Valley Foods",
  141 |   );
  142 |   await form
  143 |     .getByRole("textbox", { name: /^Cases — Canned Fava Beans/ })
  144 |     .fill("1");
  145 |   const expectedCost = form.getByRole("textbox", {
  146 |     name: /^Expected unit cost — Canned Fava Beans/,
  147 |   });
  148 |   if (!(await expectedCost.count()))
  149 |     await form
  150 |       .locator("tbody tr")
  151 |       .filter({ hasText: "Canned Fava Beans" })
  152 |       .getByRole("button", { name: "Show details", exact: true })
  153 |       .click();
  154 |   await form
  155 |     .getByRole("textbox", { name: /^Expected unit cost — Canned Fava Beans/ })
  156 |     .fill("0.9800");
  157 |   await form.getByRole("button", { name: "Place order", exact: true }).click();
  158 |   const before = await stored(page);
  159 |   const order = before.orders!.at(-1)!;
  160 |   expect(order.status).toBe("ordered");
  161 |   const line = await manual(page);
  162 |   await line.getByLabel("Invoiced", { exact: true }).fill("18");
  163 |   await line.getByLabel("Unit cost before tax", { exact: true }).fill("1.1000");
  164 |   const comparison = page.locator(".invoice-order-card");
  165 |   await chooseOption(
  166 |     page,
  167 |     comparison.getByLabel("Order (optional)", { exact: true }),
  168 |     order.id,
  169 |     `${order.reference} · ${order.date}`,
  170 |   );
  171 |   await page.getByRole("button", { name: "Post invoice", exact: true }).click();
  172 |   await expect(
  173 |     page.getByRole("link", {
  174 |       name: "Choose a decision for every order difference before posting.",
  175 |       exact: true,
  176 |     }),
  177 |   ).toBeVisible();
  178 |   const row = comparison.locator('tr[data-invoice-line="0"]');
  179 |   const refusal = comparison.getByRole("button", {
  180 |     name: "Refused / sent back with the driver",
  181 |     exact: true,
  182 |   });
  183 |   if (!(await refusal.count()))
  184 |     await row
  185 |       .getByRole("button", { name: "Show details", exact: true })
  186 |       .click();
  187 |   await comparison
  188 |     .getByRole("button", {
  189 |       name: "Refused / sent back with the driver",
  190 |       exact: true,
  191 |     })
  192 |     .click();
  193 |   await comparison
  194 |     .getByRole("button", { name: "Accept new cost", exact: true })
```