# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: notebook-edit-b.spec.ts >> an already-open worker editor expires after ten seconds and Cancel keeps the saved record intact
- Location: tests/notebook-edit-b.spec.ts:110:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('form', { name: 'Edit note', exact: true }).getByRole('alert')
Expected substring: "Ask the Supervisor"
Received string:    "The ten-second edit window has ended. Ask an Owner or Manager to edit this note."
Timeout: 5000ms

Call log:
  - Expect "toContainText" getByRole('form', { name: 'Edit note', exact: true }).getByRole('alert') with timeout 5000ms
  - waiting for getByRole('form', { name: 'Edit note', exact: true }).getByRole('alert')
    14 × locator resolved to <div role="alert" class="banner danger">The ten-second edit window has ended. Ask an Owne…</div>
       - unexpected value "The ten-second edit window has ended. Ask an Owner or Manager to edit this note."

```

```yaml
- alert: The ten-second edit window has ended. Ask an Owner or Manager to edit this note.
```

# Test source

```ts
  38  |   await page.clock.runFor(9000);
  39  |   await page.getByRole("menuitem", { name: "Edit note", exact: true }).click();
  40  |   const editor = page.getByRole("form", { name: "Edit note", exact: true });
  41  |   await editor
  42  |     .getByLabel("Note", { exact: true })
  43  |     .fill("Afternoon check corrected");
  44  |   await editor.getByLabel("Measurement (°C)", { exact: true }).fill("3.6");
  45  |   await editor
  46  |     .getByRole("button", { name: "Save changes", exact: true })
  47  |     .click();
  48  |   await expect(card).toContainText("Afternoon check corrected");
  49  |   const corrected = await storedEntry(page, "Afternoon check corrected");
  50  |   expect(corrected).toMatchObject({
  51  |     id: original.id,
  52  |     by: original.by,
  53  |     branch: original.branch,
  54  |     company_id: original.company_id,
  55  |     created_at: original.created_at,
  56  |     status: original.status,
  57  |     notify_supervisor: original.notify_supervisor,
  58  |     measurement_unit: "°C",
  59  |   });
  60  |   await page.clock.runFor(1001);
  61  |   await expect(
  62  |     card.getByRole("button", { name: "More actions", exact: true }),
  63  |   ).toHaveCount(0);
  64  | 
  65  |   await signIn(page, "Supervisor");
  66  |   await deliTab(page);
  67  |   await card.getByRole("button", { name: "More actions", exact: true }).click();
  68  |   await page.getByRole("menuitem", { name: "Edit note", exact: true }).click();
  69  |   await page
  70  |     .getByRole("form", { name: "Edit note", exact: true })
  71  |     .getByLabel("Note", { exact: true })
  72  |     .fill("Supervisor verified fridge check");
  73  |   await page.getByRole("button", { name: "Save changes", exact: true }).click();
  74  |   await expect(card).toContainText("Supervisor verified fridge check");
  75  |   await expect(page.getByRole("status")).toHaveText("Saved changes.");
  76  |   await setLanguage(page, "fa");
  77  |   await expect(page.getByRole("status")).toHaveText("تغییرات ذخیره شد.");
  78  |   await setLanguage(page, "en");
  79  |   await expect(page.getByRole("status")).toHaveText("Saved changes.");
  80  |   const verified = await storedEntry(page, "Supervisor verified fridge check");
  81  |   expect(verified).toMatchObject({
  82  |     id: original.id,
  83  |     by: original.by,
  84  |     created_at: original.created_at,
  85  |     measurement: "3.6",
  86  |     measurement_unit: "°C",
  87  |   });
  88  |   const audit = await readCanonicalBusinessEvidence(page).then(
  89  |     (canonicalState) =>
  90  |       JSON.parse(JSON.stringify(canonicalState)!).activity.filter(
  91  |         (entry: { action: string }) =>
  92  |           entry.action === "notebook_entry_updated",
  93  |       ),
  94  |   );
  95  |   expect(audit).toHaveLength(2);
  96  |   expect(audit[0]).toMatchObject({
  97  |     by: configuredPersonExpectation("manager").name_en,
  98  |     before: { text: "Afternoon check corrected" },
  99  |     after: { text: "Supervisor verified fridge check" },
  100 |     reversible: true,
  101 |   });
  102 |   expect(audit[1]).toMatchObject({
  103 |     by: configuredPersonExpectation("ny-floor").name_en,
  104 |     before: { text: "Afternoon fridge check" },
  105 |     after: { text: "Afternoon check corrected" },
  106 |     reversible: true,
  107 |   });
  108 | });
  109 | 
  110 | test("an already-open worker editor expires after ten seconds and Cancel keeps the saved record intact", async ({
  111 |   page,
  112 | }) => {
  113 |   await signIn(page, "Floor Worker");
  114 |   await page.clock.install();
  115 |   await page.clock.pauseAt(new Date(Date.now() + 1000));
  116 |   await deliTab(page);
  117 |   await page.getByRole("button", { name: "Add note", exact: true }).click();
  118 |   await page.getByLabel("Note", { exact: true }).fill("Unchanged saved check");
  119 |   await page.getByRole("button", { name: "Save note", exact: true }).click();
  120 |   const original = await storedEntry(page, "Unchanged saved check");
  121 |   await page
  122 |     .locator(`[data-notebook-entry="${original.id}"]`)
  123 |     .getByRole("button", { name: "More actions", exact: true })
  124 |     .click();
  125 |   await page.getByRole("menuitem", { name: "Edit note", exact: true }).click();
  126 |   const editor = page.getByRole("form", { name: "Edit note", exact: true });
  127 |   await editor.getByLabel("Note", { exact: true }).fill("Unsaved correction");
  128 |   await page.clock.runFor(10001);
  129 |   await expect(
  130 |     editor.getByRole("button", { name: "Save changes", exact: true }),
  131 |   ).toBeEnabled();
  132 |   await expect(editor.getByRole("status")).toContainText(
  133 |     "This note can no longer be edited.",
  134 |   );
  135 |   await editor
  136 |     .getByRole("button", { name: "Save changes", exact: true })
  137 |     .click();
> 138 |   await expect(editor.getByRole("alert")).toContainText("Ask the Supervisor");
      |                                           ^ Error: expect(locator).toContainText(expected) failed
  139 |   expect(await storedEntry(page, "Unchanged saved check")).toEqual(original);
  140 |   await editor.getByRole("button", { name: "Cancel", exact: true }).click();
  141 |   expect(await storedEntry(page, "Unchanged saved check")).toEqual(original);
  142 |   await expect(
  143 |     page.getByRole("form", { name: "Edit note", exact: true }),
  144 |   ).toHaveCount(0);
  145 | });
  146 | 
```