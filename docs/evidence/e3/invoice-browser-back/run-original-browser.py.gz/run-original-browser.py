from pathlib import Path
import subprocess,os,json,time,hashlib,signal,urllib.request,urllib.parse,socket
p=Path('/tmp/e3-ci-first-two-proof');candidate=p/'candidate';proto=candidate/'prototype';env=dict(os.environ);env['PATH']='/workspace/scratch/node-install/node-v22.23.3-linux-x64/bin:'+env['PATH'];env['PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH']='/usr/bin/chromium';assert not env.get('CI')
def sha(b):return hashlib.sha256(b).hexdigest()
def save(name,value):(p/name).write_text(json.dumps(value,indent=2)+'\n')
def pins():return {str(q.relative_to(candidate)):sha(q.read_bytes()) for root in ['prototype/src','prototype/tests','seed'] for q in sorted((candidate/root).rglob('*')) if q.is_file()}
original=json.loads((p/'final-candidate-pins.json').read_text());assert pins()==original
with socket.socket() as sock:sock.bind(('127.0.0.1',5197))
base='http://127.0.0.1:5197';adapter=proto/'playwright.ci-triage.config.ts';adapter.write_text('import base from "./playwright.config.ts";\nexport default { ...base, use: { ...base.use, baseURL: '+json.dumps(base)+' }, webServer: undefined };\n')
save('browser-adapter.json',{'path':str(adapter),'sha256':sha(adapter.read_bytes()),'changes':['owned preview baseURL','equivalent owned webServer'],'unchanged':['original tests and assertions','original desktop and phone project definitions','original per-case and assertion budgets','original native storage/authority behavior','original local retries0'],'workers':1})
dist={str(q.relative_to(proto/'dist')):sha(q.read_bytes()) for q in sorted((proto/'dist').rglob('*')) if q.is_file()};save('dist-pins.json',dist)
def served():
 result={}
 for name,h in dist.items():
  with urllib.request.urlopen(base+'/'+urllib.parse.quote(name),timeout=10) as response:
   b=response.read();assert response.status==200 and sha(b)==h;result[name]={'sha256':h,'status':response.status}
 return result
log=(p/'preview.log').open('w');preview=subprocess.Popen(['node','node_modules/vite/bin/vite.js','preview','--host','127.0.0.1','--port','5197','--strictPort'],cwd=proto,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);save('owned-preview.json',{'pid':preview.pid,'baseURL':base})
result={}
try:
 deadline=time.monotonic()+30
 while True:
  assert preview.poll() is None
  try:
   with urllib.request.urlopen(base,timeout=1) as r:
    if r.status==200:break
  except Exception:
   if time.monotonic()>deadline:raise
   time.sleep(.1)
 before=served();save('http-before.json',before)
 cmd=['node','node_modules/@playwright/test/cli.js','test','tests/catalog-a2.spec.ts','tests/c3-invoices.spec.ts','--grep','Lookup Change price defaults to all stores|posted invoice Columns persist','--config',str(adapter),'--workers=1','--reporter=line,json','--output',str(p/'browser-output')]
 env['PLAYWRIGHT_JSON_OUTPUT_NAME']=str(p/'original-browser.json');t=time.time()
 with (p/'original-browser.log').open('w') as f:r=subprocess.run(cmd,cwd=proto,env=env,stdout=f,stderr=subprocess.STDOUT)
 result={'command':cmd,'actual_exit_code':r.returncode,'seconds':time.time()-t,'source_unchanged':pins()==original,'dist_unchanged':dist=={str(q.relative_to(proto/'dist')):sha(q.read_bytes()) for q in sorted((proto/'dist').rglob('*')) if q.is_file()},'http_unchanged':served()==before,'served_assets':len(dist)}
 save('original-browser-result.json',result);print(json.dumps(result));print((p/'original-browser.log').read_text()[-12000:])
finally:
 if preview.poll() is None:
  os.killpg(preview.pid,signal.SIGTERM)
  try:preview.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(preview.pid,signal.SIGKILL);preview.wait()
 log.close()
