from pathlib import Path
import subprocess,json,os,time,hashlib
r=Path('/workspace/Supermarket-Inventory');p=Path('/tmp/e3-final-full-application-v2');p.mkdir(exist_ok=False);env=dict(os.environ);env['PATH']='/workspace/scratch/node-install/node-v22.23.3-linux-x64/bin:'+env['PATH']
names=[n for n in subprocess.check_output(['git','ls-files'],cwd=r,text=True).splitlines()if n.startswith(('prototype/','seed/','assets/'))or n in ['AGENTS.md','docs/return-policy.md']]
pins=lambda:{n:hashlib.sha256((r/n).read_bytes()).hexdigest()for n in names};before=pins();commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();assert commit=='f1545dfb4da4e0ea1a4059dcdd3aa1d59e231f76'
observer=Path('/tmp/e3-postprint-diagnostic/observer.mjs').read_text().replace('/tmp/e3-postprint-diagnostic/global-errors.json',str(p/'global-errors.json'));(p/'observer.mjs').write_text(observer)
(p/'start.json').write_text(json.dumps({'commit':commit,'source':before,'node':'22.23.3','workers':2},indent=2)+'\n');checks=[]
commands=[('app',['node','node_modules/vitest/vitest.mjs','run','--maxWorkers=2','--reporter=default','--reporter=json','--reporter='+str(p/'observer.mjs'),'--outputFile='+str(p/'app.json')]),('sdk',['npm','run','test:sdk','--','--maxWorkers=2','--reporter=default','--reporter=json','--outputFile='+str(p/'sdk.json')])]
for name,cmd in commands:
 start=time.time()
 with(p/(name+'.log')).open('w')as log:done=subprocess.run(cmd,cwd=r/'prototype',env=env,stdout=log,stderr=subprocess.STDOUT)
 checks.append({'name':name,'command':cmd,'actual_exit_code':done.returncode,'seconds':time.time()-start,'source_unchanged':pins()==before});(p/'progress.json').write_text(json.dumps(checks,indent=2)+'\n');print(json.dumps(checks[-1]),flush=True)
result={'commit':commit,'checks':checks,'source_unchanged':pins()==before};(p/'result.json').write_text(json.dumps(result,indent=2)+'\n');raise SystemExit(0 if result['source_unchanged'] and all(c['actual_exit_code']==0 and c['source_unchanged']for c in checks)else 1)
