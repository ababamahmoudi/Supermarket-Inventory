from pathlib import Path
import subprocess,json,os,time,hashlib,tarfile,sys
repo=Path('/workspace/Supermarket-Inventory');p=Path('/tmp/e3-brand-final-adapted-validation');r=p/'source'
env=dict(os.environ);env['PATH']='/workspace/scratch/node-install/node-v22.23.3-linux-x64/bin:'+env['PATH']
def save(name,value):
 (p/name).write_text(json.dumps(value,indent=2)+'\n')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
if sys.argv[1]=='prepare':
 p.mkdir(exist_ok=False);r.mkdir();commit='a6c66dc0d14e74c3d717f0ce355a9656ec924732'
 assert commit=='a6c66dc0d14e74c3d717f0ce355a9656ec924732'
 with(p/'exact-source.tar').open('wb')as f:subprocess.run(['git','archive','--format=tar',commit],cwd=repo,stdout=f,check=True)
 with tarfile.open(p/'exact-source.tar')as t:t.extractall(r,filter='data')
 (r/'prototype/node_modules').symlink_to(repo/'prototype/node_modules',target_is_directory=True)
 adapter=Path('/tmp/brand-css-readiness-backports-formatted-final/e2/candidate/prototype/vitest-brand-backport-proof.config.ts');(r/'prototype/vitest-brand-archive-proof.config.ts').write_bytes(adapter.read_bytes())
 save('private-adapter.json',{'reason':'Exact Git archive uses genuine stable shared dependency directory outside the normal archive fs.allow; add only that directory to avoid Denied PDF worker import. No test, module, timeout, assertion, mock or production override.','path':'prototype/vitest-brand-archive-proof.config.ts','sha256':sha(adapter),'source':str(adapter),'tracked':False,'root_head_at_prepare':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()})
 names=[n for n in subprocess.check_output(['git','ls-files'],cwd=repo,text=True).splitlines()if n.startswith(('prototype/','seed/','assets/'))or n in ['AGENTS.md','docs/return-policy.md']]
 pins={n:sha(r/n)for n in names};assert all(pins[n]==sha(repo/n)for n in names)
 old=json.loads(Path('/tmp/e3-persian-final-application/start.json').read_text());changed=[n for n in names if old['source'].get(n)!=pins[n]];assert changed==['prototype/src/store.test.tsx'],changed
 observer=Path('/tmp/e3-postprint-diagnostic/observer.mjs').read_text().replace('/tmp/e3-postprint-diagnostic/global-errors.json',str(p/'global-errors.json'));(p/'observer.mjs').write_text(observer)
 save('start.json',{'commit':commit,'source':pins,'changed_since_0786':changed,'production_unchanged_since_0786':True,'archive_sha256':sha(p/'exact-source.tar'),'workers':2,'node':'22.23.3'})
 print(json.dumps({'prepared':commit,'inputs':len(pins),'changed':changed}),flush=True)
else:
 before=json.loads((p/'start.json').read_text());pins=lambda:{n:sha(r/n)for n in before['source']};assert pins()==before['source'];stage=sys.argv[1]
 if stage=='lint-build':commands=[('lint',['npm','run','lint']),('build',['npm','run','build'])]
 elif stage=='application':commands=[('app',['node','node_modules/vitest/vitest.mjs','run','--config','vitest-brand-archive-proof.config.ts','--maxWorkers=2','--reporter=default','--reporter=json','--reporter='+str(p/'observer.mjs'),'--outputFile='+str(p/'app.json')]),('sdk',['npm','run','test:sdk','--','--maxWorkers=2','--reporter=default','--reporter=json','--outputFile='+str(p/'sdk.json')])]
 else:raise ValueError(stage)
 checks=[]
 for name,cmd in commands:
  started=time.time()
  with(p/(name+'.log')).open('w')as log:done=subprocess.run(cmd,cwd=r/'prototype',env=env,stdout=log,stderr=subprocess.STDOUT)
  check={'name':name,'command':cmd,'actual_exit_code':done.returncode,'seconds':time.time()-started,'source_unchanged':pins()==before['source']};checks.append(check);save(name+'-execution.json',check);print(json.dumps(check),flush=True)
  if done.returncode:break
 result={'commit':before['commit'],'checks':checks,'source_unchanged':pins()==before['source']}
 if stage=='lint-build'and len(checks)==2 and checks[-1]['actual_exit_code']==0:
  dist={str(f.relative_to(r/'prototype/dist')):sha(f)for f in sorted((r/'prototype/dist').rglob('*'))if f.is_file()};save('dist-pins.json',dist);old=json.loads(Path('/tmp/e3-final-shared-persian-unit-native/dist-pins.json').read_text());result['fresh_dist_files']=len(dist);result['dist_identical_to_0786_native']=dist==old;assert result['dist_identical_to_0786_native']
 save(stage+'-result.json',result)
 raise SystemExit(0 if len(checks)==len(commands)and result['source_unchanged']and all(c['actual_exit_code']==0 for c in checks)else 1)
