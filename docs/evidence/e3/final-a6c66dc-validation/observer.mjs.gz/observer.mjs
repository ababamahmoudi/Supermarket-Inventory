import { writeFileSync } from 'node:fs';
const out='/tmp/e3-brand-final-adapted-validation/global-errors.json';
function save(value) {
 const seen=new WeakSet();
 writeFileSync(out,JSON.stringify(value,(_,v)=>{
  if(v&&typeof v==='object'){if(seen.has(v))return '[Circular]';seen.add(v);}
  return v;
 },2)+'\n');
}
export default class ErrorObserver {
 onInit(ctx) { this.ctx=ctx; process.once('exit',(code)=>{
  const errors=this.ctx.state.getUnhandledErrors?.() ?? [];
  save({phase:'process-exit',code,errors,atRunEnd:this.result});
 }); }
 onTestRunEnd(modules,errors,reason) {
  this.result={phase:'onTestRunEnd',reason,errors,moduleCount:modules.length};
  save(this.result);
 }
}
