from pathlib import Path
import difflib,gzip,hashlib,json,subprocess
ROOT=Path('/workspace/Supermarket-Inventory');STAGE=Path('/tmp/brand-css-readiness-source');PACK=Path('/tmp/brand-css-readiness-proof-packet');FILE='prototype/src/store.test.tsx';COMMIT='0786ea262b6ebdf573cd02f2b56479952633ee21';CI=Path('/tmp/final-ci-0786/20261015T211000Z')
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(ROOT),*args])
def dump(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
baseline=git('show',COMMIT+':'+FILE);text=baseline.decode();old='''    expect(style.getPropertyValue("--company-primary")).toBe("#0F766E");
    expect(style.getPropertyValue("--company-dark-primary")).toBe("#5EEAD4");
    expect(style.getPropertyValue("--company-kpi-accent-end")).toBe("#0D9488");''';assert text.count(old)==1
new='''    await waitFor(() => {
      expect(style.getPropertyValue("--company-primary")).toBe("#0F766E");
      expect(style.getPropertyValue("--company-dark-primary")).toBe("#5EEAD4");
      expect(style.getPropertyValue("--company-kpi-accent-end")).toBe("#0D9488");
    });''';text=text.replace(old,new,1);assert text.replace(new,old,1).encode()==baseline
refs={}
for ref in ['HEAD','feat/prototype-e1-location-roles','feat/prototype-e2-price-updates']:
 commit=git('rev-parse',ref).decode().strip();actual=git('show',commit+':'+FILE);assert actual==baseline;refs[ref]={'commit':commit,'fixture_sha256':sha(actual)}
assert (ROOT/FILE).read_bytes()==baseline
(STAGE/FILE).parent.mkdir(parents=True,exist_ok=True);(STAGE/FILE).write_text(text);dump(STAGE/'manifest.json',{'baseline_commit':COMMIT,'files':[{'path':FILE,'source':str(STAGE/FILE),'baseline_sha256':sha(baseline),'sha256':sha(text.encode())}]})
d=PACK/'docs/evidence/e3/brand-css-readiness';d.mkdir(parents=True,exist_ok=False);raw={}
def comp(name,path):
 b=Path(path).read_bytes();z=gzip.compress(b,mtime=0);f=d/(name+'.gz');f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(z);raw[name+'.gz']={'sha256':sha(z),'bytes':len(z),'original_sha256':sha(b),'original_bytes':len(b)}
for name in ['check-116670025819-annotations-1.json','run-38806913395-jobs.json']:
 comp('ci-originals/'+name,CI/name)
comp('candidate-store.test.tsx',STAGE/FILE)
patch=''.join(difflib.unified_diff(baseline.decode().splitlines(keepends=True),text.splitlines(keepends=True),fromfile='baseline/'+FILE,tofile='css-readiness/'+FILE));z=gzip.compress(patch.encode(),mtime=0);(d/'fixture-only.patch.gz').write_bytes(z);raw['fixture-only.patch.gz']={'sha256':sha(z),'bytes':len(z),'original_sha256':sha(patch.encode()),'original_bytes':len(patch.encode())}
comp('stage-candidate.py',Path('/tmp/stage-brand-css-readiness.py'))
annotation=json.loads((CI/'check-116670025819-annotations-1.json').read_text())['body'];failure=[a for a in annotation if a.get('path')==FILE and 'company configured' in a.get('title','')];assert len(failure)==1
jobs=json.loads((CI/'run-38806913395-jobs.json').read_text())['body']['jobs'];job=next(j for j in jobs if 'Prototype lint' in j['name'])
diag={'ci_source_commit':COMMIT,'ci_run_id':38806913395,'ci_actual_failure':failure[0],'ci_unit_step':'failure','ci_build_step':'skipped','ci_browser_step':'skipped','separate_from_job_timeout':True,'source_file':FILE,'baseline_sha256':sha(baseline),'candidate_sha256':sha(text.encode()),'identical_baseline_file_refs':refs,'source_delta':'Only await existing waitFor around all three unchanged exact CSS property assertions.','default_waitFor_timeout_ms':1000,'show_helper_timeout_ms_unchanged':10000,'global_vitest_timeout_ms_unchanged':30000,'all_exact_color_values_and_matchers_unchanged':True,'other_file_bytes_unchanged':True,'new_timers_or_authority_result_mocks':False,'tracked_writes':False,'tests_or_builds_executed_for_candidate':False,'candidate_verification':'Pending: all heavy tests held while final native72 uses four workers.','causal_observation':'show() observes rendered auth stage leaving loading; actual branding properties are written separately in DemoProvider useEffect after snapshot config changes. Stage observation alone does not establish CSS publication.','causal_limit':'CI records only default color at assertion, not authStage/effect timings; exact scheduling and CPU/resource cause are unproven.','local_full_app_context':'Root reports exact0786 application1444/1444 CLI0 locally; it is separate from this actual CI failure and does not prove candidate verification.','raw_files':raw};dump(d/'diagnosis.json',diag)
readme='''# Company-brand CSS readiness: candidate and actual CI failure

Exact source `0786ea262b6ebdf573cd02f2b56479952633ee21`, PR CI run `38806913395`, failed the actual unit step in `store.test.tsx`: expected `--company-primary` **#0F766E**, received the default **#2B59C3**. Build and browser steps were skipped. This failure is separate from earlier 30-minute browser job cancellations. Original API annotation/job payloads are preserved unchanged here.

The fixture's `show()` waits for the rendered authentication stage to leave `loading`. `DemoProvider` writes branding properties on `document.documentElement.style` in a separate passive effect after its projected configuration changes. The former stage predicate does not guarantee that the CSS effect has published. The CI annotation does not capture exact stage/effect scheduling; no CPU cause or proven production fault is claimed.

The minimal candidate wraps **all three original exact color assertions together** in the existing `waitFor`. Values, property names and matchers remain unchanged: **#0F766E**, **#5EEAD4**, **#0D9488**. No timeout option is added: Testing Library's default **1,000 ms** remains; the existing `show()` 10,000 ms and Vitest 30,000 ms budgets are unchanged. There are no new imports, timers, mocks, authority/repository/result replacements or production changes. If the configured palette never appears, the unchanged exact assertions fail.

**Candidate tests/builds: Pending.** All heavy work is held while the four-worker final native verification runs. The original full local application pass and actual CI failure remain separate outcomes; this candidate has not been presented as verified. [Diagnosis and raw hashes](diagnosis.json) records source/ref fingerprints and current limits. Root is the sole applier; this staging task made no tracked edits.
''';(d/'README.md').write_text(readme)
files=[{'path':str(f.relative_to(PACK)),'source':str(f),'baseline_sha256':None,'sha256':sha(f.read_bytes())} for f in sorted(d.rglob('*')) if f.is_file()];dump(PACK/'manifest.json',{'baseline_commit':COMMIT,'files':files})
print(json.dumps({'source_manifest':str(STAGE/'manifest.json'),'source_manifest_sha256':sha((STAGE/'manifest.json').read_bytes()),'candidate_sha256':sha(text.encode()),'proof_manifest':str(PACK/'manifest.json'),'proof_manifest_sha256':sha((PACK/'manifest.json').read_bytes()),'candidate_tests':'Pending; not started','proof_files':len(files)}))
