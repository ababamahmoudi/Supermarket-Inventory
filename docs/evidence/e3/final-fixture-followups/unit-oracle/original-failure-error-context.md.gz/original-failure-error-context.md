# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: layout-proof-c6.spec.ts >> ordinary en Activity sizes stay together and an unmarked split is detected
- Location: tests/layout-proof-c6.spec.ts:152:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - complementary "Main menu" [ref=e5]:
    - generic [ref=e6]:
      - img "Super Arzon" [ref=e9]
      - generic [ref=e10]: Super Arzon
    - navigation "Pages" [ref=e11]:
      - generic [ref=e12]:
        - paragraph [ref=e13]: Daily
        - generic [ref=e14]:
          - link "Lookup" [ref=e15] [cursor=pointer]:
            - /url: "#lookup"
          - link "Invoices" [ref=e20] [cursor=pointer]:
            - /url: "#invoices"
          - link "Received" [ref=e25] [cursor=pointer]:
            - /url: "#received"
          - link "Returns" [ref=e32] [cursor=pointer]:
            - /url: "#returns"
          - link "Price updates" [ref=e37] [cursor=pointer]:
            - /url: "#price-updates"
          - link "Labels" [ref=e43] [cursor=pointer]:
            - /url: "#labels"
          - link "Date tracking" [ref=e48] [cursor=pointer]:
            - /url: "#expiry"
          - link "Notes" [ref=e53] [cursor=pointer]:
            - /url: "#notes"
            - generic [ref=e57]: "2"
          - link "Branch requests" [ref=e58] [cursor=pointer]:
            - /url: "#requests"
      - generic [ref=e63]:
        - paragraph [ref=e64]: Catalog
        - generic [ref=e65]:
          - link "Products" [ref=e66] [cursor=pointer]:
            - /url: "#products"
          - link "Offers" [ref=e72] [cursor=pointer]:
            - /url: "#offers"
          - link "Suppliers" [ref=e78] [cursor=pointer]:
            - /url: "#suppliers"
      - generic [ref=e84]:
        - paragraph [ref=e85]: Manager
        - generic [ref=e86]:
          - link "Dashboard" [ref=e87] [cursor=pointer]:
            - /url: "#dashboard"
          - link "Approvals" [ref=e94] [cursor=pointer]:
            - /url: "#approvals"
            - generic [ref=e99]: "3"
          - link "Alerts" [ref=e100] [cursor=pointer]:
            - /url: "#alerts"
            - generic [ref=e105]: "3"
          - link "Payables" [ref=e106] [cursor=pointer]:
            - /url: "#payables"
          - link "Orders" [ref=e110] [cursor=pointer]:
            - /url: "#orders"
      - generic [ref=e117]:
        - paragraph [ref=e118]: Admin
        - generic [ref=e119]:
          - link "Settings" [ref=e120] [cursor=pointer]:
            - /url: "#settings"
          - link "History" [ref=e125] [cursor=pointer]:
            - /url: "#history"
    - button "User menu" [ref=e132] [cursor=pointer]:
      - generic [ref=e133]:
        - generic [aria-hidden] [ref=e134]: DM
        - generic [ref=e135]:
          - strong [ref=e136]: Demo Manager
          - generic [ref=e137]: Manager
  - generic [ref=e138]:
    - banner [ref=e139]:
      - button "Collapse sidebar" [expanded] [ref=e140] [cursor=pointer]
      - navigation "Breadcrumbs" [ref=e144]:
        - link "North York" [ref=e145] [cursor=pointer]:
          - /url: "#dashboard"
        - link "Dashboard" [ref=e148] [cursor=pointer]:
          - /url: "#dashboard"
      - search [ref=e149]:
        - textbox "Search all products" [ref=e153]:
          - /placeholder: Search products
        - generic [aria-hidden] [ref=e154]: /
      - combobox "Location" [ref=e155] [cursor=pointer]:
        - generic [ref=e160]: North York
      - button "Switch to Persian" [ref=e163] [cursor=pointer]: فا
      - button "Switch to dark theme" [ref=e164] [cursor=pointer]
      - button "Comfortable text size" [ref=e167] [cursor=pointer]:
        - generic [aria-hidden] [ref=e168]: Aa
      - button "Notifications, 5 unread" [ref=e169] [cursor=pointer]:
        - generic [ref=e170]: "5"
      - button "Demo" [ref=e175] [cursor=pointer]
    - main [ref=e178]:
      - generic [ref=e179]:
        - generic [ref=e180]:
          - heading "Manager dashboard" [level=1] [ref=e181]
          - paragraph [ref=e182]: Your branch priorities, approvals, and recent activity.
        - button "Review approvals" [ref=e184] [cursor=pointer]
      - generic [ref=e185]:
        - generic [ref=e186]:
          - generic [ref=e187]:
            - 'button "Approvals waiting: 3" [ref=e188] [cursor=pointer]':
              - generic [ref=e189]: Approvals waiting
              - strong [ref=e195]: "3"
              - generic "1 price change · 1 new product" [ref=e196]
            - 'button "Open alerts: 3" [ref=e199] [cursor=pointer]':
              - generic [ref=e200]: Open alerts
              - strong [ref=e205]: "3"
              - generic "0 lower prices · 1 conflict" [ref=e206]
            - 'button "Open shorts: 0" [ref=e209] [cursor=pointer]':
              - generic [ref=e210]: Open shorts
              - strong [ref=e216]: "0"
              - generic "Items waiting for delivery" [ref=e217]
            - 'button "Expiring soon: 2" [ref=e220] [cursor=pointer]':
              - generic [ref=e221]: Expiring soon
              - strong [ref=e227]: "2"
              - generic "Within each product's reminder window" [ref=e228]
          - generic [ref=e231]:
            - generic [ref=e232]:
              - heading "Approvals queue" [level=2] [ref=e233]
              - generic [ref=e234]:
                - generic [ref=e235]:
                  - generic [ref=e236]:
                    - heading "Sunflower Oil 1.8 L روغن آفتابگردان ۱٫۸ لیتری" [level=3] [ref=e237]:
                      - generic [ref=e238]:
                        - strong [ref=e239]:
                          - generic [ref=e240]:
                            - text: Sunflower Oil
                            - generic [ref=e241]: 1.8 L
                        - generic [ref=e243]:
                          - text: روغن آفتابگردان
                          - generic [ref=e244]: ۱٫۸ لیتری
                    - generic [ref=e245]: Sale request
                  - generic [ref=e246]:
                    - strong [ref=e247]: $7.99
                    - generic [ref=e248]: North York
                    - generic [ref=e249]: 2026-10-15 – 2026-10-28
                  - paragraph [ref=e250]: "Requested by: Demo North York Floor Worker · Why? slow seller"
                  - paragraph [ref=e251]:
                    - text: Margin at this price
                    - generic [ref=e252]: 24%
                  - generic [ref=e253]:
                    - paragraph [ref=e254]: This price is below the minimum margin.
                    - checkbox "Use this price anyway" [ref=e255] [cursor=pointer]
                  - generic [ref=e258]:
                    - button "Approve" [ref=e259] [cursor=pointer]
                    - button "Change and approve" [ref=e260] [cursor=pointer]
                    - button "Reject" [ref=e261] [cursor=pointer]
                - generic [ref=e262]:
                  - generic [ref=e263]:
                    - generic [ref=e264]:
                      - strong [ref=e265]:
                        - generic [ref=e266]:
                          - text: Lavash Bread
                          - generic [ref=e267]: 500 g
                      - generic [ref=e269]:
                        - text: نان لواش
                        - generic [ref=e270]: ۵۰۰ گرمی
                    - generic [ref=e271]: "0006"
                  - generic [ref=e272]: Price change
                  - generic [ref=e273]:
                    - generic [ref=e274]:
                      - text: Old
                      - generic [ref=e275]: $1.99
                    - generic [ref=e276]:
                      - text: New
                      - generic [ref=e277]: $2.99
                  - generic [ref=e278]: North York
                  - generic [ref=e279]:
                    - button "Approve" [ref=e280] [cursor=pointer]
                    - button "More" [ref=e281] [cursor=pointer]
                - generic [ref=e287]:
                  - generic [ref=e288]:
                    - generic [ref=e289]:
                      - strong [ref=e290]:
                        - generic [ref=e291]:
                          - text: Dried Barberries
                          - generic [ref=e292]: 100 g
                      - generic [ref=e294]:
                        - text: زرشک خشک
                        - generic [ref=e295]: ۱۰۰ گرمی
                    - generic [ref=e296]: "0015"
                  - generic [ref=e297]: New product
                  - generic [ref=e298]:
                    - generic [ref=e299]:
                      - text: Old
                      - generic [ref=e300]: —
                    - generic [ref=e301]:
                      - text: New
                      - generic [ref=e302]: $5.49
                  - generic [ref=e303]: North York
                  - generic [ref=e304]:
                    - button "Approve" [ref=e305] [cursor=pointer]
                    - button "More" [ref=e306] [cursor=pointer]
            - generic [ref=e312]:
              - heading "Alerts" [level=2] [ref=e313]
              - generic [ref=e314]:
                - generic [ref=e315]:
                  - generic [ref=e316]:
                    - strong [ref=e317]:
                      - generic [ref=e319]:
                        - text: Black Tea
                        - generic [ref=e320]: 450 g
                    - generic [ref=e321]: All branches
                  - generic [ref=e322]: Conflict
                  - button "Review" [ref=e325] [cursor=pointer]
                - generic [ref=e328]:
                  - generic [ref=e329]:
                    - strong [ref=e330]:
                      - generic [ref=e332]:
                        - text: Lavash Bread
                        - generic [ref=e333]: 500 g
                    - generic [ref=e334]: North York
                  - generic [ref=e335]: Date tracking
                  - button "Review" [ref=e338] [cursor=pointer]
                - generic [ref=e341]:
                  - generic [ref=e342]:
                    - strong [ref=e343]:
                      - generic [ref=e345]:
                        - text: Sour Cherry Juice
                        - generic [ref=e346]: 1 L
                    - generic [ref=e347]: North York
                  - generic [ref=e348]: Date tracking
                  - button "Review" [ref=e351] [cursor=pointer]
          - generic [ref=e354]:
            - generic [ref=e355]:
              - heading "Recent invoices" [level=2] [ref=e356]
              - table [ref=e358]:
                - rowgroup [ref=e363]:
                  - row [ref=e364]:
                    - columnheader "Invoice" [ref=e365]
                    - columnheader "Status" [ref=e366]
                    - columnheader "Action" [ref=e367]
                - rowgroup [ref=e368]:
                  - row [ref=e369] [cursor=pointer]:
                    - cell "FV-20390" [ref=e370]
                    - cell "Posted" [ref=e372]
                    - cell [ref=e375]:
                      - generic [ref=e376]:
                        - link "View" [ref=e377]:
                          - /url: "#invoices?id=a2-fixture%3AFV-20390"
                        - button "Show details" [ref=e380]
                  - row [ref=e383] [cursor=pointer]:
                    - cell "GG-11879" [ref=e384]
                    - cell "Posted" [ref=e386]
                    - cell [ref=e389]:
                      - generic [ref=e390]:
                        - link "View" [ref=e391]:
                          - /url: "#invoices?id=a2-fixture%3AGG-11879"
                        - button "Show details" [ref=e394]
                  - row [ref=e397] [cursor=pointer]:
                    - cell "SB-7862" [ref=e398]
                    - cell "Posted" [ref=e400]
                    - cell [ref=e403]:
                      - generic [ref=e404]:
                        - link "View" [ref=e405]:
                          - /url: "#invoices?id=a2-fixture%3ASB-7862"
                        - button "Show details" [ref=e408]
                  - row [ref=e411] [cursor=pointer]:
                    - cell "SB-7848" [ref=e412]
                    - cell "Posted" [ref=e414]
                    - cell [ref=e417]:
                      - generic [ref=e418]:
                        - link "View" [ref=e419]:
                          - /url: "#invoices?id=a2-fixture%3ASB-7848"
                        - button "Show details" [ref=e422]
                  - row [ref=e425] [cursor=pointer]:
                    - cell "HW-4910" [ref=e426]
                    - cell "Posted" [ref=e428]
                    - cell [ref=e431]:
                      - generic [ref=e432]:
                        - link "View" [ref=e433]:
                          - /url: "#invoices?id=a2-fixture%3AHW-4910"
                        - button "Show details" [ref=e436]
            - generic [ref=e439]:
              - generic [ref=e440]:
                - heading "Returns" [level=2] [ref=e441]
                - button "View all returns" [ref=e442] [cursor=pointer]
              - generic [ref=e445]:
                - generic [ref=e446] [cursor=pointer]:
                  - generic [ref=e447]:
                    - strong [ref=e448]: Fresh Valley Foods
                    - generic [ref=e449]:
                      - text: North York ·
                      - generic [ref=e452]:
                        - text: Sour Cherry Juice
                        - generic [ref=e453]: 1 L
                  - generic [ref=e454]: Open
                  - link "View" [ref=e457]:
                    - /url: "#return?id=demo-return-1"
                - generic [ref=e460] [cursor=pointer]:
                  - generic [ref=e461]:
                    - strong [ref=e462]: Golden Grain Distributors
                    - generic [ref=e463]:
                      - text: North York ·
                      - generic [ref=e466]:
                        - text: Basmati Rice
                        - generic [ref=e467]: 4.5 kg
                  - generic [ref=e468]: Partially resolved
                  - link "View" [ref=e471]:
                    - /url: "#return?id=demo-return-2"
          - generic [ref=e474]:
            - heading "Supplier balances" [level=2] [ref=e475]
            - table [ref=e477]:
              - rowgroup [ref=e484]:
                - row [ref=e485]:
                  - columnheader "Supplier" [ref=e486]
                  - columnheader "Balance" [ref=e487]
                  - columnheader "Open invoices" [ref=e488]
                  - columnheader "Overdue" [ref=e489]
                  - columnheader "Action" [ref=e490]
              - rowgroup [ref=e491]:
                - row [ref=e492] [cursor=pointer]:
                  - cell "HomeWare Imports" [ref=e493]
                  - cell "$1,260.00" [ref=e494]
                  - cell "1" [ref=e495]
                  - cell "$0.00" [ref=e496]
                  - cell [ref=e497]:
                    - link "View" [ref=e498]:
                      - /url: "#payables"
                - row [ref=e501] [cursor=pointer]:
                  - cell "Golden Grain Distributors" [ref=e502]
                  - cell "$842.10" [ref=e503]
                  - cell "2" [ref=e504]
                  - cell "$210.00" [ref=e505]
                  - cell [ref=e506]:
                    - link "View" [ref=e507]:
                      - /url: "#payables"
                - row [ref=e510] [cursor=pointer]:
                  - cell "Fresh Valley Foods" [ref=e511]
                  - cell "$169.79" [ref=e512]
                  - cell "1" [ref=e513]
                  - cell "$0.00" [ref=e514]
                  - cell [ref=e515]:
                    - link "View" [ref=e516]:
                      - /url: "#payables"
                - row [ref=e519] [cursor=pointer]:
                  - cell "Sunrise Beverages" [ref=e520]
                  - cell "$96.40" [ref=e521]
                  - cell "1" [ref=e522]
                  - cell "$96.40" [ref=e523]
                  - cell [ref=e524]:
                    - link "View" [ref=e525]:
                      - /url: "#payables"
                - row [ref=e528] [cursor=pointer]:
                  - cell "Corner Spice Co." [ref=e529]
                  - cell "$0.00" [ref=e530]
                  - cell "0" [ref=e531]
                  - cell "$0.00" [ref=e532]
                  - cell [ref=e533]:
                    - link "View" [ref=e534]:
                      - /url: "#payables"
          - generic [ref=e537]:
            - generic [ref=e538]:
              - heading "Purchases by supplier, this month" [level=2] [ref=e539]
              - list [ref=e540]:
                - listitem [ref=e541]:
                  - generic [ref=e542]:
                    - generic [ref=e543]: Golden Grain Distributors
                    - generic [ref=e544]: $636.00
                - listitem [ref=e547]:
                  - generic [ref=e548]:
                    - generic [ref=e549]: Fresh Valley Foods
                    - generic [ref=e550]: $181.22
                - listitem [ref=e553]:
                  - generic [ref=e554]:
                    - generic [ref=e555]: Sunrise Beverages
                    - generic [ref=e556]: $133.59
              - paragraph [ref=e559]: Net purchases · CAD
            - generic [ref=e560]:
              - heading "Purchases, last 8 weeks" [level=2] [ref=e561]
              - img "Net purchases by week" [ref=e563]:
                - 'generic "2026-08-21 – 2026-08-27: $25.20" [ref=e566]'
                - 'generic "2026-08-28 – 2026-09-03: $0.00" [ref=e567]'
                - 'generic "2026-09-04 – 2026-09-10: $368.00" [ref=e568]'
                - 'generic "2026-09-11 – 2026-09-17: $0.00" [ref=e569]'
                - 'generic "2026-09-18 – 2026-09-24: $1,332.78" [ref=e570]'
                - 'generic "2026-09-25 – 2026-10-01: $0.00" [ref=e571]'
                - 'generic "2026-10-02 – 2026-10-08: $133.59" [ref=e572]'
                - 'generic "2026-10-09 – 2026-10-15: $817.22" [ref=e573]'
              - generic [ref=e574]:
                - generic [ref=e575]: 2026-08-21
                - generic [ref=e576]: 2026-09-04
                - generic [ref=e577]: 2026-09-18
                - generic [ref=e578]: 2026-10-09
              - paragraph [ref=e579]: Net purchases · CAD
          - generic [ref=e580]:
            - generic [ref=e581]:
              - heading "Arrived this week" [level=2] [ref=e582]
              - generic [ref=e583] [cursor=pointer]:
                - generic [ref=e584]:
                  - strong [ref=e585]:
                    - generic [ref=e586]:
                      - strong [ref=e587]:
                        - generic [ref=e588]:
                          - text: Canned Fava Beans
                          - generic [ref=e589]: 400 g
                      - generic [ref=e591]:
                        - text: باقالا کنسرو شده
                        - generic [ref=e592]: ۴۰۰ گرمی
                  - generic [ref=e593]:
                    - text: North York · 2026-10-14 ·
                    - generic [ref=e594]: FV-20390
                - generic [ref=e595]: 24 units
                - link "View" [ref=e598]:
                  - /url: "#received?product=0002"
              - generic [ref=e601] [cursor=pointer]:
                - generic [ref=e602]:
                  - strong [ref=e603]:
                    - generic [ref=e604]:
                      - strong [ref=e605]:
                        - generic [ref=e606]:
                          - text: Ground Sumac
                          - generic [ref=e607]: 100 g
                      - generic [ref=e609]:
                        - text: سماق
                        - generic [ref=e610]: ۱۰۰ گرمی
                  - generic [ref=e611]:
                    - text: North York · 2026-10-14 ·
                    - generic [ref=e612]: FV-20390
                - generic [ref=e613]: 12 units
                - link "View" [ref=e616]:
                  - /url: "#received?product=0005"
              - generic [ref=e619] [cursor=pointer]:
                - generic [ref=e620]:
                  - strong [ref=e621]:
                    - generic [ref=e622]:
                      - strong [ref=e623]:
                        - generic [ref=e624]:
                          - text: Lavash Bread
                          - generic [ref=e625]: 500 g
                      - generic [ref=e627]:
                        - text: نان لواش
                        - generic [ref=e628]: ۵۰۰ گرمی
                  - generic [ref=e629]:
                    - text: North York · 2026-10-14 ·
                    - generic [ref=e630]: FV-20390
                - generic [ref=e631]: 20 units
                - link "View" [ref=e634]:
                  - /url: "#received?product=0006"
              - generic [ref=e637] [cursor=pointer]:
                - generic [ref=e638]:
                  - strong [ref=e639]:
                    - generic [ref=e640]:
                      - strong [ref=e641]:
                        - generic [ref=e642]:
                          - text: Sour Cherry Juice
                          - generic [ref=e643]: 1 L
                      - generic [ref=e645]:
                        - text: آب آلبالو
                        - generic [ref=e646]: ۱ لیتری
                  - generic [ref=e647]:
                    - text: North York · 2026-10-14 ·
                    - generic [ref=e648]: FV-20390
                - generic [ref=e649]: 36 units
                - link "View" [ref=e652]:
                  - /url: "#received?product=0003"
              - generic [ref=e655] [cursor=pointer]:
                - generic [ref=e656]:
                  - strong [ref=e657]:
                    - generic [ref=e658]:
                      - strong [ref=e659]:
                        - generic [ref=e660]:
                          - text: Dried Barberries
                          - generic [ref=e661]: 100 g
                      - generic [ref=e663]:
                        - text: زرشک خشک
                        - generic [ref=e664]: ۱۰۰ گرمی
                  - generic [ref=e665]:
                    - text: North York · 2026-10-14 ·
                    - generic [ref=e666]: FV-20390
                - generic [ref=e667]: 6 units
                - link "View" [ref=e670]:
                  - /url: "#received?product=0015"
              - generic [ref=e673] [cursor=pointer]:
                - generic [ref=e674]:
                  - strong [ref=e675]:
                    - generic [ref=e676]:
                      - strong [ref=e677]:
                        - generic [ref=e678]:
                          - text: Potato Chips
                          - generic [ref=e679]: 150 g
                      - generic [ref=e681]:
                        - text: چیپس سیب‌زمینی
                        - generic [ref=e682]: ۱۵۰ گرمی
                  - generic [ref=e683]:
                    - text: North York · 2026-10-14 ·
                    - generic [ref=e684]: FV-20390
                - generic [ref=e685]: 12 units
                - link "View" [ref=e688]:
                  - /url: "#received?product=0009"
            - generic [ref=e691]:
              - heading "Price changes this week" [level=2] [ref=e692]
              - generic [ref=e693] [cursor=pointer]:
                - generic [ref=e694]:
                  - strong [ref=e695]:
                    - generic [ref=e697]:
                      - text: Black Tea
                      - generic [ref=e698]: 450 g
                  - generic [ref=e699]: Demo Supervisor · North York · 2026-10-14 · $6.49
                - generic [ref=e700]: Approved
                - link "View" [ref=e703]:
                  - /url: "#product?code=0004"
              - generic [ref=e706] [cursor=pointer]:
                - generic [ref=e707]:
                  - strong [ref=e708]:
                    - generic [ref=e710]:
                      - text: Dried Red Kidney Beans
                      - generic [ref=e711]: 900 g
                  - generic [ref=e712]: Demo Supervisor · North York · 2026-10-13 · $3.99
                - generic [ref=e713]: Approved
                - link "View" [ref=e716]:
                  - /url: "#product?code=0007"
        - complementary "Notes and activity" [ref=e719]:
          - generic [ref=e720]:
            - generic [ref=e721]:
              - heading "Price updates to apply" [level=2] [ref=e722]
              - button "View all 0" [ref=e723] [cursor=pointer]:
                - text: View all
                - generic [ref=e724]: "0"
            - paragraph [ref=e730]: No pending price updates.
          - generic [ref=e731]:
            - heading "Notes for Manager" [level=2] [ref=e732]
            - generic [ref=e734] [cursor=pointer]:
              - generic [ref=e735]:
                - strong [ref=e736]: Customer asked about the tea glass set price; please confirm.
                - generic [ref=e737]:
                  - text: Demo Floor Worker · North York ·
                  - time [ref=e738]: Just now
              - generic [ref=e739]: Open
              - link "View" [ref=e742]:
                - /url: "#notes"
          - generic [ref=e745]:
            - heading "Activity" [level=2] [ref=e746]
            - list [ref=e747]:
              - listitem [ref=e748]:
                - generic [aria-hidden] [ref=e749]: S
                - generic [ref=e750]:
                  - strong [ref=e751]: Start sale
                  - generic [ref=e754]:
                    - text: Stainless Steel Pot
                    - generic [ref=e755]: 24 cm
                  - generic [ref=e756]: System · North York
                  - time [ref=e757]: Just now
              - listitem [ref=e758]:
                - generic [aria-hidden] [ref=e759]: DS
                - generic [ref=e760]:
                  - strong [ref=e761]: Approve price
                  - generic [ref=e764]:
                    - text: Black Tea
                    - generic [ref=e765]: 450 g
                  - generic [ref=e766]: Demo Supervisor · North York
                  - time [ref=e767]: 1 d ago
              - listitem [ref=e768]:
                - generic [aria-hidden] [ref=e769]: DS
                - generic [ref=e770]:
                  - strong [ref=e771]: Approve price
                  - generic [ref=e774]:
                    - text: Dried Red Kidney Beans
                    - generic [ref=e775]: 900 g
                  - generic [ref=e776]: Demo Supervisor · North York
                  - time [ref=e777]: 2 d ago
```

# Test source

```ts
  103 |       };
  104 |       Object.assign((element as HTMLElement).style, {
  105 |         display: "inline",
  106 |         whiteSpace: "normal",
  107 |       });
  108 |       Object.assign(parent.style, {
  109 |         display: "block",
  110 |         width: "18px",
  111 |         whiteSpace: "normal",
  112 |       });
  113 |       return original;
  114 |     });
  115 |     let broken;
  116 |     try {
  117 |       broken = await inspectResponsiveLayout(
  118 |         page,
  119 |         "unit-negative-control",
  120 |         language,
  121 |         900,
  122 |       );
  123 |       expect(
  124 |         broken.failures.some((value) =>
  125 |           value.includes("unit fragment broken across lines"),
  126 |         ),
  127 |       ).toBe(true);
  128 |     } finally {
  129 |       await fragment.evaluate((element, original) => {
  130 |         for (const [node, value] of [
  131 |           [element, original.self],
  132 |           [element.parentElement!, original.parent],
  133 |         ] as const)
  134 |           if (value === null) node.removeAttribute("style");
  135 |           else node.setAttribute("style", value);
  136 |       }, saved);
  137 |     }
  138 |     const restored = await inspectResponsiveLayout(
  139 |       page,
  140 |       "units-restored",
  141 |       language,
  142 |       900,
  143 |     );
  144 |     expect(restored.failures).toEqual([]);
  145 |     await info.attach("Real product-name unit wrapping negative control", {
  146 |       body: JSON.stringify({ clean, broken, restored }, null, 2),
  147 |       contentType: "application/json",
  148 |     });
  149 |   });
  150 | 
  151 | for (const language of ["en", "fa"] as const)
  152 |   test(`ordinary ${language} Activity sizes stay together and an unmarked split is detected`, async ({
  153 |     page,
  154 |   }, info) => {
  155 |     await page.setViewportSize({ width: 1440, height: 1080 });
  156 |     await signIn(page, "Supervisor");
  157 |     await setLanguage(page, language);
  158 |     await page.goto("/#dashboard");
  159 |     const text = page
  160 |       .locator(".dashboard-activity-list .unit-text")
  161 |       .filter({ has: page.locator(".unit-fragment") })
  162 |       .first();
  163 |     await expect(text).toBeVisible();
  164 |     // Removing .unit-fragment changes the filtered locator's first match.
  165 |     // Retain the exact DOM node so the negative control restores its own row.
  166 |     const textNode = await text.elementHandle();
  167 |     if (!textNode) throw new Error("Activity text node is unavailable");
  168 |     const clean = await inspectResponsiveLayout(
  169 |       page,
  170 |       "activity-units",
  171 |       language,
  172 |       1440,
  173 |     );
  174 |     expect(clean.failures).toEqual([]);
  175 |     const saved = await textNode.evaluate((element) => {
  176 |       const original = {
  177 |         html: element.innerHTML,
  178 |         style: element.getAttribute("style"),
  179 |         text: element.textContent,
  180 |       };
  181 |       element.replaceChildren(
  182 |         document.createTextNode(element.textContent ?? ""),
  183 |       );
  184 |       Object.assign((element as HTMLElement).style, {
  185 |         display: "block",
  186 |         width: "18px",
  187 |         whiteSpace: "normal",
  188 |       });
  189 |       return original;
  190 |     });
  191 |     let broken;
  192 |     try {
  193 |       broken = await inspectResponsiveLayout(
  194 |         page,
  195 |         "raw-activity-negative-control",
  196 |         language,
  197 |         1440,
  198 |       );
  199 |       expect(
  200 |         broken.failures.some((value) =>
  201 |           value.includes("plain-text unit fragment broken across lines"),
  202 |         ),
> 203 |       ).toBe(true);
      |         ^ Error: expect(received).toBe(expected) // Object.is equality
  204 |     } finally {
  205 |       await textNode.evaluate((element, original) => {
  206 |         element.innerHTML = original.html;
  207 |         if (original.style === null) element.removeAttribute("style");
  208 |         else element.setAttribute("style", original.style);
  209 |       }, saved);
  210 |     }
  211 |     await expect(text).toHaveText(saved.text ?? "");
  212 |     const restored = await inspectResponsiveLayout(
  213 |       page,
  214 |       "activity-restored",
  215 |       language,
  216 |       1440,
  217 |     );
  218 |     expect(restored.failures).toEqual([]);
  219 |     await info.attach("Unmarked real Activity size wrapping negative control", {
  220 |       body: JSON.stringify({ clean, broken, restored }, null, 2),
  221 |       contentType: "application/json",
  222 |     });
  223 |   });
  224 | 
```