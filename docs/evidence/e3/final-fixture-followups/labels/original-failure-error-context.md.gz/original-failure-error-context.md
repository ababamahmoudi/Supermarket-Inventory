# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: labels-b.spec.ts >> live A4 designer redraws capacity and calibration, stores editable presets and prints an alignment page
- Location: tests/labels-b.spec.ts:19:1

# Error details

```
Error: expect(locator).toHaveValue(expected) failed

Locator:  getByLabel('Width (mm)', { exact: true })
Expected: "60"
Received: "70"
Timeout:  5000ms

Call log:
  - Expect "toHaveValue" getByLabel('Width (mm)', { exact: true }) with timeout 5000ms
  - waiting for getByLabel('Width (mm)', { exact: true })
    14 × locator resolved to <input min="0" dir="ltr" step="0.5" value="70" type="text" inputmode="decimal" aria-invalid="false" id="label-template-width" class="ui-input ui-number" aria-labelledby="label-template-width-label"/>
       - unexpected value "70"

```

```yaml
- textbox "Width (mm)": "70"
```

# Test source

```ts
  1   | import { readCanonicalBusinessEvidence } from "./business-evidence";
  2   | import { expect, test } from "@playwright/test";
  3   | import { setBranch, signIn } from "./helpers";
  4   | import {
  5   |   addSelectedLabels,
  6   |   selectLabelGroup,
  7   |   waitlistCopies,
  8   | } from "./label-selection";
  9   | 
  10  | async function saveTemplate(page: Parameters<typeof signIn>[0]) {
  11  |   await page
  12  |     .getByRole("button", { name: "Save template", exact: true })
  13  |     .click();
  14  |   await expect(page.getByLabel("Saved template", { exact: true })).toHaveText(
  15  |     "Template 1",
  16  |   );
  17  | }
  18  | 
  19  | test("live A4 designer redraws capacity and calibration, stores editable presets and prints an alignment page", async ({
  20  |   page,
  21  | }) => {
  22  |   await page.addInitScript(() => {
  23  |     window.print = () => {
  24  |       document.body.dataset.printCalls = String(
  25  |         Number(document.body.dataset.printCalls ?? 0) + 1,
  26  |       );
  27  |     };
  28  |   });
  29  |   await signIn(page, "Floor Worker");
  30  |   await page.goto("/#labels");
  31  |   await page.getByRole("tab", { name: "Templates", exact: true }).click();
  32  |   await page.getByRole("button", { name: "New template", exact: true }).click();
  33  |   await expect(page.locator(".label-preview-caption")).toContainText(
  34  |     "18 labels per sheet",
  35  |   );
  36  |   await expect(page.locator(".label-preview-slot.is-used")).toHaveCount(4);
  37  |   await page.getByLabel("Width (mm)", { exact: true }).fill("70");
  38  |   await expect(page.locator(".label-preview-caption")).toContainText(
  39  |     "12 labels per sheet",
  40  |   );
  41  |   await page.getByLabel("Horizontal offset (mm)", { exact: true }).fill("1");
  42  |   await expect(
  43  |     page.locator('.label-preview-slot[data-slot="1"] rect'),
  44  |   ).toHaveAttribute("x", "11");
  45  |   await page.locator('.label-preview-slot[data-slot="3"]').click();
  46  |   await expect(page.getByLabel("Starting slot", { exact: true })).toHaveValue(
  47  |     "3",
  48  |   );
  49  |   await expect(page.locator(".label-preview-slot.is-used")).toHaveCount(2);
  50  |   await saveTemplate(page);
  51  |   await page
  52  |     .getByRole("button", { name: "Print test alignment page", exact: true })
  53  |     .click();
  54  |   await expect(page.locator("body")).toHaveAttribute("data-print-calls", "1");
  55  |   await page.emulateMedia({ media: "print" });
  56  |   const sheet = page.locator(".label-print-output .print-sheet");
  57  |   await expect(sheet).toBeVisible();
  58  |   await expect(sheet.locator(".label-alignment-box")).toHaveCount(12);
  59  |   const physical = await sheet.evaluate((element) => {
  60  |     const bounds = element.getBoundingClientRect();
  61  |     const first = element
  62  |       .querySelector(".label-alignment-box")!
  63  |       .getBoundingClientRect();
  64  |     return {
  65  |       width: bounds.width,
  66  |       height: bounds.height,
  67  |       firstLeft: first.left - bounds.left,
  68  |     };
  69  |   });
  70  |   expect(Math.abs(physical.width - (210 * 96) / 25.4)).toBeLessThan(0.2);
  71  |   expect(Math.abs(physical.height - (297 * 96) / 25.4)).toBeLessThan(0.2);
  72  |   expect(Math.abs(physical.firstLeft - (11 * 96) / 25.4)).toBeLessThan(0.2);
  73  |   await page.emulateMedia({ media: "screen" });
  74  |   await page.getByLabel("Width (mm)", { exact: true }).fill("60");
  75  |   await page
  76  |     .getByRole("button", { name: "Save template", exact: true })
  77  |     .click();
  78  |   await page.reload();
  79  |   await page.getByRole("tab", { name: "Templates", exact: true }).click();
  80  |   await page.getByLabel("Saved template", { exact: true }).click();
  81  |   await page.getByRole("option", { name: "Template 1", exact: true }).click();
> 82  |   await expect(page.getByLabel("Width (mm)", { exact: true })).toHaveValue(
      |                                                                ^ Error: expect(locator).toHaveValue(expected) failed
  83  |     "60",
  84  |   );
  85  |   await expect(
  86  |     page.getByLabel("Horizontal offset (mm)", { exact: true }),
  87  |   ).toHaveValue("1");
  88  | });
  89  | 
  90  | test("shared waitlist prints multiple pages but only explicit Yes clears it", async ({
  91  |   page,
  92  | }) => {
  93  |   await page.addInitScript(() => {
  94  |     window.print = () => {
  95  |       document.body.dataset.printCalls = String(
  96  |         Number(document.body.dataset.printCalls ?? 0) + 1,
  97  |       );
  98  |     };
  99  |   });
  100 |   await signIn(page, "Floor Worker");
  101 |   await page.goto("/#labels");
  102 |   const initialQueue = await readCanonicalBusinessEvidence(page).then(
  103 |     (canonicalState) =>
  104 |       JSON.parse(JSON.stringify(canonicalState)!).label_waitlist,
  105 |   );
  106 |   expect(initialQueue).toHaveLength(1);
  107 |   expect(initialQueue[0]).toMatchObject({
  108 |     product_code: "0012",
  109 |     preferred_template: "promo",
  110 |     copies: 1,
  111 |     branch: "Branch 1",
  112 |   });
  113 |   await page.getByRole("tab", { name: "Templates", exact: true }).click();
  114 |   await page.getByRole("button", { name: "New template", exact: true }).click();
  115 |   await saveTemplate(page);
  116 |   await page.getByRole("tab", { name: "Products", exact: true }).click();
  117 |   await page.getByLabel("Search products", { exact: true }).fill("0015");
  118 |   await expect(
  119 |     page.getByRole("checkbox", { name: "Select product 0015", exact: true }),
  120 |   ).toBeDisabled();
  121 |   await page.getByLabel("Search products", { exact: true }).fill("0003");
  122 |   await addSelectedLabels(page, ["0003"], 20);
  123 |   await page.getByRole("tab", { name: /^Waitlist/ }).click();
  124 |   await selectLabelGroup(page, "regular", "Template 1");
  125 |   await page.getByLabel("Starting slot", { exact: true }).fill("5");
  126 |   await expect(await waitlistCopies(page, "0003")).toHaveValue("20");
  127 |   await expect(
  128 |     page.locator(".label-bilingual-preview .print-sheet"),
  129 |   ).toHaveCount(2);
  130 |   const queuedBeforePrint = await readCanonicalBusinessEvidence(page).then(
  131 |     (canonicalState) =>
  132 |       JSON.parse(JSON.stringify(canonicalState)!).label_waitlist,
  133 |   );
  134 |   await page.getByRole("button", { name: "Print labels", exact: true }).click();
  135 |   await expect(page.locator("body")).toHaveAttribute("data-print-calls", "1");
  136 |   await expect(
  137 |     page.getByRole("dialog", {
  138 |       name: "Did the labels print correctly?",
  139 |       exact: true,
  140 |     }),
  141 |   ).toBeVisible();
  142 |   await page
  143 |     .getByRole("dialog")
  144 |     .getByRole("button", { name: "No", exact: true })
  145 |     .click();
  146 |   await expect(await waitlistCopies(page, "0003")).toHaveValue("20");
  147 |   expect(
  148 |     await readCanonicalBusinessEvidence(page).then(
  149 |       (canonicalState) =>
  150 |         JSON.parse(JSON.stringify(canonicalState)!).label_waitlist,
  151 |     ),
  152 |   ).toEqual(queuedBeforePrint);
  153 |   await page.reload();
  154 |   await page.getByRole("tab", { name: /^Waitlist/ }).click();
  155 |   await selectLabelGroup(page, "regular", "Template 1");
  156 |   await page.getByLabel("Starting slot", { exact: true }).fill("5");
  157 |   await page.getByRole("button", { name: "Print labels", exact: true }).click();
  158 |   await page
  159 |     .getByRole("dialog")
  160 |     .getByRole("button", { name: "Yes", exact: true })
  161 |     .click();
  162 |   // Printing/removing the Regular intent leaves the original Sale's Promo
  163 |   // record untouched, including its exact identity and copy count.
  164 |   await expect
  165 |     .poll(() =>
  166 |       readCanonicalBusinessEvidence(page).then(
  167 |         (canonicalState) =>
  168 |           JSON.parse(JSON.stringify(canonicalState)!).label_waitlist,
  169 |       ),
  170 |     )
  171 |     .toEqual(initialQueue);
  172 |   await expect(await waitlistCopies(page, "0012")).toHaveValue("1");
  173 |   await expect(page.getByLabel("Copies for 0003", { exact: true })).toHaveCount(
  174 |     0,
  175 |   );
  176 |   const printed = await readCanonicalBusinessEvidence(page).then(
  177 |     (canonicalState) =>
  178 |       JSON.parse(JSON.stringify(canonicalState)!).activity.find(
  179 |         (item: { action: string }) => item.action === "Print labels",
  180 |       ),
  181 |   );
  182 |   expect(printed.reversible).toBe(false);
```