# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: filters-a2.spec.ts >> Payables filters supplier totals and keeps selected report in the same branch
- Location: tests/filters-a2.spec.ts:234:1

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('.payables-overview').locator('tbody tr')
Expected: 1
Received: 5
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" locator('.payables-overview').locator('tbody tr') with timeout 5000ms
  - waiting for locator('.payables-overview').locator('tbody tr')
    14 × locator resolved to 5 elements
       - unexpected value "5"

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=e5]:
    - banner [ref=e6]:
      - button "Open menu" [ref=e7] [cursor=pointer]
      - combobox "Location" [ref=e11] [cursor=pointer]:
        - generic [ref=e16]: North York
      - button "Notifications, 5 unread" [ref=e19] [cursor=pointer]:
        - generic [ref=e20]: "5"
      - button "User menu" [ref=e25] [cursor=pointer]:
        - generic [aria-hidden] [ref=e27]: DM
      - button "More" [ref=e28] [cursor=pointer]
    - main [ref=e34]:
      - generic [ref=e35]:
        - generic [ref=e36]:
          - heading "Payables" [level=1] [ref=e37]
          - paragraph [ref=e38]: Supplier balances and payment records by branch.
        - button "Record external payment" [ref=e40] [cursor=pointer]
      - generic [ref=e41]:
        - heading "Suppliers" [level=2] [ref=e42]
        - generic "Payables filters" [ref=e43]:
          - textbox "Search suppliers" [ref=e48]
          - combobox "Payables branch" [ref=e49] [cursor=pointer]:
            - generic [ref=e50]: North York
          - checkbox "Overdue only" [ref=e53] [cursor=pointer]
          - checkbox "With balance" [ref=e56] [cursor=pointer]
          - button "Clear filters" [ref=e59] [cursor=pointer]
          - generic [ref=e61]:
            - generic [ref=e62]: 5 suppliers
            - button "Columns" [ref=e63] [cursor=pointer]
        - table [ref=e67]:
          - rowgroup [ref=e68]:
            - row "Fresh Valley Foods" [ref=e69]:
              - cell [ref=e70]:
                - link "Fresh Valley Foods" [ref=e72] [cursor=pointer]:
                  - /url: "#payables"
              - cell "$169.79" [ref=e73]
              - cell [ref=e74]:
                - link "View Fresh Valley Foods" [ref=e75] [cursor=pointer]:
                  - /url: "#payables"
              - cell "North York 2026-10-28" [ref=e78]:
                - generic [ref=e79]: North York
                - generic [ref=e80]: 2026-10-28
            - row "Golden Grain Distributors" [ref=e82]:
              - cell [ref=e83]:
                - link "Golden Grain Distributors" [ref=e85] [cursor=pointer]:
                  - /url: "#payables"
              - cell "$842.10" [ref=e86]
              - cell [ref=e87]:
                - link "View Golden Grain Distributors" [ref=e88] [cursor=pointer]:
                  - /url: "#payables"
              - cell "North York 2026-10-18" [ref=e91]:
                - generic [ref=e92]: North York
                - generic [ref=e93]: 2026-10-18
            - row "HomeWare Imports" [ref=e95]:
              - cell [ref=e96]:
                - link "HomeWare Imports" [ref=e98] [cursor=pointer]:
                  - /url: "#payables"
              - cell "$1,260.00" [ref=e99]
              - cell [ref=e100]:
                - link "View HomeWare Imports" [ref=e101] [cursor=pointer]:
                  - /url: "#payables"
              - cell "North York 2026-10-24" [ref=e104]:
                - generic [ref=e105]: North York
                - generic [ref=e106]: 2026-10-24
            - row "Sunrise Beverages" [ref=e108]:
              - cell [ref=e109]:
                - link "Sunrise Beverages" [ref=e111] [cursor=pointer]:
                  - /url: "#payables"
              - cell "$96.40" [ref=e112]
              - cell [ref=e113]:
                - link "View Sunrise Beverages" [ref=e114] [cursor=pointer]:
                  - /url: "#payables"
              - cell "North York 2026-10-13" [ref=e117]:
                - generic [ref=e118]: North York
                - generic [ref=e119]: 2026-10-13
            - row "Corner Spice Co." [ref=e121]:
              - cell [ref=e122]:
                - link "Corner Spice Co." [ref=e124] [cursor=pointer]:
                  - /url: "#payables"
              - cell "$0.00" [ref=e125]
              - cell [ref=e126]:
                - link "View Corner Spice Co." [ref=e127] [cursor=pointer]:
                  - /url: "#payables"
              - cell "North York —" [ref=e130]:
                - generic [ref=e131]: North York
                - generic [ref=e132]: —
```

# Test source

```ts
  147 |     "multi_buy",
  148 |     "Multi-buy",
  149 |   );
  150 |   await expect(current.locator("tbody tr[data-product-code]")).toHaveCount(4);
  151 |   await page.goto("/#lookup");
  152 |   await page.getByLabel("Search products", { exact: true }).fill("0003");
  153 |   await setBranch(page, "Branch 1");
  154 |   await expect(page.locator(".price")).toHaveText("$2.99");
  155 | });
  156 | 
  157 | test("Offers branch filtering never lets a Floor Worker read another branch offer", async ({
  158 |   page,
  159 | }) => {
  160 |   await signIn(page, "supervisor");
  161 |   await page.goto("/#offers");
  162 |   const filters = page.getByLabel("Offer filters", { exact: true });
  163 |   await chooseOption(
  164 |     page,
  165 |     filters.getByLabel("Offer branch", { exact: true }),
  166 |     "Richmond Hill",
  167 |   );
  168 |   await page.getByRole("button", { name: "Create offer", exact: true }).click();
  169 |   const create = page.getByRole("dialog", {
  170 |     name: "Create offer",
  171 |     exact: true,
  172 |   });
  173 |   await chooseOption(
  174 |     page,
  175 |     create.getByLabel("Product", { exact: true }),
  176 |     "0003",
  177 |     "Sour Cherry Juice 1 L · \u20660003\u2069",
  178 |   );
  179 |   await chooseOption(
  180 |     page,
  181 |     create.getByLabel("Offer scope", { exact: true }),
  182 |     "branch",
  183 |     "This branch only — Richmond Hill",
  184 |   );
  185 |   await create
  186 |     .getByRole("button", { name: "Create offer", exact: true })
  187 |     .click();
  188 |   const current = page.locator("section.card").filter({
  189 |     has: page.getByRole("heading", { name: "Current offers", exact: true }),
  190 |   });
  191 |   await expect(current.locator("tbody tr[data-product-code]")).toHaveCount(5);
  192 |   await expect(current.locator('tr[data-product-code="0003"]')).toHaveCount(1);
  193 |   const juiceScope = await responsiveColumn(
  194 |     current.locator('tr[data-product-code="0003"]'),
  195 |     "Scope",
  196 |   );
  197 |   await expect(juiceScope.locator(".offer-group-entry")).toHaveCount(2);
  198 |   await expect(
  199 |     current.locator("tbody").getByText("Richmond Hill", { exact: true }),
  200 |   ).toBeVisible();
  201 |   await signIn(page, "floor_worker");
  202 |   await page.goto("/#offers");
  203 |   await expect(
  204 |     filters.getByLabel("Offer branch", { exact: true }),
  205 |   ).toBeDisabled();
  206 |   await expect(filters.getByLabel("Offer branch", { exact: true })).toHaveText(
  207 |     "North York",
  208 |   );
  209 |   await expect(current.locator("tbody tr[data-product-code]")).toHaveCount(7);
  210 |   await expect(
  211 |     current.locator('tbody tr[data-offer-kind="sale"]'),
  212 |   ).toContainText("Stainless Steel Pot");
  213 |   await expect(
  214 |     current.locator('tbody tr[data-offer-kind="request"]'),
  215 |   ).toContainText("Sunflower Oil");
  216 |   await chooseOption(
  217 |     page,
  218 |     filters.getByLabel("Offer type", { exact: true }),
  219 |     "multi_buy",
  220 |     "Multi-buy",
  221 |   );
  222 |   await expect(current.locator("tbody tr[data-product-code]")).toHaveCount(5);
  223 |   await expect(
  224 |     current.locator("tbody").getByText("Richmond Hill", { exact: true }),
  225 |   ).toHaveCount(0);
  226 |   await filters
  227 |     .getByRole("button", { name: "Clear filters", exact: true })
  228 |     .click();
  229 |   await expect(filters.getByLabel("Offer branch", { exact: true })).toHaveText(
  230 |     "North York",
  231 |   );
  232 | });
  233 | 
  234 | test("Payables filters supplier totals and keeps selected report in the same branch", async ({
  235 |   page,
  236 | }) => {
  237 |   await signIn(page, "supervisor");
  238 |   await page.goto("/#payables");
  239 |   const filters = page.getByLabel("Payables filters", { exact: true });
  240 |   const overview = page.locator(".payables-overview");
  241 |   await chooseOption(
  242 |     page,
  243 |     filters.getByLabel("Payables branch", { exact: true }),
  244 |     "North York",
  245 |   );
  246 |   await filters.getByLabel("Search suppliers", { exact: true }).fill("fresh");
> 247 |   await expect(overview.locator("tbody tr")).toHaveCount(1);
      |                                              ^ Error: expect(locator).toHaveCount(expected) failed
  248 |   await expect(overview).toContainText("$169.79");
  249 |   await overview
  250 |     .getByRole("link", { name: "Fresh Valley Foods", exact: true })
  251 |     .click();
  252 |   const report = page.getByLabel("Supplier financial report", { exact: true });
  253 |   await expect(report.locator(".payables-summary-grid")).toContainText(
  254 |     "$169.79",
  255 |   );
  256 |   await chooseOption(
  257 |     page,
  258 |     filters.getByLabel("Payables branch", { exact: true }),
  259 |     "Richmond Hill",
  260 |   );
  261 |   const selectedSupplier = overview.locator("tbody tr").filter({
  262 |     has: page.getByRole("link", { name: "Fresh Valley Foods", exact: true }),
  263 |   });
  264 |   await expect(selectedSupplier).toHaveCount(1);
  265 |   await expect(await responsiveColumn(selectedSupplier, "Branch")).toHaveText(
  266 |     "Richmond Hill",
  267 |   );
  268 |   await expect(await responsiveColumn(selectedSupplier, "Balance")).toHaveText(
  269 |     "$0.00",
  270 |   );
  271 |   await expect(report.locator(".payables-summary-grid")).toContainText("$0.00");
  272 |   await filters
  273 |     .getByRole("checkbox", { name: "With balance", exact: true })
  274 |     .check();
  275 |   await expect(report).toHaveCount(0);
  276 |   await expect(overview).toContainText("No suppliers match these filters");
  277 |   await filters
  278 |     .getByRole("button", { name: "Clear filters", exact: true })
  279 |     .click();
  280 |   await chooseOption(
  281 |     page,
  282 |     filters.getByLabel("Payables branch", { exact: true }),
  283 |     "North York",
  284 |   );
  285 |   await filters
  286 |     .getByRole("checkbox", { name: "Overdue only", exact: true })
  287 |     .check();
  288 |   await filters
  289 |     .getByRole("checkbox", { name: "With balance", exact: true })
  290 |     .check();
  291 |   const rows = overview.locator("tbody tr");
  292 |   await expect(rows).toHaveCount(2);
  293 |   await expect(
  294 |     rows.filter({ hasText: "Golden Grain Distributors" }),
  295 |   ).toContainText("$842.10");
  296 |   const grain = rows.filter({ hasText: "Golden Grain Distributors" });
  297 |   if (await grain.evaluate((element) => element.matches(".phone-list-row"))) {
  298 |     // Compact rows keep the balance; the same supplier's actual report keeps
  299 |     // its separate overdue amount. Do not re-add omitted private list cells.
  300 |     await grain
  301 |       .getByRole("link", { name: "Golden Grain Distributors", exact: true })
  302 |       .click();
  303 |     await expect(page.locator(".payables-report-heading h2")).toHaveText(
  304 |       "Golden Grain Distributors",
  305 |     );
  306 |     await expect(
  307 |       report.locator(".payables-summary-grid .ui-summary-tile").filter({
  308 |         has: page.getByText("Overdue", { exact: true }),
  309 |       }),
  310 |     ).toContainText("$210.00");
  311 |   } else {
  312 |     await expect(grain).toContainText("$210.00");
  313 |   }
  314 |   await expect(rows.filter({ hasText: "Sunrise Beverages" })).toContainText(
  315 |     "$96.40",
  316 |   );
  317 |   await expect(filters).toContainText("2 suppliers");
  318 |   await signIn(page, "floor_worker");
  319 |   await page.goto("/#payables");
  320 |   await expect(
  321 |     page.getByRole("heading", { name: "Payables", exact: true }),
  322 |   ).toHaveCount(0);
  323 |   await expect(page.locator(".payables-overview")).toHaveCount(0);
  324 | });
  325 | 
  326 | test("Persian Offers and Payables keep complete custom-filter choices and isolated supplier names", async ({
  327 |   page,
  328 | }) => {
  329 |   await signIn(page, "supervisor");
  330 |   await setLanguage(page, "fa");
  331 |   await page.goto("/#offers");
  332 |   const offers = page.getByLabel("فیلترهای پیشنهادها", { exact: true });
  333 |   await chooseOption(
  334 |     page,
  335 |     offers.getByLabel("تأمین‌کننده پیشنهاد", { exact: true }),
  336 |     "Golden Grain Distributors",
  337 |   );
  338 |   const current = page.locator("section.card").filter({
  339 |     has: page.getByRole("heading", { name: "پیشنهادهای فعلی", exact: true }),
  340 |   });
  341 |   const supplierRows = current.locator("tbody tr[data-product-code]");
  342 |   await expect(supplierRows).toHaveCount(2);
  343 |   expect(
  344 |     await supplierRows.evaluateAll((rows) =>
  345 |       rows.map((row) => row.getAttribute("data-product-code")).sort(),
  346 |     ),
  347 |   ).toEqual(["0007", "0008"]);
```