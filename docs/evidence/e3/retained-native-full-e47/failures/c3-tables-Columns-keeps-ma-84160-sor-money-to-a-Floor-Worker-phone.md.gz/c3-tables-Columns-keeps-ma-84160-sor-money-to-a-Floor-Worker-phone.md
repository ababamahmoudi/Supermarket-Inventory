# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: c3-tables.spec.ts >> Columns keeps mandatory names, persists by user and never exposes Supervisor money to a Floor Worker
- Location: tests/c3-tables.spec.ts:292:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('.catalog-products-table td[data-column-key=price]').first()
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('.catalog-products-table td[data-column-key=price]').first() with timeout 5000ms
  - waiting for locator('.catalog-products-table td[data-column-key=price]').first()

```

```yaml
- link "Skip to content":
  - /url: "#main-content"
- banner:
  - button "Open menu"
  - combobox "Location": North York
  - button "Notifications, 0 unread"
  - button "User menu"
  - button "More"
- main:
  - heading "Products" [level=1]
  - paragraph: Approved prices, pending changes and branch details in one catalog.
  - searchbox "Search products"
  - combobox "Pricing category": All pricing categories
  - combobox "AI category": All AI categories
  - combobox "Status": All statuses
  - combobox "Supplier": All suppliers
  - checkbox "Has pending price"
  - checkbox "Has offer"
  - checkbox "Manual prices"
  - checkbox "On sale"
  - button "Clear filters"
  - text: 16 products
  - button "Columns"
  - table:
    - rowgroup:
      - row "Basmati Rice 4.5 kg برنج باسماتی ۴٫۵ کیلوگرمی 4.5 kg $23.99 Open Basmati Rice 4.5 kg 0001 Approved":
        - cell "Basmati Rice 4.5 kg برنج باسماتی ۴٫۵ کیلوگرمی 4.5 kg":
          - link "Basmati Rice 4.5 kg":
            - /url: "#product?code=0001"
            - strong: Basmati Rice 4.5 kg
          - paragraph: برنج باسماتی ۴٫۵ کیلوگرمی
          - paragraph: 4.5 kg
        - cell "$23.99"
        - cell "Open Basmati Rice 4.5 kg":
          - link "Open Basmati Rice 4.5 kg":
            - /url: "#product?code=0001"
        - cell "0001 Approved"
      - row "Black Tea 450 g چای سیاه ۴۵۰ گرمی 450 g $6.49 Open Black Tea 450 g 0004 Approved":
        - cell "Black Tea 450 g چای سیاه ۴۵۰ گرمی 450 g":
          - link "Black Tea 450 g":
            - /url: "#product?code=0004"
            - strong: Black Tea 450 g
          - paragraph: چای سیاه ۴۵۰ گرمی
          - paragraph: 450 g
        - cell "$6.49"
        - cell "Open Black Tea 450 g":
          - link "Open Black Tea 450 g":
            - /url: "#product?code=0004"
        - cell "0004 Approved"
      - row "Bulk Almonds بادام فله Sold by weight $7.49/lb $16.51/kg Open Bulk Almonds 0016 Approved":
        - cell "Bulk Almonds بادام فله Sold by weight":
          - link "Bulk Almonds":
            - /url: "#product?code=0016"
            - strong: Bulk Almonds
          - paragraph: بادام فله
          - paragraph: Sold by weight
        - cell "$7.49/lb $16.51/kg"
        - cell "Open Bulk Almonds":
          - link "Open Bulk Almonds":
            - /url: "#product?code=0016"
        - cell "0016 Approved"
      - row "Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی 400 g $1.49 Open Canned Fava Beans 400 g 0002 Approved":
        - cell "Canned Fava Beans 400 g باقالا کنسرو شده ۴۰۰ گرمی 400 g":
          - link "Canned Fava Beans 400 g":
            - /url: "#product?code=0002"
            - strong: Canned Fava Beans 400 g
          - paragraph: باقالا کنسرو شده ۴۰۰ گرمی
          - paragraph: 400 g
        - cell "$1.49"
        - cell "Open Canned Fava Beans 400 g":
          - link "Open Canned Fava Beans 400 g":
            - /url: "#product?code=0002"
        - cell "0002 Approved"
      - row "Dried Barberries 100 g زرشک خشک ۱۰۰ گرمی 100 g — Open Dried Barberries 100 g 0015 Pending $5.49":
        - cell "Dried Barberries 100 g زرشک خشک ۱۰۰ گرمی 100 g":
          - link "Dried Barberries 100 g":
            - /url: "#product?code=0015"
            - strong: Dried Barberries 100 g
          - paragraph: زرشک خشک ۱۰۰ گرمی
          - paragraph: 100 g
        - cell "—"
        - cell "Open Dried Barberries 100 g":
          - link "Open Dried Barberries 100 g":
            - /url: "#product?code=0015"
        - cell "0015 Pending $5.49"
      - row "Dried Red Kidney Beans 900 g لوبیا قرمز ۹۰۰ گرمی 900 g $3.99 Open Dried Red Kidney Beans 900 g 0007 Approved 2 for $7.00":
        - cell "Dried Red Kidney Beans 900 g لوبیا قرمز ۹۰۰ گرمی 900 g":
          - link "Dried Red Kidney Beans 900 g":
            - /url: "#product?code=0007"
            - strong: Dried Red Kidney Beans 900 g
          - paragraph: لوبیا قرمز ۹۰۰ گرمی
          - paragraph: 900 g
        - cell "$3.99"
        - cell "Open Dried Red Kidney Beans 900 g":
          - link "Open Dried Red Kidney Beans 900 g":
            - /url: "#product?code=0007"
        - cell "0007 Approved 2 for $7.00"
      - row "Fruit Soda 6-pack نوشابه میوه‌ای بسته ۶ عددی 6 x 355 ml $4.99 Open Fruit Soda 6-pack 0010 Approved":
        - cell "Fruit Soda 6-pack نوشابه میوه‌ای بسته ۶ عددی 6 x 355 ml":
          - link "Fruit Soda 6-pack":
            - /url: "#product?code=0010"
            - strong: Fruit Soda 6-pack
          - paragraph: نوشابه میوه‌ای بسته ۶ عددی
          - paragraph: 6 x 355 ml
        - cell "$4.99"
        - cell "Open Fruit Soda 6-pack":
          - link "Open Fruit Soda 6-pack":
            - /url: "#product?code=0010"
        - cell "0010 Approved"
      - row "Ground Sumac 100 g سماق ۱۰۰ گرمی 100 g $1.99 Open Ground Sumac 100 g 0005 Approved 3 for $5.00":
        - cell "Ground Sumac 100 g سماق ۱۰۰ گرمی 100 g":
          - link "Ground Sumac 100 g":
            - /url: "#product?code=0005"
            - strong: Ground Sumac 100 g
          - paragraph: سماق ۱۰۰ گرمی
          - paragraph: 100 g
        - cell "$1.99"
        - cell "Open Ground Sumac 100 g":
          - link "Open Ground Sumac 100 g":
            - /url: "#product?code=0005"
        - cell "0005 Approved 3 for $5.00"
      - row "Kitchen Sponge 3-pack اسفنج ظرفشویی بسته ۳ عددی 3 pcs $2.49 Open Kitchen Sponge 3-pack 0014 Approved":
        - cell "Kitchen Sponge 3-pack اسفنج ظرفشویی بسته ۳ عددی 3 pcs":
          - link "Kitchen Sponge 3-pack":
            - /url: "#product?code=0014"
            - strong: Kitchen Sponge 3-pack
          - paragraph: اسفنج ظرفشویی بسته ۳ عددی
          - paragraph: 3 pcs
        - cell "$2.49"
        - cell "Open Kitchen Sponge 3-pack":
          - link "Open Kitchen Sponge 3-pack":
            - /url: "#product?code=0014"
        - cell "0014 Approved"
      - row "Lavash Bread 500 g نان لواش ۵۰۰ گرمی 500 g $1.99 Open Lavash Bread 500 g 0006 Pending $2.99 3 for $5.00":
        - cell "Lavash Bread 500 g نان لواش ۵۰۰ گرمی 500 g":
          - link "Lavash Bread 500 g":
            - /url: "#product?code=0006"
            - strong: Lavash Bread 500 g
          - paragraph: نان لواش ۵۰۰ گرمی
          - paragraph: 500 g
        - cell "$1.99"
        - cell "Open Lavash Bread 500 g":
          - link "Open Lavash Bread 500 g":
            - /url: "#product?code=0006"
        - cell "0006 Pending $2.99 3 for $5.00"
      - row "Potato Chips 150 g چیپس سیب‌زمینی ۱۵۰ گرمی 150 g $2.99 Open Potato Chips 150 g 0009 Approved 2 for $5.00":
        - cell "Potato Chips 150 g چیپس سیب‌زمینی ۱۵۰ گرمی 150 g":
          - link "Potato Chips 150 g":
            - /url: "#product?code=0009"
            - strong: Potato Chips 150 g
          - paragraph: چیپس سیب‌زمینی ۱۵۰ گرمی
          - paragraph: 150 g
        - cell "$2.99"
        - cell "Open Potato Chips 150 g":
          - link "Open Potato Chips 150 g":
            - /url: "#product?code=0009"
        - cell "0009 Approved 2 for $5.00"
      - row "Rice Cooker 1.8 L پلوپز ۱٫۸ لیتری 1.8 L $52.49 Open Rice Cooker 1.8 L 0013 Approved":
        - cell "Rice Cooker 1.8 L پلوپز ۱٫۸ لیتری 1.8 L":
          - link "Rice Cooker 1.8 L":
            - /url: "#product?code=0013"
            - strong: Rice Cooker 1.8 L
          - paragraph: پلوپز ۱٫۸ لیتری
          - paragraph: 1.8 L
        - cell "$52.49"
        - cell "Open Rice Cooker 1.8 L":
          - link "Open Rice Cooker 1.8 L":
            - /url: "#product?code=0013"
        - cell "0013 Approved"
      - row "Sour Cherry Juice 1 L آب آلبالو ۱ لیتری 1 L $2.99 Open Sour Cherry Juice 1 L 0003 Approved 2 for $5.00":
        - cell "Sour Cherry Juice 1 L آب آلبالو ۱ لیتری 1 L":
          - link "Sour Cherry Juice 1 L":
            - /url: "#product?code=0003"
            - strong: Sour Cherry Juice 1 L
          - paragraph: آب آلبالو ۱ لیتری
          - paragraph: 1 L
        - cell "$2.99"
        - cell "Open Sour Cherry Juice 1 L":
          - link "Open Sour Cherry Juice 1 L":
            - /url: "#product?code=0003"
        - cell "0003 Approved 2 for $5.00"
      - row "Stainless Steel Pot 24 cm قابلمه استیل ۲۴ سانتی‌متری 24 cm $16.99 Sale Regular $20.99 Until Oct 25 Open Stainless Steel Pot 24 cm 0012 Approved":
        - cell "Stainless Steel Pot 24 cm قابلمه استیل ۲۴ سانتی‌متری 24 cm":
          - link "Stainless Steel Pot 24 cm":
            - /url: "#product?code=0012"
            - strong: Stainless Steel Pot 24 cm
          - paragraph: قابلمه استیل ۲۴ سانتی‌متری
          - paragraph: 24 cm
        - cell "$16.99 Sale Regular $20.99 Until Oct 25":
          - text: $16.99 Sale
          - deletion: Regular $20.99
          - text: Until Oct 25
        - cell "Open Stainless Steel Pot 24 cm":
          - link "Open Stainless Steel Pot 24 cm":
            - /url: "#product?code=0012"
        - cell "0012 Approved"
      - row "Sunflower Oil 1.8 L روغن آفتابگردان ۱٫۸ لیتری 1.8 L $9.49 Sale requested $7.99 · Oct 15–Oct 28 Waiting for approval Open Sunflower Oil 1.8 L 0008 Approved":
        - cell "Sunflower Oil 1.8 L روغن آفتابگردان ۱٫۸ لیتری 1.8 L":
          - link "Sunflower Oil 1.8 L":
            - /url: "#product?code=0008"
            - strong: Sunflower Oil 1.8 L
          - paragraph: روغن آفتابگردان ۱٫۸ لیتری
          - paragraph: 1.8 L
        - cell "$9.49 Sale requested $7.99 · Oct 15–Oct 28 Waiting for approval"
        - cell "Open Sunflower Oil 1.8 L":
          - link "Open Sunflower Oil 1.8 L":
            - /url: "#product?code=0008"
        - cell "0008 Approved"
      - row "Tea Glass Set (6 pcs) ست استکان چای (۶ عددی) 6 pcs $8.99 Open Tea Glass Set (6 pcs) 0011 Approved":
        - cell "Tea Glass Set (6 pcs) ست استکان چای (۶ عددی) 6 pcs":
          - link "Tea Glass Set (6 pcs)":
            - /url: "#product?code=0011"
            - strong: Tea Glass Set (6 pcs)
          - paragraph: ست استکان چای (۶ عددی)
          - paragraph: 6 pcs
        - cell "$8.99"
        - cell "Open Tea Glass Set (6 pcs)":
          - link "Open Tea Glass Set (6 pcs)":
            - /url: "#product?code=0011"
        - cell "0011 Approved"
  - button "Previous" [disabled]
  - text: Page 1 of 1 · 16 products
  - button "Next" [disabled]
```

# Test source

```ts
  226 |           const hiddenColumns = supplierColumns.filter(
  227 |             ([key]) => !visibleKeys.includes(key),
  228 |           );
  229 |           expect(hiddenColumns).toHaveLength(widthHidden);
  230 |           expect(visibleKeys).toEqual(
  231 |             supplierColumns
  232 |               .filter(([key]) => visibleKeys.includes(key))
  233 |               .map(([key]) => key),
  234 |           );
  235 |           if (widthHidden) {
  236 |             await supplierTable
  237 |               .locator(".table-details-toggle")
  238 |               .first()
  239 |               .click();
  240 |             await expect(
  241 |               supplierTable.locator(".table-expanded-row dl > div"),
  242 |             ).toHaveCount(widthHidden);
  243 |             await expect(
  244 |               supplierTable.locator(".table-expanded-row dl dt"),
  245 |             ).toHaveText(
  246 |               hiddenColumns.map((column) => column[language === "en" ? 1 : 2]),
  247 |             );
  248 |             await check("suppliers width-hidden values remain in row details");
  249 |             await supplierTable
  250 |               .locator(".table-details-toggle")
  251 |               .first()
  252 |               .click();
  253 |           }
  254 |           await check("suppliers with every optional column enabled");
  255 |         }
  256 |       }
  257 |       await page.goto(orderUrl);
  258 |       await check("saved order detail");
  259 |       await page.goto("/#payables");
  260 |       await page
  261 |         .locator(".payables-overview tbody tr")
  262 |         .filter({ hasText: "Fresh Valley Foods" })
  263 |         .getByRole("link", {
  264 |           name: "Fresh Valley Foods",
  265 |           exact: true,
  266 |         })
  267 |         .click();
  268 |       await check("supplier ledger");
  269 |       await page.goto("/#orders");
  270 |       await page
  271 |         .getByRole("button", {
  272 |           name: language === "en" ? "New order" : "سفارش جدید",
  273 |           exact: true,
  274 |         })
  275 |         .click();
  276 |       await chooseOption(
  277 |         page,
  278 |         page.getByLabel(language === "en" ? "Supplier" : "تأمین‌کننده", {
  279 |           exact: true,
  280 |         }),
  281 |         "Fresh Valley Foods",
  282 |       );
  283 |       await check("new order item and cost fields");
  284 |       await testInfo.attach(`tables-${width}-${language}.json`, {
  285 |         body: JSON.stringify(report, null, 2),
  286 |         contentType: "application/json",
  287 |       });
  288 |     });
  289 |   }
  290 | }
  291 | 
  292 | test("Columns keeps mandatory names, persists by user and never exposes Supervisor money to a Floor Worker", async ({
  293 |   page,
  294 | }) => {
  295 |   await signIn(page, "Supervisor");
  296 |   await page.goto("/#products");
  297 |   await page.getByRole("button", { name: "Columns", exact: true }).click();
  298 |   let dialog = page.getByRole("dialog", { name: "Columns", exact: true });
  299 |   await expect(
  300 |     dialog.getByRole("checkbox", { name: "Product", exact: true }),
  301 |   ).toBeDisabled();
  302 |   await dialog
  303 |     .getByRole("checkbox", { name: "Approved price", exact: true })
  304 |     .uncheck();
  305 |   await dialog.getByRole("button", { name: "Close", exact: true }).click();
  306 |   await expect(
  307 |     page.locator(".catalog-products-table th[data-column-key=price]"),
  308 |   ).toHaveCount(0);
  309 |   await page.reload();
  310 |   // An absent optional header also matches an app that has not resumed yet.
  311 |   // Assert the real signed-in catalog before checking its persisted columns.
  312 |   await expect(page.locator(".topbar")).toBeVisible();
  313 |   await expect(
  314 |     page.locator(".catalog-products-table tbody tr").first(),
  315 |   ).toBeVisible();
  316 |   await expect(
  317 |     page.locator(".catalog-products-table th[data-column-key=price]"),
  318 |   ).toHaveCount(0);
  319 |   await signIn(page, "Floor Worker");
  320 |   await page.goto("/#products");
  321 |   await expect(
  322 |     page.locator(".catalog-products-table th[data-column-key=price]"),
  323 |   ).toHaveCount(1);
  324 |   await expect(
  325 |     page.locator(".catalog-products-table td[data-column-key=price]").first(),
> 326 |   ).toBeVisible();
      |     ^ Error: expect(locator).toBeVisible() failed
  327 |   await page.goto("/#suppliers");
  328 |   await expect(
  329 |     page.locator(
  330 |       ".suppliers-table [data-column-key=balance], .suppliers-table [data-column-key=overdue], .suppliers-table [data-column-key=due]",
  331 |     ),
  332 |   ).toHaveCount(0);
  333 |   await page.getByRole("button", { name: "Columns", exact: true }).click();
  334 |   dialog = page.getByRole("dialog", { name: "Columns", exact: true });
  335 |   await expect(
  336 |     dialog.getByRole("checkbox", { name: /Balance|Overdue|Next due date/ }),
  337 |   ).toHaveCount(0);
  338 |   await dialog.getByRole("button", { name: "Close", exact: true }).click();
  339 |   await signIn(page, "Supervisor");
  340 |   await page.goto("/#products");
  341 |   await expect(
  342 |     page.locator(".catalog-products-table th[data-column-key=price]"),
  343 |   ).toHaveCount(0);
  344 |   await page.getByRole("button", { name: "Columns", exact: true }).click();
  345 |   dialog = page.getByRole("dialog", { name: "Columns", exact: true });
  346 |   await dialog
  347 |     .getByRole("button", { name: "Reset columns", exact: true })
  348 |     .click();
  349 |   await dialog.getByRole("button", { name: "Close", exact: true }).click();
  350 |   await expect(
  351 |     page.locator(".catalog-products-table th[data-column-key=price]"),
  352 |   ).toHaveCount(1);
  353 |   await expect(
  354 |     page.locator(".catalog-products-table td[data-column-key=price]").first(),
  355 |   ).toBeVisible();
  356 | });
  357 | 
  358 | test("browser Back restores the Products search and Orders status without mutating data", async ({
  359 |   page,
  360 | }) => {
  361 |   await signIn(page, "Supervisor");
  362 |   await page.goto("/#products");
  363 |   const search = page.getByLabel("Search products", { exact: true });
  364 |   await search.fill("0004");
  365 |   await page
  366 |     .locator(".catalog-products-table tbody tr")
  367 |     .first()
  368 |     .getByRole("link", { name: "Black Tea 450 g", exact: true })
  369 |     .click();
  370 |   await expect(page).toHaveURL(/#product\?code=/);
  371 |   await page.goBack();
  372 |   await expect(search).toHaveValue("0004");
  373 |   await expect(page.locator(".catalog-products-table tbody tr")).toHaveCount(1);
  374 |   const form = await newOrder(page);
  375 |   await form
  376 |     .getByRole("textbox", { name: /^Cases —/ })
  377 |     .first()
  378 |     .fill("1");
  379 |   await form
  380 |     .getByRole("button", { name: "Save as draft", exact: true })
  381 |     .click();
  382 |   await page
  383 |     .getByRole("button", { name: "Back to Orders", exact: true })
  384 |     .click();
  385 |   await chooseOption(page, page.getByLabel("Status", { exact: true }), "Draft");
  386 |   const order = page.locator(".orders-list-table tbody tr").first();
  387 |   await order.locator(".order-reference-link").click();
  388 |   await expect(page).toHaveURL(/#orders\?id=/);
  389 |   await page.goBack();
  390 |   await expect(page.getByLabel("Status", { exact: true })).toHaveText("Draft");
  391 |   await expect(page.locator(".orders-list-table tbody tr")).toHaveCount(1);
  392 | });
  393 | 
  394 | test("an order error belongs to its invalid item and clears immediately only when that item changes", async ({
  395 |   page,
  396 | }) => {
  397 |   await signIn(page, "Supervisor");
  398 |   const form = await newOrder(page);
  399 |   const details = form.getByRole("button", {
  400 |     name: "Show details",
  401 |     exact: true,
  402 |   });
  403 |   while (await details.count()) await details.first().click();
  404 |   const costs = form.getByRole("textbox", { name: /^Expected unit cost —/ });
  405 |   const cases = form.getByRole("textbox", { name: /^Cases —/ });
  406 |   expect(await costs.count()).toBeGreaterThan(1);
  407 |   await cases.nth(0).fill("1");
  408 |   await cases.nth(1).fill("1");
  409 |   await costs.nth(0).fill("1.00001");
  410 |   await form
  411 |     .getByRole("button", { name: "Save as draft", exact: true })
  412 |     .click();
  413 |   await expect(costs.nth(0)).toHaveAttribute("aria-invalid", "true");
  414 |   await expect(costs.nth(1)).toHaveAttribute("aria-invalid", "false");
  415 |   await costs.nth(1).fill("2.5000");
  416 |   await expect(costs.nth(0)).toHaveAttribute("aria-invalid", "true");
  417 |   await costs.nth(0).fill("1.0000");
  418 |   await expect(costs.nth(0)).toHaveAttribute("aria-invalid", "false");
  419 |   const saved = await readCanonicalBusinessEvidence(page).then(
  420 |     (canonicalState) => JSON.parse(JSON.stringify(canonicalState)!).orders,
  421 |   );
  422 |   expect(saved).toHaveLength(0);
  423 | });
  424 | 
  425 | test("external payment is unchanged until explicit money confirmation, and cancellation records nothing", async ({
  426 |   page,
```