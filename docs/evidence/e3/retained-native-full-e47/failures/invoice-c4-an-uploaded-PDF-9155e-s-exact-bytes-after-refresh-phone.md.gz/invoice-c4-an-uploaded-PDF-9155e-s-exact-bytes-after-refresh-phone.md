# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: invoice-c4.spec.ts >> an uploaded PDF uses the custom viewer, navigates actual pages and retains exact bytes after refresh
- Location: tests/invoice-c4.spec.ts:234:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('img', { name: 'Original invoice PDF', exact: true })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('img', { name: 'Original invoice PDF', exact: true }) with timeout 5000ms
  - waiting for getByRole('img', { name: 'Original invoice PDF', exact: true })

```

```yaml
- link "Skip to content":
  - /url: "#main-content"
- banner:
  - button "Open menu"
  - combobox "Location": North York
  - button "Notifications, 5 unread": "5"
  - button "User menu"
  - button "More"
- main:
  - link "Back to Invoices":
    - /url: "#invoices"
  - heading "Invoices" [level=1]
  - paragraph: Deliveries and supplier invoices
  - button "New invoice"
  - tablist "Invoice views":
    - tab "Drafts" [selected]
    - tab "Processing"
    - tab "Needs review"
    - tab "Ready to post"
    - tab "Posted"
    - tab "Cancelled"
  - complementary "Original invoice":
    - heading "Original invoice" [level=2]
    - paragraph: AI invoice reading is simulated
    - button "Upload"
    - button "Manual entry"
    - text: Upload a PDF or photo
    - button "Upload a PDF or photo"
    - button "Take photo"
    - paragraph: Drop a PDF or photo here, or browse
    - button "Browse"
    - button "Take photo"
    - paragraph: No original attached
    - button "Attach original"
  - heading "Drafts" [level=2]
  - table:
    - rowgroup:
      - row "— Supplier — Date 2026-10-15 Status Draft Details Show details":
        - cell "—"
        - cell "Supplier —"
        - cell "Date 2026-10-15"
        - cell "Status Draft"
        - cell "Details Show details":
          - text: Details
          - button "Show details"
  - text: Subtotal
  - strong: $0.00
  - text: Tax
  - strong: $0.00
  - text: Shorts and refused deduction
  - strong: $0.00
  - text: Payable
  - strong: $0.00
  - paragraph: This is the amount of this invoice, not a supplier balance. Received records only physically delivered units.
  - heading "Invoice details" [level=2]:
    - button "Invoice details" [expanded]
  - paragraph: · — · North York · 2026-10-15
  - paragraph: Needs review Changes save automatically in this browser.
  - group:
    - text: Supplier
    - combobox "Supplier": Choose supplier
    - text: Supplier invoice number (optional)
    - textbox "Supplier invoice number (optional)":
      - /placeholder: Assigned on posting if blank
    - text: Invoice date
    - button "Invoice date": 2026-10-15
    - text: Received date
    - button "Received date": 2026-10-15
    - text: Received time
    - textbox "Received time":
      - /placeholder: HH:mm
      - text: 15:28
    - paragraph: Store local time, 24-hour HH:mm
    - text: Receiving employee
    - combobox "Receiving employee": Demo Manager
    - text: Location
    - combobox "Location": North York
    - text: Ship to (optional)
    - textbox "Ship to (optional)"
    - text: Subtotal
    - textbox "Subtotal": "0.00"
    - text: Tax
    - textbox "Tax": "0.00"
    - text: Final total
    - textbox "Final total": "0.00"
    - text: Due date (optional)
    - button "Due date (optional)": 2026-10-29
    - text: Payment terms (optional)
    - combobox "Payment terms (optional)": Choose payment terms
  - heading "Compare with order" [level=2]
  - text: Order (optional)
  - combobox "Order (optional)": No linked order
  - paragraph: Choose an open order for this supplier and receiving location.
  - heading "Review invoice lines" [level=2]
  - paragraph: Choose Cases or Units and confirm the product, pack, quantities, cost, and date decision on each line.
  - paragraph: No lines. Add a product below to start your manual draft.
  - table
  - text: Add a product to the invoice
  - combobox "Add a product to the invoice": ⁦0002⁩ · ⁦Canned Fava Beans 400 g ⁩
  - button "Add line"
  - button "+ Add new product"
  - button "Save as draft"
  - button "Post invoice"
```

# Test source

```ts
  152 |     await expect(
  153 |       page.getByRole("button", {
  154 |         name: fa ? "اصلاح فاکتور" : "Correct invoice",
  155 |         exact: true,
  156 |       }),
  157 |     ).toBeVisible();
  158 |     await page.reload();
  159 |     expect((await saved(page)).invoice_content_corrections!.at(-1)).toEqual(
  160 |       correction,
  161 |     );
  162 |     await page.goto("/#history");
  163 |     const correctedLink = page.locator(".history-table").getByRole("link", {
  164 |       name: fa ? "نمایش اصلاح‌شده" : "View corrected",
  165 |       exact: true,
  166 |     });
  167 |     await expect(correctedLink).toBeVisible();
  168 |     const row = correctedLink.locator("xpath=ancestor::tr[1]");
  169 |     const action = fa ? "اصلاح فاکتور" : "Correct invoice";
  170 |     if (!(await row.getByText(action, { exact: true }).isVisible())) {
  171 |       const disclosure = row.getByRole("button", {
  172 |         name: fa ? "نمایش جزئیات" : "Show details",
  173 |         exact: true,
  174 |       });
  175 |       const panelId = await disclosure.getAttribute("aria-controls");
  176 |       await disclosure.click();
  177 |       await expect(
  178 |         page.locator(`[id=${JSON.stringify(panelId)}]`),
  179 |       ).toContainText(action);
  180 |     } else {
  181 |       await expect(row.getByText(action, { exact: true })).toBeVisible();
  182 |     }
  183 |     await expect(
  184 |       row.getByRole("link", {
  185 |         name: fa ? "نمایش اصلاح‌شده" : "View corrected",
  186 |         exact: true,
  187 |       }),
  188 |     ).toHaveAttribute("href", new RegExp(`version=${correction.id}`));
  189 |     await row
  190 |       .getByRole("button", {
  191 |         name: fa ? "کارهای بیشتر" : "More actions",
  192 |         exact: true,
  193 |       })
  194 |       .click();
  195 |     await page
  196 |       .getByRole("menuitem", {
  197 |         name: fa ? "نمایش اصل" : "View original",
  198 |         exact: true,
  199 |       })
  200 |       .click();
  201 |     await expect(page).toHaveURL(/version=original/);
  202 |   });
  203 | 
  204 | /** A real two-page PDF built from vector content, uploaded through the same file control. */
  205 | function twoPagePdf() {
  206 |   const stream = (contents: string) =>
  207 |     `<< /Length ${Buffer.byteLength(contents)} >>\nstream\n${contents}endstream`;
  208 |   const objects = [
  209 |     "<< /Type /Catalog /Pages 2 0 R >>",
  210 |     "<< /Type /Pages /Kids [3 0 R 5 0 R] /Count 2 >>",
  211 |     "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 300 400] /Resources << >> /Contents 4 0 R >>",
  212 |     stream("0.2 0.4 0.8 rg 20 280 260 90 re f\n"),
  213 |     "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 300 400] /Resources << >> /Contents 6 0 R >>",
  214 |     stream("0.8 0.4 0.2 rg 20 100 260 90 re f\n"),
  215 |   ];
  216 |   let body = "%PDF-1.4\n";
  217 |   const offsets = [0];
  218 |   objects.forEach((object, index) => {
  219 |     offsets.push(Buffer.byteLength(body));
  220 |     body += `${index + 1} 0 obj\n${object}\nendobj\n`;
  221 |   });
  222 |   const xref = Buffer.byteLength(body);
  223 |   body += `xref\n0 7\n0000000000 65535 f \n${offsets
  224 |     .slice(1)
  225 |     .map((offset) => `${String(offset).padStart(10, "0")} 00000 n \n`)
  226 |     .join("")}trailer\n<< /Size 7 /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
  227 |   return {
  228 |     name: "fictional-two-page-invoice.pdf",
  229 |     mimeType: "application/pdf",
  230 |     buffer: Buffer.from(body),
  231 |   };
  232 | }
  233 | 
  234 | test("an uploaded PDF uses the custom viewer, navigates actual pages and retains exact bytes after refresh", async ({
  235 |   page,
  236 | }, testInfo) => {
  237 |   const fixture = twoPagePdf();
  238 |   const digest = (bytes: Buffer) =>
  239 |     createHash("sha256").update(bytes).digest("hex");
  240 |   const expectedHash = digest(fixture.buffer);
  241 |   await signIn(page, "Supervisor");
  242 |   await page.goto("/#invoices");
  243 |   await page.getByRole("button", { name: "New invoice", exact: true }).click();
  244 |   await page.getByRole("button", { name: "Manual entry", exact: true }).click();
  245 |   await page
  246 |     .getByLabel("Upload a PDF or photo", { exact: true })
  247 |     .setInputFiles(fixture);
  248 |   const canvas = page.getByRole("img", {
  249 |     name: "Original invoice PDF",
  250 |     exact: true,
  251 |   });
> 252 |   await expect(canvas).toBeVisible();
      |                        ^ Error: expect(locator).toBeVisible() failed
  253 |   await expect(page.locator(".invoice-pdf-pages")).toContainText("1 / 2");
  254 |   await expect
  255 |     .poll(() =>
  256 |       canvas.evaluate((element) => (element as HTMLCanvasElement).width),
  257 |     )
  258 |     .toBeGreaterThan(1);
  259 |   const pixel = (vertical: number) =>
  260 |     canvas.evaluate((element, vertical) => {
  261 |       const canvas = element as HTMLCanvasElement;
  262 |       return Array.from(
  263 |         canvas
  264 |           .getContext("2d")!
  265 |           .getImageData(
  266 |             Math.floor(canvas.width / 2),
  267 |             Math.floor(canvas.height * vertical),
  268 |             1,
  269 |             1,
  270 |           ).data,
  271 |       ).slice(0, 3);
  272 |     }, vertical);
  273 |   await expect.poll(() => pixel(0.18)).toEqual([51, 102, 204]);
  274 |   const initialPixels = await canvas.evaluate((element) =>
  275 |     (element as HTMLCanvasElement).toDataURL(),
  276 |   );
  277 |   await page.getByRole("button", { name: "Next page", exact: true }).click();
  278 |   await expect(page.locator(".invoice-pdf-pages")).toContainText("2 / 2");
  279 |   await expect
  280 |     .poll(() =>
  281 |       canvas.evaluate((element) => (element as HTMLCanvasElement).toDataURL()),
  282 |     )
  283 |     .not.toBe(initialPixels);
  284 |   await expect.poll(() => pixel(0.63)).toEqual([204, 102, 51]);
  285 |   await expect
  286 |     .poll(async () => (await saved(page)).invoice.file_data)
  287 |     .toMatch(new RegExp(`^idb-file:v1:.*:${expectedHash}$`));
  288 |   const retained = await saved(page);
  289 |   const uploaded = retained.invoice.file_data!;
  290 |   const companyId = retained.config.company.seed_key;
  291 |   expect(retained.invoice.file_size).toBe(fixture.buffer.length);
  292 |   const storedPdf = () =>
  293 |     page.evaluate(
  294 |       async ({ reference, companyId }) => {
  295 |         const database = await new Promise<IDBDatabase>((resolve, reject) => {
  296 |           const request = indexedDB.open("supermarket-prototype-files-v1", 1);
  297 |           request.onsuccess = () => resolve(request.result);
  298 |           request.onerror = () => reject(request.error);
  299 |         });
  300 |         try {
  301 |           const record = await new Promise<{
  302 |             company_id: string;
  303 |             type: string;
  304 |             sha256: string;
  305 |             source_size: number;
  306 |             source: Blob;
  307 |           }>((resolve, reject) => {
  308 |             const request = database
  309 |               .transaction("files", "readonly")
  310 |               .objectStore("files")
  311 |               .get(reference);
  312 |             request.onsuccess = () =>
  313 |               request.result
  314 |                 ? resolve(request.result)
  315 |                 : reject(new Error("Missing retained PDF source."));
  316 |             request.onerror = () => reject(request.error);
  317 |           });
  318 |           if (record.company_id !== companyId)
  319 |             throw new Error("Stored PDF company scope mismatch.");
  320 |           return {
  321 |             company_id: record.company_id,
  322 |             type: record.type,
  323 |             sha256: record.sha256,
  324 |             size: record.source_size,
  325 |             bytes: Array.from(
  326 |               new Uint8Array(await record.source.arrayBuffer()),
  327 |             ),
  328 |           };
  329 |         } finally {
  330 |           database.close();
  331 |         }
  332 |       },
  333 |       { reference: uploaded, companyId },
  334 |     );
  335 |   const beforeReload = await storedPdf();
  336 |   expect(beforeReload.type).toBe("application/pdf");
  337 |   expect(beforeReload.sha256).toBe(expectedHash);
  338 |   expect(beforeReload.size).toBe(fixture.buffer.length);
  339 |   expect(Buffer.from(beforeReload.bytes)).toEqual(fixture.buffer);
  340 |   expect(digest(Buffer.from(beforeReload.bytes))).toBe(expectedHash);
  341 |   await page.reload();
  342 |   await expect(page.locator(".invoice-pdf-pages")).toContainText("1 / 2");
  343 |   expect((await saved(page)).invoice.file_data).toBe(uploaded);
  344 |   await expect.poll(() => pixel(0.18)).toEqual([51, 102, 204]);
  345 |   const afterReload = await storedPdf();
  346 |   expect(afterReload).toEqual(beforeReload);
  347 |   expect(Buffer.from(afterReload.bytes)).toEqual(fixture.buffer);
  348 |   const downloadEvent = page.waitForEvent("download");
  349 |   await page
  350 |     .locator(".invoice-original-controls")
  351 |     .getByRole("button", { name: "Download", exact: true })
  352 |     .click();
```