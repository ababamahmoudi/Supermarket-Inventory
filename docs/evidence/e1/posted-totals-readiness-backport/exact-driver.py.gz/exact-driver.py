from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,os,subprocess,tarfile,time
ROOT=Path('/workspace/Supermarket-Inventory');BASE=Path('/tmp/posted-totals-readiness-backports');BASE.mkdir(exist_ok=False)
BRANCHES={'e1':'feat/prototype-e1-location-roles','e2':'feat/prototype-e2-price-updates'};FILE='prototype/src/screens/DocumentsReturns.c5.test.tsx';EXPECTED='953980181b1af9395a01489de3d7c5d89c7496f4309fce1878a6dd61baf9ac77'
sha=lambda b:hashlib.sha256(b).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git','-C',str(ROOT),*args])
ENV=dict(os.environ);ENV['PATH']='/workspace/scratch/node-install/node-v22.23.3-linux-x64/bin:'+ENV['PATH']
prepared=[]
for stage,branch in BRANCHES.items():
 commit=git('rev-parse',branch).decode().strip();folder=BASE/stage;folder.mkdir();candidate=folder/'candidate';candidate.mkdir();archive=folder/'exact-branch-source.tar'
 with archive.open('wb') as out:subprocess.run(['git','-C',str(ROOT),'archive',commit],stdout=out,check=True)
 with tarfile.open(archive) as tf:tf.extractall(candidate,filter='data')
 (candidate/'prototype/node_modules').symlink_to(ROOT/'prototype/node_modules',target_is_directory=True)
 assert sha((candidate/FILE).read_bytes())==EXPECTED
 paths=[p for p in git('ls-tree','-rz','--name-only',commit).decode().split('\0') if p and (p.startswith(('prototype/','seed/','assets/')) or p.endswith('AGENTS.md') or p=='docs/return-policy.md')]
 pins={p:sha((candidate/p).read_bytes()) for p in paths if (candidate/p).is_file()}
 config=candidate/'prototype/vitest-posted-backport-proof.config.ts';config.write_text('''import config from "./vite.config.ts";
export default {
 ...config,
 server: {
  ...config.server,
  fs: {
   ...config.server?.fs,
   allow: [...(config.server?.fs?.allow ?? []), "/workspace/Supermarket-Inventory/prototype/node_modules"],
  },
 },
};
''')
 observer=folder/'observer.mjs';observer.write_text('''import {writeFileSync} from 'node:fs';
const output='''+json.dumps(str(folder/'global-errors.json'))+''';
const save=v=>writeFileSync(output,JSON.stringify(v,null,2)+'\\n');
export default class ErrorObserver {
 onInit(ctx){this.ctx=ctx;process.once('exit',code=>save({phase:'process-exit',code,errors:this.ctx.state.getUnhandledErrors?.()??[],atRunEnd:this.result}));}
 onTestRunEnd(modules,errors,reason){this.result={phase:'onTestRunEnd',reason,errors,moduleCount:modules.length};save(this.result);}
}
''')
 start={'stage':stage,'branch':branch,'commit':commit,'archive_sha256':sha(archive.read_bytes()),'source_pins':pins,'source_pin_count':len(pins),'source_overlay':[],'fixture_sha256':EXPECTED,'runner_adapter':'Append only actual shared dependency directory to Vite fs.allow; no source replacements or production mocks.'};dump(folder/'start.json',start);prepared.append((folder,candidate,start))
def run(item):
 folder,candidate,start=item;command=['node','node_modules/vitest/vitest.mjs','run','--config','vitest-posted-backport-proof.config.ts','src/screens/DocumentsReturns.c5.test.tsx','--maxWorkers=1','--reporter=default','--reporter=json','--reporter='+str(folder/'observer.mjs'),'--outputFile='+str(folder/'unit.json')];began=time.time()
 with (folder/'unit.log').open('w') as out:res=subprocess.run(command,cwd=candidate/'prototype',env=ENV,stdout=out,stderr=subprocess.STDOUT)
 report=json.loads((folder/'unit.json').read_text());errors=json.loads((folder/'global-errors.json').read_text());after={p:sha((candidate/p).read_bytes()) for p in start['source_pins']}
 result={'stage':start['stage'],'branch':start['branch'],'commit':start['commit'],'command':command,'actual_exit_code':res.returncode,'seconds':time.time()-began,'source_pin_count':start['source_pin_count'],'source_unchanged':start['source_pins']==after,'unit_counts':{k:report[k] for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','success']},'global_errors':errors['errors'],'fixture_sha256':sha((candidate/FILE).read_bytes()),'no_source_overlay':True};dump(folder/'result.json',result);print(json.dumps(result),flush=True);return result
with ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(run,prepared))
dump(BASE/'summary.json',{'scope':'Entire actual DocumentsReturns file on exact E1 and E2 committed Git archives;1 worker each, no source overlays','results':results,'tracked_writes':False,'root_branch_switches':False})
assert all(r['actual_exit_code']==0 and r['source_unchanged'] and r['unit_counts']['numPassedTests']==7 and r['unit_counts']['numFailedTests']==0 and r['unit_counts']['numPendingTests']==0 and not r['global_errors'] for r in results)
