import { Blob as NodeBlob } from "node:buffer";
import { webcrypto } from "node:crypto";
import { writeFileSync } from "node:fs";
import { afterEach, beforeEach, expect, it, vi } from "/workspace/Supermarket-Inventory/prototype/node_modules/vitest/dist/index.js";
import { IDBFactory } from "/workspace/Supermarket-Inventory/prototype/node_modules/fake-indexeddb/build/esm/index.js";
import { configSeed } from "/workspace/Supermarket-Inventory/prototype/src/config";
import { initialState, relativeDate } from "/workspace/Supermarket-Inventory/prototype/src/e1-bootstrap";
import { companyDate, dateAfter } from "/workspace/Supermarket-Inventory/prototype/src/invoice";
import { createE1ShellRuntime } from "/workspace/Supermarket-Inventory/prototype/src/e1-shell-runtime";
import { createBrowserProviderOptions } from "/workspace/Supermarket-Inventory/prototype/src/e1-application-options";
import { BrowserAuthorityRepository } from "/workspace/Supermarket-Inventory/prototype/src/authority-repository";

const NativeDateTimeFormat = Intl.DateTimeFormat;
const now = new Date("2026-10-19T16:00:00.000Z");
const repositories: BrowserAuthorityRepository[] = [];
let closeRuntime: (() => void) | undefined;

beforeEach(() => {
  vi.useFakeTimers({ toFake: ["Date"] });
  vi.setSystemTime(now);
  localStorage.clear();
  sessionStorage.clear();
  vi.stubGlobal("indexedDB", new IDBFactory());
  vi.stubGlobal("crypto", webcrypto);
  vi.stubGlobal("Blob", NodeBlob);
});
afterEach(() => {
  closeRuntime?.();
  closeRuntime = undefined;
  for (const repository of repositories.splice(0)) repository.dispose();
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
  vi.useRealTimers();
});

function useSlashFormattedEnCaDate() {
  vi.spyOn(Intl, "DateTimeFormat").mockImplementation(function (
    locales?: Intl.LocalesArgument,
    options?: Intl.DateTimeFormatOptions,
  ) {
    const formatter = new NativeDateTimeFormat(locales, options);
    if (
      locales === "en-CA" &&
      options?.year === "numeric" &&
      options.month === "2-digit" &&
      options.day === "2-digit" &&
      !options.hour
    ) {
      // Alter only the presentation ordering of a valid localized date. The
      // actual engine's formatToParts, timezone and calendar remain unchanged.
      Object.defineProperty(formatter, "format", {
        configurable: true,
        value: (value?: Date | number) => {
          const parts = formatter.formatToParts(value);
          const part = (type: string) =>
            parts.find((entry) => entry.type === type)!.value;
          return `${part("month")}/${part("day")}/${part("year")}`;
        },
      });
    }
    return formatter;
  });
}

function runtimeOptions() {
  const repository = new BrowserAuthorityRepository(indexedDB);
  repositories.push(repository);
  return {
    ...createBrowserProviderOptions(),
    repository,
    localStorage,
    sessionStorage,
    publish: vi.fn(),
    publishPreferences: vi.fn(),
    publishError: vi.fn(),
  };
}

it("baseline uses the original date formatter and actual demo/config without reset", () => {
  expect(relativeDate(0)).toBe("2026-10-19");
  const state = initialState();
  expect(state.config.company.timezone).toBe(configSeed.company.timezone);
  expect(state.supplier_balance_snapshot_date).toBe("2026-10-19");
  expect(state.invoices!.length).toBeGreaterThan(0);
  expect(createBrowserProviderOptions().demoUsers).toHaveLength(6);
});

it("baseline actual runtime completes with normal initial loader and untouched accounts", async () => {
  const options = runtimeOptions();
  const runtime = await createE1ShellRuntime(options);
  closeRuntime = () => runtime.dispose();
  expect(options.publish).toHaveBeenCalled();
  expect(options.publishError).not.toHaveBeenCalled();
  expect((await runtime.demoPeople()).map((person) => person.username)).toEqual(
    options.demoUsers.map((person) => person.username),
  );
});

it("another localized en-CA date ordering breaks actual initialState in dateAfter, while companyDate stays ISO", () => {
  useSlashFormattedEnCaDate();
  expect(relativeDate(0)).toBe("10/19/2026");
  expect(companyDate(configSeed, now)).toBe("2026-10-19");
  expect(dateAfter(companyDate(configSeed, now), -56)).toBe("2026-08-24");
  let failure: unknown;
  try {
    initialState();
  } catch (error) {
    failure = error;
  }
  expect(failure).toBeInstanceOf(RangeError);
  expect((failure as Error).stack).toMatch(/dateAfter/);
  expect((failure as Error).stack).toMatch(/hydrateDemoFixture/);
  const evidence = {
      proof: "simulated localized ordering; not native WebKit evidence",
      configuredTimeZone: configSeed.company.timezone,
      localizedDate: relativeDate(0),
      assembledDate: companyDate(configSeed, now),
      failure: {
        name: (failure as Error).name,
        message: (failure as Error).message,
        frames: (failure as Error).stack?.split("\n").slice(1, 6),
      },
    };
  writeFileSync(
    "/tmp/c9-date-format-proof/controlled-hypothesis.json",
    JSON.stringify(evidence, null, 2) + "\n",
  );
});

it("the same localized ordering rejects the actual runtime before publishing its initial session", async () => {
  useSlashFormattedEnCaDate();
  const options = runtimeOptions();
  await expect(createE1ShellRuntime(options)).rejects.toThrow(RangeError);
  expect(options.publish).not.toHaveBeenCalled();
  expect(options.demoUsers).toHaveLength(6);
});
