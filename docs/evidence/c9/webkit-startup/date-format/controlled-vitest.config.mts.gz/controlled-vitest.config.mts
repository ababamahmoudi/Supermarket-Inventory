export default {
  root: "/workspace/Supermarket-Inventory/prototype",
  server: { fs: { allow: ["/workspace", "/tmp"] } },
  test: {
    environment: "jsdom",
    include: ["/tmp/c9-date-format-proof/date-format.proof.test.ts"],
    restoreMocks: true,
    clearMocks: true,
    maxWorkers: 2,
    testTimeout: 30000,
  },
};
