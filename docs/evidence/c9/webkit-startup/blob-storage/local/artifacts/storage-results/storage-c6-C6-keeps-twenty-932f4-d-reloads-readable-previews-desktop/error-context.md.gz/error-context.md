# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: storage-c6.spec.ts >> C6 keeps twenty distinct 3MB photos out of text storage, preserves exact originals and reloads readable previews
- Location: tests/storage-c6.spec.ts:406:1

# Error details

```
Error: expect(received).toMatch(expected)

Matcher error: received value must be a string

Received has value: undefined

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - complementary "Main menu" [ref=e5]:
    - generic [ref=e6]:
      - img "Super Arzon" [ref=e9]
      - generic [ref=e10]: Super Arzon
    - navigation "Pages" [ref=e11]:
      - generic [ref=e12]:
        - button "Daily" [expanded] [ref=e13] [cursor=pointer]
        - generic [ref=e17]:
          - link "Lookup" [ref=e18] [cursor=pointer]:
            - /url: "#lookup"
          - link "Invoices" [ref=e23] [cursor=pointer]:
            - /url: "#invoices"
          - link "Received" [ref=e28] [cursor=pointer]:
            - /url: "#received"
          - link "Returns" [ref=e35] [cursor=pointer]:
            - /url: "#returns"
          - link "Price updates" [ref=e40] [cursor=pointer]:
            - /url: "#price-updates"
          - link "Labels" [ref=e46] [cursor=pointer]:
            - /url: "#labels"
          - link "Date tracking" [ref=e51] [cursor=pointer]:
            - /url: "#expiry"
          - link "Notes" [ref=e56] [cursor=pointer]:
            - /url: "#notes"
            - generic [ref=e60]: "2"
          - link "Branch requests" [ref=e61] [cursor=pointer]:
            - /url: "#requests"
      - button "Catalog" [ref=e67] [cursor=pointer]
      - button "Manager" [ref=e72] [cursor=pointer]
      - button "Admin" [ref=e77] [cursor=pointer]
    - button "User menu" [ref=e82] [cursor=pointer]:
      - generic [ref=e83]:
        - generic [aria-hidden] [ref=e84]: DM
        - generic [ref=e85]:
          - strong [ref=e86]: Demo Manager
          - generic [ref=e87]: Manager
  - generic [ref=e88]:
    - banner [ref=e89]:
      - button "Collapse sidebar" [expanded] [ref=e90] [cursor=pointer]
      - navigation "Breadcrumbs" [ref=e94]:
        - link "North York" [ref=e95] [cursor=pointer]:
          - /url: "#dashboard"
        - link "Invoices" [ref=e98] [cursor=pointer]:
          - /url: "#invoices"
      - search [ref=e99]:
        - textbox "Search all products" [ref=e103]:
          - /placeholder: Search products
        - generic [aria-hidden] [ref=e104]: /
      - combobox "Location" [ref=e105] [cursor=pointer]:
        - generic [ref=e110]: North York
      - button "Switch to Persian" [ref=e113] [cursor=pointer]: فا
      - button "Switch to dark theme" [ref=e114] [cursor=pointer]
      - button "Comfortable text size" [ref=e117] [cursor=pointer]:
        - generic [aria-hidden] [ref=e118]: Aa
      - button "Notifications, 5 unread" [ref=e119] [cursor=pointer]:
        - generic [ref=e120]: "5"
      - button "Demo" [ref=e125] [cursor=pointer]
    - main [ref=e128]:
      - generic [ref=e129]:
        - link "Back to Invoices" [ref=e130] [cursor=pointer]:
          - /url: "#invoices"
        - generic [ref=e133]:
          - generic [ref=e134]:
            - heading "Invoices" [level=1] [ref=e135]
            - paragraph [ref=e136]: Deliveries and supplier invoices
          - button "New invoice" [ref=e138] [cursor=pointer]
        - tablist "Invoice views" [ref=e139]:
          - tab "Drafts" [ref=e140] [cursor=pointer]
          - tab "Processing" [ref=e142] [cursor=pointer]
          - tab "Needs review" [selected] [ref=e144] [cursor=pointer]
          - tab "Ready to post" [ref=e146] [cursor=pointer]
          - tab "Posted" [ref=e148] [cursor=pointer]
          - tab "Cancelled" [ref=e150] [cursor=pointer]
        - generic [ref=e152]:
          - complementary "Original invoice" [ref=e153]:
            - generic [ref=e154]:
              - heading "Original invoice" [level=2] [ref=e155]
              - paragraph [ref=e156]: AI invoice reading is simulated
              - generic [ref=e158]:
                - generic [ref=e159]: Upload a PDF or photo
                - generic [ref=e160]:
                  - button "Upload a PDF or photo" [ref=e161]
                  - button "Take photo" [ref=e162]
                  - generic [ref=e163]:
                    - generic [ref=e167]:
                      - strong [ref=e168]: fictional-storage-photo-5.jpg
                      - generic [ref=e169]: 3.0 MB
                    - button "Remove file" [ref=e170] [cursor=pointer]
                  - button "Browse" [ref=e175] [cursor=pointer]
              - group "Original invoice" [ref=e176]:
                - generic [ref=e177]:
                  - button "Zoom out" [ref=e178] [cursor=pointer]
                  - generic [ref=e180]: 100%
                  - button "Zoom in" [ref=e181] [cursor=pointer]
                - button "Fit width" [ref=e183] [cursor=pointer]
                - button "Fit page" [ref=e184] [cursor=pointer]
                - button "Download" [ref=e185] [cursor=pointer]
              - img "Original invoice image" [ref=e190]
          - generic [ref=e191]:
            - generic [ref=e192]:
              - generic "Delivery summary" [ref=e193]:
                - generic [ref=e194]:
                  - generic [ref=e195]: Subtotal
                  - strong [ref=e196]: $0.00
                - generic [ref=e197]:
                  - generic [ref=e198]: Tax
                  - strong [ref=e199]: $0.00
                - generic [ref=e200]:
                  - generic [ref=e201]: Shorts and refused deduction
                  - strong [ref=e202]: $0.00
                - generic [ref=e203]:
                  - generic [ref=e204]: Payable
                  - strong [ref=e205]: $0.00
              - paragraph [ref=e206]: This is the amount of this invoice, not a supplier balance. Received records only physically delivered units.
            - generic [ref=e207]:
              - heading [level=2] [ref=e208]:
                - button "Invoice details" [ref=e209] [cursor=pointer]
              - paragraph [ref=e212]:
                - text: ·
                - generic [ref=e213]: —
                - text: · North York ·
                - generic [ref=e214]: 2026-10-19
              - paragraph [ref=e215]:
                - generic [ref=e216]: Needs review
                - text: Changes save automatically in this browser.
            - generic [ref=e218]:
              - heading "Compare with order" [level=2] [ref=e219]
              - generic [ref=e220]:
                - generic [ref=e221]: Order (optional)
                - combobox "Order (optional)" [ref=e222] [cursor=pointer]:
                  - generic [ref=e223]: No linked order
                - paragraph [ref=e226]: Choose an open order for this supplier and receiving location.
            - generic [ref=e227]:
              - heading "Review invoice lines" [level=2] [ref=e228]
              - paragraph [ref=e229]: Choose Cases or Units and confirm the product, pack, quantities, cost, and date decision on each line.
              - paragraph [ref=e235]: No lines. Add a product below to start your manual draft.
              - generic:
                - table
              - generic [ref=e236]:
                - generic [ref=e237]:
                  - generic [ref=e238]: Add a product to the invoice
                  - combobox "Add a product to the invoice" [ref=e239] [cursor=pointer]:
                    - generic [ref=e241]:
                      - text: ⁦0002⁩ · ⁦
                      - generic [ref=e242]:
                        - text: Canned Fava Beans
                        - generic [ref=e243]: 400 g
                      - text: ⁩
                - button "Add line" [ref=e246] [cursor=pointer]
                - button "+ Add new product" [ref=e247] [cursor=pointer]
          - generic [ref=e249]:
            - button "Save as draft" [ref=e250] [cursor=pointer]
            - button "Post invoice" [ref=e251] [cursor=pointer]
```

# Test source

```ts
  334 |   }, databaseName);
  335 | }
  336 | 
  337 | async function canonicalBusinessExists(page: Page) {
  338 |   return page.evaluate(
  339 |     ({ databaseName, companyId }) =>
  340 |       new Promise<boolean>((resolve, reject) => {
  341 |         const request = indexedDB.open(databaseName);
  342 |         request.onupgradeneeded = () => {
  343 |           request.transaction?.abort();
  344 |           reject(new Error("Evidence must not create a canonical database."));
  345 |         };
  346 |         request.onerror = () => reject(request.error);
  347 |         request.onsuccess = () => {
  348 |           const database = request.result;
  349 |           const transaction = database.transaction("business", "readonly");
  350 |           const read = transaction.objectStore("business").get(companyId);
  351 |           let exists = false;
  352 |           read.onsuccess = () => {
  353 |             exists = read.result !== undefined;
  354 |           };
  355 |           transaction.oncomplete = () => {
  356 |             database.close();
  357 |             resolve(exists);
  358 |           };
  359 |           transaction.onabort = transaction.onerror = () => {
  360 |             database.close();
  361 |             reject(
  362 |               transaction.error ??
  363 |                 new Error("Cannot inspect canonical publication."),
  364 |             );
  365 |           };
  366 |         };
  367 |       }),
  368 |     {
  369 |       databaseName: AUTHORITY_DATABASE_NAME,
  370 |       companyId: companyId,
  371 |     },
  372 |   );
  373 | }
  374 | async function openManual(page: Page) {
  375 |   const previousInvoiceId = (await saved(page)).invoice.id;
  376 |   await page.getByRole("button", { name: "New invoice", exact: true }).click();
  377 |   // New and Manual entry are two real persisted commands. Do not choose the
  378 |   // old invoice's entry method while New is still committing its replacement.
  379 |   await expect
  380 |     .poll(async () => (await saved(page)).invoice.id)
  381 |     .not.toBe(previousInvoiceId);
  382 |   await expect(
  383 |     page.getByRole("button", { name: "New invoice", exact: true }),
  384 |   ).toBeEnabled();
  385 |   await page.getByRole("button", { name: "Manual entry", exact: true }).click();
  386 |   // A retained large original is still reconciling when its reference appears.
  387 |   // The real entry barrier releases only when route and projection agree.
  388 |   await expect(
  389 |     page.getByRole("button", { name: "New invoice", exact: true }),
  390 |   ).toBeEnabled();
  391 |   await expect
  392 |     .poll(async () => {
  393 |       const current = (await saved(page)).invoice;
  394 |       return (
  395 |         current.id !== previousInvoiceId &&
  396 |         current.entry_mode === "manual" &&
  397 |         current.status === "draft"
  398 |       );
  399 |     })
  400 |     .toBe(true);
  401 |   await expect(
  402 |     page.getByRole("heading", { name: "Review invoice lines", exact: true }),
  403 |   ).toBeVisible();
  404 | }
  405 | 
  406 | test("C6 keeps twenty distinct 3MB photos out of text storage, preserves exact originals and reloads readable previews", async ({
  407 |   page,
  408 | }, testInfo) => {
  409 |   test.setTimeout(300_000);
  410 |   const errors: string[] = [];
  411 |   page.on("pageerror", (error) => errors.push(error.message));
  412 |   await signIn(page, "Supervisor");
  413 |   await waitForSavedFiles(page);
  414 |   await page.goto("/#invoices");
  415 |   const uploaded: {
  416 |     id: string;
  417 |     reference: string;
  418 |     sha256: string;
  419 |     size: number;
  420 |     name: string;
  421 |   }[] = [];
  422 |   for (let index = 0; index < 20; index++) {
  423 |     await openManual(page);
  424 |     const photo = await makePhoto(page, index);
  425 |     await page
  426 |       .getByLabel("Upload a PDF or photo", { exact: true })
  427 |       .setInputFiles({
  428 |         name: photo.name,
  429 |         mimeType: "image/jpeg",
  430 |         buffer: photo.buffer,
  431 |       });
  432 |     await expect
  433 |       .poll(async () => (await saved(page))?.invoice.file_data)
> 434 |       .toMatch(new RegExp(`^idb-file:v1:.*:${photo.sha256}$`));
      |        ^ Error: expect(received).toMatch(expected)
  435 |     const invoice = (await saved(page)).invoice;
  436 |     uploaded.push({
  437 |       id: invoice.id,
  438 |       reference: invoice.file_data!,
  439 |       sha256: photo.sha256,
  440 |       size: photo.size,
  441 |       name: photo.name,
  442 |     });
  443 |     const image = page.getByRole("img", {
  444 |       name: "Original invoice image",
  445 |       exact: true,
  446 |     });
  447 |     await expect(image).toBeVisible();
  448 |     await expect
  449 |       .poll(() =>
  450 |         image.evaluate((element: HTMLImageElement) => element.naturalWidth),
  451 |       )
  452 |       .toBe(2000);
  453 |     await expect(page.getByText(storageFailure)).toHaveCount(0);
  454 |   }
  455 |   expect(new Set(uploaded.map((file) => file.sha256)).size).toBe(20);
  456 |   expect(new Set(uploaded.map((file) => file.reference)).size).toBe(20);
  457 |   const before = await retainedFiles(
  458 |     page,
  459 |     uploaded.map((file) => file.reference),
  460 |   );
  461 |   expect(before).toHaveLength(20);
  462 |   for (const [index, file] of before.entries()) {
  463 |     expect(file.size).toBe(uploaded[index].size);
  464 |     expect(file.hash).toBe(uploaded[index].sha256);
  465 |     expect(file.recorded_hash).toBe(file.hash);
  466 |     expect(
  467 |       Math.max(file.preview_width, file.preview_height),
  468 |     ).toBeLessThanOrEqual(2000);
  469 |     expect(file.preview_size).toBeLessThan(file.size);
  470 |   }
  471 |   const bytesBefore = await textBytes(page);
  472 |   if (bytesBefore >= 5 * 1024 * 1024) {
  473 |     const profile = await page.evaluate(
  474 |       (state) => {
  475 |         const fields = Object.entries(state)
  476 |           .map(([key, value]) => ({
  477 |             key,
  478 |             bytes: JSON.stringify(value).length * 2,
  479 |           }))
  480 |           .sort((a, b) => b.bytes - a.bytes);
  481 |         const keys = Array.from({ length: localStorage.length }, (_, index) =>
  482 |           localStorage.key(index)!,
  483 |         ).map((key) => ({
  484 |           key,
  485 |           bytes: (key.length + localStorage.getItem(key)!.length) * 2,
  486 |         }));
  487 |         const actions: Record<string, number> = {};
  488 |         for (const entry of state.activity)
  489 |           actions[entry.action] =
  490 |             (actions[entry.action] ?? 0) + JSON.stringify(entry).length * 2;
  491 |         return {
  492 |           keys,
  493 |           fields,
  494 |           activity_count: state.activity.length,
  495 |           action_bytes: actions,
  496 |         };
  497 |       },
  498 |       await saved(page),
  499 |     );
  500 |     await testInfo.attach("Text storage size profile", {
  501 |       body: JSON.stringify(profile, null, 2),
  502 |       contentType: "application/json",
  503 |     });
  504 |   }
  505 |   expect(bytesBefore).toBeLessThan(5 * 1024 * 1024);
  506 |   await page.reload();
  507 |   await waitForSavedFiles(page);
  508 |   const after = await retainedFiles(
  509 |     page,
  510 |     uploaded.map((file) => file.reference),
  511 |   );
  512 |   expect(after).toEqual(before);
  513 |   const state = await saved(page);
  514 |   const allInvoices = [...state.invoices!, state.invoice];
  515 |   for (const file of uploaded)
  516 |     expect(
  517 |       allInvoices.some(
  518 |         (invoice: { id: string; file_data?: string }) =>
  519 |           invoice.id === file.id && invoice.file_data === file.reference,
  520 |       ),
  521 |     ).toBe(true);
  522 |   await expect
  523 |     .poll(() =>
  524 |       page
  525 |         .getByRole("img", { name: "Original invoice image", exact: true })
  526 |         .evaluate((element: HTMLImageElement) => element.naturalWidth),
  527 |     )
  528 |     .toBe(2000);
  529 |   const downloadEvent = page.waitForEvent("download");
  530 |   await page
  531 |     .locator(".invoice-original-controls")
  532 |     .getByRole("button", { name: "Download", exact: true })
  533 |     .click();
  534 |   const download = await downloadEvent;
```