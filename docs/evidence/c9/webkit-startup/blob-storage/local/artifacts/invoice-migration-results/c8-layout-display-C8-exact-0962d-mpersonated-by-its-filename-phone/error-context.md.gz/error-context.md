# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: c8-layout-display.spec.ts >> C8 exact included sale-cost original preserves drafts and cannot be impersonated by its filename
- Location: tests/c8-layout-display.spec.ts:448:1

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('.invoice-line')
Expected: 1
Received: 0
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" locator('.invoice-line') with timeout 5000ms
  - waiting for locator('.invoice-line')
    3 × locator resolved to 6 elements
      - unexpected value "6"
    7 × locator resolved to 0 elements
      - unexpected value "0"

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=e5]:
    - banner [ref=e6]:
      - button "Open menu" [ref=e7] [cursor=pointer]
      - combobox "Location" [ref=e11] [cursor=pointer]:
        - generic [ref=e16]: North York
      - button "Notifications, 5 unread" [ref=e19] [cursor=pointer]:
        - generic [ref=e20]: "5"
      - button "User menu" [ref=e25] [cursor=pointer]:
        - generic [aria-hidden] [ref=e27]: DM
      - button "More" [ref=e28] [cursor=pointer]
    - main [ref=e34]:
      - generic [ref=e35]:
        - link "Back to Invoices" [ref=e36] [cursor=pointer]:
          - /url: "#invoices"
        - generic [ref=e39]:
          - generic [ref=e40]:
            - heading "Invoices" [level=1] [ref=e41]
            - paragraph [ref=e42]: Deliveries and supplier invoices
          - button "New invoice" [ref=e44] [cursor=pointer]
        - tablist "Invoice views" [ref=e45]:
          - tab "Drafts" [ref=e46] [cursor=pointer]
          - tab "Processing" [ref=e48] [cursor=pointer]
          - tab "Needs review" [selected] [ref=e50] [cursor=pointer]
          - tab "Ready to post" [ref=e52] [cursor=pointer]
          - tab "Posted" [ref=e54] [cursor=pointer]
          - tab "Cancelled" [ref=e56] [cursor=pointer]
        - generic [ref=e58]:
          - complementary "Original invoice" [ref=e59]:
            - generic [ref=e60]:
              - heading "Original invoice" [level=2] [ref=e61]
              - paragraph [ref=e62]: AI invoice reading is simulated
              - generic [ref=e64]:
                - generic [ref=e65]: Upload a PDF or photo
                - generic [ref=e66]:
                  - button "Upload a PDF or photo" [ref=e67]
                  - button "Take photo" [ref=e68]
                  - generic [ref=e69]:
                    - generic [ref=e73]:
                      - strong [ref=e74]: fictional-hw-5012.svg
                      - generic [ref=e75]: 3 KB
                    - button "Remove file" [ref=e76] [cursor=pointer]
                  - generic [ref=e80]:
                    - button "Browse" [ref=e81] [cursor=pointer]
                    - button "Take photo" [ref=e82] [cursor=pointer]
              - group "Original invoice" [ref=e86]:
                - generic [ref=e87]:
                  - button "Zoom out" [ref=e88] [cursor=pointer]
                  - generic [ref=e90]: 100%
                  - button "Zoom in" [ref=e91] [cursor=pointer]
                - button "Fit width" [ref=e93] [cursor=pointer]
                - button "Fit page" [ref=e94] [cursor=pointer]
                - button "Download" [ref=e95] [cursor=pointer]
              - img "Original invoice image" [ref=e100]
          - generic [ref=e101]:
            - generic [ref=e102]:
              - generic "Delivery summary" [ref=e103]:
                - generic [ref=e104]:
                  - generic [ref=e105]: Subtotal
                  - strong [ref=e106]: $42.60
                - generic [ref=e107]:
                  - generic [ref=e108]: Tax
                  - strong [ref=e109]: $5.54
                - generic [ref=e110]:
                  - generic [ref=e111]: Shorts and refused deduction
                  - strong [ref=e112]: $0.00
                - generic [ref=e113]:
                  - generic [ref=e114]: Payable
                  - strong [ref=e115]: $48.14
              - paragraph [ref=e116]: This is the amount of this invoice, not a supplier balance. Received records only physically delivered units.
            - generic [ref=e117]:
              - heading [level=2] [ref=e118]:
                - button "Invoice details" [ref=e119] [cursor=pointer]
              - paragraph [ref=e122]:
                - generic [ref=e123]: HomeWare Imports
                - text: ·
                - generic [ref=e124]: HW-5012
                - text: · North York ·
                - generic [ref=e125]: 2026-10-12
              - paragraph [ref=e126]:
                - generic [ref=e127]: Needs review
                - text: Changes save automatically in this browser.
            - generic [ref=e129]:
              - heading "Compare with order" [level=2] [ref=e130]
              - generic [ref=e131]:
                - generic [ref=e132]: Order (optional)
                - combobox "Order (optional)" [ref=e133] [cursor=pointer]:
                  - generic [ref=e134]: No linked order
                - paragraph [ref=e137]: Choose an open order for this supplier and receiving location.
            - generic [ref=e138]:
              - heading "Review invoice lines" [level=2] [ref=e139]
              - paragraph [ref=e140]: Choose Cases or Units and confirm the product, pack, quantities, cost, and date decision on each line.
              - table [ref=e142]:
                - 'rowgroup "Line 1: Stainless Steel Pot 24 cm" [ref=e143]':
                  - row [ref=e144] [cursor=pointer]:
                    - cell "1. Stainless Steel Pot 24 cm قابلمه استیل ۲۴ سانتی‌متری 0012 · 24 cm Matched Taxable" [ref=e145]:
                      - generic [ref=e146]:
                        - heading [level=3] [ref=e147]:
                          - button "1. Stainless Steel Pot 24 cm قابلمه استیل ۲۴ سانتی‌متری" [expanded] [ref=e148]:
                            - generic [ref=e149]: "1."
                            - generic [ref=e150]:
                              - strong [ref=e151]:
                                - generic [ref=e152]:
                                  - text: Stainless Steel Pot
                                  - generic [ref=e153]: 24 cm
                              - generic [ref=e155]:
                                - text: قابلمه استیل
                                - generic [ref=e156]: ۲۴ سانتی‌متری
                        - paragraph [ref=e159]:
                          - text: 0012 ·
                          - generic [ref=e160]: 24 cm
                        - generic [ref=e163]:
                          - generic [ref=e164]: Matched
                          - generic [ref=e165]: Taxable
                    - cell [ref=e166]:
                      - generic [ref=e167]:
                        - generic [ref=e168]: Invoiced
                        - textbox "Invoiced" [ref=e169]: "1"
                      - generic [ref=e170]:
                        - generic [ref=e171]: Delivered
                        - textbox "Delivered" [ref=e172]: "3"
                    - cell [ref=e173]:
                      - generic [ref=e174]:
                        - generic [ref=e175]: Unit cost before tax
                        - textbox "Unit cost before tax" [ref=e176]: "14.2000"
                    - cell "Line total $42.60" [ref=e177]:
                      - generic [ref=e178]: Line total
                      - text: $42.60
                    - 'cell "Selling price $23.49 Pending Goes to approval when posted Approved: $20.99" [ref=e179]':
                      - generic [ref=e180]:
                        - generic [ref=e181]: Selling price
                        - strong [ref=e182]:
                          - strong [ref=e185]: $23.49
                        - generic [ref=e186]: Pending
                        - generic [ref=e187]: Goes to approval when posted
                        - paragraph [ref=e188]: "Approved: $20.99"
                  - row [ref=e189]:
                    - cell [ref=e190]:
                      - generic [ref=e191]:
                        - group [ref=e192]:
                          - generic [ref=e193]:
                            - generic [ref=e194]: Quantity unit
                            - combobox "Quantity unit" [ref=e195] [cursor=pointer]:
                              - generic [ref=e196]: Cases
                          - generic [ref=e199]:
                            - generic [ref=e200]: Units per case
                            - textbox "Units per case" [ref=e201]: "3"
                          - generic [ref=e202]:
                            - generic [ref=e203]: Supplier item code (optional)
                            - textbox "Supplier item code (optional)" [ref=e204]
                          - generic [ref=e205]:
                            - generic [ref=e206]: Case cost before tax
                            - textbox "Case cost before tax" [ref=e207]: "42.6000"
                          - paragraph [ref=e208]: 1 × 3 = 3 units
                          - generic [ref=e209]:
                            - generic [ref=e210]: Matched product
                            - combobox "Matched product" [ref=e211] [cursor=pointer]:
                              - generic [ref=e213]:
                                - text: ⁦0012⁩ · ⁦
                                - generic [ref=e214]:
                                  - text: Stainless Steel Pot
                                  - generic [ref=e215]: 24 cm
                                - text: ⁩
                          - generic [ref=e218]:
                            - generic [ref=e219]: Pricing category
                            - combobox "Pricing category" [ref=e220] [cursor=pointer]:
                              - generic [ref=e221]: Kitchenware
                        - button "Remove line" [ref=e224] [cursor=pointer]
                        - checkbox "Mark as short" [ref=e225] [cursor=pointer]
                        - group [ref=e228]:
                          - generic [ref=e229]:
                            - generic [ref=e230]: Track date
                            - group "Track date" [ref=e231]:
                              - button "Yes" [ref=e232] [cursor=pointer]
                              - button "No" [pressed] [ref=e234] [cursor=pointer]
                        - checkbox "Confirm this invoice line" [ref=e236] [cursor=pointer]
              - generic [ref=e239]:
                - generic [ref=e240]:
                  - generic [ref=e241]: Add a product to the invoice
                  - combobox "Add a product to the invoice" [ref=e242] [cursor=pointer]:
                    - generic [ref=e244]:
                      - text: ⁦0002⁩ · ⁦
                      - generic [ref=e245]:
                        - text: Canned Fava Beans
                        - generic [ref=e246]: 400 g
                      - text: ⁩
                - button "Add line" [ref=e249] [cursor=pointer]
                - button "+ Add new product" [ref=e250] [cursor=pointer]
          - generic [ref=e252]:
            - button "Save as draft" [ref=e253] [cursor=pointer]
            - button "Post invoice" [ref=e254] [cursor=pointer]
```

# Test source

```ts
  361 |         name: copy(language, en, fa),
  362 |         exact: true,
  363 |       });
  364 |       await expect(option).not.toBeChecked();
  365 |       await option.click();
  366 |       await expect(option).toBeChecked();
  367 |     }
  368 |     await columns
  369 |       .getByRole("button", {
  370 |         name: copy(language, "Close", "بستن"),
  371 |         exact: true,
  372 |       })
  373 |       .click();
  374 |     for (const [key, en, fa] of [
  375 |       ["name", "Supplier", "تأمین‌کننده"],
  376 |       ["status", "Status", "وضعیت"],
  377 |       ["last_delivery", "Last delivery", "آخرین تحویل"],
  378 |       ["deliveries", "Deliveries", "تحویل‌ها"],
  379 |       ["returns", "Open returns", "مرجوعی‌های باز"],
  380 |       ["shorts", "Open shorts", "کسری‌های باز"],
  381 |       ["terms", "Payment terms", "شرایط پرداخت"],
  382 |       ["contact", "Sales rep and phone", "نماینده فروش و تلفن"],
  383 |       ["balance", "Balance", "مانده"],
  384 |       ["overdue", "Overdue", "سررسید گذشته"],
  385 |       ["due", "Next due date", "سررسید بعدی"],
  386 |       ["actions", "Action", "عملیات"],
  387 |     ]) {
  388 |       const header = suppliersTable.locator(
  389 |         `thead th[data-column-key="${key}"]`,
  390 |       );
  391 |       await expect(header).toBeVisible();
  392 |       await expect(header).toContainText(copy(language, en, fa));
  393 |       await expect(
  394 |         supplierRow.locator(`td[data-column-key="${key}"]`),
  395 |       ).toBeVisible();
  396 |     }
  397 |     for (const [key, value] of Object.entries(visibleValues))
  398 |       await expect(
  399 |         supplierRow.locator(`td[data-column-key="${key}"]`),
  400 |       ).toHaveText(value);
  401 |     await expect(supplierRow.locator('td[data-column-key="terms"]')).toHaveText(
  402 |       supplier.payment_terms ?? "—",
  403 |     );
  404 |     await expect(
  405 |       supplierRow.locator('td[data-column-key="contact"]'),
  406 |     ).toContainText(supplier.sales_rep_name ?? "—");
  407 |     await expect(
  408 |       supplierRow.locator('td[data-column-key="contact"]'),
  409 |     ).toContainText(supplier.sales_rep_phone ?? "—");
  410 |     await expect(supplierRow.locator('td[data-column-key="due"]')).toHaveText(
  411 |       /^(?:\d{4}-\d{2}-\d{2}|—)$/,
  412 |     );
  413 |     await expect(suppliersTable).toHaveAttribute(
  414 |       "data-width-hidden-column-count",
  415 |       "0",
  416 |     );
  417 |     await expect(suppliersTable.locator(".table-details-toggle")).toHaveCount(
  418 |       0,
  419 |     );
  420 |     const after = await saved(page);
  421 |     expect(after.suppliers).toEqual(before.suppliers);
  422 |     expect(after.invoices).toEqual(before.invoices);
  423 |     expect(after.ledger).toEqual(before.ledger);
  424 |   });
  425 | 
  426 |   test(`C8 Payables filters share their list card and preserve scoped rows (${language})`, async ({
  427 |     page,
  428 |   }) => {
  429 |     await signIn(page, "Supervisor");
  430 |     await page.goto("/#payables");
  431 |     await setLanguage(page, language);
  432 |     const card = page.locator(".payables-overview");
  433 |     await expect(card.locator(".payables-filters")).toBeVisible();
  434 |     await card
  435 |       .getByRole("textbox", {
  436 |         name: copy(language, "Search suppliers", "جستجوی تأمین‌کنندگان"),
  437 |         exact: true,
  438 |       })
  439 |       .fill("Fresh Valley");
  440 |     const rows = card.locator("tbody > tr[data-row-href]");
  441 |     await expect(rows).toHaveCount(1);
  442 |     await expect(rows).toContainText("Fresh Valley Foods");
  443 |     await rows.locator(".table-row-link").click();
  444 |     await expect(page.locator(".payables-ledger-card")).toBeVisible();
  445 |   });
  446 | }
  447 | 
  448 | test("C8 exact included sale-cost original preserves drafts and cannot be impersonated by its filename", async ({
  449 |   page,
  450 | }) => {
  451 |   await signIn(page, "Supervisor");
  452 |   await page.goto("/#invoices");
  453 |   const before = await saved(page);
  454 |   const original = fileURLToPath(
  455 |     new URL("../public/demo-originals/fictional-hw-5012.svg", import.meta.url),
  456 |   );
  457 |   await (await openInvoiceUpload(page)).setInputFiles(original);
  458 |   await expect(
  459 |     page.getByRole("heading", { name: "Review invoice lines", exact: true }),
  460 |   ).toBeVisible({ timeout: 10000 });
> 461 |   await expect(page.locator(".invoice-line")).toHaveCount(1);
      |                                               ^ Error: expect(locator).toHaveCount(expected) failed
  462 |   await expect
  463 |     .poll(async () => (await saved(page)).invoice.supplier_invoice_number)
  464 |     .toBe("HW-5012");
  465 |   const loaded = await saved(page);
  466 |   expect(loaded.invoice.id).toBe("demo-c8-hw-5012");
  467 |   expect(loaded.invoice.lines[0].unit_cost_before_tax).toBe("14.2000");
  468 |   expect(loaded.invoice.final_total).toBe("48.14");
  469 |   expect(loaded.invoice.receiving_employee).toBe(
  470 |     await page.locator(".user-chip-copy strong").textContent(),
  471 |   );
  472 |   expect(loaded.ledger).toEqual(before.ledger);
  473 |   expect(
  474 |     loaded.alerts.filter((item) => item.type === "sale_cost_increase"),
  475 |   ).toHaveLength(0);
  476 |   expect(await retainedOriginalHash(page, loaded.invoice.file_data!)).toBe(
  477 |     "b0f9b1cb07929298d0666800cb1ca3493bbaebd65e52a2f28b1bde9633f84444",
  478 |   );
  479 |   // Starting another workspace retains the old unread original, too.
  480 |   expect(
  481 |     loaded.invoices!.find((item) => item.id === before.invoice.id)!.file_data,
  482 |   ).toBe(before.invoice.file_data);
  483 |   await page
  484 |     .locator(".invoice-line")
  485 |     .first()
  486 |     .getByLabel("Unit cost before tax", { exact: true })
  487 |     .fill("14.3000");
  488 |   await expect
  489 |     .poll(async () => (await saved(page)).invoice.lines[0].unit_cost_before_tax)
  490 |     .toBe("14.3000");
  491 |   await page.getByRole("button", { name: "New invoice", exact: true }).click();
  492 |   await (await openInvoiceUpload(page)).setInputFiles(original);
  493 |   await expect(
  494 |     page.getByRole("heading", { name: "Review invoice lines", exact: true }),
  495 |   ).toBeVisible({ timeout: 10000 });
  496 |   await expect
  497 |     .poll(async () => (await saved(page)).invoice.lines[0].unit_cost_before_tax)
  498 |     .toBe("14.3000");
  499 |   const reused = await saved(page);
  500 |   expect(reused.invoice.id).toBe(loaded.invoice.id);
  501 |   expect(reused.invoice.file_data).toBe(loaded.invoice.file_data);
  502 |   expect(reused.ledger).toEqual(before.ledger);
  503 |   await page.getByRole("button", { name: "New invoice", exact: true }).click();
  504 |   await (
  505 |     await openInvoiceUpload(page)
  506 |   ).setInputFiles({ ...invoiceImage, name: "fictional-hw-5012.svg" });
  507 |   await expect(
  508 |     page.getByRole("heading", { name: "Review invoice lines", exact: true }),
  509 |   ).toBeVisible({ timeout: 10000 });
  510 |   const unknown = await saved(page);
  511 |   expect(unknown.invoice.id).not.toBe(loaded.invoice.id);
  512 |   expect(unknown.invoice.supplier_invoice_number).toBe(
  513 |     demo.demo_invoice.supplier_invoice_number,
  514 |   );
  515 |   expect(unknown.invoice.lines).toHaveLength(demo.demo_invoice.lines.length);
  516 |   expect(unknown.ledger).toEqual(before.ledger);
  517 | });
  518 | 
```