import ts from "/workspace/Supermarket-Inventory/prototype/node_modules/typescript/lib/typescript.js";
import { createHash } from "node:crypto";
import { execFileSync } from "node:child_process";
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { fileURLToPath } from "node:url";

const root = "/workspace/Supermarket-Inventory";
const destination = "/tmp/c9-file-bytes-browser-audit";
const baseline = "a1b37c3e2b1b52c716c7736eb18d7793dbef1d6f";
const files = [
  "prototype/tests/storage-c6.spec.ts",
  "prototype/tests/sha256-lan-c6.spec.ts",
  "prototype/tests/c8-migration.spec.ts",
  "prototype/tests/c8-layout-display.spec.ts",
  "prototype/tests/invoice-c4.spec.ts",
  "prototype/tests/invoice-a2.spec.ts",
];
const sha256 = (text) => createHash("sha256").update(text).digest("hex");
const compact = (text) => text.replace(/\s+/g, " ").trim();
const git = (...args) => execFileSync("git", args, { cwd: root, encoding: "utf8" });
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);

function analyze(source, filename) {
  const file = ts.createSourceFile(filename, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  const result = { assertions: [], titles: [], controls: [], control_options: [] };
  function base(expression) {
    return ts.isIdentifier(expression)
      ? expression.text
      : ts.isPropertyAccessExpression(expression)
        ? base(expression.expression)
        : null;
  }
  function entry(node) {
    const normalized_source = compact(node.getText(file));
    return {
      line: file.getLineAndCharacterOfPosition(node.getStart(file)).line + 1,
      normalized_source,
      normalized_sha256: sha256(normalized_source),
    };
  }
  function context(node) {
    const conditions = [];
    for (let parent = node.parent; parent; parent = parent.parent) {
      if (ts.isIfStatement(parent)) conditions.push(compact(parent.expression.getText(file)));
    }
    return conditions;
  }
  function visit(node) {
    if (ts.isCallExpression(node)) {
      const callBase = base(node.expression);
      const expression = node.expression.getText(file);
      // Count expect(...) and expect.poll/soft(...), not the chained matcher.
      if (callBase === "expect") result.assertions.push(entry(node));
      if (
        callBase === "test" && node.arguments.length &&
        (ts.isStringLiteralLike(node.arguments[0]) || ts.isTemplateExpression(node.arguments[0]))
      ) result.titles.push(entry(node.arguments[0]));
      if (/(?:setTimeout|setDefaultTimeout|setDefaultNavigationTimeout|\.skip|\.fixme|\.slow|\.use|\.configure)$/.test(expression)) {
        result.controls.push({ ...entry(node), enclosing_if_conditions: context(node) });
      }
    }
    if (ts.isPropertyAssignment(node)) {
      const name = node.name.getText(file).replace(/^['"]|['"]$/g, "");
      if (["timeout", "testTimeout", "maxWorkers", "workers", "retries", "fullyParallel", "forbidOnly", "testMatch"].includes(name)) {
        result.control_options.push(entry(node));
      }
    }
    ts.forEachChild(node, visit);
  }
  visit(file);
  return result;
}

const textOnly = (entries) => entries.map(({ normalized_source, enclosing_if_conditions }) => ({
  normalized_source,
  ...(enclosing_if_conditions ? { enclosing_if_conditions } : {}),
}));

const results = files.map((path) => {
  const beforeSource = git("show", `${baseline}:${path}`);
  const afterSource = readFileSync(`${root}/${path}`, "utf8");
  const before = analyze(beforeSource, path);
  const after = analyze(afterSource, path);
  return {
    path,
    before_sha256: sha256(beforeSource),
    after_sha256: sha256(afterSource),
    assertion_calls_identical: same(textOnly(before.assertions), textOnly(after.assertions)),
    titles_identical: same(textOnly(before.titles), textOnly(after.titles)),
    control_calls_and_enclosing_conditions_identical: same(textOnly(before.controls), textOnly(after.controls)),
    control_options_identical: same(textOnly(before.control_options), textOnly(after.control_options)),
    before,
    after,
  };
});

const preservedConfigPaths = ["prototype/playwright.config.ts", ".github/workflows/ci.yml"];
const preserved_config = preservedConfigPaths.map((path) => {
  const before = git("show", `${baseline}:${path}`);
  const after = readFileSync(`${root}/${path}`, "utf8");
  return { path, before_sha256: sha256(before), after_sha256: sha256(after), byte_identical: before === after };
});

const totals = results.reduce((total, file) => ({
  before_assertions: total.before_assertions + file.before.assertions.length,
  after_assertions: total.after_assertions + file.after.assertions.length,
  before_titles: total.before_titles + file.before.titles.length,
  after_titles: total.after_titles + file.after.titles.length,
}), { before_assertions: 0, after_assertions: 0, before_titles: 0, after_titles: 0 });

const fileDatabasePath = "prototype/src/file-database.ts";
const issues = results.filter((file) => !file.assertion_calls_identical || !file.titles_identical || !file.control_calls_and_enclosing_conditions_identical || !file.control_options_identical).map((file) => `Original assertions/titles/controls changed: ${file.path}`);
if (totals.before_assertions !== 413 || totals.after_assertions !== 413 || totals.before_titles !== 22 || totals.after_titles !== 22) issues.push("Unexpected static assertion/title count.");
if (preserved_config.some((file) => !file.byte_identical)) issues.push("Playwright or CI configuration differs from the audited baseline.");

const report = {
  kind: "Independent, read-only AST preservation audit and source-bound manual helper review",
  generated_at_utc: new Date().toISOString(),
  baseline_commit: baseline,
  head_at_audit: git("rev-parse", "HEAD").trim(),
  audit_script_sha256: sha256(readFileSync(fileURLToPath(import.meta.url))),
  production_file: { path: fileDatabasePath, after_sha256: sha256(readFileSync(`${root}/${fileDatabasePath}`)) },
  totals,
  all_original_assertions_and_titles_preserved: issues.length === 0,
  preserved_config,
  reviewed_observations: [
    "The six inspectors read raw IndexedDB independently of the production decoder; all exact-byte, SHA-256, company-scope, quota, failure and recovery assertions remain unchanged.",
    "Dual-format decoders accept an unmarked genuine Blob, or the explicit array-buffer-v1 marker with a genuine page-realm ArrayBuffer and string MIME that survives Blob normalization; every other shape throws, with no empty fallback.",
    "Raw IndexedDB reads and their decoders run in the same Playwright page realm. Production independently uses a cross-realm-safe native internal-slot ArrayBuffer check.",
    "The C8 Blob constructor Proxy forwards the real native constructor, argument bytes and newTarget using Reflect.construct, retaining the native prototype.",
    "C8 migration instrumentation only adds reconstructed Blobs to its observation set when their exact ArrayBuffer was already seen in the targeted real backup get result.",
    "A constructor observation alone does not mark verification complete: the original guarded text() and arrayBuffer()/SHA-256 reads must occur before the original durable publish event; all those assertions are retained.",
    "C8 backup quota injection remains keyed by actual store/reference and recovery flag, independently of Blob versus ArrayBuffer payload. Existing failure, retained raw/original data and recovery assertions remain effective.",
    "No original corruption fixture was removed; the changed C8 Blob recognition is readback-verification instrumentation, not a corruption bypass.",
  ],
  material_issues: issues,
  limitations: [
    "This is a static preservation audit plus manual source review; it does not substitute for browser execution.",
    "The 22 count is static test declarations/titles across these six files; configured browser projects and parameterized cases may execute more runtime cases.",
    "Source hashes bind observations to the exact working-tree files at audit time. No app, test, docs or configuration file is modified by this script.",
  ],
  files: results,
};
mkdirSync(destination, { recursive: true });
writeFileSync(`${destination}/preservation-audit.json`, JSON.stringify(report, null, 2) + "\n");
console.log(JSON.stringify({ baseline, head: report.head_at_audit, totals, material_issues: issues, report: `${destination}/preservation-audit.json` }));
if (issues.length) process.exitCode = 1;
