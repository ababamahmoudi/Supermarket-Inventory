import { mergeConfig } from "/workspace/Supermarket-Inventory/prototype/node_modules/vitest/dist/config.js";
import base from "/workspace/Supermarket-Inventory/prototype/vite.config.ts";
export default mergeConfig(base, {
  resolve: {
    alias: [
      {
        find: "./file-database",
        replacement: "/tmp/c9-file-database-webkit-proof/file-database.negative.ts",
      },
    ],
  },
  server: {
    fs: {
      allow: ["/workspace/Supermarket-Inventory", "/tmp/c9-file-database-webkit-proof"],
    },
  },
});
