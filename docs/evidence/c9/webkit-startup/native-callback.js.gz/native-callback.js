(() => {
    const records = [];
    window.__c9NativeExceptions = records;
    const record = (source, error) => {
        try {
            if (!(error instanceof Error || error instanceof DOMException) ||
                records.length >= 32)
                return;
            const ownValue = (key) => Object.getOwnPropertyDescriptor(error, key)?.value;
            const nativeProperty = (key) => {
                if (!(error instanceof DOMException))
                    return undefined;
                return Object.getOwnPropertyDescriptor(DOMException.prototype, key)?.get?.call(error);
            };
            let name = ownValue("name") ?? nativeProperty("name");
            if (typeof name !== "string") {
                const descriptor = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(error), "name");
                name = descriptor?.value;
            }
            const message = ownValue("message") ?? nativeProperty("message");
            const code = ownValue("code") ?? nativeProperty("code");
            const stack = ownValue("stack");
            const diagnostic = {
                source,
                name: typeof name === "string" ? name.slice(0, 80) : "Error",
                code: typeof code === "number"
                    ? code
                    : typeof code === "string"
                        ? code.slice(0, 80)
                        : null,
                message: typeof message === "string" ? message.slice(0, 400) : "",
                frames: typeof stack === "string"
                    ? stack
                        .split(/\r?\n/)
                        .filter((line) => /^\s*at\b|@https?:\/\//.test(line))
                        .slice(0, 8)
                        .map((line) => line
                        .replace(/(https?:\/\/[^\s)?#]+)[?#][^\s)]*/g, "$1")
                        .trim()
                        .slice(0, 240))
                    : [],
            };
            if (!records.some((previous) => JSON.stringify(previous) === JSON.stringify(diagnostic)))
                records.push(diagnostic);
        }
        catch {
            // Diagnostics must not replace the original rejection or exception.
        }
    };
    const originalCatch = Promise.prototype.catch;
    const originalThen = Promise.prototype.then;
    Promise.prototype.catch = function (onRejected) {
        // Only ordinary native promises are tapped. Borrowed catch calls,
        // subclasses and custom then methods keep their original callback too.
        if (typeof onRejected !== "function" ||
            !this ||
            typeof this !== "object" ||
            Object.getPrototypeOf(this) !== Promise.prototype ||
            Object.getOwnPropertyDescriptor(this, "then") ||
            Object.getOwnPropertyDescriptor(Promise.prototype, "then")?.value !==
                originalThen)
            return Reflect.apply(originalCatch, this, [onRejected]);
        return Reflect.apply(originalCatch, this, [
            (error) => {
                record("Promise.catch rejection", error);
                return Reflect.apply(onRejected, undefined, [error]);
            },
        ]);
    };
    if (typeof IDBFactory === "undefined")
        return;
    const originalOpen = IDBFactory.prototype.open;
    IDBFactory.prototype.open = function (...args) {
        try {
            const request = Reflect.apply(originalOpen, this, args);
            request.addEventListener("error", () => record("IndexedDB open error", request.error));
            request.addEventListener("success", () => {
                const database = request.result;
                const observeError = (event) => {
                    const target = event.target;
                    if (target instanceof IDBRequest ||
                        target instanceof IDBTransaction)
                        record(`IndexedDB ${event.type}`, target.error);
                };
                database.addEventListener("error", observeError, true);
                database.addEventListener("abort", observeError, true);
            });
            return request;
        }
        catch (error) {
            record("IndexedDB open exception", error);
            throw error;
        }
    };
})