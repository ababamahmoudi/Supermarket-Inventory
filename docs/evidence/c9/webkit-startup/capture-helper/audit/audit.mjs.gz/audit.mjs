import ts from "/workspace/Supermarket-Inventory/prototype/node_modules/typescript/lib/typescript.js";
import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";

const root = "/workspace/Supermarket-Inventory";
const baseline = "be25d01c613a467da100111bfb5addb3b68a30b6";
const path = "prototype/scripts/capture-c8-proof.mjs";
const destination = "/workspace/scratch/c9-capture-helper/preservation-audit.json";
const git = (...args) => execFileSync("git", args, { cwd: root, encoding: "utf8" });
const sha256 = (text) => createHash("sha256").update(text).digest("hex");
const compact = (text) => text.replace(/\s+/g, " ").trim();

function inspect(source, filename) {
  const file = ts.createSourceFile(filename, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.JS);
  const assertions = [], controls = [], options = [];
  let helper;
  function base(expression) {
    return ts.isIdentifier(expression) ? expression.text : ts.isPropertyAccessExpression(expression) ? base(expression.expression) : null;
  }
  function visit(node) {
    if (ts.isFunctionDeclaration(node) && node.name?.text === "readC8OriginalSHA") helper = node;
    if (ts.isCallExpression(node)) {
      const expression = node.expression.getText(file);
      if (base(node.expression) === "expect") assertions.push(compact(node.getText(file)));
      if (/(?:setTimeout|setDefaultTimeout|setDefaultNavigationTimeout|\.skip|\.fixme|\.slow|\.use|\.configure)$/.test(expression)) controls.push(compact(node.getText(file)));
    }
    if (ts.isPropertyAssignment(node) && ["timeout", "testTimeout", "maxWorkers", "workers", "retries", "fullyParallel", "forbidOnly"].includes(node.name.getText(file))) options.push(compact(node.getText(file)));
    ts.forEachChild(node, visit);
  }
  visit(file);
  const helperSource = helper.getText(file);
  const outsideHelper = compact(source.slice(0, helper.getStart(file)) + "/* targeted helper */" + source.slice(helper.end));
  const digestCalls = [], resultHexCalls = [], errorMessages = [];
  function walkHelper(node) {
    if (ts.isCallExpression(node) && node.expression.getText(file) === "crypto.subtle.digest") digestCalls.push({ algorithm: node.arguments[0].text, call: compact(node.getText(file)) });
    if (ts.isCallExpression(node) && node.expression.getText(file) === "Array.from") resultHexCalls.push(compact(node.getText(file)));
    if (ts.isNewExpression(node) && node.expression.getText(file) === "Error") errorMessages.push(node.arguments[0].text);
    ts.forEachChild(node, walkHelper);
  }
  walkHelper(helper);
  return { assertions, controls, options, outsideHelper, helperSource, digestCalls, resultHexCalls, uniqueErrorMessages: [...new Set(errorMessages)] };
}

const beforeSource = git("show", `${baseline}:${path}`);
const afterSource = readFileSync(`${root}/${path}`, "utf8");
const before = inspect(beforeSource, path), after = inspect(afterSource, path);
const equal = (left, right) => JSON.stringify(left) === JSON.stringify(right);
const preservedPaths = ["prototype/tests/c8-sales.spec.ts", "prototype/playwright.config.ts", ".github/workflows/ci.yml", "prototype/src/file-database.ts"];
const untouchedFiles = preservedPaths.map((path) => {
  const old = git("show", `${baseline}:${path}`), current = readFileSync(`${root}/${path}`, "utf8");
  return { path, before_sha256: sha256(old), after_sha256: sha256(current), byte_identical: old === current };
});
const checks = {
  all_original_assertion_calls_identical: equal(before.assertions, after.assertions),
  timeout_use_skip_control_calls_identical: equal(before.controls, after.controls),
  timeout_retry_worker_options_identical: equal(before.options, after.options),
  all_source_outside_target_helper_identical: before.outsideHelper === after.outsideHelper,
  native_digest_count_unchanged: before.digestCalls.length === 1 && after.digestCalls.length === 1,
  native_sha256_algorithm_unchanged: before.digestCalls[0].algorithm === "SHA-256" && after.digestCalls[0].algorithm === "SHA-256",
  native_digest_hex_encoding_identical: equal(before.resultHexCalls, after.resultHexCalls),
  missing_evidence_error_messages_identical: equal(before.uniqueErrorMessages, after.uniqueErrorMessages),
  app_affected_tests_and_configuration_untouched: untouchedFiles.every((file) => file.byte_identical),
};
const report = {
  kind: "Read-only source-bound preservation audit for one stale private-format proof helper",
  generated_at_utc: new Date().toISOString(), baseline_commit: baseline, head_at_audit: git("rev-parse", "HEAD").trim(),
  path, before_sha256: sha256(beforeSource), after_sha256: sha256(afterSource),
  assertion_calls_before: before.assertions.length, assertion_calls_after: after.assertions.length,
  checks,
  before: { assertions: before.assertions, controls: before.controls, options: before.options, helper_source: before.helperSource },
  after: { assertions: after.assertions, controls: after.controls, options: after.options, helper_source: after.helperSource },
  untouched_files: untouchedFiles,
  review_observations: [
    "The helper reads actual raw IndexedDB evidence, independently of the production decoder.",
    "It accepts unmarked genuine legacy Blob values, or explicit array-buffer-v1 payloads with string MIME surviving native Blob normalization.",
    "The native ArrayBuffer byteLength getter checks actual internal slots across realms; typed views, SharedArrayBuffer and property/tag spoofs cannot pass that brand check.",
    "The original crypto.subtle SHA-256 digest and hexadecimal oracle remain intact and consume actual retained bytes. Malformed rows retain the original missing-evidence error.",
    "No test, application, configuration, budget, worker, retry, skip or assertion was changed. Actual affected browser cases are run separately by Root.",
  ],
  limitations: ["Static source inspection and lint/format verification only; this audit is not browser execution or proof that CI passed."],
  material_issues: Object.entries(checks).filter(([, pass]) => !pass).map(([name]) => name),
};
writeFileSync(destination, JSON.stringify(report, null, 2) + "\n");
console.log(JSON.stringify({ report: destination, before_sha256: report.before_sha256, after_sha256: report.after_sha256, assertion_calls_before: report.assertion_calls_before, assertion_calls_after: report.assertion_calls_after, material_issues: report.material_issues }));
if (report.material_issues.length) process.exitCode = 1;
