import {writeFileSync} from 'node:fs';
const output="/tmp/posted-totals-readiness-backports/e2/global-errors.json";
const save=v=>writeFileSync(output,JSON.stringify(v,null,2)+'\n');
export default class ErrorObserver {
 onInit(ctx){this.ctx=ctx;process.once('exit',code=>save({phase:'process-exit',code,errors:this.ctx.state.getUnhandledErrors?.()??[],atRunEnd:this.result}));}
 onTestRunEnd(modules,errors,reason){this.result={phase:'onTestRunEnd',reason,errors,moduleCount:modules.length};save(this.result);}
}
