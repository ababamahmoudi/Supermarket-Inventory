from pathlib import Path
import json,hashlib,os,subprocess,time,urllib.request,urllib.parse,signal,tarfile,sys
proof=Path('/tmp/e2-ci-bounded-originals-v1');repo=Path('/workspace/Supermarket-Inventory');commit='73891b6c19852e1da6a99316b2fef7873039ea9c';manifest=Path('/tmp/e2-ci-review-guarded-fixtures/manifest.json')
if proof.exists():raise RuntimeError('Fresh proof directory required')
proof.mkdir();tree=proof/'source';tree.mkdir();sha=lambda b:hashlib.sha256(b).hexdigest()
def save(name,obj):
 p=proof/name;p.parent.mkdir(parents=True,exist_ok=True);temp=p.with_name(p.name+'.tmp');temp.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');temp.replace(p)
archive=proof/'exact-e2-source.tar'
with archive.open('wb') as output:subprocess.run(['git','-C',str(repo),'archive','--format=tar',commit,'AGENTS.md','prototype','docs','seed','assets'],stdout=output,check=True)
with tarfile.open(archive) as tar:tar.extractall(tree,filter='data')
data=json.loads(manifest.read_text());assert data['baseline_head']==commit
for row in data['files']:
 target=tree/row['path'];new=Path(row['source']).read_bytes();assert sha(target.read_bytes())==row['baseline_sha256'];assert sha(new)==row['sha256'];target.write_bytes(new)
(tree/'prototype/node_modules').symlink_to(repo/'prototype/node_modules',target_is_directory=True)
base='http://127.0.0.1:5204';cfg=tree/'prototype/bounded.config.ts';cfg.write_text('import base from "./playwright.config";\nexport default { ...base, use: { ...base.use, baseURL: '+json.dumps(base)+' }, webServer: undefined };\n')
def pins():
 return {str(p.relative_to(tree)):sha(p.read_bytes()) for p in tree.rglob('*') if p.is_file() and not p.is_symlink() and 'node_modules' not in p.parts and 'dist' not in p.parts}
before=pins();save('source-pins-before.json',before);save('freeze.json',{'exact_e2_git_commit':commit,'archive_sha256':sha(archive.read_bytes()),'candidate_manifest_sha256':sha(manifest.read_bytes()),'candidate_files':data['files'],'private_transport_adapter':str(cfg.relative_to(tree)),'source_file_count':len(before),'node_modules_source':str(repo/'prototype/node_modules'),'node_modules_package_lock_sha256':sha((tree/'prototype/package-lock.json').read_bytes()),'production_source_modified':False})
env=dict(os.environ);env['PATH']='/workspace/scratch/node-install/node-v22.23.3-linux-x64/bin:'+env['PATH'];env['PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH']='/usr/bin/chromium';env.pop('CI',None);env.pop('C6_NONSECURE_TEST_ORIGIN',None);env.pop('C6_LAN_BASE_URL',None)
executions=[];started=time.time()
def run(command,label):
 begin=time.time()
 with (proof/(label+'.log')).open('w') as log:
  process=subprocess.Popen(command,cwd=tree/'prototype',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  save(label+'-running.json',{'pid':process.pid,'process_group':process.pid,'command':command,'started_utc_epoch':begin})
  code=process.wait()
 result={'label':label,'command':command,'actual_exit_code':code,'seconds':time.time()-begin};executions.append(result);save('progress.json',executions);print(json.dumps(result),flush=True);return code
build=run(['npm','run','build'],'normal-build')
if build:
 save('execution-result.json',{'executions':executions,'source_unchanged':pins()==before,'actual_exit_code':build});raise SystemExit(build)
dist={str(p.relative_to(tree/'prototype/dist')):sha(p.read_bytes()) for p in (tree/'prototype/dist').rglob('*') if p.is_file()};save('dist-pins.json',dist)
preview_log=(proof/'preview.log').open('w');preview=subprocess.Popen(['node','node_modules/vite/bin/vite.js','preview','--host','127.0.0.1','--port','5204','--strictPort'],cwd=tree/'prototype',env=env,stdout=preview_log,stderr=subprocess.STDOUT,start_new_session=True);save('owned-preview.json',{'pid':preview.pid,'process_group':preview.pid,'base_url':base})
def http_pins():
 result={}
 for name,expected in dist.items():
  with urllib.request.urlopen(base+'/'+urllib.parse.quote(name),timeout=10) as response:
   blob=response.read();assert response.status==200;result[name]={'status':response.status,'sha256':sha(blob)};assert result[name]['sha256']==expected
 return result
final_code=1
try:
 deadline=time.monotonic()+30
 while True:
  if preview.poll() is not None:raise RuntimeError('Owned preview exited before ready')
  try:
   with urllib.request.urlopen(base,timeout=1) as response:assert response.status==200;response.read()
   break
  except Exception:
   if time.monotonic()>deadline:raise RuntimeError('Original 30-second webServer readiness budget exceeded')
   time.sleep(.1)
 http_before=http_pins();save('http-pins-before.json',http_before)
 jobs=[('desktop','labels-c1.spec.ts','^built-in templates can be duplicated, edited, archived and restored without deletion$','labels-desktop',1),('phone','labels-c1.spec.ts','^built-in templates can be duplicated, edited, archived and restored without deletion$','labels-phone',1),('phone','c8-layout-proof.spec.ts','^C8 every page keeps rows inside their cards and retains glyph/control guards fa 900px$','c8-fa900-phone',1)]
 save('execution-start.json',{'base_git_commit':commit,'candidate_manifest':str(manifest),'candidate_manifest_sha256':sha(manifest.read_bytes()),'jobs':jobs,'workers':1,'retries':0,'production_files_unchanged':True,'original_test_bodies_except_recorded_observation_barriers':True,'original_timeouts_assertions_and_skip_annotations_preserved':True,'expected_tests':3,'served_dist_assets':len(dist)})
 for project,testfile,grep,label,count in jobs:
  env['PLAYWRIGHT_JSON_OUTPUT_NAME']=str(proof/(label+'-playwright.json'))
  command=['node','node_modules/@playwright/test/cli.js','test',testfile,'--config',str(cfg),'--workers=1','--retries=0','--project='+project,'--grep',grep,'--reporter=line,json','--output',str(proof/(label+'-output'))]
  run(command,'native-'+label)
 http_after=http_pins();save('http-pins-after.json',http_after);after=pins();save('source-pins-after.json',after)
 summary=[]
 for project,testfile,grep,label,count in jobs:
  report=json.loads((proof/(label+'-playwright.json')).read_text());summary.append({'label':label,'stats':report['stats'],'global_errors':report.get('errors',[])})
 final_code=0 if all(row['actual_exit_code']==0 for row in executions) and before==after and http_before==http_after and all(row['stats']['expected']==1 and row['stats']['unexpected']==0 and row['stats']['flaky']==0 and row['stats']['skipped']==0 and not row['global_errors'] for row in summary) else 1
 result={'executions':executions,'seconds':time.time()-started,'source_unchanged':before==after,'http_matches_dist_before':True,'http_unchanged':http_before==http_after,'dist_assets':len(dist),'expected_tests':3,'summaries':summary,'actual_exit_code':final_code};save('execution-result.json',result);print(json.dumps(result),flush=True)
finally:
 if preview.poll() is None:os.killpg(preview.pid,signal.SIGTERM);preview.wait(timeout=10)
 preview_log.close()
raise SystemExit(final_code)
